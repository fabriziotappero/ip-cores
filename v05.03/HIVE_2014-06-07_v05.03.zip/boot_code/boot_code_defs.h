`include "reg_set_addr.h"
`include "op_encode.h"

localparam IM_W = 6;

// defines that make programming code more human readable
`define __			4'h0
`define s0			4'h0
`define s1			4'h1
`define s2			4'h2
`define s3			4'h3
`define s4			4'h4
`define s5			4'h5
`define s6			4'h6
`define s7			4'h7
`define P0			4'h8
`define P1			4'h9
`define P2			4'ha
`define P3			4'hb
`define P4			4'hc
`define P5			4'hd
`define P6			4'he
`define P7			4'hf
//
`define nop			op_nop[CODE_W-1:8]
`define pop			op_pop[CODE_W-1:8]
`define pcp			op_pcp[CODE_W-1:8]
`define lit_s		op_lit_s[CODE_W-1:8]
`define lit_h		op_lit_h[CODE_W-1:8]
`define lit_u		op_lit_u[CODE_W-1:8]
`define reg_ir		op_reg_ir[CODE_W-1:10]
`define reg_iw		op_reg_iw[CODE_W-1:10]
//
`define cpy			op_cpy[CODE_W-1:8]
`define isg			op_isg[CODE_W-1:8]
`define not			op_not[CODE_W-1:8]
`define flp			op_flp[CODE_W-1:8]
`define lzc			op_lzc[CODE_W-1:8]
`define bra			op_bra[CODE_W-1:8]
`define bro			op_bro[CODE_W-1:8]
`define brx			op_brx[CODE_W-1:8]
`define and			op_and[CODE_W-1:8]
`define orr			op_orr[CODE_W-1:8]
`define xor			op_xor[CODE_W-1:8]
//
`define add			op_add[CODE_W-1:8]
`define add_xs		op_add_xs[CODE_W-1:8]
`define add_xu		op_add_xu[CODE_W-1:8]
`define sub			op_sub[CODE_W-1:8]
`define sub_xs		op_sub_xs[CODE_W-1:8]
`define sub_xu		op_sub_xu[CODE_W-1:8]
`define mul			op_mul[CODE_W-1:8]
`define mul_xs		op_mul_xs[CODE_W-1:8]
`define mul_xu		op_mul_xu[CODE_W-1:8]
`define shl_s		op_shl_s[CODE_W-1:8]
`define shl_u		op_shl_u[CODE_W-1:8]
`define pow			op_pow[CODE_W-1:8]
//
`define jmp_z		op_jmp_z[CODE_W-1:8]
`define jmp_nz		op_jmp_nz[CODE_W-1:8]
`define jmp_lz		op_jmp_lz[CODE_W-1:8]
`define jmp_nlz	op_jmp_nlz[CODE_W-1:8]
`define jmp			op_jmp[CODE_W-1:8]
`define gto			op_gto[CODE_W-1:8]
`define rtn			op_rtn[CODE_W-1:8]
`define gsb			op_gsb[CODE_W-1:8]
//
`define mem_irs	op_mem_irs[CODE_W-1:12]
`define mem_irh	op_mem_irh[CODE_W-1:12]
`define mem_iw		op_mem_iw[CODE_W-1:12]
`define mem_iwh	op_mem_iwh[CODE_W-1:12]
//
`define jmp_ie		op_jmp_ie[CODE_W-1:12]
`define jmp_ine	op_jmp_ine[CODE_W-1:12]
`define jmp_ils	op_jmp_ils[CODE_W-1:12]
`define jmp_inls	op_jmp_inls[CODE_W-1:12]
`define jmp_ilu	op_jmp_ilu[CODE_W-1:12]
`define jmp_inlu	op_jmp_inlu[CODE_W-1:12]
//
`define jmp_iz		op_jmp_iz[CODE_W-1:10]
`define jmp_inz	op_jmp_inz[CODE_W-1:10]
`define jmp_ilz	op_jmp_ilz[CODE_W-1:10]
`define jmp_inlz	op_jmp_inlz[CODE_W-1:10]
//
`define dat_is		op_dat_is[CODE_W-1:10]
`define add_is		op_add_is[CODE_W-1:10]
`define shl_is		op_shl_is[CODE_W-1:10]
`define pus_i		op_pus_i[CODE_W-1:10]
//
`define VER			VER_ADDR[IM_W-1:0]
`define ERROR		ERROR_ADDR[IM_W-1:0]
`define TIME_ID	TIME_ID_ADDR[IM_W-1:0]
`define VECTOR		VECTOR_ADDR[IM_W-1:0]
`define IO			IO_ADDR[IM_W-1:0]
`define UART		UART_ADDR[IM_W-1:0]
