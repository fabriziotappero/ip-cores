/*
--------------------------------------------------------------------------------

Module : boot_code.h

--------------------------------------------------------------------------------

Function:
- Boot code for a processor core.

Instantiates:
- Nothing.

Notes:
- For testing (@ core.v):
  CLR_BASE		= 'h0;
  CLR_SPAN		= 2;  // gives 4 instructions
  ISR_BASE		= 'h20;  // 'd32
  ISR_SPAN		= 2;  // gives 4 instructions


--------------------------------------------------------------------------------
*/

	/*
	--------------------
	-- external stuff --
	--------------------
	*/
	`include "boot_code_defs.h"

	
	/*
	----------------------------------------
	-- initialize: fill with default data --
	----------------------------------------
	*/
	integer i;

	initial begin

/*	// fill with nop (some compilers need this)
	for ( i = 0; i < CAPACITY; i = i+1 ) begin
		ram[i] = { `nop, `__, `__ };
	end
*/

	/*
	---------------
	-- boot code --
	---------------
	*/


	// Thread 0 : enable interrupts
	// All threads : output thread ID @ interrupt

	///////////////
	// clr space //
	///////////////

	// thread 0 : enable interrupts & loop forever
	i='h0;   ram[i] = { `lit_u,            `__, `s3 };  // s3='h0100
	i=i+1;   ram[i] =                      16'h0100  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3
	i=i+1;   ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	// all others : loop forever
	i='h04;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h08;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h0c;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h10;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h14;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h18;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever
	i='h1c;  ram[i] = { `jmp_ie,    -4'd1, `s0, `s0 };  // loop forever

	////////////////
	// isr space //
	////////////////

	// all threads : read and output thread ID
	i='h20;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h24;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h28;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h2c;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h30;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h34;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h38;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0
	//
	i='h3c;  ram[i] = { `lit_u,            `__, `s3 };  // s3='h0110
	i=i+1;   ram[i] =                      16'h0110  ;  // 
	i=i+1;   ram[i] = { `gsb,              `P3, `s3 };  // gsb, pop s3 (addr)
	i=i+1;   ram[i] = { `rtn,              `P0, `__ };  // return, pop s0



	///////////////////////
	// code & data space //
	///////////////////////



	/////////////////
	// subroutines //
	/////////////////


	// sub : enable all ints, return to (s3)
	i='h100; ram[i] = { `lit_u,            `__, `s0 };  // s0='hFF00
	i=i+1;   ram[i] =                      16'hFF00  ;  // 
	i=i+1;   ram[i] = { `reg_iw,       `VECTOR, `P0 };  // reg(VECTOR)=s0, pop s0
	i=i+1;   ram[i] = { `gto,              `P3, `__ };  // return, pop s3

	// sub : read ID & write to GPIO, return to (s3)
	i='h110; ram[i] = { `reg_ir,      `TIME_ID, `s0 };  // s0=reg(TIME_ID)
	i=i+1;   ram[i] = { `shl_is,         6'd29, `P0 };  // s0<<=29
	i=i+1;   ram[i] = { `pus_i,         -6'd29, `P0 };  // s0>>=29
	i=i+1;   ram[i] = { `reg_iw,           `IO, `P0 };  // reg(IO)=s0, pop s0
	i=i+1;   ram[i] = { `gto,              `P3, `__ };  // return, pop s3


	end
