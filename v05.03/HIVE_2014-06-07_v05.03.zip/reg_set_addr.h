// `ifndef _reg_set_addr_h_
// `define _reg_set_addr_h_

// internal register addresses
localparam	integer	VER_ADDR			= 'h0;
localparam	integer	ERROR_ADDR		= 'h1;
localparam	integer	TIME_ID_ADDR	= 'h2;
localparam	integer	VECTOR_ADDR		= 'h3;
localparam	integer	UART_ADDR		= 'h4;
localparam	integer	IO_ADDR			= 'h5;

// `endif  // _reg_set_addr_h_