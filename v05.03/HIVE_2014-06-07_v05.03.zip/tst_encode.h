`ifndef _tst_encode_h_
`define _tst_encode_h_

//
`define z		2'h0
`define nz		2'h1
`define lz		2'h2
`define nlz		2'h3
//
`define e		4'h8
`define ne		4'h9
`define ls		4'ha
`define nls		4'hb
`define lu		4'hc
`define nlu		4'hd
//

`endif  // _tst_encode_h_