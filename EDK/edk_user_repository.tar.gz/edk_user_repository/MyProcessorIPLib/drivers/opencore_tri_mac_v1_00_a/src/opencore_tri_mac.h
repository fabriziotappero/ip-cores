//////////////////////////////////////////////////////////////////////////////
// Filename:          D:\edatools\edk_user_repository\MyProcessorIPLib/drivers/opencore_tri_mac_v1_00_a/src/opencore_tri_mac.h
// Version:           1.00.a
// Description:       opencore_tri_mac Driver Header File
// Date:              Sun Aug 03 07:07:35 2008 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////

#ifndef OPENCORE_TRI_MAC_H
#define OPENCORE_TRI_MAC_H

/***************************** Include Files *******************************/

#include "xbasic_types.h"
#include "xstatus.h"
#include "xio.h"

/************************** Constant Definitions ***************************/
#define FF_STATUS_CTRL_OFFSET 0x80*4
#define RX_MAC_RA_MASK          0x1
#define RX_MAC_RA               0x1
#define TX_MAC_WA_MASK          0x2
#define TX_MAC_WA               0x2
#define PKG_LGTH_FIFO_RA_MASK   0x4
#define PKG_LGTH_FIFO_RA        0x4


#define FF_PACKET_LGTH_OFFSET   0x81*4

#define TX_PACKET_CTRL_OFFSET   0x82*4
#define TX_SOP      0x8
#define TX_MID      0x0
#define TX_EOP_BE1  0x5
#define TX_EOP_BE2  0x6
#define TX_EOP_BE3  0x7
#define TX_EOP_BE4  0x4

#define RX_PACKET_CTRL_OFFSET   0x83*4

#define TX_PACKET_DATA_OFFSET   0x84*4

#define RX_PACKET_DATA_OFFSET   0x85*4

#define SPEED_OFFSET            34*4
#define MODE_1000M              0x4
#define MODE_100M               0x2
#define MODE_10M                0x1


/**************************** Type Definitions *****************************/


/***************** Macros (Inline Functions) Definitions *******************/

/**
 *
 * Write a value to a OPENCORE_TRI_MAC register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the OPENCORE_TRI_MAC device.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note
 * C-style signature:
 * 	void OPENCORE_TRI_MAC_mWriteReg(Xuint32 BaseAddress, unsigned RegOffset, Xuint32 Data)
 *
 */
#define OPENCORE_TRI_MAC_mWriteReg(BaseAddress, RegOffset, Data) \
 	XIo_Out32((BaseAddress) + (RegOffset), (Xuint32)(Data))

/**
 *
 * Read a value from a OPENCORE_TRI_MAC register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the OPENCORE_TRI_MAC device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note
 * C-style signature:
 * 	Xuint32 OPENCORE_TRI_MAC_mReadReg(Xuint32 BaseAddress, unsigned RegOffset)
 *
 */
#define OPENCORE_TRI_MAC_mReadReg(BaseAddress, RegOffset) \
 	XIo_In32((BaseAddress) + (RegOffset))


/**
 *
 * Write/Read 32 bit value to/from OPENCORE_TRI_MAC user logic memory (BRAM).
 *
 * @param   Address is the memory address of the OPENCORE_TRI_MAC device.
 * @param   Data is the value written to user logic memory.
 *
 * @return  The data from the user logic memory.
 *
 * @note
 * C-style signature:
 * 	void OPENCORE_TRI_MAC_mWriteMemory(Xuint32 Address, Xuint32 Data)
 * 	Xuint32 OPENCORE_TRI_MAC_mReadMemory(Xuint32 Address)
 *
 */
#define OPENCORE_TRI_MAC_mWriteMemory(Address, Data) \
 	XIo_Out32(Address, (Xuint32)(Data))
#define OPENCORE_TRI_MAC_mReadMemory(Address) \
 	XIo_In32(Address)

/************************** Function Prototypes ****************************/


/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the OPENCORE_TRI_MAC instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus OPENCORE_TRI_MAC_SelfTest(void * baseaddr_p);

XStatus OPENCORE_TRI_MAC_SendFrame(u32 BaseAddress, u8 *FramePtr, unsigned ByteCount);
u16 XEmacLite_RecvFrame(u32 BaseAddress, u8 *FramePtr);
XStatus OPENCORE_TRI_MAC_SetSpeed(u32 BaseAddress,u32 Speed);
XStatus OPENCORE_TRI_MAC_PrintReg(u32 BaseAddress);

#endif // OPENCORE_TRI_MAC_H
