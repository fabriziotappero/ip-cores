//////////////////////////////////////////////////////////////////////////////
// Filename:          D:\edatools\edk_user_repository\MyProcessorIPLib/drivers/opencore_tri_mac_v1_00_a/src/opencore_tri_mac.c
// Version:           1.00.a
// Description:       opencore_tri_mac Driver Source File
// Date:              Sun Aug 03 07:07:35 2008 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////


/***************************** Include Files *******************************/

#include "opencore_tri_mac.h"

/************************** Function Definitions ***************************/
XStatus OPENCORE_TRI_MAC_SendFrame(u32 BaseAddress, u8 *FramePtr, unsigned ByteCount)
{
    int i;
    int mid_counter;
    u32 *wordptr;
    /*
    if(OPENCORE_TRI_MAC_mReadReg(BaseAddress,FF_STATUS_CTRL_OFFSET)&TX_MAC_WA_MASK!=TX_MAC_WA)
        {
        print("opencore trimac tx fifo full!");
        return 0;
        }
        */    
    wordptr =(u32 *)FramePtr;  
    //start transmit firt 4 bytes with sop indicator
    OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_SOP);
 	OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_DATA_OFFSET, *wordptr);
    //get the mid repeat times
    if ((ByteCount&0x3)==0)
        mid_counter =(ByteCount>>2)-2;
    else
        mid_counter =(ByteCount>>2)-1;
    //output mid indicator
    OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_MID);        
    for (i=1;i<=mid_counter;i++)
        {
        OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_DATA_OFFSET,*(wordptr+i)); 
        }
	//output eop
    switch (ByteCount&0x3)
        {
        case 1   :OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_EOP_BE1); break;
        case 2   :OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_EOP_BE2); break;
        case 3   :OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_EOP_BE3); break;
        case 0   :OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_EOP_BE4); break;
        default  :OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_CTRL_OFFSET,TX_EOP_BE4);
        }
	OPENCORE_TRI_MAC_mWriteReg(BaseAddress,TX_PACKET_DATA_OFFSET,*(wordptr+mid_counter+1));        
        
}

u16 OPENCORE_TRI_MAC_RecvFrame(u32 BaseAddress, u8 *FramePtr)
{
    u16 frame_lgth;
    u32 *frameword;
    u16 read_steps;
	u16 i;
    
    frameword=(u32 *)FramePtr;
    //get the frame lgth;
    frame_lgth=OPENCORE_TRI_MAC_mReadReg(BaseAddress,FF_PACKET_LGTH_OFFSET);
    
    if ((frame_lgth&0x3)==0)
        read_steps =(frame_lgth>>2);
    else
        read_steps =(frame_lgth>>2)+1;
 
    for (i=0;i<read_steps;i++)
    	{
        *(frameword+i)=OPENCORE_TRI_MAC_mReadReg(BaseAddress,RX_PACKET_DATA_OFFSET);
    	}
    
    
    return frame_lgth;
    
}

XStatus OPENCORE_TRI_MAC_SetSpeed(u32 BaseAddress,u32 Speed)
{
    OPENCORE_TRI_MAC_mWriteReg(BaseAddress,SPEED_OFFSET,Speed);
}

XStatus OPENCORE_TRI_MAC_PrintReg(u32 BaseAddress)
{
    u32 i;
    for (i=0;i<=34;i++)
        xil_printf("Register Address-%02d:0x%08x\r\n",i,OPENCORE_TRI_MAC_mReadReg(BaseAddress,i*4));
}
