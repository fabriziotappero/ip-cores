
Springer Office 2007 - Word Style Sheet
=======================================

This archive contains the Office 2007 Word style sheet for the series
Lecture Notes in Computer Science.

The current version is named "sv-ln20100518.dotm".
If you double-click on it,  you have to allow the Word macro processing
for the current document to be able to use the builtin features.

The document "typeinst.doc" contains general and typing instructions;
it may be used as a template.

First usage of the style may be problematic caused by security measures:
In Word 2007/2010 macros are disabled by default unless the template
containing them is loaded from a so-called "trusted location". Usually
several trusted locations are created during the installation of Word
2007/2010 by default:

1. [drive]\Program Files\Microsoft Office\Templates
2. [drive]\Program Files\Microsoft Office\Office12\Startup
3. [drive]\Users\[User name]\AppData\Roaming\Microsoft\Templates

Please copy the template file "sv-ln20100518.dotm" to one of those folders
and load it from there. Now the LNCS macro ribbon should be both visible
and functional.

Alternatively you could set the macro security level in the "Trust Center"
to "Enable all macros" (see the detailed instructions at
http://office.microsoft.com/en-us/word-help/enable-or-disable-macros-in-off
ice-documents-HA010031071.aspx#BM17). For security reasons, this adjustment
should only be considered as a temporary setting.

