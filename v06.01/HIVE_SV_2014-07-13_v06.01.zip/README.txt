* Hive soft processor core readme file *

- All *.sv SystemVerilog files are in a single directory,
  where "hive_core.sv" is the top level entry.
- There are several boot code files in the "boot_code" directory,
  to use one, edit "dp_ram_dual.sv" to include it.
- There may also an "unused" directory containing files that aren't
  part of the project but may be of interest.
- There is a "hive_core.qpf" project file for Altera Quartus II9.1sp2 Web Edition.
  With this tool you can compile to a target, and with the file "hive_core.vwf" you 
  can simulate.  I recommend functional simulation when fiddling around
  because the compile is much faster.
- There is also a "hive_core.sdc" file which sets the target top speed to 
  200 MHz in Quartus, and "hive_core.qsf" which is a project settings file.
- Don't forget to assign pins when doing a real project!
