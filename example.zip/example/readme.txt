Need comment "`include "defines.v" string in generated ".sv" file.
