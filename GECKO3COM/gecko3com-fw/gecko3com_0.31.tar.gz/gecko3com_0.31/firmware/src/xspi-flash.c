/***********************************************************
*  Gecko3 SoC HW/SW Development Board
*   ___    ___   _   _
*  (  _`\ (  __)( ) ( )   
*  | (_) )| (   | |_| |   Berne University of Applied Sciences
*  |  _ <'|  _) |  _  |   School of Engineering and
*  | (_) )| |   | | | |   Information Technology
*  (____/'(_)   (_) (_)
*
*
*  Author:  Christoph Zimmermann
*  Date of creation: 17.09.2007
*  Description:
*	Headerfile for the xspi-flash Driveer 
*   Driver to access the SPI Flash supported by the
*	 spi-flash library
*
*  Changelog:
*   24.09.2007
*   first version
***********************************************************/

#include "xspi-flash.h"

volatile Xboolean spiFlashTransferInProgress;
volatile Xboolean spiFlashTransferError;

Xuint8 xspi_flash_sendBuf[262];

/****************************************************************************
/**
*
* Initializes a specific XSpi instance such that the driver is ready to use.
*
* The state of the device after initialization is:
*   - Device is disabled
*   - Slave mode
*   - Active high clock polarity
*   - Clock phase 0
*
* @param InstancePtr is a pointer to the XSpi instance to be worked on.
* @param Config is a reference to a structure containing information about
*        a specific SPI device. This function initializes an InstancePtr object
*        for a specific device specified by the contents of Config. This
*        function can initialize multiple instance objects with the use of
*        multiple calls giving different Config information on each call.
*
* @param EffectiveAddr is the device base address in the virtual memory address
*        space. The caller is responsible for keeping the address mapping
*        from EffectiveAddr to the device physical base address unchanged
*        once this function is invoked. Unexpected errors may occur if the
*        address mapping changes after this function is called. If address
*        translation is not used, use Config->BaseAddress for this parameters,
*        passing the physical address instead.
*
* @return
*
* The return value is XST_SUCCESS if successful.  On error, a code indicating
* the specific error is returned.  Possible error codes are:
* - XST_DEVICE_IS_STARTED if the device is started. It must be stopped to
*   re-initialize.
*
* @note
*
* None.
*
****************************************************************************/
XStatus XSpiFlashInitialize( XSpi *spiPtr, XSpi_flash *flashPtr, Xuint32 deviceID) { 

	XStatus status;
	Xuint8 status_int = 0;
	Xuint8 sendBuf[10], receiveBuf[10];
	
	ptrCheck(spiPtr);
	#ifdef DEBUG
		print("spiPtr ok, ");
	#endif
	ptrCheck(flashPtr);
	#ifdef DEBUG
		print("flashPtr ok\r\n");
	#endif
	
	flashPtr->spiPtr = spiPtr;
	
	flashPtr->chipSelectMask = 1 << deviceID;
	
	status = XSpi_SetSlaveSelect(spiPtr, flashPtr->chipSelectMask);
	#ifdef DEBUG
		print("select Flash, ");
	#endif
	STATUS_CHECK(status);
	
	sendBuf[0] = RDID;
	
	spiFlashTransferInProgress = XTRUE; 
	 
	status = XSpi_Transfer(spiPtr, sendBuf, receiveBuf, 4);
	#ifdef DEBUG
		print("send command, ");
	#endif
	STATUS_CHECK(status);
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif
	
	status = XSpi_SetSlaveSelect(spiPtr, SLAVE_DESELECT);
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("deselect failed");
		}
	#endif
	
	status_int = (Xuint8)SetType(&flashPtr->flash, &receiveBuf[1]);
	#ifdef DEBUG
		xil_printf("status_int = %d",status_int);
	#endif
	if(status_int == GOOD) {
		status = XST_SUCCESS;
	}
	else {
		status = XST_DEVICE_NOT_FOUND;
	}
	#ifdef DEBUG
		xil_printf("Received ID: 0x%X, 0x%X, 0x%X,0x%X\r\n",receiveBuf[1],receiveBuf[2],receiveBuf[3],receiveBuf[4]);
		xil_printf("maxAdress: 0x%X\r\n", flashPtr->flash.type.maxAdress);
	#endif
		
	return status;
}



XStatus XSpiFlashIsBusy(XSpi_flash *flashPtr) {
	XStatus status;
	Xuint8 buffer[5];
	
	ptrCheck(flashPtr);
	
	if(spiFlashTransferInProgress == XTRUE) {
		return XST_DEVICE_BUSY;
	}
	
	if(flashPtr->flash.isBusy == true) {
		//ask flash if still busy
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
		STATUS_CHECK(status);
		
		
		buffer[0]= RDSR;
		
		spiFlashTransferInProgress = XTRUE; 
	 
		status = XSpi_Transfer(flashPtr->spiPtr, buffer, buffer, 2);
		STATUS_CHECK(status);
		
		while(spiFlashTransferInProgress == XTRUE) {
		}
		#ifdef DEBUG
			if(spiFlashTransferError != XFALSE) {
				print("Transfer Error\r\n");
			}
		#endif
		
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
		STATUS_CHECK(status);
	
		if((buffer[1] & 1) == 1) {
			return XST_DEVICE_BUSY;
		}
		else {
			flashPtr->flash.isBusy == false;
		}
	}
	return XST_SUCCESS;
}


XStatus XSpiFlashRead(XSpi_flash *flashPtr, Xuint32 adress, Xuint8 *buffer, Xuint32 length, Xuint8 *readOffset) {
	
	XStatus status;
	Xuint8 i;
	Xuint8 firstSendOffset = 4;
	
	*readOffset = firstSendOffset;
	
	
	ptrCheck(flashPtr);
	#ifdef DEBUG
		print("flashPtr ok\r\n");
	#endif
	
	status = XSpiFlashIsBusy(flashPtr);
	//print("flashBusy? ");
	STATUS_CHECK(status);
	//print("no\r\n");
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
	//print("select\r\n");
	STATUS_CHECK(status);
	buffer[0]= READ;
	buffer[3]= (Xuint8)(adress & 0x000000FF);
	buffer[2]= (Xuint8)((adress & 0x0000FF00)>>8);
	buffer[1]= (Xuint8)((adress & 0x00FF0000)>>16); 
	
	#ifdef DEBUG
		xil_printf("readAdress = %X %X %X\r\n",buffer[1], buffer[2], buffer[3]);
	#endif
	
	spiFlashTransferInProgress = XTRUE;
	
	status = XSpi_Transfer(flashPtr->spiPtr, buffer, buffer, length+firstSendOffset);
	STATUS_CHECK(status);
	#ifdef DEBUG
		xil_printf("read %d bytes, status = %d\r\n", length, status);
	#endif
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif	
	
	return XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
}
	
	



XStatus XSpiFlashTransferFinished() {
	if(spiFlashTransferInProgress == XTRUE) {
		return XTRUE;
	}
	return XFALSE;
}



XStatus XSpiFlashEraseBulk(XSpi_flash *flashPtr) {
		
	XStatus status;
	Xuint8 sendBuf[4];
	
	ptrCheck(flashPtr);
	
	status = XSpiFlashIsBusy(flashPtr);
	STATUS_CHECK(status);
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
	STATUS_CHECK(status);
	
	sendBuf[0]= WREN;
	
	spiFlashTransferInProgress = XTRUE; 
 
	status = XSpi_Transfer(flashPtr->spiPtr, sendBuf, sendBuf, 1);
	STATUS_CHECK(status);
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
	STATUS_CHECK(status);
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
	STATUS_CHECK(status);
	
	sendBuf[0]= BE;
	spiFlashTransferInProgress = XTRUE;
	status = XSpi_Transfer(flashPtr->spiPtr, sendBuf, NULL, 1);
	STATUS_CHECK(status);
	
	flashPtr->flash.isBusy = true;
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif
	
	return XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
}


XStatus XSpiFlashErase(XSpi_flash *flashPtr, Xuint32 adress) {
		
	XStatus status;
	Xuint8 sendBuf[5];	
	
	ptrCheck(flashPtr);
	
	status = XSpiFlashIsBusy(flashPtr);
	STATUS_CHECK(status);
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
	sendBuf[0]= WREN;
	
	spiFlashTransferInProgress = XTRUE; 
 
	status = XSpi_Transfer(flashPtr->spiPtr, sendBuf, sendBuf, 1);
	STATUS_CHECK(status);
	
	flashPtr->flash.isBusy = true;
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
	
	status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
	
	sendBuf[0]= SE;
	sendBuf[3]= (Xuint8)(adress & 0x000000FF);
	sendBuf[2]= (Xuint8)((adress & 0x0000FF00)>>8);
	sendBuf[1]= (Xuint8)((adress & 0x00FF0000)>>16);
	
	spiFlashTransferInProgress = XTRUE;
	
	status = XSpi_Transfer(flashPtr->spiPtr, sendBuf, NULL, 4);
	STATUS_CHECK(status);
	
	while(spiFlashTransferInProgress == XTRUE) {
	}
	#ifdef DEBUG
		if(spiFlashTransferError != XFALSE) {
			print("Transfer Error\r\n");
		}
	#endif
	
	return XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
}

XStatus XSpiFlashWrite(XSpi_flash *flashPtr, Xuint32 adress, Xuint8 *buffer, Xuint32 length) {
	XStatus status;
	Xuint32 i, bufferPos = 0, transferedBytes=0,writeableBytes=0;
	Xuint8 firstSendOffset = 4;
	
	ptrCheck(flashPtr);
	#ifdef DEBUG
		print("flashPtr ok\r\n");
	#endif
	
	status = XSpiFlashIsBusy(flashPtr);
	STATUS_CHECK(status);
	
	
	while(length > 0) {
	
		writeableBytes = pageEnd(adress) - adress + 1;
		//xil_printf("writeableBytes = %d\r\n",writeableBytes);
	
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
		STATUS_CHECK(status);
		xspi_flash_sendBuf[0]= WREN;
		
		spiFlashTransferInProgress = XTRUE; 
	 
		status = XSpi_Transfer(flashPtr->spiPtr, xspi_flash_sendBuf, xspi_flash_sendBuf, 1);
		STATUS_CHECK(status);
		
		while(spiFlashTransferInProgress == XTRUE) {
		}
		#ifdef DEBUG
			if(spiFlashTransferError != XFALSE) {
				print("Transfer Error\r\n");
			}
		print("write enable send");	
		#endif
		
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
		STATUS_CHECK(status);
	
		xspi_flash_sendBuf[0]= PP;
		xspi_flash_sendBuf[3]= (Xuint8)(adress & 0x000000FF);
		xspi_flash_sendBuf[2]= (Xuint8)((adress & 0x0000FF00)>>8);
		xspi_flash_sendBuf[1]= (Xuint8)((adress & 0x00FF0000)>>16);
		
		#ifdef DEBUG
			xil_printf("writeadress: %x %x %x\r\n", xspi_flash_sendBuf[1], xspi_flash_sendBuf[2], xspi_flash_sendBuf[3]);
		#endif
		
		spiFlashTransferInProgress = XTRUE; 
	
		if(length > writeableBytes) {
			transferedBytes = writeableBytes+firstSendOffset;
			length -= writeableBytes;
			adress += writeableBytes;
		}
		else {
			transferedBytes = length+firstSendOffset;
			length = 0;
		}
		
		for(i=firstSendOffset;i<transferedBytes;i++) {
			xspi_flash_sendBuf[i] = buffer[bufferPos++];
			#ifdef DEBUG
				xil_printf("i = %d, bufferPos = %d, data = %d\r\n", i, bufferPos-1, xspi_flash_sendBuf[i]);
			#endif
		}		
		
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, flashPtr->chipSelectMask);
		STATUS_CHECK(status);
		
		status = XSpi_Transfer(flashPtr->spiPtr, xspi_flash_sendBuf, NULL, transferedBytes);
		#ifdef DEBUG
			xil_printf("write %d bytes\r\n", transferedBytes);
		#endif
		STATUS_CHECK(status);
		
		while(spiFlashTransferInProgress == XTRUE) {
		}
		#ifdef DEBUG
			if(spiFlashTransferError != XFALSE) {
				print("Transfer Error\r\n");
			}
		#endif
		
		flashPtr->flash.isBusy = true;
		status = XSpi_SetSlaveSelect(flashPtr->spiPtr, SLAVE_DESELECT);
		STATUS_CHECK(status);
		while(XSpiFlashIsBusy(flashPtr) == XST_DEVICE_BUSY) {
			#ifdef DEBUG
				print("is busy\r\n");
			#endif	
		}
	}
	
	return XST_SUCCESS;

}
