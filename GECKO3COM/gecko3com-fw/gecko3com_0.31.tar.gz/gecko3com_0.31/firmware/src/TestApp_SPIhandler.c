#include "TestApp_SPIhandler.h"

volatile Xboolean spiTransferInProgress;
volatile Xuint8 error;

void SpiHandler(void *callBackRef, Xuint32 statusEvent, unsigned int byteCount)
{
    /* Indicate the transfer on the SPI bus is no longer in progress
     * regardless of the status event
     */
    spiTransferInProgress = XFALSE;
	 //xil_printf("Interrupt occoured, statusEvent = %d", statusEvent);

    /* If the event was not transfer done, then track it as an error */

    if (statusEvent != XST_SPI_TRANSFER_DONE)
    {
        error++;
    }
	 
	 XSpiFlashHandler(statusEvent, byteCount);
}
