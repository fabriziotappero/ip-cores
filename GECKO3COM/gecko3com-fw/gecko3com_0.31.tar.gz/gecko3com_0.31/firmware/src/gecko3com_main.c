/* GECKO3COM
 *
 * Copyright (C) 2008 by
 *   ___    ____  _   _
 *  (  _`\ (  __)( ) ( )   
 *  | (_) )| (_  | |_| |   Bern University of Applied Sciences
 *  |  _ <'|  _) |  _  |   School of Engineering and
 *  | (_) )| |   | | | |   Information Technology
 *  (____/'(_)   (_) (_)
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*********************************************************************/
/** \file     gecko3com_main.c
 *********************************************************************
 * \brief     main file for the GECKO3COM project
 *
 * \author    Christoph Zimmermann bfh.ch
 * \date      2009-1-22
 *
*/

/** enable DFU class support */
#define USB_DFU_SUPPORT

#include <string.h>
#include <stdint.h>

#include "fx2utils.h"
#include "timer.h"
//#include "spi.h"
#include "i2c.h"
#include "isr.h"
#include "eeprom_io.h"
#include "delay.h"

#include "gecko3com_i2c.h"
#include "gecko3com_common.h"
#include "gecko3com_commands.h"
#include "fpga_load.h"
//#include "gecko3com_gpif_inline.h"

#include "usb_common.h"
#include "usb_requests.h"
#include "usb_descriptors.h"
#include "usb_dfu.h"
#include "usb_tmc.h"
#include "scpi_parser.h"

#include "firmware_version.h"
#include "debugprint.h"
#ifdef DEBUG_LEVEL_ERROR
#include "ser.h"
#endif

/* -------------------------------------------------------------------- */

#define WATCHDOG_TIME           100 /**< time untill the watchdog times out, 100 equals 1 second */

/* Global variables */
volatile uint8_t watchdog_count = WATCHDOG_TIME;

static void
get_ep0_data (void)
{
  EP0BCL = 0;			/* arm EP0 for OUT xfer.  This sets the busy bit */

  while (EP0CS & bmEPBUSY)	/* wait for busy to clear */
    ;
}

/*
 * enable debug output through the serial uart
 */
#ifdef DEBUG_LEVEL_ERROR

/** simple wraper to provide putchar function over serial line */
void
putchar (char p)
{
  ser_putc((unsigned char) p);
}

/** simple wraper to provide getchar function over serial line */
char
getchar (void)
{
  return (char) ser_getc();
}
#endif



#ifdef USB_DFU_SUPPORT
uint8_t app_firmware_write (void)
{
  static xdata uint16_t eeprom_offset;

  get_ep0_data();
  
  if(usb_dfu_state == DFU_STATE_dfuIDLE){
    eeprom_offset = 0;
  }

  if(!eeprom_write(I2C_ADDR_BOOT, eeprom_offset, EP0BUF, wLengthL)){
    print_err("eeprom_write failed\n");
    usb_dfu_status = DFU_STATUS_errWRITE;
    return 0;
  }
  eeprom_offset += wLengthL;
  return 1;
}
#endif

/** 
 * function to configure an fpga with data from usb 
 */
uint8_t app_configure_fpga()
{
  uint16_t byte_count;
  xdata Fpga_Info fpga_file_header;
  static xdata int32_t file_size;
  static xdata int8_t continue_analyse;
  uint8_t offset;

  xdata char fpga_type[FPGA_TYPE_LEN];

  byte_count = (EP2BCH << 8) + EP2BCL;	/* read byte counter from EP2OUT */

  if(usb_tmc_transfer.new_transfer == NEWTRANSFER) {

    /* check if this is the start of the fpga configuration */
    if(usb_tmc_transfer.nbytes_rxd == 0) {
      /* first part of configuration. setup all stuff */
      continue_analyse = 0;

      if(byte_count < usb_tmc_transfer.transfer_size) {
	/* normaly the first transfer is longer than one packet */
	usb_tmc_transfer.nbytes_rxd = byte_count - USB_TMC_HEADER_SIZE;
	
	/* 10 is the length of the command "fpga:conf " */
	byte_count = byte_count - USB_TMC_HEADER_SIZE - 10;
      }
      else {
	usb_tmc_transfer.nbytes_rxd = usb_tmc_transfer.transfer_size;
	byte_count = usb_tmc_transfer.transfer_size;
      }
      
      /* offset for the first transfer is always after the header and the command */
      offset = USB_TMC_HEADER_SIZE + 10;

      /* remove length of command "fpga:conf " from transfer_size */
      usb_tmc_transfer.transfer_size -= 10;

    }
    else {
      /* configuration in progress. new transfer, so we have to remove the tmc header */
      offset = USB_TMC_HEADER_SIZE;
      byte_count -= USB_TMC_HEADER_SIZE;
      usb_tmc_transfer.nbytes_rxd += byte_count;
    }
  }
  
  /* continue with pending transfer */
  else {
    offset = 0;

    if(byte_count < usb_tmc_transfer.transfer_size) {
      usb_tmc_transfer.nbytes_rxd += byte_count;
    }
    else {
      /* last packet of tmc transfer. use the smaller number */
      usb_tmc_transfer.nbytes_rxd += usb_tmc_transfer.transfer_size;
      byte_count = (uint16_t)usb_tmc_transfer.transfer_size;
    }
  }

  /* finished set up all pointers, offsets and this stuff */


  /* -------------------------------------------------------------------- */
  /* analyse bit file */
  if(continue_analyse <= 0) {
    if(continue_analyse == 0) {
      fpga_file_header.length = 0;
      fpga_file_header.left = 0;
      fpga_file_header.type = FPGA_TYPE;
    }
  
    /* first value to read from the header file is the fpga type */
    if(fpga_file_header.type == FPGA_TYPE){
      if(fpga_scan_file(EP2FIFOBUF+offset, byte_count, &fpga_file_header) \
	 == FPGA_INFO_COMPLETE) {
	
	/* compare fpga type from header with value in eeprom */
	if(!eeprom_read(I2C_ADDR_BOOT, FPGA_TYPE_OFFSET, fpga_type, FPGA_TYPE_LEN)){
	  return 0;
	}
	
	if(strncmp(fpga_file_header.info, fpga_type, FPGA_TYPE_LEN)) {
	  print_err("wrong FPGA type\n");
	  return 0;
	}
	
	/* next value to read from the header is the file length */
	fpga_file_header.type = FILE_LENGTH;
	fpga_file_header.length = 0;
	fpga_file_header.left = 0;

	continue_analyse = FPGA_INFO_COMPLETE;
      }
      else {
	continue_analyse = FPGA_INFO_NOT_COMPLETE;
      }
    }

    /* second value to read from the header file is the file length */
    if(fpga_file_header.type == FILE_LENGTH){
      if(fpga_scan_file(EP2FIFOBUF+offset, byte_count, &fpga_file_header) \
	 == FPGA_INFO_COMPLETE) {
	
	((uint8_t*)&file_size)[0] = fpga_file_header.info[2];
	((uint8_t*)&file_size)[1] = fpga_file_header.info[1];
	((uint8_t*)&file_size)[2] = fpga_file_header.info[0];
	((uint8_t*)&file_size)[3] = 0;
	
	/* intialize fpga for configuration */
	if(!fpga_load_begin()) {
	  print_err("initializing FPGA\n");
	  return 0;
	}
	continue_analyse = FPGA_INFO_COMPLETE;
      }
      else {
	continue_analyse = FPGA_INFO_NOT_COMPLETE;
      }
    }

    /* adjust the offset and byte_count variables to point to the 
     * binary data after the header */
    offset += fpga_file_header.position;
    byte_count -= fpga_file_header.position;
    usb_tmc_transfer.nbytes_rxd += fpga_file_header.position;
    usb_tmc_transfer.transfer_size -= fpga_file_header.position;
  }

  /* -------------------------------------------------------------------- */
  /* anything ready, transfer data to fpga */

  if(continue_analyse > 0) {
    /* transmitt config data to fpga */
    if(!fpga_load_xfer(EP2FIFOBUF+offset, byte_count)) {
      return 0;
    }
    
    usb_tmc_transfer.transfer_size -= byte_count; 
    file_size -= byte_count;

    
    /* transfer finished, finishing configuration */
    if(file_size <= 0) {
      if(!fpga_load_end()) {
	print_err("finalizing FPGA\n");
	return 0;
      }
      usb_tmc_state = TMC_STATE_IDLE;
    }
  }
  
  return 1;
}


/** 
 * \brief Handle the class commands on endpoint 0.
 * If we handle this one, return non-zero.
 */
unsigned char
app_class_cmd (void)
{
#ifdef USB_DFU_SUPPORT
  if (usb_dfu_request()){
    if(!usb_handle_dfu_packet()){
      print_err("dfu request\n");
      return 0;
    }
  }

  else
#endif 
  if (usb_tmc_request()){
    if(!usb_handle_tmc_packet()){
      print_err("tmc request\n");
      return 0;
    }
  }
  else {
    print_err("invalid class request\n");
    return 0; /* invalid class request */
  }
  
  return 1;
}

/** 
 * \brief Handle our "Vendor Extension" commands on endpoint 0.
 * If we handle this one, return non-zero.
 */
unsigned char
app_vendor_cmd (void)
{

  if (bRequestType == VRT_VENDOR_IN){
    /*********************************
     *    handle the IN requests
     ********************************/

    switch (bRequest){

    default:
      return 0;
    }
  }

  else if (bRequestType == VRT_VENDOR_OUT){
    /***********************************
     *    handle the OUT requests
     **********************************/

    switch (bRequest){

    case VRQ_SET_SERIAL:
      get_ep0_data();
      if(wLengthL > SERIAL_NO_LEN){
	return 0;
      }
      if(!eeprom_write(I2C_ADDR_BOOT, SERIAL_NO_OFFSET, EP0BUF, wLengthL)){
	return 0;
      }
      break;

    case VRQ_SET_HW_REV:
      get_ep0_data();
      if(!eeprom_write(I2C_ADDR_BOOT, HW_REV_OFFSET, EP0BUF, 1)){
	return 0;
      }
      break;

    case VRQ_SET_FPGA_TYPE:
      get_ep0_data();
      if(wLengthL > FPGA_TYPE_LEN){
	return 0;
      }
      if(!eeprom_write(I2C_ADDR_BOOT, FPGA_TYPE_OFFSET, EP0BUF, wLengthL)){
	return 0;
      }
      break;

    case VRQ_SET_FPGA_IDCODE:
      get_ep0_data();
      if(!eeprom_write(I2C_ADDR_BOOT, FPGA_IDCODE_OFFSET, EP0BUF, FPGA_IDCODE_LEN)){
	return 0;
      }
      break;

    default:
      return 0;

    }
  }
  else
    return 0;    /* invalid bRequestType */

  return 1;
}

/** 
 * \brief Read h/w rev code and serial number out of boot eeprom and
 * patch the usb descriptors with these values.
 */
void 
patch_usb_descriptors(void)
{
  static xdata uint8_t hw_rev;
  static xdata unsigned char serial_no[SERIAL_NO_LEN];
  unsigned char ch;
  uint8_t i;

  /* hardware revision */
  eeprom_read(I2C_ADDR_BOOT, HW_REV_OFFSET, &hw_rev, 1);	/* LSB of device id */
  usb_desc_hw_rev_binary_patch_location_0[0] = hw_rev;
  usb_desc_hw_rev_binary_patch_location_1[0] = hw_rev;

  /* serial number */
  eeprom_read(I2C_ADDR_BOOT, SERIAL_NO_OFFSET, serial_no, SERIAL_NO_LEN);

  for (i = 0; i < SERIAL_NO_LEN; i++){
    ch = serial_no[i];
    if (ch == 0xff)	/* make unprogrammed EEPROM default to '0' */
      ch = '0';
    usb_desc_serial_number_ascii[i << 1] = ch;
  }
}

/** 
 * we do all the work here. infinite loop
 */
static void
main_loop (void)
{
  tHeader *tmc_header, *tmc_response_header;
  static xdata uint32_t transfer_size;
  static xdata TMC_Response_Queue response_queue;
  xdata Scanner scpi_scanner;

  uint16_t index;


  scpi_scanner.action = NOACTION;

  //  setup_flowstate_common();

  while (1){
    usb_tmc_transfer.new_transfer = 0;

    /* SETUP Package on Endpoint 0. Handle if we received one */
    if (usb_setup_packet_avail())
      usb_handle_setup_packet();
      
    /* Let's do some work when an Endpoint has data */
    if (!(EP2468STAT & bmEP2EMPTY) && flLOCAL == GECKO3COM_LOCAL){ 

      /* -------------------------------------------------------------------- */
      if(usb_tmc_state == TMC_STATE_IDLE || usb_tmc_transfer.transfer_size == 0){

	/* start to analyze the data in EP2 if it is a correct TMC header */
	tmc_header = (tHeader*)EP2FIFOBUF;

	/* bTag sanity check. store bTag for correct IN response */
	if (tmc_header->bTag == ~tmc_header->bTagInverse) {
	  usb_tmc_transfer.bTag = tmc_header->bTag;

	  /* check if this is a OUT message */
	  if(tmc_header->MsgID == DEV_DEP_MSG_OUT){
	    usb_tmc_transfer.transfer_size = ((DEV_DEP_MSG_OUT_Header*)tmc_header->msg_specific)->TransferSize;
	    usb_tmc_transfer.new_transfer = NEWTRANSFER;
	    
	    /* if not IDLE, the transfer size was 0 and we continue 
	     * to exectue the action and don't try to parse a new command */
	    if(usb_tmc_state == TMC_STATE_IDLE) {
	      /* fresh OUT Transfer: handle device dependent command message */
	      usb_tmc_state = TMC_STATE_OUT_TRANSFER;
	      usb_tmc_transfer.nbytes_rxd = 0;
	      
	      /* when we receive an new out message before we sent the response, clear the queue */
	      IEEE488_clear_mav();
	      usb_tmc_transfer.nbytes_txd = 0;
	      response_queue.length = 0;

	      /* setup variables for scpi parser. point to first command byte in endpoint buffer */
	      scpi_scanner.source = (unsigned char*)(EP2FIFOBUF + USB_TMC_HEADER_SIZE);
	      scpi_scanner.action = NOACTION;
	    
	      /* start SCPI parser */
	      if(!scpi_scan(&scpi_scanner, &response_queue)){
		ieee488_status.EventStatusRegister |= bmCOMMAND_ERROR;
		usb_tmc_state = TMC_STATE_IDLE;
		scpi_scanner.action = NOACTION;
		usb_tmc_transfer.new_transfer = 0;
		print_err("syntax failure\n");
	      }
	    }
	  }

	  /* check if this is a IN request and we have a IN response queued */
	  else if(tmc_header->MsgID == REQUEST_DEV_DEP_MSG_IN && response_queue.length > 0) {

	    /* IN Transfer: handle response message to a device dependent command message */
	    usb_tmc_state = TMC_STATE_IN_TRANSFER;
	    usb_tmc_transfer.transfer_size = ((REQUEST_DEV_DEP_MSG_IN_Header*) tmc_header->msg_specific)->TransferSize;
	    usb_tmc_transfer.nbytes_txd = 0;

	  }
	  else {
	    EP2CS |= bmEPSTALL;  /* unknown message ID */
	    print_err("unknown message ID\n");
	  }
	}

	else {
	  EP2CS |= bmEPSTALL;   /* bTag and bTagInverse don't match */
	  print_err("bTag invalid\n");
	}
      }

      /* -------------------------------------------------------------------- */
      if(usb_tmc_state == TMC_STATE_OUT_TRANSFER){
	
	/* new data for a pending tmc transfer. continue to handle it */
	switch (scpi_scanner.action) {

	case SYSTEM_RESET:
	  gecko3com_system_reset();
	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case rqFPGA_IDCODE:
	  /* request to read the FPGA jtag id code */
	  eeprom_read(I2C_ADDR_BOOT, FPGA_IDCODE_OFFSET, \
		      response_queue.buf, FPGA_IDCODE_LEN);
	  response_queue.buf[FPGA_IDCODE_LEN] = '\n';
	  response_queue.length = FPGA_IDCODE_LEN+1;
	  IEEE488_set_mav();
	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case rqFPGA_TYPE:
	  /* request to read the FPGA type string */
	  eeprom_read(I2C_ADDR_BOOT, FPGA_TYPE_OFFSET, \
		      response_queue.buf, FPGA_TYPE_LEN);
	  response_queue.buf[FPGA_TYPE_LEN] = '\n';
	  response_queue.length = FPGA_TYPE_LEN+1;
	  IEEE488_set_mav();
	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case rqFPGA_DONE:
	  if(fpga_done()) {
	    response_queue.buf[0] = '1';
	  }
	  else {
	    response_queue.buf[0] = '0';
	  }
	  response_queue.buf[1] = '\n';
	  response_queue.length = 2;
	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case FPGA_CONFIGURE:
	  if(!app_configure_fpga()) {
	    ieee488_status.EventStatusRegister |= bmEXECUTION_ERROR;
	    usb_tmc_state = TMC_STATE_IDLE;
	  }
	  break;

	case rqSPI_FILE_LIST:
	  fpga_load_end();
	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case SPI_DELETE:
	  /* send the delete command for each block and loop through the main_loop */
	  /* check busy and set usb_tmc_state back to idle when finished file delete */

	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	case SPI_WRITE:

	  usb_tmc_state = TMC_STATE_IDLE;
	  break;

	default:

	  usb_tmc_state = TMC_STATE_IDLE;
	}
      }
      

      /* finished handling usb package. rearm OUT endpoint to receive new data */
      OUTPKTEND = bmSKIP | USB_TMC_EP_OUT;
    }

    /* -------------------------------------------------------------------- */
    /* Let's continue to send data when an Endpoint is free */
    if (!(EP2468STAT & bmEP6FULL) && usb_tmc_state == TMC_STATE_IN_TRANSFER){
      
      /* fresh IN transfer, send first header */
      if(usb_tmc_transfer.nbytes_txd == 0) {
	index = 0;
	tmc_response_header = (tHeader*)EP6FIFOBUF;
	tmc_response_header->MsgID = REQUEST_DEV_DEP_MSG_IN;
	tmc_response_header->bTag = usb_tmc_transfer.bTag;
	tmc_response_header->bTagInverse = ~usb_tmc_transfer.bTag;
	tmc_response_header->Reserved = 0;
	((DEV_DEP_MSG_IN_Header*)tmc_response_header->msg_specific)->TransferSize = response_queue.length;
	((DEV_DEP_MSG_IN_Header*)tmc_response_header->msg_specific)->Reserved[0] = 0;
	((DEV_DEP_MSG_IN_Header*)tmc_response_header->msg_specific)->Reserved[1] = 0;
	((DEV_DEP_MSG_IN_Header*)tmc_response_header->msg_specific)->Reserved[2] = 0;

	/* if we can send all data in one usb packet, set EOM (end of message) bit */
	if(USBCS & bmHSM && response_queue.length <= 500 | response_queue.length <= 56)
	  ((DEV_DEP_MSG_OUT_Header*)tmc_response_header->msg_specific)->bmTransferAttributes = bmTA_EOM;
	else
	  ((DEV_DEP_MSG_OUT_Header*)tmc_response_header->msg_specific)->bmTransferAttributes = 0;

	index = USB_TMC_HEADER_SIZE;
      } /* finished writing header */


      /* Transmit data */
      for(usb_tmc_transfer.nbytes_txd; \
	  usb_tmc_transfer.nbytes_txd <= response_queue.length; \
	  usb_tmc_transfer.nbytes_txd++){
	EP6FIFOBUF[index++] = response_queue.buf[usb_tmc_transfer.nbytes_txd];
	if(USBCS & bmHSM && response_queue.length == 512 | response_queue.length == 64)
	  break;
      }

      EP6BCH = index >> 8;
      EP6BCL = index & 0xFF;
      index = 0;

      /* detect end of transfer */
      if(usb_tmc_transfer.nbytes_txd >= response_queue.length){
	usb_tmc_state = TMC_STATE_IDLE;
	IEEE488_clear_mav();
	response_queue.length = 0;
      }     
    }

    if(flLED == LEDS_OFF) {
      set_led_ext(LEDS_OFF);
    }
    watchdog_count = WATCHDOG_TIME;
  } /* end of infinite main loop */
}


/** 
 * called at 100 Hz from timer2 interrupt
 *
 * Toggle led 0
 */
void
isr_tick (void) interrupt
{
  static uint8_t count = 1;      

  if (--count == 0){
    count = 50;
    toggle_led_0();
    flLED = LEDS_OFF;
  }

  //  if (--watchdog_count == 0){
  //    clear_timer_irq(); 
  //  #ifdef DEBUG_LEVEL_ERROR
    //  print_err("Watchdog timed out! System reset\n");
  //mdelay(100);             /* wait 100 ms to give the uart some time to transmit */
  //  #endif

      /* simulate CPU reset */  /* FIXME this stuff here does not work. no idea how to simulate an CPU reset instead... */
      /* _asm
      ljmp    __reset_vector
      _endasm;*/
  //}

#ifdef USB_DFU_SUPPORT
  if (usb_dfu_state == DFU_STATE_appDETACH){
    if (--usb_dfu_timeout == 0){
      usb_toggle_dfu_handlers();
    } 
  }
#endif

  clear_timer_irq();
}

//void
//isr_ep2test (void) interrupt
//{
//  print_info("EP2 ISR data\n");
//  clear_usb_irq();
//}


/** 
 * starting point of execution.
 * we initialize all system components here. after that we go to the main_loop function.
 * there all the work is done.
 */
void
main(void)
{
  init_gecko3com();
  init_io_ext();
  init_usb_tmc();
  //  init_gpif();
  //init_spi();

  /* set the context switch flag to local operation, not fpga */
  flLOCAL = GECKO3COM_LOCAL;

#ifdef DEBUG_LEVEL_ERROR
  ser_init();
  printf_tiny("Firmware: %s",FIRMWARE_VERSION);
#endif

  /* if (UC_START_WITH_GSTATE_OUTPUT_ENABLED) */
  IFCONFIG |= bmGSTATE;			/* no conflict, start with it on */

  EA = 0;		/* disable all interrupts */

  patch_usb_descriptors();
  setup_autovectors();
  usb_install_handlers();
  hook_timer_tick((unsigned short) isr_tick);

  //hook_uv(UV_EP2, (unsigned short) isr_ep2test);
  //EPIE |= 0x10;

  EIEX4 = 1;		/* disable INT4 FIXME */
  EA = 1;		/* global interrupt enable */  

  if(get_switch()){
    set_led_ext(GREEN);
  }
  else {
    set_led_ext(RED);
  }

#ifdef HOST_FW_LOAD
  fx2_renumerate();	/* simulates disconnect / reconnect */
#endif

  main_loop();
}
