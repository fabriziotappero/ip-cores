/*
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A 
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR 
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION 
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE 
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO 
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO 
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE 
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 */

/*
 * Xilinx EDK 8.2.02 EDK_Im_Sp2.4
 *
 * This file is a sample test application
 *
 * This application is intended to test and/or illustrate some 
 * functionality of your system.  The contents of this file may
 * vary depending on the IP in your system and may use existing
 * IP driver functions.  These drivers will be generated in your
 * XPS project when you run the "Generate Libraries" menu item
 * in XPS.
 *
 * Your XPS project directory is at:
 *    /work/GECKO3main-basesystem/
 */


// Located in: microblaze_0/include/xparameters.h
#include "xparameters.h"
#include "stdio.h"
#include "xutil.h"
#include "xbasic_types.h"
#include "xstatus.h"

#include "xspi.h"
#include "xintc.h"

#include "TestApp_SPIhandler.h"
#include "xspi-flash.h"

#define INTC_DEVICE_ID XPAR_OPB_INTC_0_DEVICE_ID
#define SPI_DEVICE_ID XPAR_GENERIC_SPI_DEVICE_ID
#define SPI_INTERRUPT_POINTER XPAR_OPB_INTC_0_GENERIC_SPI_IP2INTC_IRPT_INTR
#define SPIFLASH 0


//#define DEBUG 1


Xuint8 sendBuffer[350], receiveBuffer[350];

/***************** Macros (Inline Functions) Definitions *********************/

/*****************************************************************************
*
* MACRO:
*
* STATUS_CHECK
*
* DESCRIPTION:
*
* This macro checks the status for functions called. It performs a return
* if the status was not success.  The purpose of this macro is to allow
* centralized status checking.
*
* ARGUMENTS:
*
* Status contains any status from a Xilinx driver.
*
* RETURN VALUE:
*
* None.
*
* NOTES:
*
* Signature: void STATUS_CHECK(XStatus Status)
*
******************************************************************************/
#define STATUS_CHECK(status)            \
    {                                   \
        if (status != XST_SUCCESS)      \
        {                               \
            return status;              \
        }                               \
    }



/****************************************************************************
*
* FUNCTION:
*
* SetupInterruptSystem
*
* DESCRIPTION:
*
* This function setups the interrupt system such that interrupts can occur
* for the SPI driver.  This function is application specific since the actual
* system may or may not have an interrupt controller.  The SPI device could
* be directly connected to a processor without an interrupt controller.  The
* user should modify this function to fit the application.
*
* ARGUMENTS:
*
* SpiPtr contains a pointer to the instance of the XSpi component
* which is going to be connected to the interrupt controller.
*
* RETURN VALUE:
*
* XST_SUCCESS if successful, otherwise XST_FAILURE.
*
* NOTES:
*
*
****************************************************************************/
static XStatus SetupInterruptSystem(XSpi *spiPtr, XIntc *intcPtr)
{
    XStatus status;
	 XIntc interruptController;


    /* Initialize the interrupt controller driver so that
     * it's ready to use, specify the device ID that is generated in
     * xparameters.h
     */
    status = XIntc_Initialize(intcPtr, INTC_DEVICE_ID);
	 if(status == XST_DEVICE_IS_STARTED) {
		XIntc_Stop(intcPtr);
		status = XIntc_Initialize(intcPtr, INTC_DEVICE_ID);
	 }
	 //print("ini\r\n");

    /* Connect a device driver handler that will be called when an interrupt
     * for the device occurs, the device driver handler performs the specific
     * interrupt processing for the device
     */
    status = XIntc_Connect(intcPtr, 
                            SPI_INTERRUPT_POINTER,
                           (XInterruptHandler)XSpi_InterruptHandler,
                           (void *)spiPtr);
	 STATUS_CHECK(status)
	 //print("con\r\n");
    /* Start the interrupt controller such that interrupts are enabled for
     * all devices that cause interrupts, specific real mode so that
     * the SPI can cause interrupts thru the interrupt controller.
     */
    status = XIntc_Start(intcPtr, XIN_REAL_MODE);
	 STATUS_CHECK(status)
	 //print("start\r\n");

    /* Enable the interrupt for the timer counter */

    XIntc_Enable(intcPtr, SPI_INTERRUPT_POINTER);
	 //print("en\r\n");
	 
	 /*
     * Enable the Interrupts for the MicroBlaze Processor
     */
    microblaze_enable_interrupts();


    return XST_SUCCESS;
}

//====================================================

int main (void) {

	XStatus status;
	XIntc interruptController;
	XSpi spiMaster;
	XSpi_flash spiFlash;
	
	Xuint32 i,j;
	
	Xuint8 offset;

	/*
    * Enable and initialize cache
    */
	#if XPAR_MICROBLAZE_0_USE_ICACHE
		microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
		microblaze_enable_icache();
	#endif

	#if XPAR_MICROBLAZE_0_USE_DCACHE
		microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
		microblaze_enable_dcache();
	#endif

	print("-- Entering main() --\r\n");
	print("Initialize SPI Core ");

	status = XSpi_Initialize(&spiMaster, SPI_DEVICE_ID);
	XSpi_Reset(&spiMaster);
	if(status == XST_DEVICE_IS_STARTED) {
		status = XSpi_Stop(&spiMaster);
	}
	
	if (status == XST_SUCCESS) {
		print("...sucessfully initialized\r\n");
	}
	else {
		print("...failed!\r\n");
		return 1;
	}
		
	print("starting spi self test ");
	status = XSpi_SelfTest(&spiMaster);
	if (status == XST_SUCCESS) {
		print(" ...sucessfull\r\n");
	}
	else{
		print(" ...failed!\r\n");
	}

	status = XSpi_SetOptions(&spiMaster, XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION);
	 
	status = SetupInterruptSystem(&spiMaster, &interruptController);
	print("setup interrupt system ");
	if (status != XST_SUCCESS) {
		print("...failed\r\n");
		return 1;
	}
	else {
		print("...sucessfull\r\n");
	}
	
	XSpi_SetStatusHandler(&spiMaster, &spiMaster, (XSpi_StatusHandler)SpiHandler);
	 
	//print("spi start\r\n");
	status = XSpi_Start(&spiMaster);
	 
	status = XSpiFlashInitialize(&spiMaster, &spiFlash, SPIFLASH);
	if (status != XST_SUCCESS) {
		print("setup spi flash failed\r\n");
	}
	else {
		print("SPI Flash sucessfull initialized\r\n");
		xil_printf("Memory Capacity: %d kBytes\r\n", spiFlash.flash.type.capacity >> 10);
	}
	
	status = XSpiFlashIsBusy(&spiFlash);
	#ifdef DEBUG
		xil_printf("busy status: %d\r\n",status);
	#endif
	
	print("start flash erase ");
	status = XSpiFlashEraseBulk(&spiFlash);
	if (status != XST_SUCCESS) {
		print("...failed\r\n");
	}
	else {
		print("...sucessfull\r\n");
	}

	status = XSpiFlashIsBusy(&spiFlash);
	#ifdef DEBUG
		xil_printf("busy status: %d\r\n",status);
	#endif
	while(status == XST_DEVICE_BUSY) {
		status = XSpiFlashIsBusy(&spiFlash);
	}
	
	print("SPI Flash sucessfully erased\r\n");
	
	print("\r\n *** starting first Pattern Test ***\r\n");
	
	for(i=0;i<256;i++) {
		sendBuffer[i] = 0x55;
	}
		
	for(i=0;i<spiFlash.flash.type.maxAdress;i+=256) {
	
		//xil_printf("i = 0x%X\r\n",i);
		
		status = XSpiFlashWrite(&spiFlash, i, sendBuffer, 256);
		if (status != XST_SUCCESS) {
			print("write failed\r\n");
		}
		
		status = XSpiFlashRead(&spiFlash, i, receiveBuffer, 256, &offset);
		if (status != XST_SUCCESS) {
			print("reading failed\r\n");
		}
		
		for(j=offset;j<256;j++) {
			if(sendBuffer[j] != receiveBuffer[offset+j]) {
				xil_printf("ERROR at adress 0x%X: send data = 0x%X  received data = 0x%X\r\n",(i+j-offset),sendBuffer[j], receiveBuffer[offset+i]);
			}
		}
	}
		
		
	status = XSpiFlashIsBusy(&spiFlash);
	#ifdef DEBUG
		xil_printf("busy status: %d\r\n",status);
	#endif
	
	print("start flash erase ");
	status = XSpiFlashEraseBulk(&spiFlash);
	if (status != XST_SUCCESS) {
		print("...failed\r\n");
	}
	else {
		print("...sucessfull\r\n");
	}

	status = XSpiFlashIsBusy(&spiFlash);
	#ifdef DEBUG
		xil_printf("busy status: %d\r\n",status);
	#endif
	while(status == XST_DEVICE_BUSY) {
		status = XSpiFlashIsBusy(&spiFlash);
	}
	
	print("SPI Flash sucessfully erased\r\n");
	
	print("\r\n *** starting second Pattern Test ***\r\n");
	
	for(i=0;i<256;i++) {
		sendBuffer[i] = 0xAA;
	}
	
	for(i=0;i<spiFlash.flash.type.maxAdress;i+=256) {
		
		status = XSpiFlashWrite(&spiFlash, i, sendBuffer, 256);
		if (status != XST_SUCCESS) {
			print("write failed\r\n");
		}
		
		
		status = XSpiFlashRead(&spiFlash, i, receiveBuffer, 256, &offset);
		if (status != XST_SUCCESS) {
			print("reading failed\r\n");
		}
		
		for(j=offset;j<256;j++) {
			if(sendBuffer[j] != receiveBuffer[offset+j]) {
				xil_printf("ERROR at adress %X: send data = %X  received data = %X\r\n",(i+j-offset),sendBuffer[j], receiveBuffer[offset+i]);
			}
		}
	}
 
	
	
   /*
    * Disable cache and reinitialize it so that other
    * applications can be run with no problems
    */
   #if XPAR_MICROBLAZE_0_USE_DCACHE
      microblaze_disable_dcache();
      microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
   #endif

   #if XPAR_MICROBLAZE_0_USE_ICACHE
      microblaze_disable_icache();
      microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
   #endif


   print("-- Exiting main() --\r\n");
   return 0;
}

