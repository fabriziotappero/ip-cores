/* GECKO3COM
 *
 * Copyright (C) 2008 by
 *   ___    ___   _   _
 *  (  _`\ (  __)( ) ( )   
 *  | (_) )| (   | |_| |   Berne University of Applied Sciences
 *  |  _ <'|  _) |  _  |   School of Engineering and
 *  | (_) )| |   | | | |   Information Technology
 *  (____/'(_)   (_) (_)
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Author:  Christoph Zimmermann
 *  Date of creation: 17.09.2007
 *  Description:
 *	C code for the spi-flash Library 
 *   Library to access the SPI Flash devices from ST 
 *	Microelectronics or Spansion. 
 *	Supported densities:
 *		8, 16, 32 Mbit
 *
 *  Changelog:
 *   17.09.2007
 *   first version
 *		based on the m25p16.h header file
 **********************************************************/

#include "spi-flash.h"

int_fast8_t SetType(SPI_flash* flashPtr, int8_t* idPtr) {
	int8_t capacity = 0;
	
	ptrCheck(flashPtr);
	
	if(idPtr[0] == MANUFACTURER_STM || idPtr[0] == MANUFACTURER_SPA) {
		if(idPtr[1] == MEMTYPE_STM) {
			capacity = idPtr[2];
		}
		else {	
			if(idPtr[1] == MEMTYPE_SPA) {
				capacity = idPtr[2]+1;
			}
			else {
				return UNSUPPORTED_TYPE;
			}
		}
		
		switch(capacity) {
			case MEMCAPACITY_32MBIT_STM :
				flashPtr->type.maxAdress = MAXADRESS_32MBIT;
				flashPtr->type.capacity = FLASH_SIZE_32MBIT;
				flashPtr->type.pages = FLASH_PAGE_COUNT_32MBIT;
				flashPtr->type.sectors = FLASH_SECTOR_COUNT_32MBIT;
				break;
			case MEMCAPACITY_16MBIT_STM :
				flashPtr->type.maxAdress = MAXADRESS_16MBIT;
				flashPtr->type.capacity = FLASH_SIZE_16MBIT;
				flashPtr->type.pages = FLASH_PAGE_COUNT_16MBIT;
				flashPtr->type.sectors = FLASH_SECTOR_COUNT_16MBIT;
				break;	
			case MEMCAPACITY_8MBIT_STM :
				flashPtr->type.maxAdress = MAXADRESS_8MBIT;
				flashPtr->type.capacity = FLASH_SIZE_8MBIT;
				flashPtr->type.pages = FLASH_PAGE_COUNT_8MBIT;
				flashPtr->type.sectors = FLASH_SECTOR_COUNT_8MBIT;					
				break;
			default :
				return UNSUPPORTED_TYPE;					
		}
		
		return GOOD;
	}
	else {
		return UNSUPPORTED_TYPE;
	}	
}

