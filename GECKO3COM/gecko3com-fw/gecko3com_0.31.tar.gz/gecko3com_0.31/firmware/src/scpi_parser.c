/* GECKO3COM
 *
 * Copyright (C) 2009 by
 *   ___    ____  _   _
 *  (  _`\ (  __)( ) ( )   
 *  | (_) )| (_  | |_| |   Berne University of Applied Sciences
 *  |  _ <'|  _) |  _  |   School of Engineering and
 *  | (_) )| |   | | | |   Information Technology
 *  (____/'(_)   (_) (_)
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*********************************************************************/
/** \file     scpi_parser.re
 *********************************************************************
 * \brief     Parser for the SCPI commands. Excecutes the necessary 
 *            Function.
 *
 *            The SCPI Parser is developed as a set of regular 
 *            expressions and blocks of C code to excecute. \n
 *            We use the opensource programm re2c (http://re2c.org/) to
 *            generate the parser. With solution we have an easy to 
 *            maintain and extend parser definitions without the hassle 
 *            of optimizing the parser sourcecode by hand. \n \n
 *            Don't forget to use the "-s" option with re2c to generate
 *            nested ifs for some switches because sdcc hates long 
 *            switch case structures.
 *
 * \todo      use newer re2c to generate state event diagramm to include here
 *
 * \author    Christoph Zimmermann bfh.ch
 * \date      2009-02-04
 *
*/

#include <stdint.h>
#include <ctype.h>
#include <string.h>

#include "scpi_parser.h"
#include "usb_tmc.h"
#include "usb_descriptors.h"
#include "firmware_version.h"
#include "debugprint.h"


#define SCPI_VERSION "1999.0\n" /**< Version of the SCPI standard this device complies to */

#define	YYCTYPE		unsigned char
#define	YYCURSOR	s->cur
#define	YYLIMIT		s->lim
#define	YYMARKER	s->ptr
#define	YYFILL(n)	{YYCURSOR = fill(s, buffer, n);}
#define YYMAXFILL       12


/** helper function to convert a unsigned byte to an ascii string
 *
 *  \param[in]  byte unsigned byte to convert
 *  \param[out] ascii string with "\n" at the end
 *  \return     length of string
 */
uint8_t byte2ascii(uint8_t byte, unsigned char *ascii) {
  unsigned char first_digit, second_digit, third_digit;
  uint8_t i = 0;

  first_digit = byte % 10;
  byte -= first_digit;
  byte /= 10;
  second_digit = byte % 10;
  if(second_digit == 0) {
    ascii[i++] = first_digit + '0';
    ascii[i] = '\n';
    return i+1;
  }
  byte -= second_digit;
  byte /= 10;
  third_digit = byte % 10;
  if(third_digit == 0) {
    ascii[i++] = second_digit + '0';
    ascii[i++] = first_digit + '0';
    ascii[i] = '\n';
    return i+1;
  }
  ascii[i++] = third_digit + '0';
  ascii[i++] = second_digit + '0';
  ascii[i++] = first_digit + '0';
  ascii[i] = '\n';
  return i+1;
}

/** helper function to convert an ascii string to a unsigned byte
 *
 *  \param[in]  ascii string with '\n' or '\0' at the end
 *  \return byte result unsigned byte, 0 if case of error
 */
uint8_t ascii2byte(unsigned char *ascii) {
  uint8_t byte = 0, i = 0;

  for(i; i<4;i++) {
    if(ascii[i] >= '0' && ascii[i] <= '9') {
      byte = byte*10 + (ascii[i] - '0');
    }
    else if(ascii[i] == '\n' || ascii[i] == '\0') {
      return byte;
    }
    else {
      ieee488_status.EventStatusRegister |= bmEXECUTION_ERROR;
      return 0;
    }
  }

  ieee488_status.EventStatusRegister |= bmEXECUTION_ERROR;
  return 0;
}

/** helper function to copy unicode 16 chars from the usb descriptor to an 
 * ascii string to form the *idn? response 
 * 
 * \param[in] pointer to string to fill
 * \param[in] pointer to usb string descriptor to read from
 * \return pointer that points to the last character in the string (one before \0)
 */
char* descr2string(char *target, char *descriptor) {
  uint8_t i;
  /* the first byte in the descriptor is the length, second byte is the type */
  for (i = 0; i < (uint8_t)descriptor[0]-2; i=i+2){
    target[i >> 1] = descriptor[i+2];
  }
  i = i >> 1;
  target[i+1] = '\0';

  return &target[i];
}

/** internal helper function to fill the buffer with n characters. 
 *  we convert any character to lower case because SCPI is case insensitive 
 *
 *  \param[in]  *s pointer to a Scanner struct. contains all needed pointers for the SCPI parser
 *  \param[out] *buffer pointer to the buffer to fill
 *  \param[in]  n number of bytes to read and fill into the buffer
 *  \return pointer to the next fresh character to parse
*/
unsigned char* fill(Scanner *s, unsigned char *buffer, uint8_t n){
  uint8_t i = 0;

  for(i;i<n;i++) {
    buffer[i] = tolower(*(s->source));
    s->source++;
  }

  s->cur = buffer;
  s->lim = &buffer[n];

  return s->cur;    
}

/* -------------------------------------------------------------------- */
/** SCPI command parser */
int8_t scpi_scan(Scanner *s, TMC_Response_Queue *queue){

  xdata unsigned char buffer[YYMAXFILL];
  unsigned char *i;

  YYFILL(YYMAXFILL);

  /* this set of regular expressions are for the mandatory IEEE488 commands */

  if(*YYCURSOR == '*') {
    YYCURSOR++;
    
    if(!strncmp("cls", YYCURSOR, 3)) {
      /** \li *cls, clear status command */
      ieee488_status.EventStatusRegister = 0;
      ieee488_status.StatusByteRegister = 0;
      usb_tmc_state = TMC_STATE_IDLE;
      return 1;
    }

    if(!strncmp("ese", YYCURSOR, 3)) {
      YYCURSOR += 3;
      if(*YYCURSOR == ' ') {
	/** \li *ese, standard event status enable command */
	ieee488_status.EventStatusEnable = ascii2byte(YYCURSOR+1);
	usb_tmc_state = TMC_STATE_IDLE;
	return 1;  
      }
      else if(*YYCURSOR == '?') {
	/** \li *ese?, standard event status enable query */
	queue->length = byte2ascii(ieee488_status.EventStatusEnable,queue->buf);
	IEEE488_set_mav();
	usb_tmc_state = TMC_STATE_IDLE;
	return 1;  
      }
      else {
	return 0;
      }
    }

    if(!strncmp("esr?", YYCURSOR, 4)) {
      /** \li *esr?, standard event status register query */
      queue->length = byte2ascii(ieee488_status.EventStatusRegister,queue->buf);
      IEEE488_set_mav();
      ieee488_status.EventStatusRegister = 0;
      usb_tmc_state = TMC_STATE_IDLE;
      return 1;  
    }
    
    if(!strncmp("idn?", YYCURSOR, 4)) {
      /** \li *idn?, identification query */
      i = descr2string((char*)queue->buf, string_descriptors[(uint8_t)full_speed_device_descr[14]]);
      *i = ',';
      i = descr2string(&i[1], string_descriptors[(uint8_t)full_speed_device_descr[15]]);
      *i = ',';
      i = descr2string(&i[1], string_descriptors[(uint8_t)full_speed_device_descr[16]]);
      
      strcat((char*)queue->buf, ",");
      strcat((char*)queue->buf, FIRMWARE_VERSION);
      
      queue->length = strlen((char*)queue->buf);
      
      usb_tmc_state = TMC_STATE_IDLE;
      IEEE488_set_mav();
      return 1; 
    }
    
    if(!strncmp("opc", YYCURSOR, 3)) {
      YYCURSOR += 3;
      if(*YYCURSOR == '?') {
	/** \li *opc?, operation complete query */
	queue->buf[0] = '1';
	queue->length = 1;
	usb_tmc_state = TMC_STATE_IDLE;
	IEEE488_set_mav();
	return 1;  
      }
      else {
	/** \li *opc, operation complete command */
	ieee488_status.OPC_Received = 1;
	usb_tmc_state = TMC_STATE_IDLE;
	return 1;  
      }
    }
      
    if(!strncmp("rst", YYCURSOR, 3)) {
      /** \li *rst, reset command. resets the FPGA and connected modules */
      s->action = SYSTEM_RESET;
      return 1;  
    }
    
    if(!strncmp("sre", YYCURSOR, 3)) {
      YYCURSOR += 3;
      if(*YYCURSOR == ' ') {
	/** \li *sre, service request enable command */
	ieee488_status.ServiceRequestEnable = ascii2byte(YYCURSOR+1);
	usb_tmc_state = TMC_STATE_IDLE;
	return 1;  
      }
      else if(*YYCURSOR == '?') {
	/** \li *sre?, service request enable query */
	queue->length = byte2ascii(ieee488_status.ServiceRequestEnable,queue->buf);
	usb_tmc_state = TMC_STATE_IDLE;
	return 1;  
      }
      else {
	return 0;
      }
    }
    
    if(!strncmp("stb?", YYCURSOR, 4)) {
      /** \li *stb?, read status byte query */
      queue->length = byte2ascii(IEEE488_status_query(&ieee488_status),queue->buf);
      usb_tmc_state = TMC_STATE_IDLE;
      IEEE488_set_mav();
      return 1;  
    }
    
    if(!strncmp("wai", YYCURSOR, 3)) {
      /** \li *wai, wait-to-continue command */
      /* we excecute only sequential commands, so we are always finished */
      return 1;  
    }
    
    else {
      return 0;
    }
  }

  /* -------------------------------------------------------------------- */
  /* this set of regular expressions are for the mandatory SCPI 99 commands. 
   * many are missing because we have not enought memory 
   */
  if(!strncmp("syst:", YYCURSOR, 5)) {
    YYCURSOR += 5;
    
    if(!strncmp("err?", YYCURSOR, 4)) {
      /** \li syst:err?, gets an error message if ther is one */
      if(ieee488_status.EventStatusRegister & bmCOMMAND_ERROR){
	strcpy((char*)queue->buf, "-100, \"Command error\"\n");
	queue->length = 22;
	ieee488_status.EventStatusRegister &= ~bmCOMMAND_ERROR;
      }
      else if(ieee488_status.EventStatusRegister & bmEXECUTION_ERROR){
	strcpy((char*)queue->buf, "-200, \"Execution error\"\n");
	queue->length = 24;
	ieee488_status.EventStatusRegister &= ~bmEXECUTION_ERROR;
      }
      else {
	strcpy((char*)queue->buf, "0, \"No error\"\n");
	queue->length = 14;
      }
      usb_tmc_state = TMC_STATE_IDLE;
      IEEE488_set_mav();
      return 1;  
    }
    
    if(!strncmp("vers?", YYCURSOR, 5)) {
      /** \li syst:vers?, returns the firmware version number */
      strcpy((char*)queue->buf, SCPI_VERSION);
      queue->length = 7;
      usb_tmc_state = TMC_STATE_IDLE;
      IEEE488_set_mav();
      return 1;  
    }
    
    else {
      return 0;
    }
  }
  
  /* -------------------------------------------------------------------- */
  /* this set of regular expressions are for the device functions */
  if(!strncmp("fpga:", YYCURSOR, 5)) {
    YYCURSOR += 5;
    
    if(!strncmp("conf ",YYCURSOR, 5)) {
      /** \li fpga:conf, configures the fpga with the following bitfile */
      s->action = FPGA_CONFIGURE;
      return 1;
    }
    
    if(!strncmp("type?", YYCURSOR, 5)) {
      /** \li fpga:type?, returns the fpga type as string */
      s->action = rqFPGA_TYPE; 
      return 1;  
    }
    
    if(!strncmp("id?", YYCURSOR, 3)) {
      /** \li fpga:id?, returns the jtag id code of the fpga as 32bit int */
      s->action = rqFPGA_IDCODE;
      return 1; 
    }
    
    if(!strncmp("done?", YYCURSOR, 5)) {
      /** \li fpga:done?, is true when the fpga is configured */ 
      s->action = rqFPGA_DONE;
      return 1; 
    }		

    else {
      return 0;
    }
  }
  
  if(!strncmp("mem:", YYCURSOR, 4)) {
    YYCURSOR += 4;
    
    if(!strncmp("data ", YYCURSOR, 5)) {
      /** \li mem:data, received a bitfile to store in SPI flash*/
      s->action = SPI_WRITE;
      return 1;
    }
    
    if(!strncmp("del ", YYCURSOR, 4)) {
      /** \li mem:del, deletes the desired fpga configuration */
      s->action = SPI_DELETE;
      return 1;  
    }
    
    if(!strncmp("cat?", YYCURSOR, 4)) {
      /** \li mem:cat?, list the file names of the stored fpga configurations */
      s->action = rqSPI_FILE_LIST;
      return 1; 
    }

    else {
      return 0;
    }
  }
  
  /* matches all. when no command is parsed return an error */

  return 0;
}

