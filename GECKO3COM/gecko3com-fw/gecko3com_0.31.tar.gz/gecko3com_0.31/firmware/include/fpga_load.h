/* GECKO3COM
 *
 * Copyright (C) 2008 by
 *   ___    ____  _   _
 *  (  _`\ (  __)( ) ( )   
 *  | (_) )| (_  | |_| |   Bern University of Applied Sciences
 *  |  _ <'|  _) |  _  |   School of Engineering and
 *  | (_) )| |   | | | |   Information Technology
 *  (____/'(_)   (_) (_)
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*********************************************************************/
/** \file     fpga_load.h
 *********************************************************************
 * \brief     functions to configure an FPGA
 *
 *            use a define to select the handled FPGA \n
 *            currently following vendors are suported:
 *            \li XILINX
 *            \li ALTERA, as stub. needs work
 *
 * \author    GNUradio team, Christoph Zimmermann bfh.ch
 * \date      2009-1-19
 *
*/

#ifndef INCLUDED_FPGA_LOAD_H
#define INCLUDED_FPGA_LOAD_H

uint8_t fpga_load_begin (void);
uint8_t fpga_load_xfer (uint8_t *p, uint16_t len);
uint8_t fpga_load_end (void);

/* ------------------------------------------------------------------------- */
/* Xilinx stuff. We use slave parallel mode to configure the FPGA
 */
#ifdef XILINX

#define FPGA_INFO_LEN 19
#define FPGA_INFO_COMPLETE 1
#define FPGA_INFO_NOT_COMPLETE -1

typedef enum  {
  FILENAME = 'a',
  FPGA_TYPE = 'b',
  COMPILE_DATE = 'c',
  COMPILE_TIME = 'd',
  FILE_LENGTH = 'e',
} Fpga_Info_Type;

typedef struct {
  char info[FPGA_INFO_LEN]; /**< char array that with the desired information */
  uint8_t length; /**< length of information string */
  uint8_t left; /**< internal variable, contains the number of characters still to read */
  uint16_t position; /**< current position inside the input buffer */
  Fpga_Info_Type type; /**< type of desired information, like filename, fpga type etc. */
} Fpga_Info; 

int8_t fpga_scan_file (unsigned char *p, uint16_t length, Fpga_Info* info );

#define fpga_done()   ((XILINX_DONE & bmXILINX_DONE) == bmXILINX_DONE) /**< check if DONE is set */
#endif


/* ------------------------------------------------------------------------- */
/* Altera stuff. only copied from USRP source code. does not work. only a 
 * guide to give you a start to port GECKO3COM to other boards using Altera
 * devices
 */
#ifdef ALTERA
#define fpga_done()   ((status & bmALTERA_CONF_DONE) == bmALTERA_CONF_DONE)  /**< check if DONE is set */
#endif

#endif /* INCLUDED_FPGA_LOAD_H */
