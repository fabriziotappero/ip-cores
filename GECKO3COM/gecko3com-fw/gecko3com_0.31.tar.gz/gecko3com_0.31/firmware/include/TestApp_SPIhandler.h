#ifndef TESTAPP_SPIHANDLER /* prevent circular inclusions */
#define TESTAPP_SPIHANDLER /* by using protection macros */

#include "xbasic_types.h"
#include "xstatus.h"
#include "xspi.h"

#include "xspi-flash.h"

extern volatile Xboolean spiTransferInProgress;
extern volatile Xuint8 error;

/****************************************************************************
*
* FUNCTION:
*
* SpiHandler
*
* DESCRIPTION:
*
* This function is the handler which performs processing for the SPI driver.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when a transfer of SPI data
* completes or an error occurs.
*
* This handler provides an example of how to handle SPI interrupts
* but is application specific.
*
* ARGUMENTS:
*
* None.
*
* RETURN VALUE:
*
* None.
*
* NOTES:
*
* None.
*
****************************************************************************/
void SpiHandler(void *callBackRef, Xuint32 statusEvent, unsigned int byteCount);

#endif
