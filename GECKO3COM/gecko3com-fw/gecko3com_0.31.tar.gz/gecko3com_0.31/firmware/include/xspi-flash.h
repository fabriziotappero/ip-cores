/***********************************************************
*  Gecko3 SoC HW/SW Development Board
*   ___    ___   _   _
*  (  _`\ (  __)( ) ( )   
*  | (_) )| (   | |_| |   Berne University of Applied Sciences
*  |  _ <'|  _) |  _  |   School of Engineering and
*  | (_) )| |   | | | |   Information Technology
*  (____/'(_)   (_) (_)
*
*
*  Author:  Christoph Zimmermann
*  Date of creation: 17.09.2007
*  Description:
*	Headerfile for the xspi-flash Driveer 
*   Driver to access the SPI Flash supported by the
*	 spi-flash library
*
*  Changelog:
*   24.09.2007
*   first version
***********************************************************/

#ifndef XSPI_FLASH /* prevent circular inclusions */
#define XSPI_FLASH /* by using protection macros */

#ifdef __cplusplus
extern "C" {
#endif

#include "spi-flash.h"
#include "stdio.h"
#include "xbasic_types.h"
#include "xstatus.h"
#include "xspi.h"

//#define DEBUG 0

#define SLAVE_DESELECT 0

extern volatile Xboolean spiFlashTransferInProgress;
extern volatile Xboolean spiFlashTransferError;

extern Xuint8 xspi_flash_sendBuf[262];

/**************************** Type Definitions *******************************/

typedef struct
{
    SPI_flash flash;
	 XSpi *spiPtr;
	 Xuint32 chipSelectMask;
	 Xboolean isInitialized;
} XSpi_flash;


/***************** Macros (Inline Functions) Definitions *********************/

/****************************************************************************
/**
*
* Initializes a specific XSpi instance such that the driver is ready to use.
*
* The state of the device after initialization is:
*   - Device is disabled
*   - Slave mode
*   - Active high clock polarity
*   - Clock phase 0
*
* @param InstancePtr is a pointer to the XSpi instance to be worked on.
* @param Config is a reference to a structure containing information about
*        a specific SPI device. This function initializes an InstancePtr object
*        for a specific device specified by the contents of Config. This
*        function can initialize multiple instance objects with the use of
*        multiple calls giving different Config information on each call.
*
* @param EffectiveAddr is the device base address in the virtual memory address
*        space. The caller is responsible for keeping the address mapping
*        from EffectiveAddr to the device physical base address unchanged
*        once this function is invoked. Unexpected errors may occur if the
*        address mapping changes after this function is called. If address
*        translation is not used, use Config->BaseAddress for this parameters,
*        passing the physical address instead.
*
* @return
*
* The return value is XST_SUCCESS if successful.  On error, a code indicating
* the specific error is returned.  Possible error codes are:
* - XST_DEVICE_IS_STARTED if the device is started. It must be stopped to
*   re-initialize.
*
* @note
*
* None.
*
****************************************************************************/
#define XSpiFlashHandler(statusEvent,byteCount) 								\
{																								\
    /* Indicate the transfer on the SPI bus is no longer in progress		\
     * regardless of the status event												\
     */																						\
    spiFlashTransferInProgress = XFALSE;											\
																								\
    /* If the event was not transfer done, then track it as an error */	\
																								\
    if ((statusEvent) != XST_SPI_TRANSFER_DONE) {								\
        spiFlashTransferError = XTRUE;												\
    }																							\
}


/*****************************************************************************
*
* MACRO:
*
* STATUS_CHECK
*
* DESCRIPTION:
*
* This macro checks the status for functions called. It performs a return
* if the status was not success.  The purpose of this macro is to allow
* centralized status checking.
*
* ARGUMENTS:
*
* Status contains any status from a Xilinx driver.
*
* RETURN VALUE:
*
* None.
*
* NOTES:
*
* Signature: void STATUS_CHECK(XStatus status)
*
******************************************************************************/
#define STATUS_CHECK(status)            \
    {                                   \
        if (status != XST_SUCCESS)      \
        {                               \
				return status;              \
        }                               \
    }
	 
/************************** Function Prototypes ******************************/

XStatus XSpiFlashInitialize( XSpi *spiPtr, XSpi_flash *flashPtr, Xuint32 deviceID);

XStatus XSpiFlashIsBusy(XSpi_flash *flashPtr);

XStatus XSpiFlashRead(XSpi_flash *flashPtr, Xuint32 adress, Xuint8 *buffer, Xuint32 length, Xuint8 *readOffset);

XStatus XSpiFlashTransferFinished();

XStatus XSpiFlashEraseBulk(XSpi_flash *flashPtr);
XStatus XSpiFlashErase(XSpi_flash *flashPtr, Xuint32 adress);

XStatus XSpiFlashWrite(XSpi_flash *flashPtr, Xuint32 adress, Xuint8 *buffer, Xuint32 length);

#ifdef __cplusplus
}
#endif

#endif
