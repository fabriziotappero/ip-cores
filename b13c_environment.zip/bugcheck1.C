// Bugcheck
//
// This tests out certain instructions in the processor, which have been
// reported to be BUGGY.
//
// Author: John Clayton
// Date  : 08/06/03

#device PIC16C84
#byte stat_reg     = 0x03   // Status register
#byte addr_lo      = 0x05   // Aux. bus address low
#byte addr_hi      = 0x06   // Aux. bus address high
#byte data         = 0x08   // Aux. bus data
#byte int_reg      = 0x0b   // Interrupt control register

// Global type variables
int int_count;
unsigned int w_temp;
unsigned int stat_temp;
unsigned int addr_lo_temp;
unsigned int addr_hi_temp;
unsigned int count1;
unsigned int count2;

// This functions plots a single pixel at coordinates (x,y)
// color should range from 0..7.
void plot(unsigned int x, unsigned int y, unsigned int color)
{
addr_hi = (y>>1) | 0x40;
addr_lo = x | (y<<7);
data = color;
}

void fill_block(unsigned int x1,
                unsigned int y1,
                unsigned int x2,
                unsigned int y2,
                unsigned int color)
{
int i,j;

for (i=x1;i<x2;i++)
  for (j=y1;j<y2;j++)
    plot (i,j,color);
}

void show_leds(unsigned int value)
{
addr_hi = 0xff;
addr_lo = 0x07;
data = value;
}

// This is an interrupt service routine
// #int_default -- this directive causes the compiler to produce
// code for saving registers and "cleanup."  It is not working
// too well.

#int_global

void isr1()
{
  // Save the 'w' register, so that the ISR will not destroy
  // any work in progress using the 'w' register at the time
  // the interrupt occurred.
  // Also, save the status register
  // Also, save the aux address bus values
  #asm
    movwf w_temp
    movf  stat_reg,w
    movwf stat_temp
    movf  addr_hi,w
    movwf addr_hi_temp
    movf  addr_lo,w
    movwf addr_lo_temp
  #endasm
  show_leds(++int_count);
  // Restore the contents of the 'w' register and status register
  #asm
    movf  addr_lo_temp,w
    movwf addr_lo
    movf  addr_hi_temp,w
    movwf addr_hi
    movf  stat_temp,w
    movwf stat_reg
    movf  w_temp,w
  #endasm
}


void check1()
{
#asm
  movwf w_temp      // save w

  movlw 0xff
  movwf count1      // initialize count1
load2:
  movlw 0xff
  movwf count2      // initialize count2
dec2:
  decfsz count2,1
  goto dec2
  decfsz count1,1
  goto load2

  movf  w_temp,w    // restore w
#endasm
}

void check2()
{
#asm
  movwf w_temp      // save w

  movlw 0xff
  movwf count1      // initialize count1
  subwf count1,1    // Subtract, store in count1

  movf  w_temp,w    // restore w
#endasm
}


main() {
int rand;
int a,x,y,c,d;
long b;

// Clear the screen
  fill_block(0,0,128,96,0);

// Enable the interrupts
  #asm
    bsf 0x0b,4        // set the interrupt flag
    bsf 0x0b,7        // set the GIE
  #endasm

x = 10;
y = 10;
c = 1;
d = 0;
while (1) {
  plot(x,y++,c);
  check1();
  check2();
  if (y>86) {
	  y = 10;
	  x++;
  }
  if (x>118) {
    x = 10;
    d++;
    c+=1;
  }
  c += d;
  // Delay
  for (a=0;a<2;a++)
    for (b=0;b<2000;b++) {}

} // End of while loop

} // End of main()
