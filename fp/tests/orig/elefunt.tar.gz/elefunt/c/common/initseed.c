#include "elefunt.h"

long
initseed(VOID_ARG)
{
    char *p;
    char *endptr;
    long initseed;

    p = getenv("INITIALSEED");
    if (p != (char*)NULL)
    {
	initseed = strtol(p, &endptr, 0);
	if ((endptr != (char*)NULL) && (*endptr == '\0') && (initseed > 0L))
	    return (initseed);
    }
    return (INITIALSEED);		/* default initial seed */
}
