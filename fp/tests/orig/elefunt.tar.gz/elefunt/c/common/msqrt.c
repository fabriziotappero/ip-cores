/* -*-C-*- msqrt.c */

#include "elefunt.h"

int
main()
{
    tsqrt();
    return (EXIT_SUCCESS);
}
