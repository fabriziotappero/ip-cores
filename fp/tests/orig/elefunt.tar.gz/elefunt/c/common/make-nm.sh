#! /bin/sh
for f in *.o
do
	g=`basename $f .o`
	nm $f | grep ' U ' > $g.nm
	test -s $g.nm || rm -f $g.nm
done
