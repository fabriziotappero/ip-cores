/* -*-C-*- mtanh.c */

#include "elefunt.h"

int
main()
{
    ttanh();
    return (EXIT_SUCCESS);
}
