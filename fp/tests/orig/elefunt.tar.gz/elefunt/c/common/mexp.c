/* -*-C-*- mexp.c */

#include "elefunt.h"

int
main()
{
    texp();
    return (EXIT_SUCCESS);
}
