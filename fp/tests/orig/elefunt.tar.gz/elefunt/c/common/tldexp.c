/* -*-C-*- tldexp.c */

#include "elefunt.h"

extern dp_t ldexp();

int
main(VOID_ARG)				/* test ldexp() */
{
    dp_t x,
        s;
    int e;
    typedef union { dp_t x; unsigned int i[2]; } u_t;
    u_t us;
    u_t ux;

    for (;;)
    {
	(void)printf(" Enter x e:");
	if (scanf("%lf %d", &x, &e) != 2)
	    break;
	s = ldexp(x, e);
	us.x = s;
	ux.x = x;
	(void)printf("%15.5Le 0x%08x_0x%08x %5d %15.5Le 0x%08x_0x%08x\n",
		     x, ux.i[0], ux.i[1], e, s, us.i[0], us.i[1]);
    }
    return (EXIT_SUCCESS);
}
