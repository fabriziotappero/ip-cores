#! /bin/sh
### ====================================================================
### Make a list of object file dependencies suitable for insertion in a
### Makefile.
###
### Usage:
###	./make-depends.sh >outfile
###
### [28-May-2002]
### ====================================================================

gcc -MM -I../common -I/opt/SUNWspro/WS6U2/include/cc *.c | \
	awk -F: '{printf("%-14s %s\n", ($1 ":"), $2)}' | \
		unexpand -a
