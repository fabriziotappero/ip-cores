#include "elefunt.h"

long
maxtest(VOID_ARG)
{
    char *p;
    char *endptr;
    long the_value;

    p = getenv("MAXTEST");
    if (p != (char*)NULL)
    {
	the_value = strtol(p, &endptr, 0);
	if ((endptr != (char*)NULL) && (*endptr == '\0') && (the_value > 0L))
	    return (the_value);
    }
    return (MAXTEST);
}
