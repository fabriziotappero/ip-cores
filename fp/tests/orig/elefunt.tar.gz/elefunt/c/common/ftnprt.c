/***********************************************************************
Filter a file with FTN carriage control to ASCII control.
Usage:
	ftnprt <infile >outfile
[02-Mar-88]
***********************************************************************/

#include "elefunt.h"

int
main(VOID_ARG)
{
    int eol = 1;
    int c;

    c = getchar();
    c = (c == '1') ? ' ' : c;
    (void)ungetc(c,stdin);
    while ((c = getchar()) != EOF)
    {
        if (eol)
	    switch (c)
	    {
	    case '+':
		(void)putchar('\r');
		break;
	    case '1':
		(void)putchar('\n');
		(void)putchar('\f');
		break;
	    case '-':
		(void)putchar('\n');
		/* fall through */
	    case '0':
		(void)putchar('\n');
		/* fall through */
	    default:
		(void)putchar('\n');
		break;
	    }
	else if (c != '\n')
	    (void)putchar(c);
	eol = (c == '\n');
    }
    (void)putchar('\n');
}
