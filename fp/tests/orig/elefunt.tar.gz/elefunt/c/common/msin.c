/* -*-C-*- msin.c */

#include "elefunt.h"

int
main()
{
    tsin();
    return (EXIT_SUCCESS);
}
