/* -*-C-*- tanh.c */

/*
	tanh(arg) computes the hyperbolic tangent of its floating
	point argument.

	sinh and cosh are called except for large arguments, which
	would cause overflow improperly.
*/

#include "elefunt.h"

#if STDC
dp_t
tanh(dp_t arg)
#else /* NOT STDC */
dp_t
tanh(arg)
dp_t arg;
#endif /* STDC */
{
    dp_t sign;

    sign = 1.;
    if (arg < 0.)
    {
	arg = -arg;
	sign = -1.;
    }

    if (arg > 21.)
	return (sign);

    return (sign * sinh(arg) / cosh(arg));
}
