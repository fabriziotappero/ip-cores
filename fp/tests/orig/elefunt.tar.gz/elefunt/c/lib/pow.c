/* -*-C-*- pow.c */

/*
	computes a^b.
	uses log and exp
*/

#include "elefunt.h"

#if STDC
dp_t
pow(dp_t arg1, dp_t arg2)
#else /* NOT STDC */
dp_t
pow(arg1, arg2)
dp_t arg1,
    arg2;
#endif /* STDC */
{
    dp_t temp;
    long l;

    if (arg1 <= 0.0)
    {
	if (arg1 == 0.0)
	{
	    if (arg2 <= 0.0)
		goto domain;
	    return (0.0);
	}
	l = arg2;
	if (l != arg2)
	    goto domain;
	temp = exp(arg2 * log(-arg1));
	if (l & 1)
	    temp = -temp;
	return (temp);
    }
    return (exp(arg2 * log(arg1)));

domain:
    errno = EDOM;
    return (0.0);
}
