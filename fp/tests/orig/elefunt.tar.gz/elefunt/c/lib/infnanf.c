#include "elefunt.h"

#if STDC
sp_t	infnanf(int iarg)
#else /* NOT STDC */
sp_t	infnanf(iarg)
int	iarg ;
#endif /* STDC */
{
	switch(iarg) {
	case	 ERANGE:	errno = ERANGE;	return(HUGE_VALF);
	case	-ERANGE:	errno = EDOM;	return(-HUGE_VALF);
	default:		errno = EDOM;	return(HUGE_VALF); /* HUGE_VALF instead of NaN */
	}
}
