#include "elefunt.h"

#if STDC
dp_t	infnan(int iarg)
#else /* NOT STDC */
dp_t	infnan(iarg)
int	iarg ;
#endif /* STDC */
{
	switch(iarg) {
	case	 ERANGE:	errno = ERANGE;	return(HUGE_VAL);
	case	-ERANGE:	errno = EDOM;	return(-HUGE_VAL);
	default:		errno = EDOM;	return(HUGE_VAL); /* HUGE_VAL instead of NaN */
	}
}
