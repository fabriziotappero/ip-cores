/* -*-C-*- tsin.c */

#include "elefunt.h"

/*#     PROGRAM to test sin/cos
#
#     data required
#
#        none
#
#     subprograms required from this package
#
#        machar - an environmental inquiry program providing
#                 information on the floating-point arithmetic
#                 system.  note that the call to machar can
#                 be deleted provided the following five
#                 parameters are assigned the values indicated
#
#                 ibeta  - the radix of the floating-point system
#                 it     - the number of base-ibeta digits in the
#                          significand of a floating-point number
#                 minexp - the largest in magnitude negative
#                          integer such that  float(ibeta)**minexp
#                          is a positive floating-point number
#                 eps    - the smallest positive floating-point
#                          number such that 1.0+eps != 1.0
#                 epsneg - the smallest positive floating-point
#                          number such that 1.0-epsneg != 1.0
#
#        ran(k) - a function subprogram returning random real
#                 numbers uniformly distributed over (0,1)
#
#
#     standard fortran subprograms required
#
#         abs, alog, amax1, cos, float, sin, sqrt
#
#
#     latest revision - december 6, 1979
#
#     author - w. j. cody
#              argonne national laboratory
#
#*/

void
tsin(VOID_ARG)
{
    int i,
        ibeta,
        iexp,
        irnd,
        it,
        j,
        k1,
        k2,
        k3,
        machep,
        maxexp,
        minexp,
        n,
        negep,
        ngrd;

    qp_t
        eps,
        epsneg,
        xmax,
        xmin;

    volatile qp_t 
	a,
        ait,
        albeta,
        b,
        beta,
        betap,
        c,
        del,
        expon,
        r6,
        r7,
        three,
        w,
        x,
        xl,
        xn,
        x1,
        y,
        z,
        zz;

    /*******************************************************************/

    (void)qranset(initseed());
    macharl(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp,
        &maxexp, &eps, &epsneg, &xmin, &xmax);
    beta = TO_FP_T(ibeta);
    albeta = ALOG(beta);
    ait = TO_FP_T(it);
    three = 3.0e+00L;
    a = ZERO;
    b = 1.57079632679489661923132169163975144209858469968755291e+00L;
    c = b;
    n = maxtest();
    xn = TO_FP_T(n);
    z = ZERO;

    /* random argument accuracy tests */

    for (j = 1; j <= 3; ++j)
    {
	k1 = 0;
	k3 = 0;
	x1 = ZERO;
	r6 = ZERO;
	r7 = ZERO;
	del = (b - a) / xn;
	xl = a;

	for (i = 1; i <= n; ++i)
	{
	    x = del * RAN() + xl;
	    y = x / three;
	    y += x;
	    y -= x;
	    x = three * y;
	    if (j == 3)
	    {
		z = COS(x);
		zz = COS(y);
		w = ONE;
		if (z != ZERO)
		    w = (z + zz * (three - 4.0e+00L * zz * zz)) / z;
	    }
	    else
	    {
		z = SIN(x);
		zz = SIN(y);
		w = ONE;
		if (z != ZERO)
		    w = (z - zz * (three - 4.0e+00L * zz * zz)) / z;
	    }
	    if (w > ZERO)
		k1 = k1 + 1;
	    if (w < ZERO)
		k3 = k3 + 1;
	    w = ABS(w);
	    if (w > r6)
	    {
		r6 = w;
		x1 = x;
	    }
	    r7 = r7 + w * w;
	    xl = xl + del;
	}

	k2 = n - k3 - k1;
	r7 = SQRT(r7 / xn);
	if (j == 3)
	{
	    (void)printf("1TEST OF COS(X) VS 4*COS(X/3)**3-3*COS(X/3)\n\n");
	    (void)printf("%7d RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n",n);
	    (void)printf("      (%15.4Le,%15.4Le)\n\n\n", a, b);
	    (void)printf(" COS(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("            AGREED%6d TIMES, AND\n", k2);
	    (void)printf("       WAS SMALLER%6d TIMES.\n\n", k3);
	}
	else
	{
	    (void)printf("1TEST OF SIN(X) VS 3*SIN(X/3)-4*SIN(X/3)**3\n\n");
	    (void)printf("%7d RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n", n);
	    (void)printf("      (%15.4Le,%15.4Le)\n\n\n", a, b);
	    (void)printf(" SIN(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("            AGREED%6d TIMES, AND\n", k2);
	    (void)printf("       WAS SMALLER%6d TIMES.\n\n", k3);
	}
	(void)printf(
" THERE ARE%4d BASE%4d SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n",
	    it, ibeta);
	w = -999.0e+00L;
	if (r6 != ZERO)
	    w = ALOG(ABS(r6)) / albeta;
	(void)printf(" THE MAXIMUM RELATIVE ERROR OF%15.4Le = %4d **%7.2Lf\n",
	    r6, ibeta, w);
	(void)printf("    OCCURRED FOR X =%17.6Le\n", x1);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	w = -999.0e+00L;
	if (r7 != ZERO)
	    w = ALOG(ABS(r7)) / albeta;
	(void)printf(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS%15.4Le = %4d **%7.2Lf\n",
	    r7, ibeta, w);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	a = 18.84955592153875943077586029967701730518301639625063493e+00L;
	if (j == 2)
	    a = b + c;
	b = a + c;
    }

    /* special tests */

    (void)printf("1SPECIAL TESTS\n\n");
    c = ONE / IPOW(beta, (it / 2));
    z = (SIN(a + c) - SIN(a - c)) / (c + c);
    (void)printf(" IF %13.6Le IS NOT ALMOST 1.0E0,    SIN HAS THE WRONG PERIOD.\n\n",
        z);

    (void)printf(" THE IDENTITY   SIN(-X) = -SIN(X)   WILL BE TESTED.\n");
    (void)printf("     X        F(X) + F(-X)\n");

    for (i = 1; i <= 5; ++i)
    {
	x = RAN() * a;
	z = SIN(x) + SIN(-x);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
    }

    (void)printf(" THE IDENTITY SIN(X) = X , X SMALL, WILL BE TESTED.\n");
    (void)printf("    X         X - F(X)\n\n");
    betap = IPOW(beta, it);
    x = RAN() / betap;

    for (i = 1; i <= 5; ++i)
    {
	z = x - SIN(x);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
	x = x / beta;
    }

    (void)printf(" THE IDENTITY   COS(-X) = COS(X)   WILL BE TESTED.\n");
    (void)printf("        X         F(X) - F(-X)\n");

    for (i = 1; i <= 5; ++i)
    {
	x = RAN() * a;
	z = COS(x) - COS(-x);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
    }

    (void)printf(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
    expon = TO_FP_T(minexp) *0.75e+00L;
    x = POW(beta, expon);
    y = SIN(x);
    (void)printf("\n       SIN(%13.6Le) = %13.6Le\n", x, y);
    (void)printf(" THE FOLLOWING THREE LINES ILLUSTRATE THE LOSS IN SIGNIFICANCE\n");
    (void)printf(" FOR LARGE ARGUMENTS.  THE ARGUMENTS ARE CONSECUTIVE.\n");
    z = SQRT(betap);
    x = z * (ONE - epsneg);
    y = SIN(x);
    (void)printf("\n       SIN(%13.6Le) =%13.6Le\n", x, y);
    y = SIN(z);
    (void)printf("\n       SIN(%13.6Le) =%13.6Le\n", z, y);
    x = z * (ONE + eps);
    y = SIN(x);
    (void)printf("\n       SIN(%13.6Le) =%13.6Le\n", x, y);

    /* test of error returns */

    (void)printf("1TEST OF ERROR RETURNS\n\n\n");

    x = betap;
    (void)printf(" SIN WILL BE CALLED WITH THE ARGUMENT%15.4Le\n",x);
    (void)printf(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
    fflush(stdout);
    errno = 0;
    y = SIN(x);
    if (errno)
	perror("SIN()");
    (void)printf(" SIN RETURNED THE VALUE%15.4Le\n\n\n\n", y);

    (void)printf(" THIS CONCLUDES THE TESTS\n");
}
