/* -*-C-*- elefunt.h */

#define PRECISION	4		/* must be 1, 2, or 4 (words) */

#include "../common/elefunt.h"
