/* -*-C-*- elefunt.h */

#define PRECISION	2		/* must be 1, 2, or 4 (words) */

#include "../common/elefunt.h"
