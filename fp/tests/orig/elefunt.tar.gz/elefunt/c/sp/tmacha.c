/* -*-C-*- tsmach.c */

#include "elefunt.h"

void
tmacha(VOID_ARG)
{
    int ibeta,
        iexp,
        irnd,
        it,
        machep,
        maxexp,
        minexp,
        negep,
        ngrd;

    sp_t
        eps,
        epsneg,
        xmax,
        xmin;

    macharf(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp,
        &maxexp, &eps, &epsneg, &xmin, &xmax);

    (void)printf("ibeta............%8d\n",ibeta);
    (void)printf("it...............%8d\n",it);
    (void)printf("irnd.............%8d\n",irnd);
    (void)printf("ngrd.............%8d\n",ngrd);
    (void)printf("machep...........%8d\n",machep);
    (void)printf("negep............%8d\n",negep);
    (void)printf("iexp.............%8d\n",iexp);
    (void)printf("minexp...........%8d\n",minexp);
    (void)printf("maxexp...........%8d\n",maxexp);
    (void)printf("eps..............%26.17e\n",eps);
    (void)printf("epsneg...........%26.17e\n",epsneg);
    (void)printf("xmin.............%26.17e\n",xmin);
    (void)printf("xmax.............%26.17e\n",xmax);
}
