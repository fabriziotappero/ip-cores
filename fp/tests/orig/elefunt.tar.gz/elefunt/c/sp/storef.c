/* -*-C-*- store.c */

#include "elefunt.h"

#if STDC
sp_t
(storef)(sp_t* p)
#else /* NOT STDC */
sp_t
(storef)(p)
sp_t* p;
#endif /* STDC */
{
    /* NO-OP -- want to force memory store of argument */
    /* Needed for IEEE arithmetic plus Intel, Honeywell, Motorola */
    /* (floating point registers larger than memory word size) */
    return (*p);
}
