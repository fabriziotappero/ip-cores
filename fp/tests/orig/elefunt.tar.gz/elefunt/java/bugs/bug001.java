import java.io.*;

// This program demonstrates that Java (1.1, 1.2, 1.3, 1.4) outputs
// one digit too few to conform to Matula's 1968 formula for exact
// binary<->decimal roundtrip conversions.
//
// A test on a 1.266GHz Intel Pentium 4 system with MAXTEST = 100,000,000
// ran for 1h57m and reported no conversion errors.
//
// Usage:
//	javac bug001.java
//	java [-DMAXTEST=nnnn] bug001
//
// [30-May-2002]

public class bug001
{
    public static long maxtest()
    {
	Long the_value;
	String p;
	final int MAXTEST = 1000000;

	p = System.getProperty("MAXTEST");
	if (p != null)
	{
	    try
	    {
		the_value = new Long(p);
		if (the_value.longValue() > 0L)
		    return (the_value.longValue());
	    }
	    catch (java.lang.NumberFormatException e)
	    {
		System.err.println("Ignoring bad number format in MAXTEST = " + p);
	    }
	}
	return (MAXTEST);
    }

    public static void main (String[] args)
    {
	double d;
	float f;
	long limit;

	f = 1.0F / 3.0F;
	d = 1.0 / 3.0;
	System.out.println("f = " + f);
	System.out.println("d = " + d);

	f = 1.0e+38F;
	d = 1.0e+308;
	System.out.println("f = " + f);
	System.out.println("d = " + d);

	f = 1.0e-38F;
	d = 1.0e-308;
	System.out.println("f = " + f);
	System.out.println("d = " + d);

	for (int i = 0; i < 10; ++i)
	{
	    f = (float)Math.random();
	    d = Math.random();
	    System.out.println("f = " + f);
	    System.out.println("d = " + d);
	}

	limit = maxtest();
	System.out.println("Begin I/O conversion test on interval (0,1): count = " + limit);
	for (long i = 0; i < limit; ++i)
	{
	    float f_out;
	    double d_out;
	    String f_str;
	    String d_str;

	    f = (float)Math.random();
	    d = Math.random();

	    f_str = "" + f;
	    f_out = Float.valueOf(f_str).floatValue();
	    if (f_out != f)
		System.out.println("f = " + f + " f_out = " + f_out +
				   " relerr = " + (int)Math.ceil((float)((f_out - f)/f)) + " ulps");

	    d_str = "" + d;
	    d_out = Double.valueOf(d_str).doubleValue();
	    if (d_out != d)
		System.out.println("d = " + d + " d_out = " + d_out +
				   " relerr = " + (int)Math.ceil((double)((d_out - d)/d)) + " ulps");
	}
	System.out.println("End I/O conversion test");
    }
}
