import java.io.*;

public class bug003
{
    // On Compaq/DEC Alpha OSF/1 4.0, conversion of NaN to an integer
    // type produces the same result as that for conversion of
    // negative infinity.  This is a violation of the Java Virtual
    // Machine specification, which defines the d2l (double to long)
    // operation to convert a NaN to 0.
    //
    // If the bug003.class file from the Alpha is run on another
    // system, results are again wrong.
    // 
    // If the bug003.class file from another system is run on the
    // Alpha, results are correct.
    // 

    public static void main (String[] args)
    {
	System.out.println("(byte)NaN                 = " + (byte)Double.NaN);
	System.out.println("(byte)POSITIVE_INFINITY   = " + (byte)Double.POSITIVE_INFINITY);
	System.out.println("(byte)NEGATIVE_INFINITY   = " + (byte)Double.NEGATIVE_INFINITY);

	System.out.println("(char)NaN                 = " + (long)(char)Double.NaN);
	System.out.println("(char)POSITIVE_INFINITY   = " + (long)(char)Double.POSITIVE_INFINITY);
	System.out.println("(char)NEGATIVE_INFINITY   = " + (long)(char)Double.NEGATIVE_INFINITY);

	System.out.println("(short)NaN                = " + (short)Double.NaN);
	System.out.println("(short)POSITIVE_INFINITY  = " + (short)Double.POSITIVE_INFINITY);
	System.out.println("(short)NEGATIVE_INFINITY  = " + (short)Double.NEGATIVE_INFINITY);

	System.out.println("(long)NaN                 = " + (long)Double.NaN);
	System.out.println("(long)POSITIVE_INFINITY   = " + (long)Double.POSITIVE_INFINITY);
	System.out.println("(long)NEGATIVE_INFINITY   = " + (long)Double.NEGATIVE_INFINITY);

	System.out.println("(int)NaN                  = " + (int)Double.NaN);
	System.out.println("(int)POSITIVE_INFINITY    = " + (int)Double.POSITIVE_INFINITY);
	System.out.println("(int)NEGATIVE_INFINITY    = " + (int)Double.NEGATIVE_INFINITY);
    }
}
