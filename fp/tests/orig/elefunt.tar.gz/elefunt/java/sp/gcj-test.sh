#! /bin/sh 

PATH=/usr/local/test/bin:$PATH
export PATH

COMMONOBJS="../common/extmath.o ../common/fmt.o ../common/initseed.o ../common/maxtest.o ../common/ranbase.o"

for f in tallsp.o talog.o tasin.o tatan.o texp.o tmachar.o tpower.o tsin.o tsinh.o tsqrt.o ttan.o ttanh.o
do
	g=`basename $f .o`
	gcj -g --encoding=UTF-8 --main=$g -o $g.exe *.o $COMMONOBJS
	ls -l $g.exe
done
