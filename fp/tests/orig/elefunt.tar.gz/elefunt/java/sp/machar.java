/* -*-java-*- machar.java */

import java.io.*;

public class machar
{
    /* Java's floating-point model is required to be a
    platform-independent subset of IEEE 754 arithmetic, so we simply
    define all of the environmental inquiry values as immutable
    constants. */

    public static final int ibeta	= 2;
    public static final int it		= 24;
    public static final int irnd	= 5;
    public static final int ngrd	= 0;
    public static final int machep	= -23;
    public static final int negep	= -24;
    public static final int iexp	= 8;
    public static final int minexp	= -126;
    public static final int maxexp	= 128;
    public static final float eps	= 1.19209289550781250e-07F;
    public static final float epsneg	= 5.96046447753906250e-08F;
    public static final float xmin	= (float)Math.pow(2.0, -126.0); // NOT Float.MIN_VALUE == 1.40e-45 == Math.pow(2.0F, -149.0F)
    public static final float xmax	= Float.MAX_VALUE;	// 3.40282346638528860e+38F

    public static void main(String[] args)
    {
	System.out.println("ibeta............ " + ibeta);
	System.out.println("it............... " + it);
	System.out.println("irnd............. " + irnd);
	System.out.println("ngrd............. " + ngrd);
	System.out.println("machep........... " + machep);
	System.out.println("negep............ " + negep);
	System.out.println("iexp............. " + iexp);
	System.out.println("minexp........... " + minexp);
	System.out.println("maxexp........... " + maxexp);
	System.out.println("eps.............. " + eps);
	System.out.println("epsneg........... " + epsneg);
	System.out.println("xmin............. " + xmin);
	System.out.println("xmax............. " + xmax);
    }
}
