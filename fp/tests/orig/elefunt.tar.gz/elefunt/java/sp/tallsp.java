/* -*-java-*- tallsp.java */

public class tallsp
{
    public static void main(String[] args)
    {
	talog.talog();
	tasin.tasin();
	tatan.tatan();
	texp.texp();
	tmachar.tmachar();
	tpower.tpower();
	tsin.tsin();
	tsinh.tsinh();
	tsqrt.tsqrt();
	ttan.ttan();
	ttanh.ttanh();
    }
}
