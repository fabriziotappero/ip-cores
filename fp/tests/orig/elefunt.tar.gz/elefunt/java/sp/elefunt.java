/* -*-java-*- elefunt.java */

import java.io.*;
import java.lang.Math;

public final class elefunt
{
    // VERSION and DATE must be updated with every change!
    public static final String VERSION = "1.00";
    public static final String DATE = "Wed May 29 19:21:35 2002";

    public static final int MAXTEST = 2000;
    public static final float ONE = 1.0F;
    public static final float ZERO = 0.0F;
    public static final float TWO = 2.0F;
    public static final float TEN = 10.0F;

    public static float ABS(float x)			{ return ((float)Math.abs(x)); }
    public static float AINT(float x)			{ return ((float)((long)x)); }
    public static float ACOS(float x)			{ return ((float)Math.acos(x)); }
    public static float ALOG(float x)			{ return ((float)Math.log(x)); }
    public static float ALOG10(float x)			{ return ((float)extmath.log10(x)); }
    public static float AMAX1(float x, float y)		{ return ((float)Math.max(x,y)); }
    public static float ASIN(float x)			{ return ((float)Math.asin(x)); }
    public static float ATAN(float x)			{ return ((float)Math.atan(x)); }
    public static float ATAN2(float x, float y)		{ return ((float)Math.atan2(x,y)); }
    public static float COS(float x)			{ return ((float)Math.cos(x)); }
    public static float COSH(float x)			{ return ((float)extmath.cosh(x)); }
    public static float COTAN(float x)			{ return ((float)extmath.cotan(x)); }
    public static float EXP(float x)			{ return ((float)Math.exp(x)); }
    public static float FLOOR(float x)			{ return ((float)Math.floor(x)); }
    public static float IPOW(float x,int n)		{ return (ipow.ipow(x,n)); }
    public static float LOG(float x)			{ return ((float)Math.log(x)); }
    public static float LOG10(float x)			{ return ((float)extmath.log10(x)); }
    public static float POW(float x, float y)		{ return ((float)Math.pow(x,y)); }
    public static float RAN()				{ return (ran.ran()); }
    public static float RANDL(float x)			{ return (randl.randl(x)); }
    public static float SIGN(float x, float y)		{ return ((y >= ZERO) ? ABS(x) : -ABS(x)); }
    public static float SIN(float x)			{ return ((float)Math.sin(x)); }
    public static float SINH(float x)			{ return ((float)extmath.sinh(x)); }
    public static float SQRT(float x)			{ return ((float)Math.sqrt(x)); }
    public static float STORE(float x)			{ return (store.store(x)); }
    public static float TAN(float x)			{ return ((float)Math.tan(x)); }
    public static float TANH(float x)			{ return ((float)extmath.tanh(x)); }
    public static float TO_FP_T(float x)		{ return ((float)x); }
    public static float TO_FP_T(int n)			{ return ((float)n); }

    public static int INT(float x)			{ return ((int)(x)); }

    public static float errout(String message)
    {
	System.err.println(message);
	System.out.println(message);
	return (java.lang.Float.NaN);
    }

    public static void banner(String testname)
    {
	System.out.println(" This is " + testname +
			   ": ELEFUNT in Java: version " + elefunt.VERSION +
			   " of " + elefunt.DATE + "\n");
    }
}
