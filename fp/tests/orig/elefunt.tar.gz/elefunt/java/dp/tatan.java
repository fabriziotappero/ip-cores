/* -*-java-*- tatan.java */

import java.io.*;

public class tatan
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static double ABS(double x)			{ return (elefunt.ABS(x)); }
    private static double ALOG(double x)		{ return (elefunt.ALOG(x)); }
    private static double ATAN(double x)		{ return (elefunt.ATAN(x)); }
    private static double AMAX1(double x,double y)	{ return (elefunt.AMAX1(x,y)); }
    private static double ATAN2(double x,double y)	{ return (elefunt.ATAN2(x,y)); }
    private static double IPOW(double x, int n)		{ return (elefunt.IPOW(x,n)); }
    private static double POW(double x,double y)	{ return (elefunt.POW(x,y)); }
    private static double RAN()				{ return (elefunt.RAN()); }
    private static double SQRT(double x)		{ return (elefunt.SQRT(x)); }
    private static double TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    public static void tatan()
    {
	/*
	#     program to test atan, atan2
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following six
	#                 parameters are assigned the values indicated
	#
	#                 ibeta  - the radix of the floating-point system
	#                 it     - the number of base-ibeta digits in the
	#                          significand of a floating-point number
	#                 irnd   - 0 if floating-point addition chops,
	#                          1 if floating-point addition rounds
	#                 minexp - the largest in magnitude negative
	#                          integer such that float(ibeta)**minexp
	#                          is a positive floating-point number
	#                 xmin   - the smallest non-vanishing floating-point
	#                          power of the radix
	#                 xmax   - the largest finite floating-point no.
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#     standard fortran subprograms required
	#
	#         abs, alog, amax1, atan, atan2, float, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	#*/

	final double ait = TO_FP_T(machar.it);
	final double beta = TO_FP_T(machar.ibeta);
	final double albeta = ALOG(beta);
	final double eight = 8.0e0;
	final double half = 0.5e0;
	final double tenth = 0.1e0;
	final double ONE = elefunt.ONE;
	final double TWO = elefunt.TWO;
	final double ZERO = elefunt.ZERO;

	int i,
	    k,
	    j,
	    k1,
	    k2,
	    k3,
	    n;

	double
	    a,
	    b,
	    betap,
	    del,
	    em,
	    expon,
	    ob32,
	    r6,
	    r7,
	    sum,
	    w,
	    x,
	    xl,
	    xn,
	    xsq,
	    x1,
	    y,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("tatan");

	ran.ranset(initseed.initseed());

	a = -0.0625e0;
	b = -a;
	ob32 = b * half;
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);

	/* random argument accuracy tests */

	for (j = 1; j <= 4; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;
		if (j == 2)
		    x = ((1.0e0 + x * a) - ONE) * 16.0e0;
		z = ATAN(x);
		if (j == 1)
		{
		    xsq = x * x;
		    em = 17.0e0;
		    sum = xsq / em;

		    for (k = 1; k <= 7; ++k)
		    {
			em = em - TWO;
			sum = (ONE / em - sum) * xsq;
		    }

		    sum = -x * sum;
		    zz = x + sum;
		    sum = (x - zz) + sum;
		    if (machar.irnd == 0)
			zz = zz + (sum + sum);
		}
		else
		if (j != 2)
		{
		    z = z + z;
		    y = x / ((half + x * half) * ((half - x) + half));
		    zz = ATAN(y);
		}
		else
		{
		    y = x - 0.0625e0;
		    y = y / (ONE + x * a);
		    zz = (ATAN(y) - 8.1190004042651526021e-5) + ob32;
		    zz = zz + ob32;
		}
		w = ONE;
		if (z != ZERO)
		    w = (z - zz) / z;
		if (w > ZERO)
		    k1 = k1 + 1;
		if (w < ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = xl + del;
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);
	    if (j == 1)
		System.out.print("1TEST OF ATAN(X) VS TRUNCATED TAYLOR SERIES\n\n");
	    else if (j == 2)
		System.out.print(
		"1TEST OF ATAN(X) VS ATAN(1/16) + ATAN((X-1/16)/(1+X/16))\n\n");
	    else if (j > 2)
		System.out.print("1TEST OF 2*ATAN(X) VS ATAN(2X/(1-X*X))\n\n");
	    System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
	    System.out.print(" ATAN(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
	    System.out.print("             AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
	    System.out.print("        WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n");
	    System.out.print(" THERE ARE" + fmt.I(machar.it,4) + " BASE" +  fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n");
	    w = -999.0e0;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF" + fmt.E(r6,15,4) + " = " +
			     fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS" + fmt.E(r7,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    a = b;
	    if (j == 1)
		b = TWO - SQRT(3.0e0);
	    else if (j == 2)
		b = SQRT(TWO) - ONE;
	    else if (j == 3)
		b = ONE;
	}

	/* special tests */

	System.out.print("1SPECIAL TESTS\n\n");
	System.out.print(" THE IDENTITY   ATAN(-X) = -ATAN(X)   WILL BE TESTED.\n\n\n");
	System.out.print("        X         F(X) + F(-X)\n\n");
	a = 5.0e0;

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * a;
	    z = ATAN(x) + ATAN(-x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print(" THE IDENTITY ATAN(X) = X , X SMALL, WILL BE TESTED.\n\n\n");
	System.out.print("        X         X - F(X)\n\n");
	betap = IPOW(beta, machar.it);
	x = RAN() / betap;

	for (i = 1; i <= 5; ++i)
	{
	    z = x - ATAN(x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	    x = x / beta;
	}

	System.out.print(" THE IDENTITY ATAN(X/Y) = ATAN2(X,Y) WILL BE TESTED\n");
	System.out.print(" THE FIRST COLUMN OF RESULTS SHOULD BE 0, THE SECOND +-PI\n\n");
	System.out.print("        X             Y     F1(X/Y)-F2(X,Y)F1(X/Y)-F2(X/(-Y))\n");
	a = -TWO;
	b = 4.0e0;

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * b + a;
	    y = RAN();
	    w = -y;
	    z = ATAN(x / y) - ATAN2(x, y);
	    zz = ATAN(x / w) - ATAN2(x, w);
	    System.out.print(fmt.E(x,15,7) + fmt.E(y,15,7) + fmt.E(z,15,7) + fmt.E(zz,15,7) + "\n\n");
	}

	System.out.print(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
	expon = TO_FP_T(machar.minexp) *0.75e0;
	x = POW(beta, expon);
	y = ATAN(x);
	System.out.print("       ATAN(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n");

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	System.out.print(" ATAN WILL BE CALLED WITH THE ARGUMENT" + fmt.E(machar.xmax,15,7) + "\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = ATAN(machar.xmax);
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: ATAN(" + machar.xmax + ") raised " + e);
	}
	System.out.print("       ATAN(" + fmt.E(machar.xmax,13,6) + ") =" + fmt.E(z,13,6) + "\n");

	x = ONE;
	y = ZERO;
	System.out.print(" ATAN2 WILL BE CALLED WITH THE ARGUMENTS\n" + fmt.E(x,15,7) + fmt.E(y,15,7) + "\n\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = ATAN2(x, y);
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: ATAN2(" + x + "," + y + ") raised " + e);
	}
	System.out.print("       ATAN2(" + fmt.E(x,13,6) + fmt.E(y,13,6) + ") =" + fmt.E(z,13,6) + "\n");

	System.out.print(" ATAN2 WILL BE CALLED WITH THE ARGUMENTS\n" + fmt.E(machar.xmin,15,7) +
			 fmt.E(machar.xmax,15,7) + "\n\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");

	try
	{
	    z = ATAN2(machar.xmin, machar.xmax);
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: ATAN2(" + machar.xmin + "," + machar.xmax + ") raised " + e);
	}
	System.out.print("       ATAN2(" + fmt.E(machar.xmin,13,6) +
			 fmt.E(machar.xmax,13,6) + ") =" + fmt.E(z,13,6) + "\n");

	System.out.print(" ATAN2 WILL BE CALLED WITH THE ARGUMENTS\n" + fmt.E(machar.xmax,15,7) +
			 fmt.E(machar.xmin,15,7) + "\n\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = ATAN2(machar.xmax, machar.xmin);
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: ATAN2(" + machar.xmax + "," + machar.xmin + ") raised " + e);
	}
	System.out.print("       ATAN2(" + fmt.E(machar.xmax,13,6) +
			 fmt.E(machar.xmin,13,6) + ") =" + fmt.E(z,13,6) + "\n");

	x = ZERO;
	System.out.print(" ATAN2 WILL BE CALLED WITH THE ARGUMENTS\n" + fmt.E(x,15,7) + fmt.E(y,15,7) + "\n\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = ATAN2(x, y);
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: ATAN2(" + x + "," + y + ") raised " + e);
	}
	System.out.print("       ATAN2(" + fmt.E(x,13,6) + fmt.E(y,13,6) + ") =" + fmt.E(z,13,6) + "\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	tatan();
    }
}
