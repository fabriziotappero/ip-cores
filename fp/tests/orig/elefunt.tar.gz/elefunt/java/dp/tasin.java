/* -*-java-*- tasin.java */

import java.io.*;

public class tasin
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static double ABS(double x)			{ return (elefunt.ABS(x)); }
    private static double ACOS(double x)		{ return (elefunt.ACOS(x)); }
    private static double ALOG(double x)		{ return (elefunt.ALOG(x)); }
    private static double ALOG10(double x)		{ return (elefunt.ALOG10(x)); }
    private static double ASIN(double x)		{ return (elefunt.ASIN(x)); }
    private static double AMAX1(double x,double y)	{ return (elefunt.AMAX1(x,y)); }
    private static double IPOW(double x, int n)		{ return (elefunt.IPOW(x,n)); }
    private static double POW(double x,double y)	{ return (elefunt.POW(x,y)); }
    private static double RAN()				{ return (elefunt.RAN()); }
    private static double SQRT(double x)		{ return (elefunt.SQRT(x)); }
    private static double TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    public static void tasin()
    {
	/*
	#     program to test asin/acos
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following four
	#                 parameters are assigned the values indicated
	#
	#                 ibeta  - the radix of the floating-point system
	#                 it     - the number of base-ibeta digits in the
	#                          significand of a floating-point number
	#                 irnd   - 0 if floating-point addition chops,
	#                          1 if floating-point addition rounds
	#                 minexp - the largest in magnitude negative
	#                          integer such that float(ibeta)**minexp
	#                          is a positive floating-point number
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#
	#     standard fortran subprograms required
	#
	#         abs, acos, alog, alog10, amax1, asin, float, int, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	#*/

	final double ait = TO_FP_T(machar.it);
	final double beta = TO_FP_T(machar.ibeta);
	final double albeta = ALOG(beta);
	final double eight = 8.0e0;
	final double half = 0.5e0;
	final double tenth = 0.1e0;
	final double ONE = elefunt.ONE;
	final double ZERO = elefunt.ZERO;

	int i,
	    iexp,
	    j,
	    k,
	    k1,
	    k2,
	    k3,
	    l,
	    m,
	    n;

	double
	    a,
	    b,
	    betap,
	    c1,
	    c2,
	    del,
	    r6,
	    r7,
	    s,
	    sum,
	    w,
	    x,
	    xl,
	    xm,
	    xn,
	    x1,
	    y,
	    ysq,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("tasin");

	ran.ranset(initseed.initseed());

	k = (int) (ALOG10(IPOW(beta, machar.it))) + 1;
	if (machar.ibeta != 10)
	{
	    c1 = 201.0e0 / 128.0e0;
	    c2 = 4.8382679489661923132e-4;
	}
	else
	{
	    c1 = 1.57e0;
	    c2 = 7.9632679489661923132e-4;
	}
	a = -0.125e0;
	b = -a;
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);
	l = -1;
	z = ZERO;

	/* random argument accuracy tests */

	for (j = 1; j <= 5; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    l = -l;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;
		if (j <= 2)
		{
		    y = x;
		    ysq = y * y;
		}
		else
		{
		    ysq = half - half * ABS(x);
		    x = (half - (ysq + ysq)) + half;
		    if (j == 5)
			x = -x;
		    y = SQRT(ysq);
		    y = y + y;
		}
		sum = ZERO;
		xm = TO_FP_T(k + k + 1);
		if (l > 0)
		    z = ASIN(x);
		if (l < 0)
		    z = ACOS(x);

		for (m = 1; m <= k; ++m)
		{
		    sum = ysq * (sum + 1.0e0 / xm);
		    xm = xm - 2.0e0;
		    sum = sum * (xm / (xm + 1.0e0));
		}

		sum = sum * y;
		if (!((j != 1) && (j != 4)))
		{
		    zz = y + sum;
		    sum = (y - zz) + sum;
		    if (machar.irnd != 1)
			zz = zz + (sum + sum);
		}
		else
		{
		    s = c1 + c2;
		    sum = ((c1 - s) + c2) - sum;
		    zz = s + sum;
		    sum = ((s - zz) + sum) - y;
		    s = zz;
		    zz = s + sum;
		    sum = (s - zz) + sum;
		    if (machar.irnd != 1)
			zz = zz + (sum + sum);
		}
		w = 1.0e0;
		if (z != ZERO)
		    w = (z - zz) / z;
		if (w > ZERO)
		    k1 = k1 + 1;
		if (w < ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = xl + del;
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);
	    if (l < 0)
	    {
		System.out.print("1TEST OF ACOS(X) VS TAYLOR SERIES\n\n");
		System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
		System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
		System.out.print(" ACOS(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("             AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("        WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n");
	    }
	    else
	    {
		System.out.print("1TEST OF ASIN(X) VS TAYLOR SERIES\n\n");
		System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
		System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
		System.out.print(" ASIN(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("             AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("        WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n");
	    }
	    System.out.print(" THERE ARE" + fmt.I(machar.it,4) + " BASE" +
			     fmt.I(machar.ibeta,4) + " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n");
	    w = -999.0e0;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF" + fmt.E(r6,15,4) + " = " +
			     fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS" + fmt.E(r7,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    if (j == 2)
	    {
		a = 0.75e0;
		b = 1.0e0;
	    }
	    if (j == 4)
	    {
		b = -a;
		a = -1.0e0;
		c1 = c1 + c1;
		c2 = c2 + c2;
		l = -l;
	    }
	}

	/* special tests */

	System.out.print("1SPECIAL TESTS\n\n");
	System.out.print(" THE IDENTITY  ASIN(-X) = -ASIN(X)  WILL BE TESTED.\n\n");
	System.out.print("        X         F(X) + F(-X)\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * a;
	    z = ASIN(x) + ASIN(-x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print(" THE IDENTITY ASIN(X) = X , X SMALL, WILL BE TESTED.\n\n");
	System.out.print("        X         X - F(X)\n");
	betap = IPOW(beta, machar.it);
	x = RAN() / betap;

	for (i = 1; i <= 5; ++i)
	{
	    z = x - ASIN(x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	    x = x / beta;
	}

	System.out.print(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
	x = POW(beta, TO_FP_T(machar.minexp) * 0.75e0);
	y = ASIN(x);
	System.out.print("       ASIN(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	x = 1.2e0;
	System.out.print(" ASIN WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = ASIN(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: ASIN(" + x + ") RAISED " + e);
	}

	System.out.print(" ASIN RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	tasin();
    }
}
