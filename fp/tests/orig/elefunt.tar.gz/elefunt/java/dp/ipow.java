/* -*-java-*- ipow.java */

import java.lang.Math;

public class ipow
{
    public static double ipow(double x, int n)
    {
	double value;
	int k;

	value = 1.0;
	for (k = 1; k <= Math.abs(n); ++k)
	    value *= x;
	if (n < 0)
	    value = 1.0 / value;
	return (value);
    }
}
