/* -*-java-*- fmtflt.java */

// NB: The comments in this file conform rudimentarily to javadoc
// conventions, and the HTML files produced by "javadoc fmtflt.java"
// are reasonably usable.  However, more details are likely desirable.

// TO-DO:
// (1) Perhaps add support for Fortran 90 ENw.d[Ee] (engineering)
//     formatting: exponent is divisible by three, and absolute value of
//     significand is in [1,1000).  (I have personally never had any use
//     for this item, nor ever encountered it in practical use in
//     existing Fortran code).

/**
 * The <code>fmtflt</code> class provides an extended set of
 * floating-point formatting functions to fill a serious gap in the
 * offerings of the Java libraries: namely, the inability to control
 * field width, sign, digit grouping, precision, exponential vs. fixed
 * notation, and justification in numeric output.
 *
 * <p>
 *
 * This class file contains a built-in validation suite, easily run in
 * most UNIX-like Java implementations like this:
 *
 * <pre>
 *    javac fmtflt.java && java fmtflt && diff okay/fmtflt.lst -
 * </pre>
 *
 * or, better, as part of a larger validation suite:
 *
 * <pre>
 *    make check
 * </pre>
 *
 * <p>
 *
 * These functions require the companion <code>extmath</code> and
 * <code>fmtint</code> classes, plus the standard
 * <code>java.lang.Float</code>, <code>java.lang.Double</code>,
 * <code>java.lang.Math</code>, and <code>java.lang.String</code>
 * classes from JDK 1.0 or later.  None of the functions used are
 * deprecated in any of the Java levels 1.0, 1.1, 1.2, 1.3, or 1.4.
 *
 * <p>
 *
 * These functions are modelled on the Fortran 66/77/90/95/HPF
 * <code>Fw[.d]</code>, <code>Dw.d[Ee]</code>, <code>Ew.d[Ee]</code>,
 * and <code>Gw.d[Ee]</code> <code>FORMAT</code> items, and the
 * corresponding C/C++ <code>printf()</code> <code>%w[.d]f</code>,
 * <code>%w[.d]g</code>, and <code>%w[.d]e</code> format items, with
 * additional inspiration from the Ada programming language.
 *
 * <p>
 *
 * However, unlike Fortran, whose punched-card legacy views column
 * alignment of greater importance than correct output, filling fields
 * with asterisks when they are too short to contain the numeric value,
 * in these functions, field widths automatically expand to contain
 * the value (just as format items in the C <code>printf()</code>
 * family do).
 *
 * <p>
 *
 * Output values are rounded to nearest: rounding occurs if the first
 * omitted digit is 5 or greater.
 *
 * <p>
 *
 * Signed zero, NaN, and signed Infinity are all recognized and
 * supported.  Sadly, standard Java classes in implementations before
 * JDK 1.4 cannot input NaN and Infinity, even though they can output
 * those values.  All Java implementations that I have tested handle
 * signed zero correctly.
 *
 * <p>
 *
 * These functions make it much easier to translate existing Fortran
 * and C/C++ code into Java: compare these statements:
 *
 * <pre>
 *        write (6,'(f14.3, 2x, e15.4, 2x, g15.4)') x, y, z
 *        (void)printf("%14.3f  %15.4e  15.4g\n", x, y, z)
 *        System.out.println(fmtflt.F(x,14,3) +
 *                           "  " + fmtflt.E(y,15.4) +
 *                           "  " + fmtflt.G(z,15.4));
 * </pre>
 *
 * <p>
 *
 * <b>Limitations</b>: These functions build upon the
 * <code>fmtinit.convertLong()</code> functions, and thus, the number of
 * figures that can be output is limited to scaled numbers that can be
 * represented as Java 64-bit <code>long</code> integers.  While this
 * is sufficient for Java 32-bit <code>float</code> and 64-bit
 * <code>double</code> data types, it does limit the fractional digit
 * field widths to at most 17 decimal digits.  Requests for more digits
 * will be silently reduced to that limit.  This restriction could be
 * lifted in the future by fancier scaling, or use of multiple-precision
 * arithmetic, or reimplementation of the digit conversion in
 * floating-point arithmetic, but it is unlikely to be of practical
 * significance for most numerical applications, and particularly for
 * the translation of existing numerical Fortran, C, or C++ code to
 * Java.
 * <p>
 *
 * @author Nelson H. F. Beebe, Department of Mathematics, University of Utah, Salt Lake City, UT 84112-0090, USA
 * @version 1.00, [03-Jun-2002]
 * @since   JDK1.0
 */

/*
 * Here is a list of the public methods in class fmtint:
 *
 * public static String convertDouble(double number, int width,
 *				      int fractional_digits,
 *				      int exponent_digits,
 *				      boolean require_sign, char leading_pad,
 *				      char separator, int ngroup)
 *
 * public static String convertDouble(double number, int width,
 *				      int fractional_digits)
 *
 * public static String convertDouble(double number, int width,
 *				      int fractional_digits,
 *				      int exponent_digits)
 *
 * public static String convertDouble(double number, int width,
 *				      int fractional_digits,
 *				      int exponent_digits,
 *				      boolean require_sign)
 *
 * public static String convertFloat(float number, int width,
 *				     int fractional_digits,
 *				     int exponent_digits,
 *				     boolean require_sign, char leading_pad,
 *				     char separator, int ngroup)
 *
 * public static String convertFloat(float number, int width,
 *				     int fractional_digits)
 *
 * public static String convertFloat(float number, int width,
 *				     int fractional_digits,
 *				     int exponent_digits)
 *
 * public static String convertFloat(float number, int width,
 *				     int fractional_digits,
 *				     int exponent_digits,
 *				     boolean require_sign)
 *
 * public static String E(double number)
 *
 * public static String E(double number, int width)
 *
 * public static String E(double number, int width, int fractional_digits)
 *
 * public static String E(double number, int width, int fractional_digits,
 *                        int exponent_digits, int ngroup)
 *
 * public static String F(double number)
 *
 * public static String F(double number, int width)
 *
 * public static String F(double number, int width, int fractional_digits)
 *
 * public static String F(double number, int width, int fractional_digits,
 *                        int ngroup)
 *
 * public static String G(double number)
 *
 * public static String G(double number, int width)
 *
 * public static String G(double number, int width, int total_digits)
 *
 * public static String G(double number, int width, int total_digits,
 *                        int exponent_digits)
 *
 * public static String G(double number, int width, int total_digits,
 *                        int exponent_digits, int ngroup)
 *
 * public static String E(float number)
 *
 * public static String E(float number, int width)
 *
 * public static String E(float number, int width, int fractional_digits)
 *
 * public static String E(float number, int width, int fractional_digits,
 *                        int exponent_digits)
 *
 * public static String E(float number, int width, int fractional_digits,
 *                        int exponent_digits, int ngroup)
 *
 * public static String F(float number)
 *
 * public static String F(float number, int width)
 *
 * public static String F(float number, int width, int fractional_digits)
 *
 * public static String F(float number, int width, int fractional_digits,
 *                        int ngroup)
 *
 * public static String G(float number)
 *
 * public static String G(float number, int width)
 *
 * public static String G(float number, int width, int total_digits)
 *
 * public static String G(float number, int width, int total_digits,
 *                        int exponent_digits)
 *
 * public static String G(float number, int width, int total_digits,
 *                        int exponent_digits, int ngroup)
 *
 */

public class fmtflt
{
    // Private data and functions for the class implementation

   /**
    * Named character constants.
    */
    private static final char ADA_SEPARATOR = '_';
    private static final char DECIMAL_POINT = '.';
    private static final char LEADING_BLANK = ' ';
    private static final char[] DIGITS =
    {
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
    };

   /**
    * Named double-precision floating-point constants.
    */
    private static final double TENTH =  0.1;
    private static final double ZERO  =  0.0;
    private static final double HALF  =  0.5;
    private static final double ONE   =  1.0;
    private static final double TWO   =  2.0;
    private static final double FIVE  =  5.0;
    private static final double TEN   = 10.0;

   /**
    * Named single-precision floating-point constants.
    *
    */
    private static final float TENTH_F = 0.1F;
    private static final float ZERO_F  = 0.0F;
    private static final float HALF_F =  0.5F;
    private static final float ONE_F   = 1.0F;
    private static final float FIVE_F  = 5.0F;
    private static final float TEN_F  = 10.0F;

   /**
    * Return a <code>String</code> containing exactly <code>n</code>
    * copies of the <code>fill</code> character.
    *
    * @param	fill	the fill character.
    * @param	n	length of returned string.
    * @return	String of fill characters.
    */
    private static String fill_string(char fill, int n)
    {
	// The String class unfortunately lacks a constructor to do this, sigh...

	if (n < 0)
	    n = 0;

	StringBuffer buf = new StringBuffer(n);

	buf.setLength(n);
	for (int k = 0; k < n; ++k)
	    buf.setCharAt(k,fill);
	return (buf.toString());
    }

   /**
    * Convert <code>number</code> to a decimal string representation
    * matching one of the regular expressions
    * <code>[-+]?[0-9]*[.][0-9]+</code> or
    * <code>[-+]?[0-9]+[.][0-9]*</code>, where <code>number</code> is
    * guaranteed to be finite (that is, neither signed Infinity, nor
    * NaN), and of sufficiently modest size that it can be represented
    * without an exponent field.  <b>WARNING: Neither of these
    * requirements is checked for, and nonsense output will be
    * produced if they are not satisfied!</b>
    *
    * <p>
    *
    * The string will be contained in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * digits after the decimal point.
    *
    * <p>
    *
    * The field is filled, if needed, on the left with
    * <code>leading_pad</code> characters, and a sign which is
    * mandatory if <code>require_sign</code> is true, and otherwise
    * supplied only if the number is negative.
    *
    * <p>
    *
    * Digits in the integer and fractional part are optionally separated
    * by <code>separator</code> (typically, the culture-neutral
    * underscore, or culture-dependent comma) in groups of
    * <code>ngroup</code> digits, counting from the right.  Grouping is
    * suppressed if <code>ngroup</code> &lt;= 0.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	require_sign	<code>true</code> if a leading sign is required, else <code>false</code>.
    * @param	leading_pad	Character used to fill leading empty positions.
    * @param	separator	Character used to separate digits for readability.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    private static String convertFixed(double number, int width, int fractional_digits,
				       boolean require_sign, char leading_pad,
				       char separator, int ngroup)
    {
	// sanitize the input
	width = (int)Math.max(0, width);
	ngroup = (int)Math.max(0,Math.min(ngroup, 25));	// limit so that scaling below works

	boolean is_negative;
	boolean have_carry = false;
	boolean is_negative_zero = extmath.isNegativeZero(number);
	double scaled_number;
	int dot_after = fractional_digits;
	int extra_powers_of_ten = 0;
	int nphantom;
	String sign;

	if (separator == DECIMAL_POINT) // otherwise conflicts with dotPos processing below
	    separator = '_';

	is_negative = (number < ZERO);
	if (is_negative)
	    number = -number;

	// In order to handle negative zero properly, we need to construct
	// the sign separately; otherwise, -0.0 would become 0L in the call
	// to fmtint.convertLong(...) below, losing the sign.
	if (is_negative || is_negative_zero)
	    sign = "-";
	else if (require_sign)
	    sign = (is_negative ? "-" : "+");
	else
	    sign = "";

	double power_of_10_scaling = pow10(fractional_digits);

	if (number > ((double)Long.MAX_VALUE / power_of_10_scaling))
	{
	    // Need a second rescaling to ensure that we have a representable
	    // integer to pass to convertLong().
	    extra_powers_of_ten = (int)Math.ceil(extmath.log10(number /
							       ((double)Long.MAX_VALUE / power_of_10_scaling)));

	    if (ngroup > 0)	// ensure extra_powers_of_ten % ngroup == 0 to preserve grouping
		extra_powers_of_ten = ngroup * ((extra_powers_of_ten + ngroup - 1)/ngroup);

	    dot_after -= extra_powers_of_ten;
	    scaled_number = number * pow10(fractional_digits - extra_powers_of_ten);
	    have_carry = false;
	}
	else
	{
	    scaled_number = number * power_of_10_scaling; // NB: scaled_number >= -0.0
	    double fraction = scaled_number - (long)scaled_number;
	    have_carry = (fraction >= HALF);
	}

	// When fractional_digits is not a multiple of ngroup, we need phantom digits
	// to ensure that grouping is from the left, instead of from the right.
	if (ngroup == 0)
	    nphantom = 0;
	else
	    nphantom = ngroup * ((fractional_digits + ngroup - 1)/ngroup) - fractional_digits;

	String s = fmtint.convertLong((long)scaled_number, 10, 0,
				      fractional_digits + 1, false,
				      false, false, leading_pad,
				      separator, ngroup, nphantom,
				      dot_after, have_carry);

	if (ngroup > 0)
	{
	    // When grouping is enabled, we get a return value like
	    // "987_654_321_.123_456_789", so we have to filter out
	    // the unwanted separator before the decimal point.  We
	    // cannot just convert the integer and fractional parts
	    // separately, because that loses the critical have_carry
	    // information.
	    int dotPos;

	    dotPos = s.indexOf(DECIMAL_POINT);
	    if ((dotPos > 0) && (s.charAt(dotPos-1) == separator))
		s = s.substring(0,dotPos-1) + s.substring(dotPos);
	}

	if (extra_powers_of_ten > 0)
	{	// need to add extra_powers_of_ten trailing zeros, properly grouped
	    int group_count = 0;
	    if (ngroup > 0)
	    {
		group_count = fractional_digits % ngroup;
		if (group_count == 0)
			group_count = ngroup;
	    }
	    for (int k = 0; k < extra_powers_of_ten; ++k)
	    {
		if ((ngroup > 0) && (group_count == ngroup))
		{
		    s = s + separator;
		    group_count = 0;
		}
		s = s + '0';
		group_count++;
	    }
	}

	return (fmtint.rightJustify(sign + strip_leading_zeros(s,separator),
				    width));
    }

   /**
    * Return the value (2.0 to the power <code>n</code>).
    *
    * @param	n	The exponent.
    * @return	2.0 to the power <code>n</code>.
    */
    private static double pow2(int n) // used only in testing
    {
	return (Math.pow(TWO,n));
    }

    // The commented-out code here and in pow10() implements a cache of
    // integer powers-of-ten.  Timing tests with and without the cache
    // detected no significant difference for the validation suite, with
    // identical output in both cases, so we disable it for now.

    // private static final int npowers = 308 + 1 + 308;
    // private static double[] powers_of_ten = new double [npowers];

   /**
    * Return the value (10.0 to the power <code>n</code>).
    *
    * @param	n	The exponent.
    * @return	10.0 to the power <code>n</code>.
    */
    private static double pow10(int n)
    {
	//	// fancy version with caching
	// 	int k = n + 308;
	// 	if (true && (0 <= k) && (k < npowers))
	// 	{
	// 	    if (powers_of_ten[k] == 0.0)
	// 		powers_of_ten[k] = Math.pow(TEN,n);
	// 	    return powers_of_ten[k];
	// 	}
	// 	else
	return (Math.pow(TEN,n));
    }

   /**
    * Return a copy of <code>s</code> with non-floating-point
    * characters removed.
    *
    * @param	s	Input string.
    * @return	Copy of <code>s</code> with non-floating-point
    *		characters removed.
    */
    private static String squeeze(String s)
    {
	// Squeeze out non-floating-point characters from a copy of s
	char[] buf = new char [s.length()];
	int ib = 0;
	for (int is = 0; is < s.length(); ++is)
	{
	    char c = s.charAt(is);
	    if ((c == '+') || (c == '-') || (c == DECIMAL_POINT) || (c == 'e') ||
		Character.isDigit(c))
		buf[ib++] = c;
	}
	return (new String(buf, 0, ib));
    }

   /**
    * Return a copy of <code>s</code> with leading blanks, zeros and
    * <code>separator</code> characters removed.  However, a zero
    * immediately before a dot (decimal point) is preserved.
    *
    * @param	s	Input string.
    * @param	separator	Separator character.
    * @return	Copy of <code>s</code> with leading blanks, zeros and
    *		<code>separator</code> characters removed.
    */
    private static String strip_leading_zeros(String s, char separator)
    {
	int k;

	for (k = 0; k < s.length(); ++k)
	{
	    char c = s.charAt(k);
	    if (c == ' ')
		continue;
	    else if (c == separator)
		continue;
	    else if ((c == '0') &&
		     (k < (s.length() - 1)) && (s.charAt(k+1) != DECIMAL_POINT))
		continue;
	    else
		break;
	}
	return ((k < s.length()) ? s.substring(k) : "");
    }

    // Public methods

   /**
    * Convert <code>number</code> to a decimal string representation.
    * This function serves as the core of several much-simpler-to-use
    * functions that provide for conversion of binary double-precision
    * floating-point values to string representations.
    *
    * <p>
    *
    * The string will be contained in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * digits after the decimal point.
    *
    * <p>
    *
    * The number of digits in the exponent field is
    * <code>exponent_digits</code>.  If that value is zero, the
    * exponent field is omitted, and fixed formatting (e.g., 1.234) is
    * used instead.
    *
    * <p>
    *
    * The field is filled, if needed, on the left with
    * <code>leading_pad</code> characters, and a sign which is
    * mandatory if <code>require_sign</code> is true, and otherwise
    * supplied only if the number is negative.
    *
    * <p>
    *
    * Digits in the integer and fractional part are optionally separated
    * by <code>separator</code> (typically, the culture-neutral
    * underscore, or culture-dependent comma) in groups of
    * <code>ngroup</code> digits, counting from the right.  Grouping is
    * suppressed if <code>ngroup</code> &lt;= 0.
    *
    * <p>
    *
    * Simpler-to-use functions of the same name, but with fewer
    * arguments, are available: the first three arguments are
    * mandatory, but you may omit trailing arguments after the last
    * one needed.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	require_sign	<code>true</code> if a leading sign is required, else <code>false</code>.
    * @param	leading_pad	Character used to fill leading empty positions.
    * @param	separator	Character used to separate digits for readability.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String convertDouble(double number, int width,
				       int fractional_digits,
				       int exponent_digits,
				       boolean require_sign, char leading_pad,
				       char separator, int ngroup)
    {
	// sanitize the input
	width = (int)Math.max(0, width);
	ngroup = (int)Math.max(0, ngroup);

	if (Double.isNaN(number))
	    return (fmtint.rightJustify("NaN",width));
	else if (number == Double.POSITIVE_INFINITY)
	    return (fmtint.rightJustify((require_sign ? "+" : "") + "Infinity",width));
	else if (number == Double.NEGATIVE_INFINITY)
	    return (fmtint.rightJustify("-Infinity",width));
	else if (exponent_digits > 0) // want exponential notation: 1.2345e+123
	{
	    int exponent_value;
	    double abs_number = Math.abs(number);
	    if (abs_number == ZERO)
		exponent_value = 0;
	    else
		exponent_value = (int)Math.floor(extmath.log10(abs_number));

	    double scaled_number;
	    int half_exponent_value = exponent_value / 2;

	    // If number is subnormal, then 10^exponent_value overflows,
	    // so we need to do the scaling in two steps.  If number is
	    // near MAX_VALUE in magnitude, then 10^exponent_value does
	    // not underflow, so no special additional care is needed at
	    // that end of the floating-point number range.
	    scaled_number = number * pow10(-half_exponent_value);
	    scaled_number *= pow10(-(exponent_value - half_exponent_value));

	    // test_println("DEBUG: scaled_number = " + scaled_number +
	    //              " number = " + number + " exponent_value = " + exponent_value);

	    String s = convertFixed(scaled_number, 0, fractional_digits, require_sign,
				    leading_pad, separator, ngroup);

	    // There is a final special case to consider: if rounding
	    // causes a carry to occur from the input high-order
	    // digit, then an extra output leading digit will be
	    // generated, e.g., "9.50e+10" -> "10.e+10", whereas we
	    // want to have "1.e+11".  It is unacceptable design to
	    // have a global carry flag in another class to maintain
	    // and query, so we simply check for such overflow by
	    // examining the returned string, and redo the computation
	    // with an extra scaling step if necessary.

	    int dotPos = s.indexOf(DECIMAL_POINT);
	    if ( (dotPos > 1) && Character.isDigit(s.charAt(dotPos-2)) )
	    {
		scaled_number /= TEN;
		exponent_value++;
		s = convertFixed(scaled_number, 0, fractional_digits, require_sign,
				 leading_pad, separator, ngroup);
	    }
	    return (fmtint.rightJustify(s + "e" + fmtint.convertLong(exponent_value, 10,
								     1 + exponent_digits,
								     exponent_digits,
								     true, false, false,
								     ' ', ' ', 0),
					width));
	}
	else			// want fixed notation: 1.2345
	    return (fmtint.rightJustify(convertFixed(number, 0, fractional_digits,
						     require_sign, leading_pad,
						     separator, ngroup), width));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String convertDouble(double number, int width,
				       int fractional_digits)
    {
	return (convertDouble(number, width, fractional_digits, 0));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String convertDouble(double number, int width,
				       int fractional_digits,
				       int exponent_digits)
    {
	return (convertDouble(number, width, fractional_digits,
			      exponent_digits, false));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	require_sign	<code>true</code> if a leading sign is required, else <code>false</code>.
    * @return	String containing the converted number.
    */
    public static String convertDouble(double number, int width,
				       int fractional_digits,
				       int exponent_digits,
				       boolean require_sign)
    {
	return (convertDouble(number, width, fractional_digits,
			      exponent_digits, require_sign, ' ', ' ', 0));
    }

   /**
    * Convert <code>number</code> to a decimal string representation.
    * This function serves as the core of several much-simpler-to-use
    * functions that provide for conversion of binary single-precision
    * floating-point values to string representations.
    *
    * <p>
    *
    * The string will be contained in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * digits after the decimal point.
    *
    * <p>
    *
    * The number of digits in the exponent field is
    * <code>exponent_digits</code>.  If that value is zero, the
    * exponent field is omitted, and fixed formatting (e.g., 1.234) is
    * used instead.
    *
    * <p>
    *
    * The field is filled, if needed, on the left with
    * <code>leading_pad</code> characters, and a sign which is
    * mandatory if <code>require_sign</code> is true, and otherwise
    * supplied only if the number is negative.
    *
    * <p>
    *
    * Digits in the integer and fractional part are optionally separated
    * by <code>separator</code> (typically, the culture-neutral
    * underscore, or culture-dependent comma) in groups of
    * <code>ngroup</code> digits, counting from the right.  Grouping is
    * suppressed if <code>ngroup</code> &lt;= 0.
    *
    * <p>
    *
    * Simpler-to-use functions of the same name, but with fewer
    * arguments, are available: the first three arguments are
    * mandatory, but you may omit trailing arguments after the last
    * one needed.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	require_sign	<code>true</code> if a leading sign is required, else <code>false</code>.
    * @param	leading_pad	Character used to fill leading empty positions.
    * @param	separator	Character used to separate digits for readability.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String convertFloat(float number, int width,
				      int fractional_digits,
				      int exponent_digits,
				      boolean require_sign, char leading_pad,
				      char separator, int ngroup)
    {
	// sanitize the input
	width = (int)Math.max(0, width);
	ngroup = (int)Math.max(0, ngroup);

	if (Float.isNaN(number))
	    return (fmtint.rightJustify("NaN",width));
	else if (number == Float.POSITIVE_INFINITY)
	    return (fmtint.rightJustify((require_sign ? "+" : "") + "Infinity",width));
	else if (number == Float.NEGATIVE_INFINITY)
	    return (fmtint.rightJustify("-Infinity",width));
	else
	    return (convertDouble((double)number, width, fractional_digits, exponent_digits,
				  require_sign, leading_pad, separator, ngroup));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String convertFloat(float number, int width,
				       int fractional_digits)
    {
	return (convertFloat(number, width, fractional_digits, 0));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String convertFloat(float number, int width,
				       int fractional_digits,
				       int exponent_digits)
    {
	return (convertFloat(number, width, fractional_digits,
			     exponent_digits, false));
    }

   /**
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	require_sign	<code>true</code> if a leading sign is required, else <code>false</code>.
    */
    public static String convertFloat(float number, int width,
				       int fractional_digits,
				       int exponent_digits,
				       boolean require_sign)
    {
	return (convertFloat(number, width, fractional_digits,
			     exponent_digits, require_sign, ' ', ' ', 0));
    }

   // Format items for double numbers

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 decimal places, and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String E(double number)
    {
	return (E(number, 0, 6, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 decimal places,
    * and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String E(double number, int width)
    {
	return (E(number, width, 6, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String E(double number, int width, int fractional_digits)
    {
	return (E(number, width, fractional_digits, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and an exponent field of
    * <code>exponent_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String E(double number, int width, int fractional_digits,
			   int exponent_digits)
    {
	return (E(number, width, fractional_digits, exponent_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and an exponent field of
    * <code>exponent_digits</code> digits, grouping digits into
    * <code>ngroup</code> digits, separated by an underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String E(double number, int width, int fractional_digits,
			   int exponent_digits, int ngroup)
    {
	// guarantee that exponent field appears
	exponent_digits = (int)Math.max(1, exponent_digits);

	return (fmtint.rightJustify(convertDouble(number, 0,
						  fractional_digits,
						  exponent_digits,
						  false, LEADING_BLANK,
						  ADA_SEPARATOR, ngroup),
				    width));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 decimal places, and no exponent field.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String F(double number)
    {
	return (F(number, 0, 6));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 decimal places,
    * and no exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String F(double number, int width)
    {
	return (F(number, width, 6));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and no exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String F(double number, int width, int fractional_digits)
    {
	return (F(number, width, fractional_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and no exponent field, grouping digits into
    * <code>ngroup</code> digits, separated by an underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String F(double number, int width, int fractional_digits, int ngroup)
    {
	return (fmtint.rightJustify(convertDouble(number, 0,
						  fractional_digits,
						  0,
						  false, LEADING_BLANK,
						  ADA_SEPARATOR, ngroup),
				    width));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 total digits.  A 3-digit exponent field is provided
    * only if the number cannot be displayed with the same digit count
    * in a suitable F-type format.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String G(double number)
    {
	return (G(number, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 total digits.
    * A 3-digit exponent field is provided only if the number cannot
    * be displayed with the same digit count in a suitable F-type
    * format.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String G(double number, int width)
    {
	return (G(number, width, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * digits.  A 3-digit exponent field is provided only if the number
    * cannot be displayed with the same digit count in a suitable
    * F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @return	String containing the converted number.
    */
    public static String G(double number, int width, int total_digits)
    {
	return (G(number, width, total_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * total digits.  A 3-digit exponent field is provided only if the
    * number cannot be displayed with the same digit count in a
    * suitable F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String G(double number, int width, int total_digits,
			   int exponent_digits)
    {
	return (G(number, width, total_digits, exponent_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * total digits, grouping digits into <code>ngroup</code> digits,
    * separated by an underscore.  An exponent field of
    * <code>exponent_digits</code> digits is provided only if the
    * number cannot be displayed with the same digit count in a
    * suitable F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String G(double number, int width, int total_digits,
			   int exponent_digits, int ngroup)
    {
	double abs_number = Math.abs(number);
	double low, high;

	if (total_digits <= 0)
	    total_digits = 6;

	if (exponent_digits <= 0)
	    exponent_digits = 3;

	// This complex recipe for the choice between F and E formats
	// comes from the Fortran 95 Standard (ISO/IEC 1539-1:1997(E)
	// Information technology - Programming languages - Fortran),
	// Section 10.5.4.1.2, ``Generalized real and complex editing'',
	// p. 171.  See also J. Adams et al, Fortran 95 Handbook, MIT
	// Press, 1997, ISBN 0-262-51096-0, section 10.6.2.6,
	// ``Generalized Editing of Real Data'', p. 393.

	int n = Math.max(4, exponent_digits + 2);

	if (width < (2 + total_digits + n))
	    n = 0;	// width to small for blank padding

	if (abs_number == ZERO_F)
	    return (F(number, width - n, total_digits - 1, ngroup) + fill_string(' ', n));

	low = TENTH - HALF*pow10(-total_digits-1);
	for (int k = 0; k <= total_digits; ++k)
	{
	    high = TEN * low;
	    if ((low <= abs_number) && (abs_number < high))
		return (F(number, width - n, total_digits - k, ngroup) + fill_string(' ', n));
	    low = high;
	}

	return (E(number, width, total_digits - 1, exponent_digits, ngroup));
    }

    // Format items for float numbers

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 decimal places, and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String E(float number)
    {
	return (E(number, 0, 6, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 decimal places,
    * and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String E(float number, int width)
    {
	return (E(number, width, 6, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and a 3-digit exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String E(float number, int width, int fractional_digits)
    {
	return (E(number, width, fractional_digits, 3));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and an exponent field of
    * <code>exponent_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String E(float number, int width, int fractional_digits,
			   int exponent_digits)
    {
	return (E(number, width, fractional_digits, exponent_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and an exponent field of
    * <code>exponent_digits</code> digits, grouping digits into
    * <code>ngroup</code> digits, separated by an underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String E(float number, int width, int fractional_digits,
			   int exponent_digits, int ngroup)
    {
	// guarantee that exponent field appears
	exponent_digits = (int)Math.max(1, exponent_digits);

	return (fmtint.rightJustify(convertFloat(number, 0,
						 fractional_digits,
						 exponent_digits,
						 false, LEADING_BLANK,
						 ADA_SEPARATOR, ngroup),
				    width));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 decimal places, and no exponent field.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String F(float number)
    {
	return (F(number, 0, 6));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 decimal places,
    * and no exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String F(float number, int width)
    {
	return (F(number, width, 6));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and no exponent field.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @return	String containing the converted number.
    */
    public static String F(float number, int width, int fractional_digits)
    {
	return (F(number, width, fractional_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>fractional_digits</code>
    * decimal places, and no exponent field, grouping digits into
    * <code>ngroup</code> digits, separated by an underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	fractional_digits	Number of fractional digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String F(float number, int width, int fractional_digits, int ngroup)
    {
	return (fmtint.rightJustify(convertFloat(number, 0,
						 fractional_digits,
						 0,
						 false, LEADING_BLANK,
						 ADA_SEPARATOR, ngroup),
				    width));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimal width, with a
    * default of 6 total digits.  A 3-digit exponent field is provided
    * only if the number cannot be displayed with the same digit count
    * in a suitable F-type format.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String G(float number)
    {
	return (G(number, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with a default of 6 total digits.
    * A 3-digit exponent field is provided only if the number cannot
    * be displayed with the same digit count in a suitable F-type
    * format.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String G(float number, int width)
    {
	return (G(number, width, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * digits.  A 3-digit exponent field is provided only if the number
    * cannot be displayed with the same digit count in a suitable
    * F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @return	String containing the converted number.
    */
    public static String G(float number, int width, int total_digits)
    {
	return (G(number, width, total_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * total digits.  A 3-digit exponent field is provided only if the
    * number cannot be displayed with the same digit count in a
    * suitable F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @param	exponent_digits	Number of exponent digits.
    * @return	String containing the converted number.
    */
    public static String G(float number, int width, int total_digits,
			   int exponent_digits)
    {
	return (G(number, width, total_digits, exponent_digits, 0));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with <code>total_digits</code>
    * total digits, grouping digits into <code>ngroup</code> digits,
    * separated by an underscore.  An exponent field of
    * <code>exponent_digits</code> digits is provided only if the
    * number cannot be displayed with the same digit count in a
    * suitable F-type format.
    *
    * <p>
    *
    * If <code>total_digits</code> is less than or equal to zero, it
    * is reset to the default of 6.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	total_digits	Total number of digits.
    * @param	exponent_digits	Number of exponent digits.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String G(float number, int width, int total_digits,
			   int exponent_digits, int ngroup)
    {
	float abs_number = Math.abs(number);
	float low, high;

	if (total_digits <= 0)
	    total_digits = 6;

	if (exponent_digits <= 0)
	    exponent_digits = 3;

	// This complex recipe for the choice between F and E formats
	// comes from the Fortran 95 Standard (ISO/IEC 1539-1:1997(E)
	// Information technology - Programming languages - Fortran),
	// Section 10.5.4.1.2, ``Generalized real and complex editing'',
	// p. 171.  See also J. Adams et al, Fortran 95 Handbook, MIT
	// Press, 1997, ISBN 0-262-51096-0, section 10.6.2.6,
	// ``Generalized Editing of Real Data'', p. 393.

	int n = Math.max(4, exponent_digits + 2);

	if (width < (2 + total_digits + n))
	    n = 0;	// width to small for blank padding

	if (abs_number == ZERO_F)
	    return (F(number, width - n, total_digits - 1, ngroup) + fill_string(' ', n));

	low = TENTH_F - HALF_F*(float)pow10(-total_digits-1);
	for (int k = 0; k <= total_digits; ++k)
	{
	    high = TEN_F * low;
	    if ((low <= abs_number) && (abs_number < high))
		return (F(number, width - n, total_digits - k, ngroup) + fill_string(' ', n));
	    low = high;
	}

	return (E(number, width, total_digits - 1, exponent_digits, ngroup));
    }

   /**
    * Return a copy of <code>s</code> with all <code>separator</code>
    * characters removed.
    *
    * This function can be used to reduce numeric strings made more
    * readable by the insertion of separators to something that Java
    * class library functions can parse.
    *
    * @param	s	Input string.
    * @param	separator Separator character.
    * @return	Copy of <code>s</code> with separator characters removed.
    */
    public static String unseparate(String s, char separator)
    {
	int k;
	char[] buf = new char [s.length()];
	int ib = 0;

	for (k = 0; k < s.length(); ++k)
	{
	    char c = s.charAt(k);
	    if (c == separator)
		continue;
	    buf[ib++] = c;
	}
	return (new String(buf, 0, ib));
    }

   /**
    * Return a copy of <code>s</code> with all underscore separator
    * characters removed.
    *
    * This function can be used to reduce numeric strings made more
    * readable by the insertion of separators to something that Java
    * class library functions can parse.
    *
    * @param	s	Input string.
    * @return	Copy of <code>s</code> with underscore separator
    *		characters removed.
    */
    public static String unseparate(String s)
    {
	return (unseparate(s, ADA_SEPARATOR));
    }

    // Private functions for the test suite interface

    private static void test_convertDouble()
    {
	int p = 53;
	double eps = pow2(-p + 1);
	double negeps = pow2(-p);
	double scale_up = ONE + pow2((-p + 1)/2) + eps;
	double scale_down = ONE - pow2(-p/2) - negeps;

	test_newpage();
	test_println("Test of fmtflt.convertDouble(...)\n");

	test_double_once( eps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);
	test_double_once(-eps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);

	test_double_once( negeps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);
	test_double_once(-negeps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);

	test_double_once( 0.000, 0, 4, 0, true, ' ', ' ', 0);
	test_double_once(-0.000, 0, 4, 0, true, ' ', ' ', 0);

	test_double_once( 1.234, 0, 4, 0, true, ' ', ' ', 0);
	test_double_once(-1.234, 0, 4, 0, true, ' ', ' ', 0);

	test_double_once( 1.234e+1, 0, 4, 0, true, ' ', ' ', 0);
	test_double_once(-1.234e+1, 0, 4, 0, true, ' ', ' ', 0);

	test_double_once( 1.234e+12, 0, 4, 0, true, ' ', ' ', 0);
	test_double_once(-1.234e+12, 0, 4, 0, true, ' ', ' ', 0);

	test_double_once( 1.234, 0, 4, 3, true, ' ', ' ', 0);
	test_double_once(-1.234, 0, 4, 3, true, ' ', ' ', 0);

	test_double_once( 1.2344, 0, 3, 0, true, ' ', ' ', 0);
	test_double_once(-1.2344, 0, 3, 0, true, ' ', ' ', 0);

	test_double_once( 1.234499999999999, 0, 3, 0, true, ' ', ' ', 0);
	test_double_once(-1.234499999999999, 0, 3, 0, true, ' ', ' ', 0);

	test_double_once( 1.2345, 0, 3, 0, true, ' ', ' ', 0);
	test_double_once(-1.2345, 0, 3, 0, true, ' ', ' ', 0);

	test_double_once( 1.2345000000000001, 0, 3, 0, true, ' ', ' ', 0);
	test_double_once(-1.2345000000000001, 0, 3, 0, true, ' ', ' ', 0);

	test_double_once( 1.2346, 0, 3, 0, true, ' ', ' ', 0);
	test_double_once(-1.2346, 0, 3, 0, true, ' ', ' ', 0);

	test_double_once( 1.2344, 0, 3, 3, true, ' ', ' ', 0);
	test_double_once(-1.2344, 0, 3, 3, true, ' ', ' ', 0);

	test_double_once( 1.234499999999999, 0, 3, 3, true, ' ', ' ', 0);
	test_double_once(-1.234499999999999, 0, 3, 3, true, ' ', ' ', 0);

	test_double_once( 1.2345, 0, 3, 3, true, ' ', ' ', 0);
	test_double_once(-1.2345, 0, 3, 3, true, ' ', ' ', 0);

	test_double_once( 1.2345000000000001, 0, 3, 3, true, ' ', ' ', 0);
	test_double_once(-1.2345000000000001, 0, 3, 3, true, ' ', ' ', 0);

	test_double_once( 1.2346, 0, 3, 3, true, ' ', ' ', 0);
	test_double_once(-1.2346, 0, 3, 3, true, ' ', ' ', 0);

	test_double_once( 1.234e+1, 0, 4, 3, true, ' ', ' ', 0);
	test_double_once(-1.234e+1, 0, 4, 3, true, ' ', ' ', 0);

	test_double_once( 1.234e+12, 0, 4, 3, true, ' ', ' ', 0);
	test_double_once(-1.234e+12, 0, 4, 3, true, ' ', ' ', 0);

	test_double_once( 1.234e+123, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(-1.234e+123, 0, 4, 6, true, ' ', ' ', 0);

	test_double_once( 1.234e-123, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(-1.234e-123, 0, 4, 6, true, ' ', ' ', 0);

	test_double_once( Double.MIN_VALUE, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(-Double.MIN_VALUE, 0, 4, 6, true, ' ', ' ', 0);

	test_double_once( Double.MAX_VALUE, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(-Double.MAX_VALUE, 0, 4, 6, true, ' ', ' ', 0);

	test_double_once(Double.NEGATIVE_INFINITY, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(Double.POSITIVE_INFINITY, 0, 4, 6, true, ' ', ' ', 0);

	test_double_once( Double.NaN, 0, 4, 6, true, ' ', ' ', 0);
	test_double_once(-Double.NaN, 0, 4, 6, true, ' ', ' ', 0);

	for (int k = -1074; k < 1024; k += 64) // representable powers of two test
	{
	    double x = pow2(k);

	    test_double_once(x,               25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(-x,              25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(x * scale_down,  25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(x * scale_up,    25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(-x * scale_down, 25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(-x * scale_up,   25, 15, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	}

	for (int k = -308; k < 308; k += 8) // representable powers of ten test
	{
	    double x = 5.0 * pow10(k);

	    test_double_once(x,  10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(x,  10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(-x, 10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_double_once(-x, 10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	}
    }

    private static void test_convertFloat()
    {
	int p = 24;
	float eps = (float)pow2(-p + 1);
	float negeps = (float)pow2(-p);
	float scale_up = ONE_F + (float)pow2((-p + 1)/2) + eps;
	float scale_down = ONE_F - (float)pow2(-p/2) - negeps;

	test_newpage();
	test_println("Test of fmtflt.convertFloat(...)\n");

	test_float_once( eps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);
	test_float_once(-eps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);

	test_float_once( negeps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);
	test_float_once(-negeps, 0, 16, 3, true, LEADING_BLANK, ADA_SEPARATOR, 3);

	test_float_once( 0.000F, 0, 4, 0, true, ' ', ' ', 0);
	test_float_once(-0.000F, 0, 4, 0, true, ' ', ' ', 0);

	test_float_once( 1.234F, 0, 4, 0, true, ' ', ' ', 0);
	test_float_once(-1.234F, 0, 4, 0, true, ' ', ' ', 0);

	test_float_once( 1.234e+1F, 0, 4, 0, true, ' ', ' ', 0);
	test_float_once(-1.234e+1F, 0, 4, 0, true, ' ', ' ', 0);

	test_float_once( 1.234e+12F, 0, 4, 0, true, ' ', ' ', 0);
	test_float_once(-1.234e+12F, 0, 4, 0, true, ' ', ' ', 0);

	test_float_once( 1.234F, 0, 4, 3, true, ' ', ' ', 0);
	test_float_once(-1.234F, 0, 4, 3, true, ' ', ' ', 0);

	test_float_once( 1.2344F, 0, 3, 0, true, ' ', ' ', 0);
	test_float_once(-1.2344F, 0, 3, 0, true, ' ', ' ', 0);

	test_float_once( 1.23449999F, 0, 3, 0, true, ' ', ' ', 0);
	test_float_once(-1.23449999F, 0, 3, 0, true, ' ', ' ', 0);

	test_float_once( 1.2345F, 0, 3, 0, true, ' ', ' ', 0);
	test_float_once(-1.2345F, 0, 3, 0, true, ' ', ' ', 0);

	test_float_once( 1.234501F, 0, 3, 0, true, ' ', ' ', 0);
	test_float_once(-1.234501F, 0, 3, 0, true, ' ', ' ', 0);

	test_float_once( 1.2346F, 0, 3, 0, true, ' ', ' ', 0);
	test_float_once(-1.2346F, 0, 3, 0, true, ' ', ' ', 0);

	test_float_once( 1.2344F, 0, 3, 3, true, ' ', ' ', 0);
	test_float_once(-1.2344F, 0, 3, 3, true, ' ', ' ', 0);

	test_float_once( 1.23449999F, 0, 3, 3, true, ' ', ' ', 0);
	test_float_once(-1.23449999F, 0, 3, 3, true, ' ', ' ', 0);

	test_float_once( 1.2345F, 0, 3, 3, true, ' ', ' ', 0);
	test_float_once(-1.2345F, 0, 3, 3, true, ' ', ' ', 0);

	test_float_once( 1.234501F, 0, 3, 3, true, ' ', ' ', 0);
	test_float_once(-1.234501F, 0, 3, 3, true, ' ', ' ', 0);

	test_float_once( 1.2346F, 0, 3, 3, true, ' ', ' ', 0);
	test_float_once(-1.2346F, 0, 3, 3, true, ' ', ' ', 0);

	test_float_once( 1.234e+1F, 0, 4, 3, true, ' ', ' ', 0);
	test_float_once(-1.234e+1F, 0, 4, 3, true, ' ', ' ', 0);

	test_float_once( 1.234e+12F, 0, 4, 3, true, ' ', ' ', 0);
	test_float_once(-1.234e+12F, 0, 4, 3, true, ' ', ' ', 0);

	test_float_once( 1.234e+38F, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(-1.234e+38F, 0, 4, 6, true, ' ', ' ', 0);

	test_float_once( 1.234e-38F, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(-1.234e-38F, 0, 4, 6, true, ' ', ' ', 0);

	test_float_once( Float.MIN_VALUE, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(-Float.MIN_VALUE, 0, 4, 6, true, ' ', ' ', 0);

	test_float_once( Float.MAX_VALUE, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(-Float.MAX_VALUE, 0, 4, 6, true, ' ', ' ', 0);

	test_float_once(Float.NEGATIVE_INFINITY, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(Float.POSITIVE_INFINITY, 0, 4, 6, true, ' ', ' ', 0);

	test_float_once( Float.NaN, 0, 4, 6, true, ' ', ' ', 0);
	test_float_once(-Float.NaN, 0, 4, 6, true, ' ', ' ', 0);

	for (int k = -149; k < 128; k += 4)  // representable powers of two test
	{
	    float x = (float)pow2(k);

	    test_float_once(x,               15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once(-x,              15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once((float)x * (float)scale_down,  15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once((float)x * (float)scale_up,    15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once((float)-x * (float)scale_down, 15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once((float)-x * (float)scale_up,   15, 6, 2, false,
			    LEADING_BLANK, ADA_SEPARATOR, 5);
	}

	for (int k = -38; k < 38; ++k) // representable powers of ten test
	{
	    float x = FIVE_F * (float)pow10(k);

	    test_float_once(x,  10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once(x,  10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once(-x, 10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	    test_float_once(-x, 10, 1, 4, false, LEADING_BLANK, ADA_SEPARATOR, 5);
	}
    }

    private static final double[] double_E_values =
    {
	0.0,
	Double.MIN_VALUE,
	Double.MAX_VALUE,
	Double.NaN,
	Double.POSITIVE_INFINITY,
	Double.NEGATIVE_INFINITY,
	1.23456789e+123,
	1.23456789e+005,
	1.23456789e+000,
	1.23456789e-005,
	1.23456789e-123,
    };

    private static void test_double_E()
    {
	test_double_E_0();
	test_double_E_w();
	test_double_E_w_d();
	test_double_E_w_d_e();
	test_double_E_w_d_e_g();
    }

    private static void test_double_E_0()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.E(number)\n");
	test_double_E_0_many();
    }

    private static void test_double_E_0_many()
    {
	for (int k = 0; k < double_E_values.length; ++k)
	{
	    test_double_E_0_simple(+double_E_values[k]);
	    test_double_E_0_simple(-double_E_values[k]);
	}
    }

    private static void test_double_E_0_simple(double number)
    {
	test_println("E(" + number + ") -> [" + E(number) + "]");

	test_println("");
    }

    private static void test_double_E_w()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.E_w(number,w)\n");
	test_double_E_w_many();
    }

    private static void test_double_E_w_many()
    {
	for (int k = 0; k < double_E_values.length; ++k)
	{
	    test_double_E_w_simple(+double_E_values[k]);
	    test_double_E_w_simple(-double_E_values[k]);
	}
    }

    private static void test_double_E_w_simple(double number)
    {
	final int width = 32;

	test_println("E(" + number + "," + width + ") -> [" + E(number,width) + "]");
	test_println("E(" + number + "," + 0 + ") -> [" + E(number,0) + "]");

	test_println("");
    }

    private static void test_double_E_w_d()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.E_w_d(number,w,d)\n");
	test_double_E_w_d_many();
    }

    private static void test_double_E_w_d_many()
    {
	for (int k = 0; k < double_E_values.length; ++k)
	{
	    test_double_E_w_d_simple(+double_E_values[k]);
	    test_double_E_w_d_simple(-double_E_values[k]);
	}
    }

    private static void test_double_E_w_d_simple(double number)
    {
	final int width = 22;
	final int decimals = 5;

	test_println("E(" + number + "," + width + "," +
		     decimals + ") -> [" +
		     E(number,width,decimals) + "]");
	test_println("E(" + number + "," + width + "," +
		     0 + ") -> [" +
		     E(number,width,0) + "]");
	test_println("E(" + number + "," + 0 + "," +
		     decimals + ") -> [" +
		     E(number,0,decimals) + "]");
	test_println("E(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     E(number,0,0) + "]");

	test_println("");
    }

    private static void test_double_E_w_d_e()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.E_w_d_e(number,w,d,e)\n");
	test_double_E_w_d_e_many();
    }

    private static void test_double_E_w_d_e_many()
    {
	for (int k = 0; k < double_E_values.length; ++k)
	{
	    test_double_E_w_d_e_simple(+double_E_values[k]);
	    test_double_E_w_d_e_simple(-double_E_values[k]);
	}
    }

    private static void test_double_E_w_d_e_simple(double number)
    {
	final int width = 22;
	final int decimals = 5;
	final int exponent_digits = 5;

	test_println("E(" + number + "," + width + "," + decimals + "," +
		     exponent_digits + ") -> [" +
		     E(number,width,decimals,exponent_digits) + "]");
	test_println("E(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     E(number,width,0,exponent_digits) + "]");
	test_println("E(" + number + "," + 0 + "," + decimals + "," +
		     exponent_digits + ") -> [" +
		     E(number,0,decimals,exponent_digits) + "]");
	test_println("E(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     E(number,0,0,exponent_digits) + "]");

	test_println("");
    }

    private static void test_double_E_w_d_e_g()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.E_w_d_e_g(number,w,d,e,g)\n");
	test_double_E_w_d_e_g_many();
    }

    private static void test_double_E_w_d_e_g_many()
    {
	for (int k = 0; k < double_E_values.length; ++k)
	{
	    test_double_E_w_d_e_g_simple(+double_E_values[k]);
	    test_double_E_w_d_e_g_simple(-double_E_values[k]);
	}
    }

    private static void test_double_E_w_d_e_g_simple(double number)
    {
	final int width = 32;
	final int decimals = 15;
	final int exponent_digits = 5;
	final int ngroup = 3;

	test_println("E(" + number + "," + width + "," + decimals + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,width,decimals,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,width,0,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + 0 + "," + decimals + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,0,decimals,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,0,0,exponent_digits,ngroup) + "]");

	test_println("");
    }

    private static final double[] double_F_values =
    {
	0.0,
	Double.MIN_VALUE,
	Double.MAX_VALUE,
	Double.NaN,
	Double.POSITIVE_INFINITY,
	Double.NEGATIVE_INFINITY,
	1.23456789e+12,
	1.23456789e+005,
	1.23456789e+000,
	1.23456789e-005,
	1.23456789e-12
    };

    private static void test_double_F()
    {
	test_double_F_0();
	test_double_F_w();
	test_double_F_w_d();
	test_double_F_w_d_g();
    }

    private static void test_double_F_0()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.F(number)\n");
	test_double_F_0_many();
    }

    private static void test_double_F_0_many()
    {
	for (int k = 0; k < double_F_values.length; ++k)
	{
	    test_double_F_0_simple(+double_F_values[k]);
	    test_double_F_0_simple(-double_F_values[k]);
	}
    }

    private static void test_double_F_0_simple(double number)
    {
	test_println("F(" + number + ") -> [" + F(number) + "]");

	test_println("");
    }

    private static void test_double_F_w()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.F_w(number,w)\n");
	test_double_F_w_many();
    }

    private static void test_double_F_w_many()
    {
	for (int k = 0; k < double_F_values.length; ++k)
	{
	    test_double_F_w_simple(+double_F_values[k]);
	    test_double_F_w_simple(-double_F_values[k]);
	}
    }

    private static void test_double_F_w_simple(double number)
    {
	final int width = 32;

	test_println("F(" + number + "," + width + ") -> [" + F(number,width) + "]");
	test_println("F(" + number + "," + 0 + ") -> [" + F(number,0) + "]");

	test_println("");
    }

    private static void test_double_F_w_d()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.F_w_d(number,w,d)\n");
	test_double_F_w_d_many();
    }

    private static void test_double_F_w_d_many()
    {
	for (int k = 0; k < double_F_values.length; ++k)
	{
	    test_double_F_w_d_simple(+double_F_values[k]);
	    test_double_F_w_d_simple(-double_F_values[k]);
	}
    }

    private static void test_double_F_w_d_simple(double number)
    {
	final int width = 22;
	final int decimals = 5;

	test_println("F(" + number + "," + width + "," +
		     decimals + ") -> [" +
		     F(number,width,decimals) + "]");
	test_println("F(" + number + "," + width + "," +
		     0 + ") -> [" +
		     F(number,width,0) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     decimals + ") -> [" +
		     F(number,0,decimals) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     F(number,0,0) + "]");

	test_println("");
    }

    private static void test_double_F_w_d_g()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.F_w_d_g(number,w,d,g)\n");
	test_double_F_w_d_g_many();
    }

    private static void test_double_F_w_d_g_many()
    {
	for (int k = 0; k < double_F_values.length; ++k)
	{
	    test_double_F_w_d_g_simple(+double_F_values[k]);
	    test_double_F_w_d_g_simple(-double_F_values[k]);
	}
    }

    private static void test_double_F_w_d_g_simple(double number)
    {
	final int width = 32;
	final int decimals = 15;
	final int exponent_digits = 5;
	final int ngroup = 3;

	test_println("F(" + number + "," + width + "," +
		     decimals + "," + ngroup + ") -> [" +
		     F(number,width,decimals,ngroup) + "]");
	test_println("F(" + number + "," + width + "," +
		     0 + "," + ngroup + ") -> [" +
		     F(number,width,0,ngroup) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     decimals + "," + ngroup + ") -> [" +
		     F(number,0,decimals,ngroup) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     0 + "," + ngroup + ") -> [" +
		     F(number,0,0,ngroup) + "]");

	test_println("");
    }

    private static final double[] double_G_values =
    {
	0.0,
	Double.MIN_VALUE,
	Double.MAX_VALUE,
	Double.NaN,
	Double.POSITIVE_INFINITY,
	Double.NEGATIVE_INFINITY,
	0.5772156649015328606065120900824024,	// Euler-Mascheroni gamma constant
	1.6180339887498948482045868343656381,	// golden ratio: (1 + sqrt(5))/2
	2.7182818284590452353602874713526624,	// e
	3.1415926535897932384626433832795028,	// pi
	6.626176e-34,				// Planck constant (J/Hz)
	0.52917706e-10,				// Bohr radius (m)
	2.99792458e+08,				// c (speed of light in vacuum: m/s)
	6.022045e+23				// Avogadro constant (molecules)
    };

    private static void test_double_G()
    {
	test_double_G_0();
	test_double_G_w();
	test_double_G_w_d();
	test_double_G_w_d_e();
	test_double_G_w_d_e_g();
    }

    private static void test_double_G_0()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.G(number)\n");
	test_double_G_0_many();
    }

    private static void test_double_G_0_many()
    {
	for (int k = 0; k < double_G_values.length; ++k)
	{
	    test_double_G_0_simple(+double_G_values[k]);
	    test_double_G_0_simple(-double_G_values[k]);
	}
    }

    private static void test_double_G_0_simple(double number)
    {
	test_println("G(" + number + ") -> [" + G(number) + "]");

	test_println("");
    }

    private static void test_double_G_w()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.G_w(number,w)\n");
	test_double_G_w_many();
    }

    private static void test_double_G_w_many()
    {
	for (int k = 0; k < double_G_values.length; ++k)
	{
	    test_double_G_w_simple(+double_G_values[k]);
	    test_double_G_w_simple(-double_G_values[k]);
	}
    }

    private static void test_double_G_w_simple(double number)
    {
	for (int width = 7; width <= 17; ++width)
	{
	    test_println("G(" + number + "," + width + ") -> [" +
			 G(number,width) + "]");
	}
	test_println("");
    }

    private static void test_double_G_w_d()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.G_w_d(number,w,d)\n");
	test_double_G_w_d_many();
    }

    private static void test_double_G_w_d_many()
    {
	for (int k = 0; k < double_G_values.length; ++k)
	{
	    test_double_G_w_d_simple(+double_G_values[k]);
	    test_double_G_w_d_simple(-double_G_values[k]);
	}
    }

    private static void test_double_G_w_d_simple(double number)
    {
	final int width = 22;
	final int total_digits = 5;

	test_println("G(" + number + "," + width + "," +
		     total_digits + ") -> [" +
		     G(number,width,total_digits) + "]");
	test_println("G(" + number + "," + width + "," +
		     0 + ") -> [" +
		     G(number,width,0) + "]");
	test_println("G(" + number + "," + 0 + "," +
		     total_digits + ") -> [" +
		     G(number,0,total_digits) + "]");
	test_println("G(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     G(number,0,0) + "]");

	for (int digits = 0; digits <= 15; ++digits)
	{
	    test_println("G(" + number + "," + width + "," + digits + ") -> [" +
			 G(number,width,digits) + "]");
	}

	test_println("");
    }

    private static void test_double_G_w_d_e()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.G_w_d_e(number,w,d,e)\n");
	test_double_G_w_d_e_many();
    }

    private static void test_double_G_w_d_e_many()
    {
	for (int k = 0; k < double_G_values.length; ++k)
	{
	    test_double_G_w_d_e_simple(+double_G_values[k]);
	    test_double_G_w_d_e_simple(-double_G_values[k]);
	}
    }

    private static void test_double_G_w_d_e_simple(double number)
    {
	final int width = 32;
	final int total_digits = 8;
	final int exponent_digits = 5;

	test_println("G(" + number + "," + width + "," + total_digits + "," +
		     exponent_digits + ") -> [" +
		     G(number,width,total_digits,exponent_digits) + "]");
	test_println("G(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     G(number,width,0,exponent_digits) + "]");
	test_println("G(" + number + "," + 0 + "," + total_digits + "," +
		     exponent_digits + ") -> [" +
		     G(number,0,total_digits,exponent_digits) + "]");

	for (int k = 0; k <= 12; ++k)
	{
	    test_println("G(" + number + "," + 0 + "," + k + "," +
			 exponent_digits + ") -> [" +
			 G(number,0,k,exponent_digits) + "]");
	}

	for (int k = -12; k <= 12; ++k)
	{
	    double scaled_number = number * pow10(k);
	    test_println("G(" + scaled_number + "," + width + "," + total_digits + "," +
			 exponent_digits + ") -> [" +
			 G(scaled_number,width,total_digits,exponent_digits) + "]");
	}

	test_println("");
    }

    private static void test_double_G_w_d_e_g()
    {
	test_newpage();
	test_println("Test of double-precision fmtflt.G_w_d_e_g(number,w,d,e,g)\n");
	test_double_G_w_d_e_g_many();
    }

    private static void test_double_G_w_d_e_g_many()
    {
	for (int k = 0; k < double_G_values.length; ++k)
	{
	    test_double_G_w_d_e_g_simple(+double_G_values[k]);
	    test_double_G_w_d_e_g_simple(-double_G_values[k]);
	}
    }

    private static void test_double_G_w_d_e_g_simple(double number)
    {
	final int width = 32;
	final int total_digits = 15;
	final int exponent_digits = 5;
	final int ngroup = 3;

	test_println("G(" + number + "," + width + "," + total_digits + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,width,total_digits,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,width,0,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + 0 + "," + total_digits + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,0,total_digits,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,0,0,exponent_digits,ngroup) + "]");

	test_println("");
    }

    private static void test_double_once(double number, int width, int fractional_digits,
					 int exponent_digits,
					 boolean require_sign, char leading_pad,
					 char separator, int ngroup)
    {
	boolean show_all = true; // set to false to reduce output size
	String s = convertDouble(number, width, fractional_digits, exponent_digits,
				 require_sign, leading_pad, separator, ngroup);

	if (show_all)		// suppressed to reduce output size
	{
	    test_println("convertDouble(number=" + number + ","
			 + "width=" + width + ","
			 + "fractional_digits=" + fractional_digits + ","
			 + "exponent_digits=" + exponent_digits + ","
			 + "\n\t\t"
			 + "require_sign=" + require_sign + ","
			 + "leading_pad='" + leading_pad + "',"
			 + "separator='" + separator + "',"
			 + "ngroup=" + ngroup + ") -> \n"
			 + "\t\t[" + s + "]");
	}
	if (!Double.isNaN(number) && !Double.isInfinite(number))
	{
	    double result;
	    String t = squeeze(s.trim()); // Double.valueOf() cannot handle separators
	    try
	    {
		// result = Double.parseDouble(t);	// unavailable before JDK 1.2
		result = Double.valueOf(t).doubleValue();
		double relerr = Math.abs((result - number)/number);
		if ((result != number) &&
		    (((exponent_digits > 0) && (relerr > 5.0*pow10(Math.max(-16,-1 - fractional_digits)))) ||
		     ((exponent_digits <= 0) && (relerr > 5.0*pow10(Math.max(-16,-fractional_digits))))))
		    test_println("MISMATCH: number = " + number +
				 " Double.valueOf(" + s.trim() + ").doubleValue() -> " + result +
				 " relerr = " + relerr);
	    }
	    catch (NumberFormatException e)
	    {
		if (!show_all)
		    test_println("convertDouble(number=" + number + ","
				 + "width=" + width + ","
				 + "fractional_digits=" + fractional_digits + ","
				 + "exponent_digits=" + exponent_digits + ","
				 + "\n\t\t"
				 + "require_sign=" + require_sign + ","
				 + "leading_pad='" + leading_pad + "',"
				 + "separator='" + separator + "',"
				 + "ngroup=" + ngroup + ") -> \n"
				 + "\t\t[" + s + "]");
		test_println("ERROR: Double.valueOf(" + t + ").doubleValue() threw " + e);
		if (!show_all)
		    test_println("");
	    }
	}
	if (show_all)
	    test_println("");
    }

    private static final float[] float_E_values =
    {
	0.0F,
	Float.MIN_VALUE,
	Float.MAX_VALUE,
	Float.NaN,
	Float.POSITIVE_INFINITY,
	Float.NEGATIVE_INFINITY,
	9.87654321e+023F,
	9.87654321e+005F,
	9.87654321e+000F,
	9.87654321e-005F,
	9.87654321e-023F
    };

    private static void test_float_E()
    {
	test_float_E_0();
	test_float_E_w();
	test_float_E_w_d();
	test_float_E_w_d_e();
	test_float_E_w_d_e_g();
    }

    private static void test_float_E_0()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.E(number)\n");
	test_float_E_0_many();
    }

    private static void test_float_E_0_many()
    {
	for (int k = 0; k < float_E_values.length; ++k)
	{
	    test_float_E_0_simple(+float_E_values[k]);
	    test_float_E_0_simple(-float_E_values[k]);
	}
    }

    private static void test_float_E_0_simple(float number)
    {
	test_println("E(" + number + ") -> [" + E(number) + "]");

	test_println("");
    }

    private static void test_float_E_w()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.E_w(number,w)\n");
	test_float_E_w_many();
    }

    private static void test_float_E_w_many()
    {
	for (int k = 0; k < float_E_values.length; ++k)
	{
	    test_float_E_w_simple(+float_E_values[k]);
	    test_float_E_w_simple(-float_E_values[k]);
	}
    }

    private static void test_float_E_w_simple(float number)
    {
	final int width = 22;

	test_println("E(" + number + "," + width + ") -> [" + E(number,width) + "]");
	test_println("E(" + number + "," + 0 + ") -> [" + E(number,0) + "]");

	test_println("");
    }

    private static void test_float_E_w_d()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.E_w_d(number,w,d)\n");
	test_float_E_w_d_many();
    }

    private static void test_float_E_w_d_many()
    {
	for (int k = 0; k < float_E_values.length; ++k)
	{
	    test_float_E_w_d_simple(+float_E_values[k]);
	    test_float_E_w_d_simple(-float_E_values[k]);
	}
    }

    private static void test_float_E_w_d_simple(float number)
    {
	final int width = 22;
	final int decimals = 5;

	test_println("E(" + number + "," + width + "," +
		     decimals + ") -> [" +
		     E(number,width,decimals) + "]");
	test_println("E(" + number + "," + width + "," +
		     0 + ") -> [" +
		     E(number,width,0) + "]");
	test_println("E(" + number + "," + 0 + "," +
		     decimals + ") -> [" +
		     E(number,0,decimals) + "]");
	test_println("E(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     E(number,0,0) + "]");

	test_println("");
    }

    private static void test_float_E_w_d_e()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.E_w_d_e(number,w,d,e)\n");
	test_float_E_w_d_e_many();
    }

    private static void test_float_E_w_d_e_many()
    {
	for (int k = 0; k < float_E_values.length; ++k)
	{
	    test_float_E_w_d_e_simple(+float_E_values[k]);
	    test_float_E_w_d_e_simple(-float_E_values[k]);
	}
    }

    private static void test_float_E_w_d_e_simple(float number)
    {
	final int width = 22;
	final int decimals = 5;
	final int exponent_digits = 5;

	test_println("E(" + number + "," + width + "," + decimals + "," +
		     exponent_digits + ") -> [" +
		     E(number,width,decimals,exponent_digits) + "]");
	test_println("E(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     E(number,width,0,exponent_digits) + "]");
	test_println("E(" + number + "," + 0 + "," + decimals + "," +
		     exponent_digits + ") -> [" +
		     E(number,0,decimals,exponent_digits) + "]");
	test_println("E(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     E(number,0,0,exponent_digits) + "]");

	test_println("");
    }

    private static void test_float_E_w_d_e_g()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.E_w_d_e_g(number,w,d,e,g)\n");
	test_float_E_w_d_e_g_many();
    }

    private static void test_float_E_w_d_e_g_many()
    {
	for (int k = 0; k < float_E_values.length; ++k)
	{
	    test_float_E_w_d_e_g_simple(+float_E_values[k]);
	    test_float_E_w_d_e_g_simple(-float_E_values[k]);
	}
    }

    private static void test_float_E_w_d_e_g_simple(float number)
    {
	final int width = 22;
	final int decimals = 6;
	final int exponent_digits = 2;
	final int ngroup = 2;

	test_println("E(" + number + "," + width + "," + decimals + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,width,decimals,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,width,0,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + 0 + "," + decimals + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,0,decimals,exponent_digits,ngroup) + "]");
	test_println("E(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     E(number,0,0,exponent_digits,ngroup) + "]");

	test_println("");
    }

    private static final float[] float_F_values =
    {
	0.0F,
	Float.MIN_VALUE,
	Float.MAX_VALUE,
	Float.NaN,
	Float.POSITIVE_INFINITY,
	Float.NEGATIVE_INFINITY,
	3.14159265e+12F,
	3.14159265e+005F,
	3.14159265e+000F,
	3.14159265e-005F,
	3.14159265e-12F
    };

    private static void test_float_F()
    {
	test_float_F_0();
	test_float_F_w();
	test_float_F_w_d();
	test_float_F_w_d_g();
    }

    private static void test_float_F_0()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.F(number)\n");
	test_float_F_0_many();
    }

    private static void test_float_F_0_many()
    {
	for (int k = 0; k < float_F_values.length; ++k)
	{
	    test_float_F_0_simple(+float_F_values[k]);
	    test_float_F_0_simple(-float_F_values[k]);
	}
    }

    private static void test_float_F_0_simple(float number)
    {
	test_println("F(" + number + ") -> [" + F(number) + "]");

	test_println("");
    }

    private static void test_float_F_w()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.F_w(number,w)\n");
	test_float_F_w_many();
    }

    private static void test_float_F_w_many()
    {
	for (int k = 0; k < float_F_values.length; ++k)
	{
	    test_float_F_w_simple(+float_F_values[k]);
	    test_float_F_w_simple(-float_F_values[k]);
	}
    }

    private static void test_float_F_w_simple(float number)
    {
	final int width = 22;

	test_println("F(" + number + "," + width + ") -> [" + F(number,width) + "]");
	test_println("F(" + number + "," + 0 + ") -> [" + F(number,0) + "]");

	test_println("");
    }

    private static void test_float_F_w_d()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.F_w_d(number,w,d)\n");
	test_float_F_w_d_many();
    }

    private static void test_float_F_w_d_many()
    {
	for (int k = 0; k < float_F_values.length; ++k)
	{
	    test_float_F_w_d_simple(+float_F_values[k]);
	    test_float_F_w_d_simple(-float_F_values[k]);
	}
    }

    private static void test_float_F_w_d_simple(float number)
    {
	final int width = 22;
	final int decimals = 5;

	test_println("F(" + number + "," + width + "," +
		     decimals + ") -> [" +
		     F(number,width,decimals) + "]");
	test_println("F(" + number + "," + width + "," +
		     0 + ") -> [" +
		     F(number,width,0) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     decimals + ") -> [" +
		     F(number,0,decimals) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     F(number,0,0) + "]");

	test_println("");
    }

    private static void test_float_F_w_d_g()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.F_w_d_g(number,w,d,g)\n");
	test_float_F_w_d_g_many();
    }

    private static void test_float_F_w_d_g_many()
    {
	for (int k = 0; k < float_F_values.length; ++k)
	{
	    test_float_F_w_d_g_simple(+float_F_values[k]);
	    test_float_F_w_d_g_simple(-float_F_values[k]);
	}
    }

    private static void test_float_F_w_d_g_simple(float number)
    {
	final int width = 22;
	final int decimals = 6;
	final int exponent_digits = 2;
	final int ngroup = 2;

	test_println("F(" + number + "," + width + "," +
		     decimals + "," + ngroup + ") -> [" +
		     F(number,width,decimals,ngroup) + "]");
	test_println("F(" + number + "," + width + "," +
		     0 + "," + ngroup + ") -> [" +
		     F(number,width,0,ngroup) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     decimals + "," + ngroup + ") -> [" +
		     F(number,0,decimals,ngroup) + "]");
	test_println("F(" + number + "," + 0 + "," +
		     0 + "," + ngroup + ") -> [" +
		     F(number,0,0,ngroup) + "]");

	test_println("");
    }

    private static final float[] float_G_values =
    {
	0.0F,
	Float.MIN_VALUE,
	Float.MAX_VALUE,
	Float.NaN,
	Float.POSITIVE_INFINITY,
	Float.NEGATIVE_INFINITY,
	0.5772156649015328606065120900824024F,	// Euler-Mascheroni gamma constant
	1.6180339887498948482045868343656381F,	// golden ratio: (1 + sqrt(5))/2
	2.7182818284590452353602874713526624F,	// e
	3.1415926535897932384626433832795028F,	// pi
	6.626176e-34F,				// Planck constant (J/Hz)
	0.52917706e-10F,			// Bohr radius (m)
	2.99792458e+08F,			// c (speed of light in vacuum: m/s)
	6.022045e+23F				// Avogadro constant (molecules)
    };

    private static void test_float_G()
    {
	test_float_G_0();
	test_float_G_w();
	test_float_G_w_d();
	test_float_G_w_d_e();
	test_float_G_w_d_e_g();
    }

    private static void test_float_G_0()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.G(number)\n");
	test_float_G_0_many();
    }

    private static void test_float_G_0_many()
    {
	for (int k = 0; k < float_G_values.length; ++k)
	{
	    test_float_G_0_simple(+float_G_values[k]);
	    test_float_G_0_simple(-float_G_values[k]);
	}
    }

    private static void test_float_G_0_simple(float number)
    {
	test_println("G(" + number + ") -> [" + G(number) + "]");

	test_println("");
    }

    private static void test_float_G_w()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.G_w(number,w)\n");
	test_float_G_w_many();
    }

    private static void test_float_G_w_many()
    {
	for (int k = 0; k < float_G_values.length; ++k)
	{
	    test_float_G_w_simple(+float_G_values[k]);
	    test_float_G_w_simple(-float_G_values[k]);
	}
    }

    private static void test_float_G_w_simple(float number)
    {
	for (int width = 7; width <= 17; ++width)
	{
	    test_println("G(" + number + "," + width + ") -> [" +
			 G(number,width) + "]");
	}
	test_println("");
    }

    private static void test_float_G_w_d()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.G_w_d(number,w,d)\n");
	test_float_G_w_d_many();
    }

    private static void test_float_G_w_d_many()
    {
	for (int k = 0; k < float_G_values.length; ++k)
	{
	    test_float_G_w_d_simple(+float_G_values[k]);
	    test_float_G_w_d_simple(-float_G_values[k]);
	}
    }

    private static void test_float_G_w_d_simple(float number)
    {
	final int width = 22;
	final int total_digits = 5;

	test_println("G(" + number + "," + width + "," +
		     total_digits + ") -> [" +
		     G(number,width,total_digits) + "]");
	test_println("G(" + number + "," + width + "," +
		     0 + ") -> [" +
		     G(number,width,0) + "]");
	test_println("G(" + number + "," + 0 + "," +
		     total_digits + ") -> [" +
		     G(number,0,total_digits) + "]");
	test_println("G(" + number + "," + 0 + "," +
		     0 + ") -> [" +
		     G(number,0,0) + "]");

	for (int digits = 0; digits <= 7; ++digits)
	{
	    test_println("G(" + number + "," + width + "," + digits + ") -> [" +
			 G(number,width,digits) + "]");
	}

	test_println("");
    }

    private static void test_float_G_w_d_e()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.G_w_d_e(number,w,d,e)\n");
	test_float_G_w_d_e_many();
    }

    private static void test_float_G_w_d_e_many()
    {
	for (int k = 0; k < float_G_values.length; ++k)
	{
	    test_float_G_w_d_e_simple(+float_G_values[k]);
	    test_float_G_w_d_e_simple(-float_G_values[k]);
	}
    }

    private static void test_float_G_w_d_e_simple(float number)
    {
	final int width = 32;
	final int total_digits = 8;
	final int exponent_digits = 5;

	test_println("G(" + number + "," + width + "," + total_digits + "," +
		     exponent_digits + ") -> [" +
		     G(number,width,total_digits,exponent_digits) + "]");
	test_println("G(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + ") -> [" +
		     G(number,width,0,exponent_digits) + "]");
	test_println("G(" + number + "," + 0 + "," + total_digits + "," +
		     exponent_digits + ") -> [" +
		     G(number,0,total_digits,exponent_digits) + "]");

	for (int k = 0; k <= 12; ++k)
	{
	    test_println("G(" + number + "," + 0 + "," + k + "," +
			 exponent_digits + ") -> [" +
			 G(number,0,k,exponent_digits) + "]");
	}

	for (int k = -10; k <= 10; ++k)
	{
	    float scaled_number = number * (float)pow10(k);
	    test_println("G(" + scaled_number + "," + width + "," + total_digits + "," +
			 exponent_digits + ") -> [" +
			 G(scaled_number,width,total_digits,exponent_digits) + "]");
	}

	test_println("");
    }

    private static void test_float_G_w_d_e_g()
    {
	test_newpage();
	test_println("Test of single-precision fmtflt.G_w_d_e_g(number,w,d,e,g)\n");
	test_float_G_w_d_e_g_many();
    }

    private static void test_float_G_w_d_e_g_many()
    {
	for (int k = 0; k < float_G_values.length; ++k)
	{
	    test_float_G_w_d_e_g_simple(+float_G_values[k]);
	    test_float_G_w_d_e_g_simple(-float_G_values[k]);
	}
    }

    private static void test_float_G_w_d_e_g_simple(float number)
    {
	final int width = 22;
	final int total_digits = 6;
	final int exponent_digits = 2;
	final int ngroup = 2;

	test_println("G(" + number + "," + width + "," + total_digits + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,width,total_digits,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + width + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,width,0,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + 0 + "," + total_digits + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,0,total_digits,exponent_digits,ngroup) + "]");
	test_println("G(" + number + "," + 0 + "," + 0 + "," +
		     exponent_digits + "," + ngroup + ") -> [" +
		     G(number,0,0,exponent_digits,ngroup) + "]");

	test_println("");
    }

    private static void test_float_once(float number, int width, int fractional_digits,
					int exponent_digits,
					boolean require_sign, char leading_pad,
					char separator, int ngroup)
    {
	boolean show_all = true; // set to false to reduce output size
	String s = convertFloat(number, width, fractional_digits, exponent_digits,
				 require_sign, leading_pad, separator, ngroup);

	if (show_all)		// suppressed to reduce output size
	{
	    test_println("convertFloat(number=" + number + ","
			 + "width=" + width + ","
			 + "fractional_digits=" + fractional_digits + ","
			 + "exponent_digits=" + exponent_digits + ","
			 + "\n\t\t"
			 + "require_sign=" + require_sign + ","
			 + "leading_pad='" + leading_pad + "',"
			 + "separator='" + separator + "',"
			 + "ngroup=" + ngroup + ") -> \n"
			 + "\t\t[" + s + "]");
	}
	if (!Float.isNaN(number) && !Float.isInfinite(number))
	{
	    float result;
	    String t = squeeze(s.trim()); // Float.valueOf() cannot handle separators
	    try
	    {
		// result = Float.parseFloat(t);	// unavailable before JDK 1.2
		result = Float.valueOf(t).floatValue();
		float relerr = Math.abs((result - number)/number);
		if ((result != number) &&
		    (((exponent_digits > 0) &&
		      (relerr > FIVE_F*(float)pow10(Math.max(-7,-1 - fractional_digits)))) ||
		     ((exponent_digits <= 0) &&
		      (relerr > FIVE_F*(float)pow10(Math.max(-7,-fractional_digits))))))
		    test_println("MISMATCH: number = " + number +
				 " Float.valueOf(" + s.trim() + ").floatValue() -> " + result +
				 " relerr = " + relerr);
	    }
	    catch (NumberFormatException e)
	    {
		if (!show_all)
		    test_println("convertFloat(number=" + number + ","
				 + "width=" + width + ","
				 + "fractional_digits=" + fractional_digits + ","
				 + "exponent_digits=" + exponent_digits + ","
				 + "\n\t\t"
				 + "require_sign=" + require_sign + ","
				 + "leading_pad='" + leading_pad + "',"
				 + "separator='" + separator + "',"
				 + "ngroup=" + ngroup + ") -> \n"
				 + "\t\t[" + s + "]");
		test_println("ERROR: Float.valueOf(" + t + ").floatValue() threw " + e);
		if (!show_all)
		    test_println("");
	    }
	}
	if (show_all)
	    test_println("");
    }

    private static void test_newpage()
    {
	test_println("\f");
    }

    private static void test_println(String message)
    {
	System.out.println(message);
    }

    private static void test_unseparate()
    {
	final char separator = ADA_SEPARATOR;
	final int width = 0;
	final int total_digits = 15;
	final int exponent_digits = 3;
	final int ngroup = 3;

	for (int k = 0; k < double_G_values.length; ++k)
	{
	    String s = G(double_G_values[k], width, total_digits,
			 exponent_digits, ngroup);
	    test_println("G(" + double_G_values[k] + "," + width + "," +
			 total_digits + "," + exponent_digits + "," +
			 ngroup + ") -> [" + s + "] -> unseparate() -> [" +
			 unseparate(s,separator) + "]");
	}
    }

    // Test suite program

   /**
    * Run a test suite of the public functions in this class.
    *
    * @param	args[]	Command-line arguments (ignored).
    */
    public static void main(String[] args)
    {
	test_convertDouble();
	test_double_E();
	test_double_F();
	test_double_G();

	test_convertFloat();
	test_float_E();
	test_float_F();
	test_float_G();

	test_unseparate();
    }
}
