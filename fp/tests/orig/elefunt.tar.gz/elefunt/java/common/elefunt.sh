#! /bin/sh
### ====================================================================
### Run the ELEFUNT tests for multiple compilers and optimization
### levels, automatically selecting them according to the host
### operating system.
###
### Usage:
###	./elefunt.sh
###
### [30-May-2002] -- Revise for Java compilation.
### [27-May-2002] -- Original version for C and C++
### ====================================================================

machine=`uname -m`
os=`uname -s`

CLASSPATH=.:../common
export CLASSPATH

MAKE='make distclean all'

case $os in
	AIX*)
		osmajor=`uname -v`
		osminor=`uname -r`
		$MAKE NAME=ibm-aix${osmajor}${osminor}-javac-O OPT=-O
		$MAKE NAME=ibm-aix${osmajor}${osminor}-javac-g OPT=-g
		;;

	Darwin*)
		$MAKE NAME=apple-powerpc-darwin-javac-O OPT=-O
		$MAKE NAME=apple-powerpc-darwin-javac-g OPT=-g
		;;

	FreeBSD*)
		$MAKE NAME=intel-ia32-freebsd-javac-O OPT=-O
		$MAKE NAME=intel-ia32-freebsd-javac-g OPT=-g
		;;

	HP-UX*)
		;;

	IRIX*)
		$MAKE NAME=sgi-irix-javac-O OPT=-O
		$MAKE NAME=sgi-irix-javac-g OPT=-g
		;;

	Linux*)
		case $machine in
			alpha)
				$MAKE NAME=dec-alpha-gnu-linux-javac-O OPT=-O
				$MAKE NAME=dec-alpha-gnu-linux-javac-g OPT=-g
				;;
			i486 | i586 | i686)
				$MAKE NAME=intel-ia32-gnu-linux-javac-O OPT=-O
				$MAKE NAME=intel-ia32-gnu-linux-javac-g OPT=-g
				;;
			ppc)
				$MAKE NAME=apple-powerpc-gnu-linux-javac-O OPT=-O
				$MAKE NAME=apple-powerpc-gnu-linux-javac-g OPT=-g
				;;
			sparc)
				$MAKE NAME=sun-sparc-gnu-linux-javac-O OPT=-O
				$MAKE NAME=sun-sparc-gnu-linux-javac-g OPT=-g
				;;
			*)
				echo "Unknown machine = $machine"
				exit 1
				;;
		esac
		;;

	OSF1*)
		osversion=`uname -r`
		$MAKE NAME=dec-alpha-osf-${osversion}-javac-O OPT=-O
		$MAKE NAME=dec-alpha-osf-${osversion}-javac-g OPT=-g
		;;

	Rhapsody*)
		$MAKE NAME=apple-powerpc-rhapsody-javac-O OPT=-O
		$MAKE NAME=apple-powerpc-rhapsody-javac-g OPT=-g
		;;

	SunOS*)
		osversion=`uname -r`
		sunmath=`find /opt/SUNWspro/ -name sunmath.h | head -1`
		incdir=`dirname ${sunmath}`
		libdir=${incdir}/../../lib
		$MAKE JAVAC=/usr/java1.1/bin/javac NAME=sun-sparc-solaris-${osversion}-javac-1.1-O OPT=-O
		$MAKE JAVAC=/usr/java1.1/bin/javac NAME=sun-sparc-solaris-${osversion}-javac-1.1-g OPT=-g
		$MAKE JAVAC=/usr/java1.2/bin/javac NAME=sun-sparc-solaris-${osversion}-javac-1.2-O OPT=-O
		$MAKE JAVAC=/usr/java1.2/bin/javac NAME=sun-sparc-solaris-${osversion}-javac-1.2-g OPT=-g
		$MAKE JAVAC=/usr/j2se/bin/javac    NAME=sun-sparc-solaris-${osversion}-javac-1.4.0-O OPT=-O
		$MAKE JAVAC=/usr/j2se/bin/javac    NAME=sun-sparc-solaris-${osversion}-javac-1.4.0-g OPT=-g
		;;

	*)
		echo "Unknown O/S = $os"
		exit 1
		;;

esac
echo ""
echo "Output files:"
ls -l tall[ds]p.lst*
echo ""
for f in tall[ds]p.lst*
do
	echo ==================== $f
	awk -f ../common/elefunt.awk $f
done
