/* -*-java-*- ranbase.java */

public class ranbase
{
    public static final long INITIALSEED = 100001L;
}
