/* -*-java-*- fmtint.java */
// NB: The comments in this file conform rudimentarily to javadoc
// conventions, and the HTML files produced by "javadoc fmtint.java"
// are reasonably usable.  However, more details are likely desirable.

/**
 * The <code>fmtint</code> class provides an extended set of integer
 * formatting functions to fill a serious gap in the offerings of the
 * Java libraries: namely, the inability to control field width, sign,
 * digit grouping, and justification in numeric output.
 *
 * <p>
 *
 * This class file contains a built-in validation suite, easily run in
 * most UNIX-like Java implementations like this:
 *
 * <pre>
 *    javac fmtint.java && java fmtint > fmtint.lst && diff okay/fmtint.lst fmtint.lst
 * </pre>
 *
 * or, better, as part of a larger validation suite:
 *
 * <pre>
 *    make check
 * </pre>
 *
 * <p>
 *
 * These functions require only the standard
 * <code>java.lang.Math</code> and <code>java.lang.String</code>
 * classes from JDK 1.0 or later.  None of the functions used are
 * deprecated in any of the Java levels 1.0, 1.1, 1.2, 1.3, or 1.4.
 *
 * <p>
 *
 * Although functions are provided only for the <code>long</code>
 * datatype, Java's widening rules for integer datatypes will
 * automatically promote <code>int</code>, <code>short</code>,
 * <code>char</code>, and <code>byte</code> datatypes to
 * <code>long</code> in calls to these functions.
 *
 * <p>
 *
 * These functions are modelled on the Fortran 66/77/90/95/HPF
 * <code>Bw[.d]</code>, <code>Iw[.d]</code>, <code>Ow[.d]</code>, and
 * <code>Zw[.d]</code> <code>FORMAT</code> items, with extensions for
 * Ada-style based-integer literals (e.g., 16#ffff_ffff#), and support
 * for left-, center-, and right-justification of strings in fields of
 * arbitrary width.
 *
 * <p>
 *
 * However, unlike Fortran, whose punched-card legacy views column
 * alignment of greater importance than correct output, filling fields
 * with asterisks when they are too short to contain the numeric value,
 * in these functions, field widths automatically expand to contain
 * the value (just as format items in the C <code>printf()</code>
 * family do).
 *
 * <p>
 *
 * These functions make it much easier to translate existing Fortran
 * and C/C++ code into Java: compare these statements:
 *
 * <pre>
 *        write (6,'(i14.3,2x, ''0b'', b0, 2x, ''0x'', z8.8)') i, j, k
 *        (void)printf("%14d  %x  0x%8.8x\n", i, j, k)
 *        System.out.println(fmtint.I(i,14,3) +
 *                           "  0b" + fmtint.B(j,0) +
 *                           "  0x" + fmtint.Z(k,8,8));
 * </pre>
 *
 * @author Nelson H. F. Beebe, Department of Mathematics, University of Utah, Salt Lake City, UT 84112-0090, USA
 * @version 1.00, [01-Jun-2002]
 * @since   JDK1.0
 */

/*
 * Here is a list of the public methods in class fmtint:
 *
 * public static String leftAdjust(String s, int pad_len)
 *
 * public static String centerAdjust(String s, int pad_len)
 *
 * public static String rightAdjust(String s, int pad_len)
 *
 * public static String convertLong(long number)
 *
 * public static String convertLong(long number, int base)
 *
 * public static String convertLong(long number, int base, int width)
 *
 * public static String convertLong(long number, int base, int width,
 *				int min_digits)
 *
 * public static String convertLong(long number, int base, int width,
 * 				 int min_digits, boolean require_sign)
 *
 * public static String convertLong(long number, int base, int width,
 *				int min_digits, boolean require_sign,
 *				boolean is_unsigned)
 *
 * public static String convertLong(long number, int base, int width,
 *				int min_digits, boolean require_sign,
 *				boolean is_unsigned, boolean
 *				is_ada_style)
 *
 * public static String convertLong(long number, int base, int width,
 *				int min_digits, boolean require_sign,
 *				boolean is_unsigned, boolean
 *				is_ada_style, char leading_pad, char
 *				separator, int ngroup)
 *
 * public static String convertLong(long number, int base, int width,
 *				int min_digits, boolean require_sign,
 *				boolean is_unsigned, boolean
 *				is_ada_style, char leading_pad, char
 *				separator, int ngroup, int nphantom,
 *				int dot_after, boolean have_carry)
 *
 * public static String B(long number)
 *
 * public static String B(long number, int width)
 *
 * public static String B(long number, int width, int min_digits)
 *
 * public static String B(long number, int width, int min_digits, int ngroup)
 *
 * public static String I(long number)
 *
 * public static String I(long number, int width)
 *
 * public static String I(long number, int width, int min_digits)
 *
 * public static String I(long number, int width, int min_digits, int ngroup)
 *
 * public static String O(long number)
 *
 * public static String O(long number, int width)
 *
 * public static String O(long number, int width, int min_digits)
 *
 * public static String O(long number, int width, int min_digits, int ngroup)
 *
 * public static String R(long number)
 *
 * public static String R(long number, int base)
 *
 * public static String R(long number, int base, int width)
 *
 * public static String R(long number, int base, int width, int min_digits)
 *
 * public static String R(long number, int base, int width, int min_digits,
 *			int ngroup)
 *
 * public static String S(long number)
 *
 * public static String S(long number, int base)
 *
 * public static String S(long number, int base, int width)
 *
 * public static String S(long number, int base, int width, int min_digits)
 *
 * public static String S(long number, int base, int width, int min_digits,
 *			int ngroup)
 *
 * public static String Z(long number)
 *
 * public static String Z(long number, int width)
 *
 * public static String Z(long number, int width, int min_digits)
 *
 * public static String Z(long number, int width, int min_digits, int ngroup)
 *
 */

public class fmtint
{
    // Private data and functions for the class implementation

   /**
    * Named character constants.
    */
    private static final char ADA_LITERAL_DELIMITER = '#';
    private static final char ADA_SEPARATOR = '_';
    private static final char DECIMAL_POINT = '.';
    private static final char LEADING_BLANK = ' ';
    private static final char[] DIGITS =
    {
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
	'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
	'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
	'u', 'v', 'w', 'x', 'y', 'z'
    };

   /**
    * Return a <code>String</code> containing exactly <code>n</code>
    * copies of the <code>fill</code> character.
    *
    * @param	fill	the fill character.
    * @param	n	length of returned string.
    * @return	String of fill characters.
    */
    private static String fill_string(char fill, int n)
    {
	// The String class unfortunately lacks a constructor to do this, sigh...

	if (n < 0)
	    n = 0;

	StringBuffer buf = new StringBuffer(n);

	buf.setLength(n);
	for (int k = 0; k < n; ++k)
	    buf.setCharAt(k,fill);
	return (buf.toString());
    }

    // Public methods

   /**
    * Return a copy of <code>s</code> centered, with blank padding if
    * necessary, in a string of length <code>pad_len</code>
    * characters.
    *
    * @param	s	String to be centered.
    * @param	pad_len	Length of output string.
    * @return	The centered string.
    */
    public static String centerJustify(String s, int pad_len)
    {
	int nleft;
	int nright;
	int need = Math.max(0,pad_len - s.length());

	nleft = need/2;
	nright = need - nleft;
	return (fill_string(' ', nleft) + s + fill_string(' ', nright));
    }

   /**
    * Return a copy of <code>s</code> left justified, with blank
    * padding on the right if necessary, in a string of length
    * <code>pad_len</code> characters.
    *
    * @param	s	String to be left justified.
    * @param	pad_len	Length of output string.
    * @return	The left-justified string.
    */
    public static String leftJustify(String s, int pad_len)
    {
	return (s + fill_string(' ', pad_len - s.length()));
    }

   /**
    * Return a copy of <code>s</code> right justified, with blank
    * padding on the left if necessary, in a string of length
    * <code>pad_len</code> characters.
    *
    * @param	s	String to be right justified.
    * @param	pad_len	Length of output string.
    * @return	The right-justified string.
    */
    public static String rightJustify(String s, int pad_len)
    {
	return (fill_string(' ', pad_len - s.length()) + s);
    }

   /**
    * Convert <code>number</code> to an unsigned binary string
    * representation right-justified in a field of minimal width.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String B(long number)
    {
	return (convertLong(number, 2, 0, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned binary string
    * representation right-justified in a field of at least
    * <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String B(long number, int width)
    {
	return (convertLong(number, 2, width, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned binary string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String B(long number, int width, int min_digits)
    {
	return (convertLong(number, 2, width, min_digits, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned binary string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits, grouping digits
    * into <code>ngroup</code> digits from the right, separated by an
    * underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String B(long number, int width, int min_digits, int ngroup)
    {
	return (convertLong(number, 2, min_digits, min_digits, false, true,
			    false, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of minimum width.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String I(long number)
    {
	return (convertLong(number, 10, 0, 0, false, false, false));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String I(long number, int width)
    {
	return (convertLong(number, 10, width, 0, false, false, false));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String I(long number, int width, int min_digits)
    {
	return (convertLong(number, 10, width, min_digits, false, false, false));
    }

   /**
    * Convert <code>number</code> to an optionally-signed decimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits, grouping digits
    * into <code>ngroup</code> digits from the right, separated by an
    * underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String I(long number, int width, int min_digits, int ngroup)
    {
	return (convertLong(number, 10, min_digits, min_digits, false, false,
			    false, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to an unsigned octal string
    * representation right-justified in a field of minimal width.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String O(long number)
    {
	return (convertLong(number, 8, 0, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned octal string
    * representation right-justified in a field of at least
    * <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String O(long number, int width)
    {
	return (convertLong(number, 8, width, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned octal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String O(long number, int width, int min_digits)
    {
	return (convertLong(number, 8, width, min_digits, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned octal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits, grouping digits
    * into <code>ngroup</code> digits from the right, separated by an
    * underscore.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String O(long number, int width, int min_digits, int ngroup)
    {
	return (convertLong(number, 8, min_digits, min_digits, false, true,
			    false, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to a string in base 10 right-justified
    * in a field of minimal width.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String R(long number)
    {
	return (convertLong(number, 10, 0, 0, false, false, false));
    }

   /**
    * Convert <code>number</code> to a string in base <code>base</code>
    * right-justified in a field of minimal width.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @return	String containing the converted number.
    */
    public static String R(long number, int base)
    {
	return (convertLong(number, base, 0, 0, false, false, false));
    }

   /**
    * Convert <code>number</code> to a string in base <code>base</code>
    * right-justified in a field of at least <code>width</code>
    * characters.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String R(long number, int base, int width)
    {
	return (convertLong(number, base, width, 0, false, false, false));
    }

   /**
    * Convert <code>number</code> to a string in base <code>base</code>
    * right-justified in a field of at least <code>width</code>
    * characters, with leading zeros if necessary to produce at least
    * <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String R(long number, int base, int width, int min_digits)
    {
	return (convertLong(number, base, width, min_digits, false, false, false));
    }

   /**
    * Convert <code>number</code> to an string in base <code>base</code>
    * right-justified in a field of at least <code>width</code>
    * characters, with leading zeros if necessary to produce at least
    * <code>min_digits</code> digits, grouping digits into
    * <code>ngroup</code> digits from the right, separated by an
    * underscore.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String R(long number, int base, int width, int min_digits,
			   int ngroup)
    {
	return (convertLong(number, base, min_digits, min_digits, false, false,
			    false, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to a signed (if negative) Ada-style
    * string in base 10 right-justified in a field of minimal width.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String S(long number)
    {
	return (convertLong(number, 10, 0, 0, false, false, true));
    }

   /**
    * Convert <code>number</code> to a signed (if negative) Ada-style
    * string in base <code>base</code> right-justified in a field of
    * minimal width.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @return	String containing the converted number.
    */
    public static String S(long number, int base)
    {
	return (convertLong(number, base, 0, 0, false, false, true));
    }

   /**
    * Convert <code>number</code> to a signed (if negative) Ada-style
    * string in base <code>base</code> right-justified in a field of at
    * least <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String S(long number, int base, int width)
    {
	return (convertLong(number, base, width, 0, false, false, true));
    }

   /**
    * Convert <code>number</code> to a signed (if negative) Ada-style
    * string in base <code>base</code> right-justified in a field of at
    * least <code>width</code> characters, with leading zeros if
    * necessary to produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String S(long number, int base, int width, int min_digits)
    {
	return (convertLong(number, base, width, min_digits, false, false, true));
    }

   /**
    * Convert <code>number</code> to a signed (if negative) Ada-style
    * string in base <code>base</code> right-justified in a field of at
    * least <code>width</code> characters, with leading zeros if
    * necessary to produce at least <code>min_digits</code> digits,
    * grouping digits into <code>ngroup</code> digits from the right,
    * separated by an underscore.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String S(long number, int base, int width, int min_digits,
			   int ngroup)
    {
	return (convertLong(number, base, min_digits, min_digits, false,
			    false, true, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to an unsigned hexadecimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String Z(long number)
    {
	return (convertLong(number, 16, 0, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned hexadecimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String Z(long number, int width)
    {
	return (convertLong(number, 16, width, 0, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned hexadecimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String Z(long number, int width, int min_digits)
    {
	return (convertLong(number, 16, width, min_digits, false, true, false));
    }

   /**
    * Convert <code>number</code> to an unsigned hexadecimal string
    * representation right-justified in a field of at least
    * <code>width</code> characters, with leading zeros if necessary to
    * produce at least <code>min_digits</code> digits.
    *
    * @param	number		Number to be converted.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String Z(long number, int width, int min_digits, int ngroup)
    {
	return (convertLong(number, 16, min_digits, min_digits, false, true,
			    false, LEADING_BLANK, ADA_SEPARATOR, ngroup));
    }

   /**
    * Convert <code>number</code> to a string representation in the
    * specified <code>base</code>.  This function serves as the core
    * of several much-simpler-to-use functions that provide for
    * conversion of binary integer values to string representations.
    *
    * <p>
    *
    * The string will be contained in a field of at least
    * <code>width</code> characters, and will have at least
    * <code>min_digits</code> (with leading zeros if necessary).
    *
    * <p>
    *
    * If <code>base</code> is out of the range 2..36, then
    * <code>base</code> = 10 is silently assumed.
    *
    * <p>
    *
    * The number is considered signed unless <code>is_unsigned</code>
    * is true and, in addition, the base is a power of two (that is,
    * 2, 4, 8, 16, or 32), in which case, if the number is negative,
    * it is equivalent to that value + 2<sup>64</sup>.
    *
    * <p>
    *
    * If <code>is_ada_style</code> is true, use the Ada numeric
    * literal form <code>base-in-decimal#&lt;digits&gt;#</code>.
    * Otherwise, the base is not recorded in the output string.
    *
    * <p>
    *
    * For example, in Ada style, 2#1111_1111_1111_1111# == 16#ffff# ==
    * 8#177_777# == 10#256# == 256.
    *
    * <p>
    *
    * The field is filled, if needed, on the left with
    * <code>leading_pad</code> characters, and a sign which is
    * mandatory if <code>require_sign</code> is true, and otherwise
    * supplied only if the number is negative.
    *
    * <p>
    *
    * Digits are optionally separated by <code>separator</code>
    * (typically, the culture-neutral underscore, or culture-dependent
    * comma or period) in groups of <code>ngroup</code> digits, counting
    * from the right.  Grouping is suppressed if <code>ngroup</code>
    * &lt;= 0.
    *
    * <p>
    *
    * A variant with three additional final arguments is provided for
    * use by the companion <code>fmtflt</code> class; for integer
    * conversions, simply omit them.  The additional arguments are:
    *
    * <p>
    *
    * <code>nphantom</code> is the number of phantom (unstored and
    * invisible) digits to the right of the number for the purposes of
    * digit grouping (normal value: 0).
    *
    * <p>
    *
    * <code>dot_after</code> is the number of digits from the right
    * after which a decimal point is to be inserted (normal value:
    * -1).
    *
    * <p>
    *
    * <code>have_carry</code> is true if there is a carry digit to
    * propagate into the converted integer (normal value: false).
    *
    * <p>
    *
    * <code>dot_after</code> and <code>have_carry</code> are ignored
    * if <code>is_unsigned</code> is true.
    *
    * <p>
    *
    * Simpler-to-use functions of the same name, but with fewer
    * arguments, are available: the first argument is mandatory, but
    * you may omit trailing arguments after the last one needed.
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	require_sign	<code>true</code> if a leading sign is required,
    *				else <code>false</code>.
    * @param	is_unsigned	<code>true</code> if the input number is treated
    *				as unsigned, else <code>false</code>.
    * @param	is_ada_style	<code>true</code> if the output formatting is
    *				Ada style, else <code>false</code>.
    * @param	leading_pad	Character used to fill leading empty positions.
    * @param	separator	Character used to separate digits for readability.
    * @param	ngroup		Number of digits between separator characters.
    * @param	nphantom	Number of phantom digits (for grouping control).
    * @param	dot_after	Number of digits from the right to place a decimal
    *				point after.
    * @param	have_carry	<code>true</code> if there is an input carry digit,
    *				else <code>false</code>.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits, boolean require_sign,
				     boolean is_unsigned, boolean is_ada_style,
				     char leading_pad, char separator, int
				     ngroup, int nphantom, int dot_after,
				     boolean have_carry)
    {
	// sanitize critical input values
	width = (int)Math.max(0L, (long)width);
	min_digits = (int)Math.max(0L, (long)min_digits);
	if ((base < 2) || (36 < base))
	    base = 10;
	ngroup = (int)Math.max(0L,(long)ngroup);

	int bufLength = 1 + 2 + 1 + 2*64 + 1 + 1 + width; // space for -36#zzzz...zz#.
	int bufPos;
	char[] buf = new char [bufLength];
	long digit_count;
	long group_count;
	boolean is_negative;

	is_negative = (number < 0L);
	bufPos = bufLength;

	if (is_ada_style)
	    buf[--bufPos] = ADA_LITERAL_DELIMITER;

	if ((base != 2) && (base != 4) && (base != 8) && (base != 16) && (base != 32))
	    is_unsigned = false;

	digit_count = 0;
	group_count = nphantom;
	if (is_unsigned)
	{	// We only support an unsigned interpretation for bases that are powers of two
	    int shift = 1;
	    int mask;

	    switch (base)
	    {
	    case  2: shift = 1; break;
	    case  4: shift = 2; break;
	    case  8: shift = 3; break;
	    case 16: shift = 4; break;
	    case 32: shift = 5; break;
	    }

	    mask = base - 1;
	    do
	    {
		int digit;

		digit = (int)(number & mask);
		number >>>= shift;
		if ((ngroup > 0) && (group_count == ngroup))
		{
		    buf[--bufPos] = separator;
		    group_count = 0;
		}
		buf[--bufPos] = DIGITS[digit];
		digit_count++;
		group_count++;
	    } while ((number != 0) || (digit_count < min_digits));
	}
	else			// signed case
	{
	    if (dot_after == 0)
		buf[--bufPos] = DECIMAL_POINT;
	    do
	    {
		int digit;

		// test_println("DEBUG: fmtint.convertLong(): number = " +
		//	number + " base = " + base + " have_carry = " + have_carry);

		digit = (int)(number % base);
		number /= base;
		if (number < 0L)	// in case number == Long.MIN_VALUE, which lacks a positive counterpart
		    number = -number;
		if (digit < 0)	// in case number == Long.MIN_VALUE
		    digit = -digit;
		if (have_carry)
		{
		    digit++;
		    if (digit == base)
			digit = 0;
		    else
			have_carry = false;
		}
		if ((ngroup > 0) && (group_count == ngroup))
		{
		    buf[--bufPos] = separator;
		    group_count = 0;
		}
		buf[--bufPos] = DIGITS[digit];
		digit_count++;
		group_count++;
		if (dot_after == digit_count)
		    buf[--bufPos] = DECIMAL_POINT;

		// test_println("DEBUG: fmtint.convertLong(): buf[] = [" +
		//	     new String(buf, bufPos, bufLength - bufPos) + "]");


	    } while ((number != 0) || (digit_count < min_digits) || have_carry);
	}

	if (is_ada_style)
	{
	    buf[--bufPos] = ADA_LITERAL_DELIMITER;
	    buf[--bufPos] = DIGITS[base % 10];
	    if (base >= 10)
		buf[--bufPos] = DIGITS[(base / 10) % 10];
	}

	if (is_unsigned)
	    ;
	else if (is_negative)
	    buf[--bufPos] = '-';
	else if (require_sign)
	    buf[--bufPos] = '+';

	while ((bufLength - bufPos) < width)
	    buf[--bufPos] = leading_pad;

	// test_println("DEBUG: fmtint.convertLong(): buf -> [" +
	//	     new String(buf, bufPos, bufLength - bufPos) + "]");

	return (new String(buf, bufPos, bufLength - bufPos));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number)
    {
	return (convertLong(number, 10));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base)
    {
	return (convertLong(number, base, 0));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width)
    {
	return (convertLong(number, base, width, 0));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits)
    {
	return (convertLong(number, base, width, min_digits, false));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	require_sign	<code>true</code> if a leading sign is required,
    *				else <code>false</code>.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits, boolean require_sign)
    {
	return (convertLong(number, base, width, min_digits, require_sign, false));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	require_sign	<code>true</code> if a leading sign is required,
    *				else <code>false</code>.
    * @param	is_unsigned	<code>true</code> if the input number is treated
    *				as unsigned, else <code>false</code>.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits, boolean require_sign,
				     boolean is_unsigned)
    {
	return (convertLong(number, base, width, min_digits, require_sign,
			    is_unsigned, false));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	require_sign	<code>true</code> if a leading sign is required,
    *				else <code>false</code>.
    * @param	is_unsigned	<code>true</code> if the input number is treated
    *				as unsigned, else <code>false</code>.
    * @param	is_ada_style	<code>true</code> if the output formatting is
    *				Ada style, else <code>false</code>.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits, boolean require_sign,
				     boolean is_unsigned, boolean is_ada_style)
    {
	return (convertLong(number, base, width, min_digits, require_sign,
			    is_unsigned, is_ada_style, LEADING_BLANK, ' ', 0));
    }

   /**
    *
    * @param	number		Number to be converted.
    * @param	base		Output number base.
    * @param	width		Width of returned string.
    * @param	min_digits	Minimum number of digits required.
    * @param	require_sign	<code>true</code> if a leading sign is required,
    *				else <code>false</code>.
    * @param	is_unsigned	<code>true</code> if the input number is treated
    *				as unsigned, else <code>false</code>.
    * @param	is_ada_style	<code>true</code> if the output formatting is
    *				Ada style, else <code>false</code>.
    * @param	leading_pad	Character used to fill leading empty positions.
    * @param	separator	Character used to separate digits for readability.
    * @param	ngroup		Number of digits between separator characters.
    * @return	String containing the converted number.
    */
    public static String convertLong(long number, int base, int width,
				     int min_digits, boolean require_sign,
				     boolean is_unsigned, boolean is_ada_style,
				     char leading_pad, char separator, int
				     ngroup)
    {
	return (convertLong(number, base, width, min_digits, require_sign, is_unsigned,
			    is_ada_style, leading_pad, separator, ngroup, 0, -1, false));
    }

    // Private functions for the test suite interface

    private static void test_B()
    {
	test_B_w();
	test_B_w_d();
	test_B_w_d_g();
    }

    private static void test_B_w()
    {
	test_newpage();
	test_println("Test of fmtint.B(number,w)\n");
	test_B_w_many();
    }

    private static void test_B_w_many()
    {
	test_B_w_twice(0L);
	test_B_w_twice(1L);
	test_B_w_twice(2L);
	test_B_w_twice(255L);
	test_B_w_twice(256L);
	test_B_w_twice(257L);
	test_B_w_twice(65534L);
	test_B_w_twice(65535L);
	test_B_w_twice(65536L);
	test_B_w_twice((long)Integer.MIN_VALUE);
	test_B_w_twice((long)Integer.MIN_VALUE + 1);
	test_B_w_twice((long)Integer.MAX_VALUE - 1);
	test_B_w_twice((long)Integer.MAX_VALUE);
	test_B_w_twice((long)Integer.MAX_VALUE + 1);
	test_B_w_twice(Long.MIN_VALUE);
	test_B_w_twice(Long.MAX_VALUE);
    }

    private static void test_B_w_simple(long number)
    {
	final int width = 32;

	test_println("B(" + number + "," + width + ") -> [" + B(number,width) + "]");
	test_println("B(" + number + "," + 0 + ") -> [" + B(number,0) + "]");
	test_println("");
    }

    private static void test_B_w_twice(long number)
    {
	test_B_w_simple(+number);
	test_B_w_simple(-number);
    }

    private static void test_B_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.B(number,w,d)\n");
	test_B_w_d_many();
    }

    private static void test_B_w_d_many()
    {
	test_B_w_d_twice(0L);
	test_B_w_d_twice(1L);
	test_B_w_d_twice(2L);
	test_B_w_d_twice(255L);
	test_B_w_d_twice(256L);
	test_B_w_d_twice(257L);
	test_B_w_d_twice(65534L);
	test_B_w_d_twice(65535L);
	test_B_w_d_twice(65536L);
	test_B_w_d_twice((long)Integer.MIN_VALUE);
	test_B_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_B_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_B_w_d_twice((long)Integer.MAX_VALUE);
	test_B_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_B_w_d_twice(Long.MIN_VALUE);
	test_B_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_B_w_d_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;

	test_println("B(" + number + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + B(number,width,min_width) + "]"
		     + " cf: toBinaryString -> " + Long.toBinaryString(number));
	test_println("B(" + number + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + B(number,width,0) + "]");
	test_println("B(" + number + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + B(number,0,min_width) + "]");
	test_println("B(" + number + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + B(number,0,0) + "]");
	test_println("");
    }

    private static void test_B_w_d_twice(long number)
    {
	test_B_w_d_simple(+number);
	test_B_w_d_simple(-number);
    }

    private static void test_B_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.B(number,w,d,g)\n");
	test_B_w_d_g_many();
    }

    private static void test_B_w_d_g_many()
    {
	test_B_w_d_g_twice(0L);
	test_B_w_d_g_twice(1L);
	test_B_w_d_g_twice(2L);
	test_B_w_d_g_twice(255L);
	test_B_w_d_g_twice(256L);
	test_B_w_d_g_twice(257L);
	test_B_w_d_g_twice(65534L);
	test_B_w_d_g_twice(65535L);
	test_B_w_d_g_twice(65536L);
	test_B_w_d_g_twice((long)Integer.MIN_VALUE);
	test_B_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_B_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_B_w_d_g_twice((long)Integer.MAX_VALUE);
	test_B_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_B_w_d_g_twice(Long.MIN_VALUE);
	test_B_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_B_w_d_g_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 4;

	test_println("B(" + number + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + B(number,width,min_width,ngroup) + "]");
	test_println("B(" + number + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + B(number,width,0,ngroup) + "]");
	test_println("B(" + number + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + B(number,0,min_width,ngroup) + "]");
	test_println("B(" + number + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + B(number,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_B_w_d_g_twice(long number)
    {
	test_B_w_d_g_simple(+number);
	test_B_w_d_g_simple(-number);
    }

    private static void test_I()
    {
	test_I_w();
	test_I_w_d();
	test_I_w_d_g();
    }

    private static void test_I_w()
    {
	test_newpage();
	test_println("Test of fmtint.I(number,w)\n");
	test_I_w_many();
    }

    private static void test_I_w_many()
    {
	test_I_w_twice(0L);
	test_I_w_twice(1L);
	test_I_w_twice(2L);
	test_I_w_twice(255L);
	test_I_w_twice(256L);
	test_I_w_twice(257L);
	test_I_w_twice(65534L);
	test_I_w_twice(65535L);
	test_I_w_twice(65536L);
	test_I_w_twice((long)Integer.MIN_VALUE);
	test_I_w_twice((long)Integer.MIN_VALUE + 1);
	test_I_w_twice((long)Integer.MAX_VALUE - 1);
	test_I_w_twice((long)Integer.MAX_VALUE);
	test_I_w_twice((long)Integer.MAX_VALUE + 1);
	test_I_w_twice(Long.MIN_VALUE);
	test_I_w_twice(Long.MAX_VALUE);
    }

    private static void test_I_w_simple(long number)
    {
	final int width = 32;

	test_println("I(" + number + "," + width + ") -> [" + I(number,width) + "]");
	test_println("I(" + number + "," + 0 + ") -> [" + I(number,0) + "]");
	test_println("");
    }

    private static void test_I_w_twice(long number)
    {
	test_I_w_simple(+number);
	test_I_w_simple(-number);
    }

    private static void test_I_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.I(number,w,d)\n");
	test_I_w_d_many();
    }

    private static void test_I_w_d_many()
    {
	test_I_w_d_twice(0L);
	test_I_w_d_twice(1L);
	test_I_w_d_twice(2L);
	test_I_w_d_twice(255L);
	test_I_w_d_twice(256L);
	test_I_w_d_twice(257L);
	test_I_w_d_twice(65534L);
	test_I_w_d_twice(65535L);
	test_I_w_d_twice(65536L);
	test_I_w_d_twice((long)Integer.MIN_VALUE);
	test_I_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_I_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_I_w_d_twice((long)Integer.MAX_VALUE);
	test_I_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_I_w_d_twice(Long.MIN_VALUE);
	test_I_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_I_w_d_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;

	test_println("I(" + number + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + I(number,width,min_width) + "]");
	test_println("I(" + number + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + I(number,width,0) + "]");
	test_println("I(" + number + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + I(number,0,min_width) + "]");
	test_println("I(" + number + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + I(number,0,0) + "]");
	test_println("");
    }

    private static void test_I_w_d_twice(long number)
    {
	test_I_w_d_simple(+number);
	test_I_w_d_simple(-number);
    }

    private static void test_I_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.I(number,w,d,g)\n");
	test_I_w_d_g_many();
    }

    private static void test_I_w_d_g_many()
    {
	test_I_w_d_g_twice(0L);
	test_I_w_d_g_twice(1L);
	test_I_w_d_g_twice(2L);
	test_I_w_d_g_twice(255L);
	test_I_w_d_g_twice(256L);
	test_I_w_d_g_twice(257L);
	test_I_w_d_g_twice(65534L);
	test_I_w_d_g_twice(65535L);
	test_I_w_d_g_twice(65536L);
	test_I_w_d_g_twice((long)Integer.MIN_VALUE);
	test_I_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_I_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_I_w_d_g_twice((long)Integer.MAX_VALUE);
	test_I_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_I_w_d_g_twice(Long.MIN_VALUE);
	test_I_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_I_w_d_g_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 3;

	test_println("I(" + number + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + I(number,width,min_width,ngroup) + "]");
	test_println("I(" + number + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + I(number,width,0,ngroup) + "]");
	test_println("I(" + number + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + I(number,0,min_width,ngroup) + "]");
	test_println("I(" + number + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + I(number,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_I_w_d_g_twice(long number)
    {
	test_I_w_d_g_simple(+number);
	test_I_w_d_g_simple(-number);
    }

    private static void test_O()
    {
	test_O_w();
	test_O_w_d();
	test_O_w_d_g();
    }

    private static void test_O_w()
    {
	test_newpage();
	test_println("Test of fmtint.O(number,w)\n");
	test_O_w_many();
    }

    private static void test_O_w_many()
    {
	test_O_w_twice(0L);
	test_O_w_twice(1L);
	test_O_w_twice(2L);
	test_O_w_twice(255L);
	test_O_w_twice(256L);
	test_O_w_twice(257L);
	test_O_w_twice(65534L);
	test_O_w_twice(65535L);
	test_O_w_twice(65536L);
	test_O_w_twice((long)Integer.MIN_VALUE);
	test_O_w_twice((long)Integer.MIN_VALUE + 1);
	test_O_w_twice((long)Integer.MAX_VALUE - 1);
	test_O_w_twice((long)Integer.MAX_VALUE);
	test_O_w_twice((long)Integer.MAX_VALUE + 1);
	test_O_w_twice(Long.MIN_VALUE);
	test_O_w_twice(Long.MAX_VALUE);
    }

    private static void test_O_w_simple(long number)
    {
	final int width = 32;

	test_println("O(" + number + "," + width + ") -> [" + O(number,width) + "]");
	test_println("O(" + number + "," + 0 + ") -> [" + O(number,0) + "]");
	test_println("");
    }

    private static void test_O_w_twice(long number)
    {
	test_O_w_simple(+number);
	test_O_w_simple(-number);
    }

    private static void test_O_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.O(number,w,d)\n");
	test_O_w_d_many();
    }

    private static void test_O_w_d_many()
    {
	test_O_w_d_twice(0L);
	test_O_w_d_twice(1L);
	test_O_w_d_twice(2L);
	test_O_w_d_twice(255L);
	test_O_w_d_twice(256L);
	test_O_w_d_twice(257L);
	test_O_w_d_twice(65534L);
	test_O_w_d_twice(65535L);
	test_O_w_d_twice(65536L);
	test_O_w_d_twice((long)Integer.MIN_VALUE);
	test_O_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_O_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_O_w_d_twice((long)Integer.MAX_VALUE);
	test_O_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_O_w_d_twice(Long.MIN_VALUE);
	test_O_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_O_w_d_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;

	test_println("O(" + number + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + O(number,width,min_width) + "]"
		     + " cf: toOctalString -> " + Long.toOctalString(number));
	test_println("O(" + number + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + O(number,width,0) + "]");
	test_println("O(" + number + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + O(number,0,min_width) + "]");
	test_println("O(" + number + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + O(number,0,0) + "]");
	test_println("");
    }

    private static void test_O_w_d_twice(long number)
    {
	test_O_w_d_simple(+number);
	test_O_w_d_simple(-number);
    }

    private static void test_O_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.O(number,w,d,g)\n");
	test_O_w_d_g_many();
    }

    private static void test_O_w_d_g_many()
    {
	test_O_w_d_g_twice(0L);
	test_O_w_d_g_twice(1L);
	test_O_w_d_g_twice(2L);
	test_O_w_d_g_twice(255L);
	test_O_w_d_g_twice(256L);
	test_O_w_d_g_twice(257L);
	test_O_w_d_g_twice(65534L);
	test_O_w_d_g_twice(65535L);
	test_O_w_d_g_twice(65536L);
	test_O_w_d_g_twice((long)Integer.MIN_VALUE);
	test_O_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_O_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_O_w_d_g_twice((long)Integer.MAX_VALUE);
	test_O_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_O_w_d_g_twice(Long.MIN_VALUE);
	test_O_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_O_w_d_g_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 3;

	test_println("O(" + number + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + O(number,width,min_width,ngroup) + "]");
	test_println("O(" + number + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + O(number,width,0,ngroup) + "]");
	test_println("O(" + number + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + O(number,0,min_width,ngroup) + "]");
	test_println("O(" + number + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + O(number,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_O_w_d_g_twice(long number)
    {
	test_O_w_d_g_simple(+number);
	test_O_w_d_g_simple(-number);
    }

    private static void test_R()
    {
	test_R_w();
	test_R_w_d();
	test_R_w_d_g();
    }

    private static void test_R_w()
    {
	test_newpage();
	test_println("Test of fmtint.R(number,base,w)\n");
	test_R_w_many();
    }

    private static void test_R_w_many()
    {
	test_R_w_twice(0L);
	test_R_w_twice(1L);
	test_R_w_twice(2L);
	test_R_w_twice(255L);
	test_R_w_twice(256L);
	test_R_w_twice(257L);
	test_R_w_twice(65534L);
	test_R_w_twice(65535L);
	test_R_w_twice(65536L);
	test_R_w_twice((long)Integer.MIN_VALUE);
	test_R_w_twice((long)Integer.MIN_VALUE + 1);
	test_R_w_twice((long)Integer.MAX_VALUE - 1);
	test_R_w_twice((long)Integer.MAX_VALUE);
	test_R_w_twice((long)Integer.MAX_VALUE + 1);
	test_R_w_twice(Long.MIN_VALUE);
	test_R_w_twice(Long.MAX_VALUE);
    }

    private static void test_R_w_simple(long number)
    {
	final int base = 5;
	final int width = 32;

	test_println("R(" + number + "," + base + "," + width + ") -> [" +
		     R(number,base,width) + "]");
	test_println("R(" + number + "," + base + "," + 0 + ") -> [" +
		     R(number,base,0) + "]");
	test_println("");
    }

    private static void test_R_w_twice(long number)
    {
	test_R_w_simple(+number);
	test_R_w_simple(-number);
    }

    private static void test_R_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.R(number,base,w,d)\n");
	test_R_w_d_many();
    }

    private static void test_R_w_d_many()
    {
	test_R_w_d_twice(0L);
	test_R_w_d_twice(1L);
	test_R_w_d_twice(2L);
	test_R_w_d_twice(255L);
	test_R_w_d_twice(256L);
	test_R_w_d_twice(257L);
	test_R_w_d_twice(65534L);
	test_R_w_d_twice(65535L);
	test_R_w_d_twice(65536L);
	test_R_w_d_twice((long)Integer.MIN_VALUE);
	test_R_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_R_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_R_w_d_twice((long)Integer.MAX_VALUE);
	test_R_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_R_w_d_twice(Long.MIN_VALUE);
	test_R_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_R_w_d_simple(long number)
    {
	final int base = 5;
	final int width = 32;
	final int min_width = 16;

	test_println("R(" + number + "," +
		     base + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + R(number,base,width,min_width) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + R(number,base,width,0) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + R(number,base,0,min_width) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + R(number,base,0,0) + "]");
	test_println("");
    }

    private static void test_R_w_d_twice(long number)
    {
	test_R_w_d_simple(+number);
	test_R_w_d_simple(-number);
    }

    private static void test_R_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.R(number,base,w,d,g)\n");
	test_R_w_d_g_many();
    }

    private static void test_R_w_d_g_many()
    {
	test_R_w_d_g_twice(0L);
	test_R_w_d_g_twice(1L);
	test_R_w_d_g_twice(2L);
	test_R_w_d_g_twice(255L);
	test_R_w_d_g_twice(256L);
	test_R_w_d_g_twice(257L);
	test_R_w_d_g_twice(65534L);
	test_R_w_d_g_twice(65535L);
	test_R_w_d_g_twice(65536L);
	test_R_w_d_g_twice((long)Integer.MIN_VALUE);
	test_R_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_R_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_R_w_d_g_twice((long)Integer.MAX_VALUE);
	test_R_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_R_w_d_g_twice(Long.MIN_VALUE);
	test_R_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_R_w_d_g_simple(long number)
    {
	final int base = 5;
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 4;

	test_println("R(" + number + "," +
		     base + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + R(number,base,width,min_width,ngroup) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + R(number,base,width,0,ngroup) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + R(number,base,0,min_width,ngroup) + "]");
	test_println("R(" + number + "," +
		     base + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + R(number,base,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_R_w_d_g_twice(long number)
    {
	test_R_w_d_g_simple(+number);
	test_R_w_d_g_simple(-number);
    }

    private static void test_S()
    {
	test_S_w();
	test_S_w_d();
	test_S_w_d_g();
    }

    private static void test_S_w()
    {
	test_newpage();
	test_println("Test of fmtint.S(number,base,w)\n");
	test_S_w_many();
    }

    private static void test_S_w_many()
    {
	test_S_w_twice(0L);
	test_S_w_twice(1L);
	test_S_w_twice(2L);
	test_S_w_twice(255L);
	test_S_w_twice(256L);
	test_S_w_twice(257L);
	test_S_w_twice(65534L);
	test_S_w_twice(65535L);
	test_S_w_twice(65536L);
	test_S_w_twice((long)Integer.MIN_VALUE);
	test_S_w_twice((long)Integer.MIN_VALUE + 1);
	test_S_w_twice((long)Integer.MAX_VALUE - 1);
	test_S_w_twice((long)Integer.MAX_VALUE);
	test_S_w_twice((long)Integer.MAX_VALUE + 1);
	test_S_w_twice(Long.MIN_VALUE);
	test_S_w_twice(Long.MAX_VALUE);
    }

    private static void test_S_w_simple(long number)
    {
	final int base = 5;
	final int width = 32;

	test_println("S(" + number + "," + base + "," + width + ") -> [" +
		     S(number,base,width) + "]");
	test_println("S(" + number + "," + base + "," + 0 + ") -> [" +
		     S(number,base,0) + "]");
	test_println("");
    }

    private static void test_S_w_twice(long number)
    {
	test_S_w_simple(+number);
	test_S_w_simple(-number);
    }

    private static void test_S_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.S(number,base,w,d)\n");
	test_S_w_d_many();
    }

    private static void test_S_w_d_many()
    {
	test_S_w_d_twice(0L);
	test_S_w_d_twice(1L);
	test_S_w_d_twice(2L);
	test_S_w_d_twice(255L);
	test_S_w_d_twice(256L);
	test_S_w_d_twice(257L);
	test_S_w_d_twice(65534L);
	test_S_w_d_twice(65535L);
	test_S_w_d_twice(65536L);
	test_S_w_d_twice((long)Integer.MIN_VALUE);
	test_S_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_S_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_S_w_d_twice((long)Integer.MAX_VALUE);
	test_S_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_S_w_d_twice(Long.MIN_VALUE);
	test_S_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_S_w_d_simple(long number)
    {
	final int base = 5;
	final int width = 32;
	final int min_width = 16;

	test_println("S(" + number + "," +
		     base + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + S(number,base,width,min_width) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + S(number,base,width,0) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + S(number,base,0,min_width) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + S(number,base,0,0) + "]");
	test_println("");
    }

    private static void test_S_w_d_twice(long number)
    {
	test_S_w_d_simple(+number);
	test_S_w_d_simple(-number);
    }

    private static void test_S_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.S(number,base,w,d,g)\n");
	test_S_w_d_g_many();
    }

    private static void test_S_w_d_g_many()
    {
	test_S_w_d_g_twice(0L);
	test_S_w_d_g_twice(1L);
	test_S_w_d_g_twice(2L);
	test_S_w_d_g_twice(255L);
	test_S_w_d_g_twice(256L);
	test_S_w_d_g_twice(257L);
	test_S_w_d_g_twice(65534L);
	test_S_w_d_g_twice(65535L);
	test_S_w_d_g_twice(65536L);
	test_S_w_d_g_twice((long)Integer.MIN_VALUE);
	test_S_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_S_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_S_w_d_g_twice((long)Integer.MAX_VALUE);
	test_S_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_S_w_d_g_twice(Long.MIN_VALUE);
	test_S_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_S_w_d_g_simple(long number)
    {
	final int base = 5;
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 4;

	test_println("S(" + number + "," +
		     base + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + S(number,base,width,min_width,ngroup) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + S(number,base,width,0,ngroup) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + S(number,base,0,min_width,ngroup) + "]");
	test_println("S(" + number + "," +
		     base + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + S(number,base,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_S_w_d_g_twice(long number)
    {
	test_S_w_d_g_simple(+number);
	test_S_w_d_g_simple(-number);
    }

    private static void test_Z()
    {
	test_Z_w();
	test_Z_w_d();
	test_Z_w_d_g();
    }

    private static void test_Z_w()
    {
	test_newpage();
	test_println("Test of fmtint.Z(number,w)\n");
	test_Z_w_many();
    }

    private static void test_Z_w_many()
    {
	test_Z_w_twice(0L);
	test_Z_w_twice(1L);
	test_Z_w_twice(2L);
	test_Z_w_twice(255L);
	test_Z_w_twice(256L);
	test_Z_w_twice(257L);
	test_Z_w_twice(65534L);
	test_Z_w_twice(65535L);
	test_Z_w_twice(65536L);
	test_Z_w_twice((long)Integer.MIN_VALUE);
	test_Z_w_twice((long)Integer.MIN_VALUE + 1);
	test_Z_w_twice((long)Integer.MAX_VALUE - 1);
	test_Z_w_twice((long)Integer.MAX_VALUE);
	test_Z_w_twice((long)Integer.MAX_VALUE + 1);
	test_Z_w_twice(Long.MIN_VALUE);
	test_Z_w_twice(Long.MAX_VALUE);
    }

    private static void test_Z_w_simple(long number)
    {
	final int width = 32;

	test_println("Z(" + number + "," + width + ") -> [" + Z(number,width) + "]");
	test_println("Z(" + number + "," + 0 + ") -> [" + Z(number,0) + "]");
	test_println("");
    }

    private static void test_Z_w_twice(long number)
    {
	test_Z_w_simple(+number);
	test_Z_w_simple(-number);
    }

    private static void test_Z_w_d()
    {
	test_newpage();
	test_println("Test of fmtint.Z(number,w,d)\n");
	test_Z_w_d_many();
    }

    private static void test_Z_w_d_many()
    {
	test_Z_w_d_twice(0L);
	test_Z_w_d_twice(1L);
	test_Z_w_d_twice(2L);
	test_Z_w_d_twice(255L);
	test_Z_w_d_twice(256L);
	test_Z_w_d_twice(257L);
	test_Z_w_d_twice(65534L);
	test_Z_w_d_twice(65535L);
	test_Z_w_d_twice(65536L);
	test_Z_w_d_twice((long)Integer.MIN_VALUE);
	test_Z_w_d_twice((long)Integer.MIN_VALUE + 1);
	test_Z_w_d_twice((long)Integer.MAX_VALUE - 1);
	test_Z_w_d_twice((long)Integer.MAX_VALUE);
	test_Z_w_d_twice((long)Integer.MAX_VALUE + 1);
	test_Z_w_d_twice(Long.MIN_VALUE);
	test_Z_w_d_twice(Long.MAX_VALUE);
    }

    private static void test_Z_w_d_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;

	test_println("Z(" + number + "," +
		     width + "," +
		     min_width + ")"
		     + " -> [" + Z(number,width,min_width) + "]"
		     + " cf: toHexString -> " + Long.toHexString(number));
	test_println("Z(" + number + "," +
		     width + "," +
		     0 + ")"
		     + " -> [" + Z(number,width,0) + "]");
	test_println("Z(" + number + "," +
		     0 + "," +
		     min_width + ")"
		     + " -> [" + Z(number,0,min_width) + "]");
	test_println("Z(" + number + "," +
		     0 + "," +
		     0 + ")"
		     + " -> [" + Z(number,0,0) + "]");
	test_println("");
    }

    private static void test_Z_w_d_twice(long number)
    {
	test_Z_w_d_simple(+number);
	test_Z_w_d_simple(-number);
    }

    private static void test_Z_w_d_g()
    {
	test_newpage();
	test_println("Test of fmtint.Z(number,w,d,g)\n");
	test_Z_w_d_g_many();
    }

    private static void test_Z_w_d_g_many()
    {
	test_Z_w_d_g_twice(0L);
	test_Z_w_d_g_twice(1L);
	test_Z_w_d_g_twice(2L);
	test_Z_w_d_g_twice(255L);
	test_Z_w_d_g_twice(256L);
	test_Z_w_d_g_twice(257L);
	test_Z_w_d_g_twice(65534L);
	test_Z_w_d_g_twice(65535L);
	test_Z_w_d_g_twice(65536L);
	test_Z_w_d_g_twice((long)Integer.MIN_VALUE);
	test_Z_w_d_g_twice((long)Integer.MIN_VALUE + 1);
	test_Z_w_d_g_twice((long)Integer.MAX_VALUE - 1);
	test_Z_w_d_g_twice((long)Integer.MAX_VALUE);
	test_Z_w_d_g_twice((long)Integer.MAX_VALUE + 1);
	test_Z_w_d_g_twice(Long.MIN_VALUE);
	test_Z_w_d_g_twice(Long.MAX_VALUE);
    }

    private static void test_Z_w_d_g_simple(long number)
    {
	final int width = 32;
	final int min_width = 16;
	final int ngroup = 4;

	test_println("Z(" + number + "," +
		     width + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + Z(number,width,min_width,ngroup) + "]");
	test_println("Z(" + number + "," +
		     width + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + Z(number,width,0,ngroup) + "]");
	test_println("Z(" + number + "," +
		     0 + "," +
		     min_width + "," +
		     ngroup + ")"
		     + " -> [" + Z(number,0,min_width,ngroup) + "]");
	test_println("Z(" + number + "," +
		     0 + "," +
		     0 + "," +
		     ngroup + ")"
		     + " -> [" + Z(number,0,0,ngroup) + "]");
	test_println("");
    }

    private static void test_Z_w_d_g_twice(long number)
    {
	test_Z_w_d_g_simple(+number);
	test_Z_w_d_g_simple(-number);
    }

    private static void test_convertLong()
    {
	test_newpage();
	test_println("Test of fmtint.convertLong(...)\n");
	test_println("NB: Expect ERROR reports for negative values in nondecimal bases,");
	test_println("because of a design limitation in Java's Long.parseLong().\n");

	for (long i = 0L ; i <= 10L; ++i)
	    testit_many(i);

	if (false)		// generates 50MB+ output if true and if testit_once():show_all is true!
	{
	    for (long i = 1 ; i < Long.MAX_VALUE; i *= 2)
		testit_many(i);
	    for (long i = 1 ; i < Long.MAX_VALUE; i *= 2)
		testit_many(i - 1);
	    for (long i = 1 ; i < Long.MAX_VALUE; i *= 2)
		testit_many(i + 1);
	}

	testit_many(36L * 36L * 36L * 36L * 35L +
		    36L * 36L * 36L * 35L +
		    36L * 36L * 35L +
		    36L * 35L +
		    35L);
	testit_many((long)Integer.MAX_VALUE);
	testit_many((long)Integer.MAX_VALUE + 1);
	testit_many((long)Integer.MAX_VALUE + 2);
	testit_many(Long.MIN_VALUE);
	testit_many(Long.MAX_VALUE);
    }

    private static void test_newpage()
    {
	test_println("\f");
    }

    private static void test_println(String message)
    {
	System.out.println(message);
    }

    private static void testit_base(long number, int base)
    {
	testit_five(number, base, false, false, false);
	testit_five(number, base, false, false, true);
	testit_five(number, base, true,  false, false);
	testit_five(number, base, true,  false, true);

	testit_five(number, base, false, true, false);
	testit_five(number, base, false, true, true);
	testit_five(number, base, true,  true, false);
	testit_five(number, base, true,  true, true);
    }

    private static void testit_five(long number, int base,
				    boolean require_sign, boolean is_unsigned,
				    boolean is_ada_style)
    {
	testit_once(number, base, 10,  0, require_sign, is_unsigned,
		    is_ada_style, 'X', ' ', 2);
	testit_once(number, base, 10,  4, require_sign, is_unsigned,
		    is_ada_style, '*', '_', 4);
	testit_once(number, base, 10,  4, require_sign, is_unsigned,
		    is_ada_style, ' ', ' ', 0);
	testit_once(number, base, 10,  4, require_sign, is_unsigned,
		    is_ada_style, '@', ',', 3);
	testit_once(number, base, 20, 16, require_sign, is_unsigned,
		    is_ada_style, ':', '_', 3);
    }

    private static void testit_once(long number, int base,
				    int width, int min_digits,
				    boolean require_sign, boolean is_unsigned,
				    boolean is_ada_style, char leading_pad,
				    char separator, int ngroup)
    {
	boolean show_all = false; // suppressed to reduce output size
	String s = convertLong(number, base, width, min_digits,
			       require_sign, is_unsigned, is_ada_style,
			       leading_pad, separator, ngroup);

	if (show_all)		// suppressed to reduce output size
	{
	    test_println("convertLong(number=" + number + ","
			 + "base=" + base + ","
			 + "width=" + width + ","
			 + "min_digits=" + min_digits + ","
			 + "require_sign=" + require_sign + ","
			 + "is_unsigned=" + is_unsigned + ","
			 + "\n\t    "
			 + "is_ada_style=" + is_ada_style + ","
			 + "leading_pad='" + leading_pad + "',"
			 + "separator='" + separator + "',"
			 + "ngroup=" + ngroup + ") -> [" + s + "]");
	}

	if ((ngroup <= 0) && !is_ada_style)
	{
	    long result;

	    try
	    {
		String t = s.trim(); // parseLong cannot handle leading space, sigh...
		if (t.substring(0,1).equals("+")) // parseLong cannot handle leading + sign, sigh..
		    t = new String(t.substring(1));
		result = Long.parseLong(t, ((base < 2) || (36 < base)) ? 10 : base);
		if (result != number)
		    test_println("ERROR: Long.parseLong() -> " + result);
	    }
	    catch (NumberFormatException e)
	    {
		if (!show_all)
		    test_println("convertLong(number=" + number + ","
				 + "base=" + base + ","
				 + "width=" + width + ","
				 + "min_digits=" + min_digits + ","
				 + "require_sign=" + require_sign + ","
				 + "is_unsigned=" + is_unsigned + ","
				 + "\n\t    "
				 + "is_ada_style=" + is_ada_style + ","
				 + "leading_pad='" + leading_pad + "',"
				 + "separator='" + separator + "',"
				 + "ngroup=" + ngroup + ") -> [" + s + "]");
		test_println("ERROR: s.parseLong threw " + e);
		if (!show_all)
		    test_println("");
	    }
	}
	if (show_all)
	    test_println("");
    }

    private static void testit_many(long number)
    {
	testit_twice(number, 0);
	testit_twice(number, 2);
	testit_twice(number, 4);
	testit_twice(number, 5);
	testit_twice(number, 8);
	testit_twice(number, 10);
	testit_twice(number, 16);
	testit_twice(number, 36);
	testit_twice(number, 100);
    }

    private static void testit_twice(long number, int base)
    {
	testit_base(number, base);
	testit_base(-number, base);
    }

    // Test suite program

   /**
    * Run a test suite of the public functions in this class.
    *
    * @param	args[]	Command-line arguments (ignored).
    */
    public static void main(String[] args)
    {
	test_convertLong();
	test_B();
	test_I();
	test_O();
	test_R();
	test_S();
	test_Z();
    }
}
