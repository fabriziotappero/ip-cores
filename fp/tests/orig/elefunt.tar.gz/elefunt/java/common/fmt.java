/* -*-java-*- fmt.java */

import java.lang.Math;
import java.text.*;

public class fmt
{
    private static String blank_string(int nblanks)
    {
	if (nblanks < 0)
	    nblanks = 0;

	StringBuffer blanks = new StringBuffer(nblanks);

	blanks.setLength(nblanks);
	for (int k = 0; k < nblanks; ++k)
	    blanks.setCharAt(k,' ');
	return (blanks.toString());
    }

    public static String leftAdjust(String s, int pad_len)
    {
	return (s + blank_string(pad_len - s.length()));
    }

    public static String centerAdjust(String s, int pad_len)
    {
	int nleft;
	int nright;
	int need = Math.max(0,pad_len - s.length());

	nleft = need/2;
	nright = need - nleft;
	return (blank_string(nleft) + s + blank_string(nright));
    }

    public static String rightAdjust(String s, int pad_len)
    {
	return (blank_string(pad_len - s.length()) + s);
    }

    // TO DO: decide whether to use Fortran-style **** padding to mark overflow,
    // or C/C++ style of automatic expansion of field width, or Java style of
    // silent high-order digits truncation (ugh!).  Current use is Java style!

    public static String E(double value, int width, int decimals)
    {
	// DecimalFormat myFormat = (DecimalFormat)NumberFormat.getInstance();

	// myFormat.setGroupingSize(0);   // to suppress comma separators
	// myFormat.setMinimumIntegerDigits(1);
	// myFormat.setMaximumIntegerDigits(width - decimals - 2);
	// myFormat.setMaximumIntegerDigits(1);
	// myFormat.setMinimumFractionDigits(decimals);
	// myFormat.setMaximumFractionDigits(decimals);

	if (java.lang.Double.isNaN(value))
	    return (rightAdjust("" + value, width));
	else if (java.lang.Double.isInfinite(value))
	    return (rightAdjust("" + value, width));
	else
	{
	    // return (rightAdjust(myFormat.format(value), width));	// BAD: truncates leading digits
	    // return (rightAdjust("" + value, width));

	    String s = "" + value;

	    // TO-DO: s may not have an exponent, and the decimal
	    // point can be anywhere: fix this uncontrollable idiocy!

	    // System.out.println("\t\t\tDEBUG: s = [" + s + "]");
	    int dotpos = Math.max(0,s.indexOf("."));
	    int Epos = s.indexOf("E");
	    if (Epos < 0)
		Epos = s.length();
	    String prefix = s.substring(0,dotpos + 1);
	    String fraction = s.substring(dotpos + 1,Epos);
	    String exponent = s.substring(Epos);
	    if (exponent == "")
		exponent = "e+00";
	    // System.out.println("\t\t\tDEBUG: s = [" + s + "] prefix = [" + prefix + "] + fraction = [" + fraction + "] + exponent = [" + exponent + "]");
	    // NB: This truncates the fraction, rather than rounding the last digit...
	    return(rightAdjust(prefix + fraction.substring(0,(int)Math.min(fraction.length(),decimals)) + exponent, width));
	}
    }

    public static String F(double value, int width, int decimals)
    {
	DecimalFormat myFormat = (DecimalFormat)NumberFormat.getInstance();

	myFormat.setGroupingSize(0);   // to suppress comma separators
	myFormat.setMinimumIntegerDigits(1);
	myFormat.setMaximumIntegerDigits(width - decimals - 2);
	myFormat.setMinimumFractionDigits(decimals);
	myFormat.setMaximumFractionDigits(decimals);

	if (java.lang.Double.isNaN(value))
	    return (rightAdjust("" + value, width));
	else if (java.lang.Double.isInfinite(value))
	    return (rightAdjust("" + value, width));
	else
	    return (rightAdjust(myFormat.format(value), width));
    }

    public static String I(long value, int width)
    {
	return (rightAdjust("" + value, width));
    }

    public static void main(String[] args)
    {
	// final double e = 1.23456789e+123;
	final double e = 1.23456789e+03;
	final double f = 9.876543210;
	final int n = 12345;
	final double NaN = java.lang.Double.NaN;
	final double Inf = java.lang.Double.POSITIVE_INFINITY;

	if (false)
	{
	    for (int width = 15; width < 30; ++width)
		for (int decimals = 0; decimals < 20; ++decimals)
		    System.out.println("E" + width + "." + decimals + ":\t" + E(123.456789876543210123456789e+306,width,decimals));
	}

	System.out.println("Tests of I(value,width)\n");
	for (int width = 1; width < 15; width += 1)
	    System.out.println("I" + width + ":\t" + I(n,width));

	System.out.println("\n\nTests of F(value,width,decimals)\n");
	for (int extra_width = 0; extra_width < 5; extra_width += 1)
	{
	    for (int decimals = 0; decimals < 10; ++decimals)
	    {
		int width = extra_width + 1 + 1 + decimals;
		System.out.println("F" + width + "." + decimals + ":\t" + F(f,width,decimals) + "\t" + F(-f,width,decimals));
	    }
	}

	System.out.println("\n\nTests of F(NaN,width,decimals)\n");
	for (int width = 1; width < 15; width += 3)
	{
	    for (int decimals = 0; decimals < 10; decimals += 3)
		System.out.println("F" + width + "." + decimals + ":\t" + F(NaN,width,decimals) + "\t" + F(-NaN,width,decimals));
	}

	System.out.println("\n\nTests of F(Inf,width,decimals)\n");
	for (int width = 1; width < 15; width += 3)
	{
	    for (int decimals = 0; decimals < 10; decimals += 3)
		System.out.println("F" + width + "." + decimals + ":\t" + F(Inf,width,decimals) + "\t" + F(-Inf,width,decimals));
	}

	System.out.println("\n\nTests of E(value,width,decimals)\n");
	for (int extra_width = 0; extra_width < 5; extra_width += 1)
	{
	    for (int decimals = 0; decimals < 10; decimals++)
	    {
		int width = extra_width + 1 + 1 + decimals;
		System.out.println("E" + width + "." + decimals + ":\t" + E(e,width,decimals) + "\t" + E(-e,width,decimals));
	    }
	}

	System.out.println("\n\nTests of E(NaN,width,decimals)\n");
	for (int width = 1; width < 15; width += 3)
	{
	    for (int decimals = 0; decimals < 10; decimals +=3 )
		System.out.println("E" + width + "." + decimals + ":\t" + E(NaN,width,decimals) + "\t" + E(-NaN,width,decimals));
	}

	System.out.println("\n\nTests of E(Inf,width,decimals)\n");
	for (int width = 1; width < 15; width += 3)
	{
	    for (int decimals = 0; decimals < 10; decimals += 3)
		System.out.println("E" + width + "." + decimals + ":\t" + E(Inf,width,decimals) + "\t" + E(-Inf,width,decimals));
	}
    }
}
