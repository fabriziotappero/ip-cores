/* -*-java-*- maxtest.java */

public class maxtest
{
    public static long maxtest()
    {
	Long the_value;
	String p;

	p = System.getProperty("MAXTEST");
	if (p != null)
	{
	    try
	    {
		the_value = new Long(p);
		if (the_value.longValue() > 0L)
		    return (the_value.longValue());
	    }
	    catch (java.lang.NumberFormatException e)
	    {
		System.err.println("Ignoring bad number format in MAXTEST = " + p);
	    }
	}
	return (elefunt.MAXTEST);
    }

    public static void main(String[] args)
    {
	long n;
	n = maxtest();
	System.out.println("DEBUG: maxtest() = " + n);
    }
}
