/* -*-java-*- initseed.java */

public class initseed
{
    public static long initseed()
    {
	Long the_value;
	String p;

	p = System.getProperty("INITIALSEED");
	if (p != null)
	{
	    try
	    {
		the_value = new Long(p);
		if (the_value.longValue() >= 0L)
		    return (the_value.longValue());
	    }
	    catch (java.lang.NumberFormatException e)
	    {
		System.err.println("Ignoring bad number format in INITIALSEED = " + p);
	    }
	}
	return (ranbase.INITIALSEED);
    }

    public static void main(String[] args)
    {
	long n;
	n = initseed();
	System.out.println("DEBUG: initseed() = " + n);
    }
}
