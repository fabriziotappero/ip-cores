/*******************************************
   assem.c
   an assembler for the TINY8 CPU
	 TGB Ulrich Riedel 20020223
*******************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct _tag_Tmcode {
	struct _tag_Tmcode *prev;
	struct _tag_Tmcode *next;
	int linenumber;
	unsigned short addr;       // machinecode address
  char label[34];            // destination label
	char mnemo[8];             // mnemonic or directive
	char operand[80];          // operand
	unsigned char mlen;        // machinecode length
	unsigned char _pad1;       // padding
	unsigned char mcod[8];     // machinecode
	unsigned short oaddr1;     // operand address1
	unsigned short oaddr2;     // operand address2
	char olabel1[34];          // operand label1
	char olabel2[34];          // operand label2
} Tmcode;

typedef struct {
	unsigned short addr;
	char label[40];
} Taddress;

char *getvalue(char *str, unsigned short *val);
int  doMOV(char *str, unsigned short *len, unsigned char *cod);
int  doCMP(char *str, unsigned short *len, unsigned char *cod);
int  doADD(char *str, unsigned short *len, unsigned char *cod);
int  doADC(char *str, unsigned short *len, unsigned char *cod);
int  doSUB(char *str, unsigned short *len, unsigned char *cod);
int  doSBC(char *str, unsigned short *len, unsigned char *cod);
int  doAND(char *str, unsigned short *len, unsigned char *cod);
int  doOR (char *str, unsigned short *len, unsigned char *cod);
int  doXOR(char *str, unsigned short *len, unsigned char *cod);
int  doROL(char *str, unsigned short *len, unsigned char *cod);
int  doROLC(char *str, unsigned short *len, unsigned char *cod);
int  doROR(char *str, unsigned short *len, unsigned char *cod);
int  doRORC(char *str, unsigned short *len, unsigned char *cod);
int  doLSL(char *str, unsigned short *len, unsigned char *cod);
int  doLSR(char *str, unsigned short *len, unsigned char *cod);
int  doASR(char *str, unsigned short *len, unsigned char *cod);
int  doSWAP(char *str, unsigned short *len, unsigned char *cod);
int  doMIRROR(char *str, unsigned short *len, unsigned char *cod);
int  doJMP(char *str, unsigned short *len, unsigned char *cod);
int  doJCC(char *str, unsigned short *len, unsigned char *cod);
int  doJCS(char *str, unsigned short *len, unsigned char *cod);
int  doJEQ(char *str, unsigned short *len, unsigned char *cod);
int  doJGE(char *str, unsigned short *len, unsigned char *cod);
int  doJGT(char *str, unsigned short *len, unsigned char *cod);
int  doJHI(char *str, unsigned short *len, unsigned char *cod);
int  doJLE(char *str, unsigned short *len, unsigned char *cod);
int  doJLS(char *str, unsigned short *len, unsigned char *cod);
int  doJLT(char *str, unsigned short *len, unsigned char *cod);
int  doJMI(char *str, unsigned short *len, unsigned char *cod);
int  doJNE(char *str, unsigned short *len, unsigned char *cod);
int  doJPL(char *str, unsigned short *len, unsigned char *cod);
int  doJVC(char *str, unsigned short *len, unsigned char *cod);
int  doJVS(char *str, unsigned short *len, unsigned char *cod);

int main(int argc,char *argv[])
{
	FILE *fp;
	char line[80];
	char tmpStr[40];
	int  linenumber, idx, maxi, jdx, sdx;
	unsigned short slen;
	Tmcode *head, *tail, *cPtr, *hPtr, *tPtr;
	unsigned short addr, val1, val2;
	unsigned char code[8], chksum, lsn, msn;
	Taddress *address;

	if (argc == 1) {
    fprintf(stderr, "usage: assem file\n");
		return 1;
	}

	fp = fopen(argv[1], "r");
	if(NULL == fp) {
		fprintf(stderr, "%s doesn't exist\n", argv[1]);
		return 2;
	}

/////////// pre pass /////////////////////////////////////
  linenumber = 1;
	head = tail = NULL;
	while(fgets(line, 79, fp)) {
		for(idx=0; line[idx]; idx++) {
			if(line[idx] == 13) { line[idx] = 0; continue; }
			if(line[idx] == 10) { line[idx] = 0; continue; }
			if(line[idx] == 9)  { line[idx] = 32; continue; }
			if((line[idx] & 0xE0) == 0) {
				fprintf(stderr, "%d contains non printable characters.\n", linenumber);
				return 3;
			}
			if(line[idx] < 0) {
				fprintf(stderr, "%d contains non printable characters\n", linenumber);
				return 3;
			}
			line[idx] = toupper(line[idx]);
		}
		if(line[0] == ';') { linenumber++; continue; } // comment ?
		if(line[0] == '.') {
      fprintf(stderr, "%d no directive first allowed\n", linenumber);
			linenumber++;
		  continue;
		}
///////// break into up to 3 components //////////////////
    hPtr = (Tmcode *) malloc(sizeof(Tmcode));
		memset(hPtr, 0, sizeof(Tmcode));
    if(head == NULL) {
      head = hPtr;
			tail = hPtr;
			cPtr = head;
		} else {
			tPtr = cPtr;
			cPtr->next = hPtr;
			cPtr = cPtr->next;
			cPtr->prev = tPtr;
			tail = cPtr;
		}
		hPtr->linenumber = linenumber;
///////// 1st component, label ///////////////////////////
    idx = 0;
    if(!isspace(line[0])) {
			for(; line[idx] && (idx<32); idx++) {
				if(isspace(line[idx])) break;
				tmpStr[idx] = line[idx];
			}
			tmpStr[idx] = 0;
      strcpy(hPtr->label, tmpStr);  // save label
		}
		if(0 == line[idx]) {  // end of line?, label only
			linenumber++;
			continue;
		}
///////// 2nd component, mnemonic or directive ///////////
    while(isspace(line[idx])) idx++;  // skip space
    for(jdx=0; line[idx] && (jdx<8); jdx++) {
      if(isspace(line[idx])) break;
			tmpStr[jdx] = line[idx++];
		}
		tmpStr[jdx] = 0;
		strcpy(hPtr->mnemo, tmpStr);  // save mnemonic or directive
    if(0 == line[idx]) {  // suddenly end of line?
			fprintf(stderr, "%d operand missing\n", linenumber);
			linenumber++;
			continue;
		}
    while(isspace(line[idx])) idx++;  // skip space
    if(0 == line[idx]) {  // suddenly end of line?
			fprintf(stderr, "%d operand missing\n", linenumber);
			linenumber++;
			continue;
		}
///////// 3rd component, operand /////////////////////////
    for(jdx=0; line[idx] && (jdx<80); jdx++) {
			tmpStr[jdx] = line[idx++];
		}
		tmpStr[jdx] = 0;
		strcpy(hPtr->operand, tmpStr);  // save mnemonic or directive
		linenumber++;
	}

	fclose(fp);

	printf("1st pass\n");
/////////// 1st pass ////////////////////////////////////
  addr = 0;
  hPtr = head;
	while(hPtr) {
		printf("<%s><%s><%s>\n", hPtr->label, hPtr->mnemo, hPtr->operand);
    hPtr->addr = addr;
		if(!strlen(hPtr->mnemo) && !strlen(hPtr->operand)) {  // label only
      hPtr = hPtr->next;
			continue;
		}
///////// check on directives ///////////////////////////
    if(!strcmp(hPtr->mnemo, ".ORG")) {  // set location address
      getvalue(hPtr->operand, &addr);
			hPtr->addr = addr;
			hPtr = hPtr->next;
			continue;
		}
		if(!strcmp(hPtr->mnemo, ".DC")) {   // define constant byte
			getvalue(hPtr->operand, &val1);
			hPtr->mlen = 1;
			hPtr->mcod[0] = val1;
			hPtr = hPtr->next;
			continue;
		}
///////// check on assembler mnemonics //////////////////
    if(!strcmp(hPtr->mnemo, "MOV")) {
      if(doMOV(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
		}
    if(!strcmp(hPtr->mnemo, "CMP")) {
      if(doCMP(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ADD")) {
      if(doADD(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ADC")) {
      if(doADC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "SUB")) {
      if(doSUB(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "SBC")) {
      if(doSBC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "AND")) {
      if(doAND(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "OR")) {
      if(doOR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "XOR")) {
      if(doXOR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ROL")) {
      if(doROL(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ROLC")) {
      if(doROLC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ROR")) {
      if(doROR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "RORC")) {
      if(doRORC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "LSL")) {
      if(doLSL(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "LSR")) {
      if(doLSR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "ASR")) {
      if(doASR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "SWAP")) {
      if(doSWAP(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "MIRROR")) {
      if(doMIRROR(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JMP")) {
      if(doJMP(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JCC")) {
      if(doJCC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JCS")) {
      if(doJCS(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if((!strcmp(hPtr->mnemo, "JEQ")) || (!strcmp(hPtr->mnemo, "JZ"))) {
      if(doJEQ(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JGE")) {
      if(doJGE(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JGT")) {
      if(doJGT(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JHI")) {
      if(doJHI(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JLE")) {
      if(doJLE(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JLS")) {
      if(doJLS(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JLT")) {
      if(doJLT(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JMI")) {
      if(doJMI(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if((!strcmp(hPtr->mnemo, "JNE")) || (!strcmp(hPtr->mnemo, "JNZ"))) {
      if(doJNE(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JPL")) {
      if(doJPL(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JVC")) {
      if(doJVC(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
    if(!strcmp(hPtr->mnemo, "JVS")) {
      if(doJVS(hPtr->operand, &slen, code)) {
				fprintf(stderr, "%d syntax error\n", hPtr->linenumber);
        hPtr = hPtr->next;
	  		continue;
			}
			if(slen & 0x100) {
				strcpy(hPtr->olabel1, hPtr->operand);
				slen &= 0x0F;
			}
			hPtr->mlen = (unsigned char) slen;
			memcpy(hPtr->mcod, code, slen);
			addr += slen;
			hPtr = hPtr->next;
			continue;
    }
		hPtr = hPtr->next;
	}
/////////// count label addresses ///////////////////////
  hPtr = head;
	maxi = 0;
	while(hPtr) {
		if(hPtr->label[0]) maxi++;
		hPtr = hPtr->next;
	}
/////////// table with label address ////////////////////
  address = (Taddress *) malloc(maxi * sizeof(Taddress));
	hPtr = head;
	idx = 0;
	while(hPtr) {
		if(hPtr->label[0]) {
			address[idx].addr = hPtr->addr;
			strcpy(address[idx].label, hPtr->label);
			idx++;
		}
		hPtr = hPtr->next;
	}

	printf("2nd pass\n");
/////////// 2nd pass ////////////////////////////////////
  hPtr = head;
	while(hPtr) {
    if(hPtr->olabel1[0]) {  // resolve label
      for(idx=0; idx<maxi; idx++) {
				if(!strcmp(address[idx].label, hPtr->olabel1)) {
					hPtr->mcod[1] = (unsigned char) address[idx].addr;
					hPtr->mcod[2] = (unsigned char) (address[idx].addr >> 8);
					break;
				}
			}
			if(idx == maxi) {
				fprintf(stderr, "%d unknown label\n", hPtr->linenumber);
			}
		}
		hPtr = hPtr->next;
	}

////////// output ///////////////////////////////////////
  fp = fopen("CODE.HEX", "w");  // write into Intel HEX file
  hPtr = head;
  while(hPtr) {

		printf("%04X ", hPtr->addr);
    for(idx=0; idx<hPtr->mlen; idx++) printf("%02X ", hPtr->mcod[idx]);
		printf("<%s><%s><%s>\n", hPtr->label, hPtr->mnemo, hPtr->operand);

		if(hPtr->mlen) {
      sprintf(line, ":%02X%04X00", hPtr->mlen, hPtr->addr);
			for(idx=0; idx<hPtr->mlen; idx++) {
				sprintf(tmpStr, "%02X", hPtr->mcod[idx]);
				strcat(line, tmpStr);
			}
			chksum = 0;
			for(idx=1; line[idx]; idx += 2) {
        msn = line[idx] - '0';
				if(msn > 9) msn -= 7;
        lsn = line[idx+1] - '0';
				if(lsn > 9) lsn -= 7;
				chksum += ((msn<<4) + lsn);
			}
      chksum = 256 - chksum;
			sprintf(tmpStr, "%02X", chksum);
			strcat(line, tmpStr);
			fprintf(fp, "%s\015\012", line);
	  }

		hPtr = hPtr->next;
  }
	fprintf(fp, ":00000001FF\015\012");  // end of HEX file
	fclose(fp);
	return 0;
}

int  doJCC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x1B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x1A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x1A;
	return 0;
}

int  doJCS(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x2B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x2A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x2A;
	return 0;
}

int  doJEQ(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x3B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x3A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x3A;
	return 0;
}

int  doJGE(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x4B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x4A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x4A;
	return 0;
}

int  doJGT(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x5B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x5A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x5A;
	return 0;
}

int  doJHI(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x6B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x6A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x6A;
	return 0;
}

int  doJLE(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x7B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x7A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x7A;
	return 0;
}

int  doJLS(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x8B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x8A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x8A;
	return 0;
}

int  doJLT(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x9B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x9A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x9A;
	return 0;
}

int  doJMI(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0xAB;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0xAA;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0xAA;
	return 0;
}

int  doJNE(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0xBB;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0xBA;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0xBA;
	return 0;
}

int  doJPL(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0xCB;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0xCA;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
  cod[0] = 0xCA;
	return 0;
}

int  doJVC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0xDB;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0xDA;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0xDA;
	return 0;
}

int  doJVS(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0xEB;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0xEA;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
  cod[0] = 0xEA;
	return 0;
}

int  doJMP(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	if(str[0] == '[') {
		getvalue(&str[2], &reg1);  // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
		getvalue(&str[idx+2], &reg2); // register high
		*len = 3;
		cod[0] = 0x0B;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
    return 0;
	}
  if(isdigit(str[0]) || (str[0] == '$')) {  // numeric address
		getvalue(str, &reg1);
		*len = 3;
		cod[0] = 0x0A;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) (reg1 >> 8);
		return 0;
	}
	*len = 0x103;  // signal to copy label
	cod[0] = 0x0A;
	return 0;
}

int  doADD(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ADD Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x09;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ADD Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x08;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doADC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ADC Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x19;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ADC Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x18;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doSUB(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // SUB Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x29;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // SUB Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x28;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doSBC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // SBC Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x39;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // SBC Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x38;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doAND(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // AND Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x49;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // AND Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x48;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doOR (char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // OR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x59;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // OR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x58;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doXOR(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // XOR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x69;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // XOR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x68;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doROL(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ROL Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x79;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ROL Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x78;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doROLC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ROLC Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x89;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ROLC Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x88;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doROR(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ROR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x99;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ROR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x98;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doRORC(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // RORC Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xA9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // RORC Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xA8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doLSL(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // LSL Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xB9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // LSL Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xB8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doLSR(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // LSR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xC9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // LSR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xC8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doASR(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // ASR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xD9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // ASR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xD8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doSWAP(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // SWAP Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xE9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // SWAP Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xE8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

int  doMIRROR(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int idx;

	getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // MIRROR Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xF9;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // MIRROR Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0xF8;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

///// assemble CMP instruction ////////////////////
// return 0 if OK
int  doCMP(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2;
	int  idx;

  getvalue(&str[1], &reg1);
	for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
	if(idx == 8) return 1;
	idx++;
  if(str[idx] == '#') {  // CMP Rd,#val  instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x20;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	if(str[idx] == 'R') {  // CMP Rd,Rs  instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x21;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg1;
		return 0;
	}
	return 1;
}

///// assemble MOV instruction ////////////////////
// return 0 if OK
int  doMOV(char *str, unsigned short *len, unsigned char *cod)
{
	unsigned short reg1, reg2, reg3;
	int  idx;

  if(str[0] == '[') {  // MOV [Rl,Rh],Rs instruction
		getvalue(&str[2], &reg1); // register low
		for(idx=2; idx<8; idx++) if(str[idx] == ',') break;
		if(idx == 8) return 1;
    getvalue(&str[idx+2], &reg2); // register high
    for(idx++; idx<10; idx++) if(str[idx] == ']') break;
		for(; idx<10; idx++) if(str[idx] == ',') break;
		getvalue(&str[idx+2], &reg3); // source register
    *len = 4;
		cod[0] = 0x07;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		cod[3] = (unsigned char) reg3;
		return 0;
	}
	if(!memcmp(str, "WP", 2)) {  // MOV WP, Rs instruction
		getvalue(&str[4], &reg1);
		*len = 2;
		cod[0] = 0x03;
		cod[1] = (unsigned char) reg1;
		return 0;
	}
	getvalue(&str[1], &reg1); // destination register
	for(idx=0; idx<16; idx++) if(str[idx] == ',') break;
  if(idx == 16) return 1;
  idx++; // skip ,
	if(!memcmp(&str[idx], "WP", 2)) {  // MOV Rd, WP instruction
		*len = 2;
		cod[0] = 0x02;
		cod[1] = (unsigned char) reg1;
		return 0;
	}
  if(str[idx] == '[') {  // MOV Rd,[Rl,Rh] instruction
    getvalue(&str[idx+2], &reg2); // register low
		for(; idx<16; idx++) if(str[idx] == ',') break;
		if(idx == 16) return 1;
		getvalue(&str[idx+2], &reg3); // register high
    *len = 4;
		cod[0] = 0x06;
		cod[1] = (unsigned char) reg2;
		cod[2] = (unsigned char) reg3;
		cod[3] = (unsigned char) reg1;
    return 0;
	}
	if(str[idx] == '#') {  // MOV Rd,#val instruction
    getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x05;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
  if(str[idx] == 'R') {  // MOV Rd,Rs instruction
		getvalue(&str[idx+1], &reg2);
		*len = 3;
		cod[0] = 0x04;
		cod[1] = (unsigned char) reg1;
		cod[2] = (unsigned char) reg2;
		return 0;
	}
	return 1;
}

////////// gets a decimal or hexadecimal value
// decimal     is ddd
// hexadecimal is $hhh
// returns ptr after value
char *getvalue(char *str, unsigned short *val)
{
	int idx, radix;
	unsigned short v, h;

	radix = 10;
	if(str[0] == '$') radix = 16;
	v = 0;
  if(radix == 10) {
		for(idx=0; idx<10; idx++) {
			if(isdigit(str[idx])) {
			  v *= 10;
			  v += (str[idx] - '0');
				continue;
			}
			break;
		}
	} else {
		for(idx=1; idx<9; idx++) {
			if(isxdigit(str[idx])) {
			  v <<= 4;
				h = str[idx] - '0';
				if(h > 9) h -= 7;
				v += h;
				continue;
			}
			break;
		}
	}
	*val = v;
	return &str[idx];
}
