
// Data input width
parameter LA_DATA_INPUT_WORDLEN_BITS=32;

// Memory
// LA_MEM_WORDLEN_BITS is usually (LA_DATA_INPUT_WORDLEN_BITS + 1)
parameter LA_MEM_WORDLEN_BITS=(32+1); 
parameter LA_MEM_WORDLEN_OCTETS=((LA_MEM_WORDLEN_BITS+7)/8),
		LA_LOG2_MEM_WORDLEN_OCTETS=3;
// constraint: 	LA_MEM_ADDRESS_BITS <= LA_DATA_INPUT_WORDLEN_BITS
parameter LA_MEM_ADDRESS_BITS=6;
parameter LA_MEM_FIRST_ADDR=0,
	LA_MEM_LAST_ADDR=((1<<LA_MEM_ADDRESS_BITS)-1);

// Trigger
parameter LA_TRIGGER_VALUE=32'h00000000,
	LA_TRIGGER_MASK={{(22){1'b0}}, 2'b11, 8'h00};
parameter LA_BT_QUEUE_HEAD_ADDRESS=LA_MEM_LAST_ADDR;
parameter LA_MEM_CLEAN_BEFORE_RUN=1;
// constraint: (LA_MEM_FIRST_ADDR + 4) <= LA_TRIGGER_MATCH_MEM_ADDR <= (LA_MEM_LAST_ADDR - 4)
parameter LA_TRIGGER_MATCH_MEM_ADDR=(1<<(LA_MEM_ADDRESS_BITS-3)),
	LA_MEM_LAST_ADDR_BEFORE_TRIGGER=(LA_TRIGGER_MATCH_MEM_ADDR-1),
	LA_MEM_ONE_TO_LAST_ADDR_BEFORE_TRIGGER=(LA_TRIGGER_MATCH_MEM_ADDR-2);
parameter LA_MAX_SAMPLES_AFTER_TRIGGER_BITS=26,
    LA_MAX_SAMPLES_AFTER_TRIGGER={1'b0, {(LA_MAX_SAMPLES_AFTER_TRIGGER_BITS-1){1'b1}}}; 

// Identical samples
parameter LA_IDENTICAL_SAMPLES_BITS=(LA_MEM_WORDLEN_BITS/2),
	LA_MAX_IDENTICAL_SAMPLES={LA_IDENTICAL_SAMPLES_BITS{1'b1}};

/*
Reserved mem words
1) the word situated at LA_BT_QUEUE_HEAD_ADDRESS, although this word has type=0.
2) LA_MEM_EMPTY_SLOT which represents an empty and not used memory slot.
It has sense if LA_MEM_CLEAN_BEFORE_RUN and
	a) when the trigger event arrives before the filling of the full btqueue.
	b) after the trigger event and after capturing LA_MAX_SAMPLES_AFTER_TRIGGER
*/
parameter LA_MEM_EMPTY_SLOT={1'b1, {LA_DATA_INPUT_WORDLEN_BITS{1'b0}}};