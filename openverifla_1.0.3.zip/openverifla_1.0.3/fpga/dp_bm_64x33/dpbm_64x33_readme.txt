The following files were generated for 'dpbm_64x33' in directory 
D:\lucru\scoala\cn\laborator\logic_analyzer\sump\verilog\dp_bm_64x33\:

dpbm_64x33.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

dpbm_64x33.v:
   Unisim Verilog file containing the information required to simulate
   the module.

dpbm_64x33.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

dpbm_64x33.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

dpbm_64x33_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

dpbm_64x33_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

