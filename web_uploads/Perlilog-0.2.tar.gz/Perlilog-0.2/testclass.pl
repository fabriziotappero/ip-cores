# This is a test class for Eobj.
# It's short, but if it executes at all, odds are that everything
# is 100% fine.

sub tryout {
  my $self = shift;
  my $what = shift;

  print "$what\n";
}
