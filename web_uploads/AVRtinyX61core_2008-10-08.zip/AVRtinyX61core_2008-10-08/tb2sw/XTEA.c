//////////////////////////////////////////////////////////////////////////////
//
// Written by: Andreas Hilvarsson, avmcu�opencores.org (www.syntera.se)
// Project...: Test code for TinyXcore
//
// Purpose:
//	XTEA encryption and decryption.
//
//////////////////////////////////////////////////////////////////////////////
//    AVR tiny261/461/861 core
//    Copyright (C) 2008  Andreas Hilvarsson
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
//
//    Andreas Hilvarsson reserves the right to distribute this core under
//    other licenses aswell.
//////////////////////////////////////////////////////////////////////////////

#include "Global.h"
#include <avr/io.h>

//////////////////////////////////////////////////////////////////////////////
enum { E_XTEA_NUM_ROUNDS = 32 };
enum { E_XTEA_DELTA = 0x9E3779B9L };
u32 xtea_cryptokey[4];
//////////////////////////////////////////////////////////////////////////////
void xtea_setkey(u32 *k)
{
	u8 i;
	for(i=0;i<4;i++)
		xtea_cryptokey[i] = k[i];
}
//////////////////////////////////////////////////////////////////////////////
void xtea_encipher(u32 *v)
{
	u32 v0 = v[0];
	u32 v1 = v[1];
	u32 i;
	u32 sum = 0;
	u32 *k = xtea_cryptokey;
	
	for(i=0; i<E_XTEA_NUM_ROUNDS; i++)
	{
		v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + k[sum & 3]);
		sum += E_XTEA_DELTA;
		v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + k[(sum>>11) & 3]);
	}

	v[0] = v0;
	v[1] = v1;
}
//////////////////////////////////////////////////////////////////////////////
void xtea_decipher(u32 *v)
{
	u32 v0 = v[0];
	u32 v1 = v[1];
	u32 i;
	u32 sum = E_XTEA_DELTA * E_XTEA_NUM_ROUNDS;
	u32 *k = xtea_cryptokey;

	for(i=0; i<E_XTEA_NUM_ROUNDS; i++)
	{
		v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + k[(sum>>11) & 3]);
		sum -= E_XTEA_DELTA;
		v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + k[sum & 3]);
	}

	v[0] = v0;
	v[1] = v1;
}
//////////////////////////////////////////////////////////////////////////////
eOK_FAIL xtea_testOne(u32 *k, u32 *p, u32 *c)
{
	u32 pstore[2] = {p[0],p[1]};
	xtea_setkey(k);
	xtea_encipher(p);
	if ( (p[0]!=c[0]) || (p[1]!=c[1]) )
	{
		return E_FAIL;
	}
	xtea_decipher(p);
	if ( (p[0]!=pstore[0]) || (p[1]!=pstore[1]) )
	{
		return E_FAIL;
	}
	return E_OK;
}
//////////////////////////////////////////////////////////////////////////////
#define SETK(a,b,c,d)	{k[0]=a; k[1]=b; k[2]=c; k[3]=d;}
#define SETP(a,b)			{p[0]=a; p[1]=b;}
#define SETC(a,b)			{c[0]=a; c[1]=b;}
eOK_FAIL xtea_test()
{
	u32 k[4];
	u32 p[2];
	u32 c[2];
	
	SET_STEP(2);

	SETK(0x27F917B1,0xC1DA8993,0x60E2ACAA,0xA6EB923D);
	SETP(0xAF20A390,0x547571AA);
	SETC(0xD26428AF,0x0A202283);	
	if (E_FAIL == xtea_testOne(k,p,c))
		return E_FAIL;
		
	SET_STEP(3);

	SETK(0x31415926,0x53589793,0x23846264,0x33832795);
	SETP(0x02884197,0x16939937);
	SETC(0x46E2007D,0x58BBC2EA);
	if (E_FAIL == xtea_testOne(k,p,c))
		return E_FAIL;
		
	SET_STEP(4);

	return E_OK;
}
//////////////////////////////////////////////////////////////////////////////
