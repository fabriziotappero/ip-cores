//////////////////////////////////////////////////////////////////////////////
//
// Written by: Andreas Hilvarsson, avmcu�opencores.org (www.syntera.se)
// Project...: Test code for TinyXcore
//
// Purpose:
//	XTEA encryption and decryption.
//
//////////////////////////////////////////////////////////////////////////////
//    AVR tiny261/461/861 core
//    Copyright (C) 2008  Andreas Hilvarsson
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
//
//    Andreas Hilvarsson reserves the right to distribute this core under
//    other licenses aswell.
//////////////////////////////////////////////////////////////////////////////

#ifndef XTEA_H
#define XTEA_H
#include "Global.h"

//////////////////////////////////////////////////////////////////////////////
extern void xtea_setkey(u32 *k);
extern void xtea_encipher(u32 *v);
extern void xtea_decipher(u32 *v);
extern eOK_FAIL xtea_test();
//////////////////////////////////////////////////////////////////////////////
#endif //XTEA_H
