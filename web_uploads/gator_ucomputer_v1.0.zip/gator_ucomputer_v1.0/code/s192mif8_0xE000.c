/*

; --==========================> Gator uProccessor <===========================--
; -- File:		s192mif8.c	
; -- Engineer:		Kevin Phillipson
; -- Date:		03.28.07
; -- Revision:		04.01.07
; -- Description:
; --==========================================================================--

*/

#include <stdio.h>
#include <string.h>


#define OFFSET	0xE000
#define WIDTH 8

#define BUF_SIZE 16

typedef	unsigned char	u08;
typedef	signed char	s08;
typedef	unsigned short	u16;
typedef	signed short	s16;
typedef	unsigned long	u32;
typedef	signed long	s32;

u08	hex2bin(u08 hex_digit);
u08	bin2hex(u08 nibble);
s16	load_buffer(void);
void	crlf(void);


u08	buffer[BUF_SIZE];
s16	eof_buf[BUF_SIZE];


main(void)
{


	u32	idx = 0;

	u08	num_bytes;
	
	u16	mif_addr;
	u32	mif_depth = 0;
	
	u32	raw_idx = 0;
	u16	raw_addr[0x10000];
	u08	raw_data[0x10000];

	s08	flush;
	u08	state = 0;

	for (idx = 0; idx < BUF_SIZE; idx++)
		buffer[idx] = 0x00;

	for (idx = 0; idx < BUF_SIZE; idx++)
		eof_buf[idx] = 0x00;

	while (load_buffer() != EOF)
	{
		flush = 0;
		
		switch(state)
		{
			case 0:
				if (strncmp(buffer,"S1",2) == 0)
				{
					num_bytes = 	(hex2bin(buffer[2]) << 4) +
							(hex2bin(buffer[3])) - 3;
						
					mif_addr =	(hex2bin(buffer[4]) << 12) +
							(hex2bin(buffer[5]) << 8) +
							(hex2bin(buffer[6]) << 4) + 
							(hex2bin(buffer[7]));
					
					flush = 8;
					state = 1;
				}
				break;

			case 1:
				if (num_bytes != 0)
				{
					if (mif_addr > mif_depth)
					{
						mif_depth = mif_addr;
					}
					
					raw_addr[raw_idx] =	mif_addr;
					raw_data[raw_idx] = 	(hex2bin(buffer[0]) << 4) +
								(hex2bin(buffer[1]));
								
					raw_idx++;
					mif_addr++;
					num_bytes--;
					flush = 2;
					
					if (num_bytes == 0)
					{
						state = 0;
					}
				}
				else
				{
					state = 0;
				}

				break;
				
			default:
				state = 0;
				break;
		}
		
		for (idx = 1; idx < flush; idx++)
			load_buffer();
	}

	printf("DEPTH = %d;", (mif_depth+1-OFFSET));crlf();
	printf("WIDTH = %d;", WIDTH);crlf();
	printf("ADDRESS_RADIX = HEX;");crlf();
	printf("DATA_RADIX = HEX;");crlf();
	printf("");crlf();
	printf("CONTENT");crlf();
	printf("BEGIN");crlf();
	printf("");crlf();

	for (idx = 0; idx < raw_idx; idx++)
	{

		putchar(bin2hex(((raw_addr[idx] - OFFSET) >> 12) & 0x0F));
		putchar(bin2hex(((raw_addr[idx] - OFFSET) >> 8) & 0x0F));
		putchar(bin2hex(((raw_addr[idx] - OFFSET) >> 4) & 0x0F));
		putchar(bin2hex(((raw_addr[idx] - OFFSET) >> 0) & 0x0F));
		
		printf(" : ");

		putchar(bin2hex((raw_data[idx] >> 4) & 0x0F));
		putchar(bin2hex((raw_data[idx] >> 0) & 0x0F));

		printf(";");crlf();

	}

	printf("");crlf();
	printf("END;");crlf();

	//return(0);

}


s16 load_buffer(void)
{
	s16 tmp;
	
	for (tmp = 0; tmp < BUF_SIZE-1; tmp++)
		buffer[tmp] = buffer[tmp+1];

	for (tmp = 0; tmp < BUF_SIZE-1; tmp++)
		eof_buf[tmp] = eof_buf[tmp+1];

	if (eof_buf[BUF_SIZE-1] != EOF)	//
	{
		tmp = getchar();

		//make ucase
		if((tmp >= 0x61) && (tmp <= 0x7A))
			tmp = tmp - 0x20;

	}
	else
	{
		tmp = EOF;
	}
		
	buffer[BUF_SIZE-1] = tmp;
	eof_buf[BUF_SIZE-1] = tmp;

	return eof_buf[0];
}

void crlf(void)
{
	putchar(0x0D);
	putchar(0x0A);
}

u08 hex2bin(u08 hex_digit)
{
	u08 nibble;

	if ((hex_digit >= 0x30) && (hex_digit <= 0x39))
		nibble = hex_digit - 0x30;
	else
		if ((hex_digit >= 0x41) && (hex_digit <= 0x46))
			nibble = hex_digit - 0x37;
		else
			nibble = 0xFF;
		
	return nibble;
}

u08 bin2hex(u08 nibble)
{
	u08 hex_digit;

	if (nibble < 0x0A)
		hex_digit = nibble + 0x30;
	else
		hex_digit = nibble + 0x37;

	return hex_digit;
}
