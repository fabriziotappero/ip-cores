/*

------------------------------------------------------------------------------
 
	Engineer:	Kevin Phillipson
	Date:		05/03/2005
 
------------------------------------------------------------------------------

*/

#include <stdio.h>

#define DEPTH 256
#define WIDTH 56

typedef	unsigned char	u08;
typedef	signed char	s08;
typedef	unsigned short	u16;
typedef	signed short	s16;
typedef	unsigned long	u32;
typedef	signed long	s32;

u08 hex2bin(u08 hex_digit);
u08 bin2hex(u08 nibble);
void crlf(void);

main(void)
{

	u16		mif_addr;
	s16		tmp;
	u08		data[DEPTH][(WIDTH/4)];
	u08		check_sum;
	u08		byte;

	for (mif_addr = 0; mif_addr < DEPTH; mif_addr++)
		for (tmp = 0; tmp < (WIDTH/4); tmp++)
			data[mif_addr][tmp] = '0';

	while ((tmp = getchar()) != EOF)
	{
		byte = tmp;
		if (byte == 'S')
			if (getchar() == '2')
			{
				getchar();
				getchar();
				getchar();
				
				mif_addr = 0;
				for (tmp = 3; tmp >= 0; tmp--)
					mif_addr += hex2bin(getchar()) << (4 * tmp);
	
				getchar();
				
				for (tmp = 0; tmp < (WIDTH/4); tmp++)
					data[mif_addr][tmp] = getchar();
			}
	}

	printf("DEPTH         = %d;", DEPTH); crlf();
	printf("WIDTH         = %d;", WIDTH); crlf();
	printf("ADDRESS_RADIX = HEX;"); crlf();
	printf("DATA_RADIX    = HEX;"); crlf(); crlf();

	printf("CONTENT"); crlf();
	printf("BEGIN"); crlf(); crlf();

	for (mif_addr = 0; mif_addr < DEPTH; mif_addr++)
	{
		check_sum = 0;
		
		for (tmp = 3; tmp >= 0; tmp--)
		{
			byte = (mif_addr >> (4 * tmp)) & 0x0F;
			
			if (tmp & 0x01)
				check_sum += byte << 4;
			else
				check_sum += byte;
			
			putchar(bin2hex(byte));
		}
		
		printf(" : ");
		
		for (tmp = 0; tmp < (WIDTH/4); tmp++)
		{
			byte = data[mif_addr][tmp];
			
			if (tmp & 0x01)
				check_sum += hex2bin(byte);
			else
				check_sum += hex2bin(byte) << 4;
			
			putchar(byte);
		}
		printf(";");crlf();
	}

	crlf();
	printf("END;"); crlf();

}

void crlf(void)
{
	putchar(0x0D);
	putchar(0x0A);
}

u08 hex2bin(u08 hex_digit)
{
	u08 nibble;

	if ((hex_digit >= 0x30) && (hex_digit <= 0x39))
		nibble = hex_digit - 0x30;
	else
		if ((hex_digit >= 0x41) && (hex_digit <= 0x46))
			nibble = hex_digit - 0x37;
		else
			nibble = 0xFF;
		
	return nibble;
}

u08 bin2hex(u08 nibble)
{
	u08 hex_digit;

	if (nibble < 0x0A)
		hex_digit = nibble + 0x30;
	else
		hex_digit = nibble + 0x37;

	return hex_digit;
}
