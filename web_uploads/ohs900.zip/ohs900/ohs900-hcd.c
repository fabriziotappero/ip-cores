/*
 * OHS900 HCD (Host Controller Driver) for USB.
 *
 * Based on David Brownell's SL811 HCD
 *
 * Copyright (C) 2005 Steve Fielding
 * Copyright (C) 2004 Psion Teklogix (for NetBook PRO)
 * Copyright (C) 2004 David Brownell
 * 
 * Periodic scheduling is based on Roman's OHCI code
 * 	Copyright (C) 1999 Roman Weissgaerber
 *
 * The OHS900 controller handles host side USB 
 * as well as peripheral side USB
 * This driver version doesn't implement the Gadget API
 * for the peripheral role.
 *
 * For documentation, see the OHS900 spec.
 */ 

/*
 * Status:  Passed basic testing, works with usb-storage.
 *
 * TODO:
 * - Replace direct memory accesses.
 * - various issues noted in the code
 * - use urb->iso_frame_desc[] with ISO transfers
 */

//#undef	VERBOSE
//#undef	PACKET_TRACE

#include <linux/config.h>

#ifdef CONFIG_USB_DEBUG
#	define DEBUG
#else
#	undef DEBUG
#endif

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/smp_lock.h>
#include <linux/errno.h>
#include <linux/init.h>
#include <linux/timer.h>
#include <linux/list.h>
#include <linux/interrupt.h>
#include <linux/usb.h>
#include <linux/usb_ohs900.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/system.h>
#include <asm/byteorder.h>

#include "../core/hcd.h"
#include "ohs900.h"


MODULE_DESCRIPTION("OHS900 USB Host Controller Driver");
MODULE_LICENSE("GPL");

#define DRIVER_VERSION	"25 June 2005"


#ifndef DEBUG
#	define	STUB_DEBUG_FILE
#endif

/* for now, use only one transfer register bank */
#undef	USE_B

/* this doesn't understand urb->iso_frame_desc[], but if you had a driver
 * that just queued one ISO frame per URB then iso transfers "should" work
 * using the normal urb status fields.
 */
#define	DISABLE_ISO

// #define	QUIRK2
#define	QUIRK3

static const char hcd_name[] = "ohs900-hcd";

/*-------------------------------------------------------------------------*/

static irqreturn_t ohs900h_irq(int irq, void *_ohs900, struct pt_regs *regs);

static void port_power(struct ohs900 *ohs900, int is_on)
{
	u8			tmp;

	
	INFO("driver %s, ohs900->addr_reg = 0x%x, OHS900_HWREVREG = 0x%x\n", 
			hcd_name, (unsigned int) ohs900->addr_reg, OHS900_HWREVREG);
	tmp = ohs900_read(ohs900, OHS900_HWREVREG);
	INFO("driver %s, started port_power, usb hw version = %d\n", hcd_name, tmp);
	/* hub is inactive unless the port is powered */
	if (is_on) {
		if (ohs900->port1 & (1 << USB_PORT_FEAT_POWER))
			return;

		ohs900->port1 = (1 << USB_PORT_FEAT_POWER);
		ohs900->irq_enable = OHS900_INTMASK_INSRMV;
		ohs900->hcd.self.controller->power.power_state = PM_SUSPEND_ON;
	} else {
		ohs900->port1 = 0;
		ohs900->irq_enable = 0;
		ohs900->hcd.state = USB_STATE_HALT;
		ohs900->hcd.self.controller->power.power_state = PM_SUSPEND_DISK;
	}
	INFO("driver %s, setting ohs900->ctrl1\n", hcd_name);
	ohs900->ctrl1 = OHS900_TXLCTL_MASK_FS_RATE & OHS900_TXLCTL_MASK_FS_POL;
	INFO("driver %s, disabling interrupts\n", hcd_name);
	ohs900_write(ohs900, OHS900_IRQ_ENABLE, 0);
	INFO("driver %s, clearing interrupt status\n", hcd_name);
	ohs900_write(ohs900, OHS900_IRQ_STATUS, ~0);

	if (ohs900->board && ohs900->board->port_power) {
		/* switch VBUS, at 500mA unless hub power budget gets set */
		DBG("power %s\n", is_on ? "on" : "off");
		ohs900->board->port_power(ohs900->hcd.self.controller, is_on);
	}

	/* reset as thoroughly as we can */
	if (ohs900->board && ohs900->board->reset)
		ohs900->board->reset(ohs900->hcd.self.controller);

	ohs900_write(ohs900, OHS900_IRQ_ENABLE, 0);
	ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);
	ohs900_write(ohs900, OHS900_SOFENREG, 0);
	ohs900_write(ohs900, OHS900_HOSTSLAVECTLREG, OHS900_HS_CTL_INIT);
	INFO("driver %s, OHS900_IRQ_ENABLE = %d\n", hcd_name, ohs900->irq_enable);
	ohs900_write(ohs900, OHS900_IRQ_ENABLE, ohs900->irq_enable);

	// if !is_on, put into lowpower mode now
}

/*-------------------------------------------------------------------------*/

/* This is a PIO-only HCD.  Queueing appends URBs to the endpoint's queue,
 * and may start I/O.  Endpoint queues are scanned during completion irq
 * handlers (one per packet: ACK, NAK, faults, etc) and urb cancelation.
 *
 * Using an external DMA engine to copy a packet at a time could work,
 * though setup/teardown costs may be too big to make it worthwhile.
 */

/* SETUP starts a new control request.  Devices are not allowed to
 * STALL or NAK these; they must cancel any pending control requests.
 */
static void setup_packet(
	struct ohs900		*ohs900,
	struct ohs900h_ep	*ep,
	struct urb		*urb,
	u8			control
)
{
	u8			addr;
	u8			len;

	ohs900_write(ohs900, OHS900_TXFIFOCONTROLREG, OHS900_FIFO_FORCE_EMPTY);
	addr = OHS900_HOST_TXFIFO_DATA;
	len = sizeof(struct usb_ctrlrequest);
	ohs900_write_buf(ohs900, addr, urb->setup_packet, len);

	ohs900_write(ohs900, OHS900_TXTRANSTYPEREG, OHS900_SETUP);
	ohs900_write(ohs900, OHS900_TXENDPREG, 0 /* ep->epnum */ );
	ohs900_write(ohs900, OHS900_TXADDRREG, usb_pipedevice(urb->pipe));

	/* always OUT/data0 */ ;
	ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, control);
	ep->length = 0;
	PACKET("SETUP qh%p\n", ep);
}

/* STATUS finishes control requests, often after IN or OUT data packets */
static void status_packet(
	struct ohs900		*ohs900,
	struct ohs900h_ep	*ep,
	struct urb		*urb,
	u8			control
)
{
	int			do_out;

	do_out = urb->transfer_buffer_length && usb_pipein(urb->pipe);

	ohs900_write(ohs900, OHS900_TXTRANSTYPEREG, (do_out ? OHS900_OUT_DATA1 : OHS900_IN));
	ohs900_write(ohs900, OHS900_TXENDPREG, 0 /* ep->epnum */ );
	ohs900_write(ohs900, OHS900_TXADDRREG, usb_pipedevice(urb->pipe));

	/* always data1; sometimes IN */
	ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, control);
	ep->length = 0;
	PACKET("STATUS%s/%s qh%p\n", ep->nak_count ? "/retry" : "",
			do_out ? "out" : "in", ep);
}

/* IN packets can be used with any type of endpoint. here we just
 * start the transfer, data from the peripheral may arrive later.
 * urb->iso_frame_desc is currently ignored here...
 */
static void in_packet(
	struct ohs900		*ohs900,
	struct ohs900h_ep	*ep,
	struct urb		*urb,
	u8			control
)
{
	u8			len;

	/* avoid losing data on overflow */
	len = ep->maxpacket;


	ohs900_write(ohs900, OHS900_RXFIFOCONTROLREG, OHS900_FIFO_FORCE_EMPTY);
	ohs900_write(ohs900, OHS900_TXTRANSTYPEREG, OHS900_IN);
	ohs900_write(ohs900, OHS900_TXADDRREG, usb_pipedevice(urb->pipe));
	ohs900_write(ohs900, OHS900_TXENDPREG, ep->epnum);
	ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, control);
	ep->length = min((int)len,
			urb->transfer_buffer_length - urb->actual_length);
	PACKET("IN%s/%d qh%p len%d\n", ep->nak_count ? "/retry" : "",
			!!usb_gettoggle(urb->dev, ep->epnum, 0), ep, len);
}

/* OUT packets can be used with any type of endpoint.
 * urb->iso_frame_desc is currently ignored here...
 */
static void out_packet(
	struct ohs900		*ohs900,
	struct ohs900h_ep	*ep,
	struct urb		*urb,
	u8			control
)
{
	void			*buf;
	u8			len;

	buf = urb->transfer_buffer + urb->actual_length;
	prefetch(buf);

	len = min((int)ep->maxpacket,
			urb->transfer_buffer_length - urb->actual_length);

	ohs900_write(ohs900, OHS900_TXFIFOCONTROLREG, OHS900_FIFO_FORCE_EMPTY);
	if (!(control & OHS900_HCTLMASK_ISO_EN)
			&& usb_gettoggle(urb->dev, ep->epnum, 1))
		ohs900_write(ohs900, OHS900_TXTRANSTYPEREG, OHS900_OUT_DATA1);
	else
		ohs900_write(ohs900, OHS900_TXTRANSTYPEREG, OHS900_OUT_DATA0);


	ohs900_write_buf(ohs900, OHS900_HOST_TXFIFO_DATA, buf, len);

	ohs900_write(ohs900, OHS900_TXADDRREG, usb_pipedevice(urb->pipe));
	ohs900_write(ohs900, OHS900_TXENDPREG, ep->epnum);
	ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, control);

	ep->length = len;
	PACKET("OUT%s/%d qh%p len%d\n", ep->nak_count ? "/retry" : "",
			!!usb_gettoggle(urb->dev, ep->epnum, 1), ep, len);
}
/*-------------------------------------------------------------------------*/

/* caller updates on-chip enables later */

static inline void sofirq_on(struct ohs900 *ohs900)
{
	if (ohs900->irq_enable & OHS900_INTMASK_SOFINTR)
		return;
	VDBG("sof irq on\n");
	ohs900->irq_enable |= OHS900_INTMASK_SOFINTR;
}

static inline void sofirq_off(struct ohs900 *ohs900)
{
	if (!(ohs900->irq_enable & OHS900_INTMASK_SOFINTR))
		return;
	VDBG("sof irq off\n");
	ohs900->irq_enable &= ~OHS900_INTMASK_SOFINTR;
}

/*-------------------------------------------------------------------------*/

/* pick the next endpoint for a transaction, and issue it.
 * frames start with periodic transfers (after whatever is pending
 * from the previous frame), and the rest of the time is async
 * transfers, scheduled round-robin.
 */
static struct ohs900h_ep	*start(struct ohs900 *ohs900)
{
	struct ohs900h_ep	*ep;
	struct ohs900h_req	*req;
	struct urb		*urb;
	int			fclock;
	u8			control;

	/* use endpoint at schedule head */
	if (ohs900->next_periodic) {
		ep = ohs900->next_periodic;
		ohs900->next_periodic = ep->next;
	} else {
		if (ohs900->next_async)
			ep = ohs900->next_async;
		else if (!list_empty(&ohs900->async))
			ep = container_of(ohs900->async.next,
					struct ohs900h_ep, schedule);
		else {
			/* could set up the first fullspeed periodic
			 * transfer for the next frame ...
			 */
			return NULL;
		}

		if (ep->schedule.next == &ohs900->async)
			ohs900->next_async = NULL;
		else
			ohs900->next_async = container_of(ep->schedule.next,
					struct ohs900h_ep, schedule);
	}

	if (unlikely(list_empty(&ep->queue))) {
		DBG("empty %p queue?\n", ep);
		return NULL;
	}

	req = container_of(ep->queue.next, struct ohs900h_req, queue);
	urb = req->urb;
	control = ep->defctrl;

	/* if this frame doesn't have enough time left to transfer this
	 * packet, wait till the next frame.  too-simple algorithm...
	 */
	fclock = 12000 - (ohs900_read(ohs900, OHS900_SOFTMRREG) << 6);
	fclock -= 100;		/* setup takes not much time */
	if (urb->dev->speed == USB_SPEED_LOW) {
		if (control & OHS900_HCTLMASK_PREAMBLE_EN) {
			/* also note erratum 1: some hubs won't work */
			fclock -= 800;
		}
		fclock -= ep->maxpacket << 8;

		/* erratum 2: AFTERSOF only works for fullspeed */
		if (fclock < 0) {
			if (ep->period)
				ohs900->stat_overrun++;
			sofirq_on(ohs900);
			return NULL;
		}
	} else {
		fclock -= 12000 / 19;	/* 19 64byte packets/msec */
		if (fclock < 0) {
			if (ep->period)
				ohs900->stat_overrun++;
			control |= OHS900_HCTLMASK_SOF_SYNC;

		/* throttle bulk/control irq noise */
		} else if (ep->nak_count)
			control |= OHS900_HCTLMASK_SOF_SYNC;
	}


	switch (ep->nextpid) {
	case USB_PID_IN:
		in_packet(ohs900, ep, urb, control);
		break;
	case USB_PID_OUT:
		out_packet(ohs900, ep, urb, control);
		break;
	case USB_PID_SETUP:
		setup_packet(ohs900, ep, urb, control);
		break;
	case USB_PID_ACK:		/* for control status */
		status_packet(ohs900, ep, urb, control);
		break;
	default:
		DBG("bad ep%p pid %02x\n", ep, ep->nextpid);
		ep = NULL;
	}
	return ep;
}

#define MIN_JIFFIES	((msecs_to_jiffies(2) > 1) ? msecs_to_jiffies(2) : 2)

static inline void start_transfer(struct ohs900 *ohs900)
{
	if (ohs900->port1 & (1 << USB_PORT_FEAT_SUSPEND))
		return;
	if (ohs900->active_a == NULL) {
		ohs900->active_a = start(ohs900);
		if (ohs900->active_a != NULL)
			ohs900->jiffies_a = jiffies + MIN_JIFFIES;
	}
}

static void finish_request(
	struct ohs900		*ohs900,
	struct ohs900h_ep	*ep,
	struct ohs900h_req	*req,
	struct pt_regs		*regs,
	int			status
) __releases(ohs900->lock) __acquires(ohs900->lock)
{
	unsigned		i;
	struct urb		*urb = req->urb;

	list_del(&req->queue);
	kfree(req);
	urb->hcpriv = NULL;

	if (usb_pipecontrol(urb->pipe))
		ep->nextpid = USB_PID_SETUP;

	spin_lock(&urb->lock);
	if (urb->status == -EINPROGRESS)
		urb->status = status;
	spin_unlock(&urb->lock);

	spin_unlock(&ohs900->lock);
	usb_hcd_giveback_urb(&ohs900->hcd, urb, regs);
	spin_lock(&ohs900->lock);

	/* leave active endpoints in the schedule */
	if (!list_empty(&ep->queue))
		return;

	/* async deschedule? */
	if (!list_empty(&ep->schedule)) {
		list_del_init(&ep->schedule);
		if (ep == ohs900->next_async)
			ohs900->next_async = NULL;
		return;
	}

	/* periodic deschedule */
	DBG("deschedule qh%d/%p branch %d\n", ep->period, ep, ep->branch);
	for (i = ep->branch; i < PERIODIC_SIZE; i += ep->period) {
		struct ohs900h_ep	*temp;
		struct ohs900h_ep	**prev = &ohs900->periodic[i];

		while (*prev && ((temp = *prev) != ep))
			prev = &temp->next;
		if (*prev)
			*prev = ep->next;
		ohs900->load[i] -= ep->load;
	}	
	ep->branch = PERIODIC_SIZE;
	ohs900->periodic_count--;
	hcd_to_bus(&ohs900->hcd)->bandwidth_allocated
		-= ep->load / ep->period;
	if (ep == ohs900->next_periodic)
		ohs900->next_periodic = ep->next;

	/* we might turn SOFs back on again for the async schedule */
	if (ohs900->periodic_count == 0)
		sofirq_off(ohs900);
}

static void
done(struct ohs900 *ohs900, struct ohs900h_ep *ep, struct pt_regs *regs)
{
	u8			status;
	struct ohs900h_req	*req;
	struct urb		*urb;
	int			urbstat = -EINPROGRESS;

	if (unlikely(!ep))
		return;

	status = ohs900_read(ohs900, OHS900_HRXSTATREG);

	req = container_of(ep->queue.next, struct ohs900h_req, queue);
	urb = req->urb;

	/* we can safely ignore NAKs */
	if (status & OHS900_STATMASK_NAK_RXED) {
		// PACKET("...NAK qh%p\n", ep);
		if (!ep->period)
			ep->nak_count++;
		ep->error_count = 0;

	/* ACK, or IN with no errors, advances transfer, toggle, and maybe queue */
	} else if (status & OHS900_STATMASK_ACK_RXED
			|| ((status & ~OHS900_STATMASK_DATA_SEQ) == 0) ) {
		struct usb_device	*udev = urb->dev;
		int			len;
		unsigned char		*buf;

		/* urb->iso_frame_desc is currently ignored here... */

		ep->nak_count = ep->error_count = 0;
		switch (ep->nextpid) {
		case USB_PID_OUT:
			// PACKET("...ACK/out qh%p\n", ep);
			urb->actual_length += ep->length;
			usb_dotoggle(udev, ep->epnum, 1);
			if (urb->actual_length
					== urb->transfer_buffer_length) {
				if (usb_pipecontrol(urb->pipe))
					ep->nextpid = USB_PID_ACK;

				/* some bulk protocols terminate OUT transfers
				 * by a short packet, using ZLPs not padding.
				 */
				else if (ep->length < ep->maxpacket
						|| !(urb->transfer_flags
							& URB_ZERO_PACKET))
					urbstat = 0;
			}
			break;
		case USB_PID_IN:
			// PACKET("...ACK/in qh%p\n", ep);
			buf = urb->transfer_buffer + urb->actual_length;
			prefetchw(buf);
			len = ohs900_read(ohs900, OHS900_RXFIFOCNTLSBREG) 
					+ (ohs900_read(ohs900,
					OHS900_RXFIFOCNTMSBREG) << 8);
			
			if (len > ep->length) {
				len = ep->length;
				urb->status = -EOVERFLOW;
			}
			urb->actual_length += len;
			ohs900_read_buf(ohs900, OHS900_HOST_RXFIFO_DATA,
					buf, len);
			usb_dotoggle(udev, ep->epnum, 0);
			if (urb->actual_length == urb->transfer_buffer_length)
				urbstat = 0;
			else if (len < ep->maxpacket) {
				if (urb->transfer_flags & URB_SHORT_NOT_OK)
					urbstat = -EREMOTEIO;
				else
					urbstat = 0;
			}
			if (usb_pipecontrol(urb->pipe)
					&& (urbstat == -EREMOTEIO
						|| urbstat == 0)) {

				/* NOTE if the status stage STALLs (why?),
				 * this reports the wrong urb status.
				 */
				spin_lock(&urb->lock);
				if (urb->status == -EINPROGRESS)
					urb->status = urbstat;
				spin_unlock(&urb->lock);

				req = NULL;
				ep->nextpid = USB_PID_ACK;
			}
			break;
		case USB_PID_SETUP:
			// PACKET("...ACK/setup qh%p\n", ep);
			if (urb->transfer_buffer_length == urb->actual_length)
				ep->nextpid = USB_PID_ACK;
			else if (usb_pipeout(urb->pipe)) {
				usb_settoggle(udev, 0, 1, 1);
				ep->nextpid = USB_PID_OUT;
			} else {
				usb_settoggle(udev, 0, 0, 1);
				ep->nextpid = USB_PID_IN;
			}
			break;
		case USB_PID_ACK:
			// PACKET("...ACK/status qh%p\n", ep);
			urbstat = 0;
			break;
		}

	/* STALL stops all transfers */
	} else if (status & OHS900_STATMASK_STALL_RXED) {
		PACKET("...STALL qh%p\n", ep);
		ep->nak_count = ep->error_count = 0;
		urbstat = -EPIPE;

	/* error? retry, until "3 strikes" */
	} else if (++ep->error_count >= 3) {
		if (status & OHS900_STATMASK_RX_TMOUT)
			urbstat = -ETIMEDOUT;
		else if (status & OHS900_STATMASK_RX_OVF)
			urbstat = -EOVERFLOW;
		else
			urbstat = -EPROTO;
		ep->error_count = 0;
		PACKET("...3STRIKES %02x qh%p stat %d\n",
				status, ep, urbstat);
	}

	if ((urbstat != -EINPROGRESS || urb->status != -EINPROGRESS)
			&& req)
		finish_request(ohs900, ep, req, regs, urbstat);
}

static inline u8 checkdone(struct ohs900 *ohs900)
{
	u8	ctl;
	u8	irqstat = 0;

	if (ohs900->active_a && time_before_eq(ohs900->jiffies_a, jiffies)) {
		ctl = ohs900_read(ohs900, OHS900_HOST_TX_CTLREG);
		if (ctl & OHS900_HCTLMASK_TRANS_REQ)
			ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, 0);
		DBG("%s DONE_A: ctrl %02x sts %02x\n",
			(ctl & OHS900_HCTLMASK_TRANS_REQ) ? "timeout" : "lost",
			ctl,
			ohs900_read(ohs900, OHS900_HRXSTATREG));
		irqstat |= OHS900_INTMASK_TRANS_DONE;
	}
	return irqstat;
}

static irqreturn_t ohs900h_irq(int irq, void *_ohs900, struct pt_regs *regs)
{
	struct ohs900	*ohs900 = _ohs900;
	u8		irqstat;
	irqreturn_t	ret = IRQ_NONE;
	unsigned	retries = 5;

	//printk("Entering ohs900h_irq\n");
	spin_lock(&ohs900->lock);

retry:
	irqstat = ohs900_read(ohs900, OHS900_IRQ_STATUS);
	if (irqstat) {
		ohs900_write(ohs900, OHS900_IRQ_STATUS, irqstat);
		irqstat &= ohs900->irq_enable;
	}

#ifdef	QUIRK2
	/* this may no longer be necessary ... */
	if (irqstat == 0 && ret == IRQ_NONE) {
		irqstat = checkdone(ohs900);
		if (irqstat && irq != ~0)
			ohs900->stat_lost++;
	}
#endif

	/* USB packets, not necessarily handled in the order they're
	 * issued ... that's fine if they're different endpoints.
	 */
	if (irqstat & OHS900_INTMASK_TRANS_DONE) {
		done(ohs900, ohs900->active_a, regs);
		ohs900->active_a = NULL;
		ohs900->stat_a++;
	}
	if (irqstat & OHS900_INTMASK_SOFINTR) {
		unsigned index;

		index = ohs900->frame++ % (PERIODIC_SIZE - 1);
		ohs900->stat_sof++;

		/* be graceful about almost-inevitable periodic schedule
		 * overruns:  continue the previous frame's transfers iff
		 * this one has nothing scheduled.
		 */
		if (ohs900->next_periodic) {
			// ERR("overrun to slot %d\n", index);
			ohs900->stat_overrun++;
		}
		if (ohs900->periodic[index])
			ohs900->next_periodic = ohs900->periodic[index];
	}

	/* khubd manages debouncing and wakeup */
	if (irqstat & OHS900_INTMASK_INSRMV) {
		ohs900->stat_insrmv++;

		/* most stats are reset for each VBUS session */
		ohs900->stat_wake = 0;
		ohs900->stat_sof = 0;
		ohs900->stat_a = 0;
		ohs900->stat_b = 0;
		ohs900->stat_lost = 0;

		ohs900->ctrl1 = 0;
		ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);

		ohs900->irq_enable = OHS900_INTMASK_INSRMV;
		ohs900_write(ohs900, OHS900_IRQ_ENABLE, ohs900->irq_enable);

		/* usbcore nukes other pending transactions on disconnect */
		if (ohs900->active_a) {
			ohs900_write(ohs900, OHS900_HOST_TX_CTLREG, 0);
			finish_request(ohs900, ohs900->active_a,
				container_of(ohs900->active_a->queue.next,
					struct ohs900h_req, queue),
				NULL, -ESHUTDOWN);
			ohs900->active_a = NULL;
		}

		/* port status seems wierd until after reset, so
		 * force the reset and make khubd clean up later.
		 */
		ohs900->port1 |= (1 << USB_PORT_FEAT_C_CONNECTION)
				| (1 << USB_PORT_FEAT_CONNECTION);

	} else if (irqstat & OHS900_INTMASK_RESUME_DET) {
		if (ohs900->port1 & (1 << USB_PORT_FEAT_SUSPEND)) {
			DBG("wakeup\n");
			ohs900->port1 |= 1 << USB_PORT_FEAT_C_SUSPEND;
			ohs900->stat_wake++;
		} else
			irqstat &= ~OHS900_INTMASK_RESUME_DET;
	}

	if (irqstat) {
		if (ohs900->port1 & (1 << USB_PORT_FEAT_ENABLE))
			start_transfer(ohs900);
		ret = IRQ_HANDLED;
		ohs900->hcd.saw_irq = 1;
		if (retries--)
			goto retry;
	}

	if (ohs900->periodic_count == 0 && list_empty(&ohs900->async)) 
		sofirq_off(ohs900);
	ohs900_write(ohs900, OHS900_IRQ_ENABLE, ohs900->irq_enable);

	spin_unlock(&ohs900->lock);

	return ret;
}

/*-------------------------------------------------------------------------*/

/* usb 1.1 says max 90% of a frame is available for periodic transfers.
 * this driver doesn't promise that much since it's got to handle an
 * IRQ per packet; irq handling latencies also use up that time.
 */
#define	MAX_PERIODIC_LOAD	500	/* out of 1000 usec */

static int balance(struct ohs900 *ohs900, u16 period, u16 load)
{
	int	i, branch = -ENOSPC;

	/* search for the least loaded schedule branch of that period
	 * which has enough bandwidth left unreserved.
	 */
	for (i = 0; i < period ; i++) {
		if (branch < 0 || ohs900->load[branch] > ohs900->load[i]) {
			int	j;

			for (j = i; j < PERIODIC_SIZE; j += period) {
				if ((ohs900->load[j] + load)
						> MAX_PERIODIC_LOAD)
					break;
			}
			if (j < PERIODIC_SIZE)
				continue;
			branch = i; 
		}
	}
	return branch;
}

/*-------------------------------------------------------------------------*/

static int ohs900h_urb_enqueue(
	struct usb_hcd	*hcd,
	struct urb	*urb,
	int		mem_flags
) {
	struct ohs900		*ohs900 = hcd_to_ohs900(hcd);
	struct usb_device	*udev = urb->dev;
	struct hcd_dev		*hdev = (struct hcd_dev *) udev->hcpriv;
	unsigned int		pipe = urb->pipe;
	int			is_out = !usb_pipein(pipe);
	int			type = usb_pipetype(pipe);
	int			epnum = usb_pipeendpoint(pipe);
	struct ohs900h_ep	*ep = NULL;
	struct ohs900h_req	*req;
	unsigned long		flags;
	int			i;
	int			retval = 0;

#ifdef	DISABLE_ISO
	if (type == PIPE_ISOCHRONOUS)
		return -ENOSPC;
#endif

	/* avoid all allocations within spinlocks: request or endpoint */
	urb->hcpriv = req = kmalloc(sizeof *req, mem_flags);
	if (!req)
		return -ENOMEM;
	req->urb = urb;

	i = epnum << 1;
	if (i && is_out)
		i |= 1;
	if (!hdev->ep[i])
		ep = kcalloc(1, sizeof *ep, mem_flags);

	spin_lock_irqsave(&ohs900->lock, flags);

	/* don't submit to a dead or disabled port */
	if (!(ohs900->port1 & (1 << USB_PORT_FEAT_ENABLE))
			|| !HCD_IS_RUNNING(ohs900->hcd.state)) {
		retval = -ENODEV;
		goto fail;
	}

	if (hdev->ep[i]) {
		kfree(ep);
		ep = hdev->ep[i];
	} else if (!ep) {
		retval = -ENOMEM;
		goto fail;

	} else {
		INIT_LIST_HEAD(&ep->queue);
		INIT_LIST_HEAD(&ep->schedule);
		ep->udev = usb_get_dev(udev);
		ep->epnum = epnum;
		ep->maxpacket = usb_maxpacket(udev, urb->pipe, is_out);
		ep->defctrl = OHS900_HCTLMASK_TRANS_REQ;
		usb_settoggle(udev, epnum, is_out, 0);

		if (type == PIPE_CONTROL)
			ep->nextpid = USB_PID_SETUP;
		else if (is_out)
			ep->nextpid = USB_PID_OUT;
		else
			ep->nextpid = USB_PID_IN;

		if (ep->maxpacket > H_MAXPACKET) {
			/* iso packets up to 64 bytes could work... */
			DBG("dev %d ep%d maxpacket %d\n",
				udev->devnum, epnum, ep->maxpacket);
			retval = -EINVAL;
			goto fail;
		}

		if (udev->speed == USB_SPEED_LOW) {
			/* send preamble for external hub? */
			if (ohs900->ctrl1 & OHS900_TXLCTL_MASK_FS_RATE)
				ep->defctrl |= OHS900_HCTLMASK_PREAMBLE_EN;
		}
		switch (type) {
		case PIPE_ISOCHRONOUS:
		case PIPE_INTERRUPT:
			if (urb->interval > PERIODIC_SIZE)
				urb->interval = PERIODIC_SIZE;
			ep->period = urb->interval;
			ep->branch = PERIODIC_SIZE;
			if (type == PIPE_ISOCHRONOUS)
				ep->defctrl |= OHS900_HCTLMASK_ISO_EN;
			ep->load = usb_calc_bus_time(udev->speed, !is_out,
				(type == PIPE_ISOCHRONOUS),
				usb_maxpacket(udev, pipe, is_out))
					/ 1000;
			break;
		}

		hdev->ep[i] = ep;
	}

	/* maybe put endpoint into schedule */
	switch (type) {
	case PIPE_CONTROL:
	case PIPE_BULK:
		if (list_empty(&ep->schedule))
			list_add_tail(&ep->schedule, &ohs900->async);
		break;
	case PIPE_ISOCHRONOUS:
	case PIPE_INTERRUPT:
		urb->interval = ep->period;
		if (ep->branch < PERIODIC_SIZE)
			break;

		retval = balance(ohs900, ep->period, ep->load);
		if (retval < 0)
			goto fail;
		ep->branch = retval;
		retval = 0;
		urb->start_frame = (ohs900->frame & (PERIODIC_SIZE - 1))
					+ ep->branch;

		/* sort each schedule branch by period (slow before fast)
		 * to share the faster parts of the tree without needing
		 * dummy/placeholder nodes
		 */
		DBG("schedule qh%d/%p branch %d\n", ep->period, ep, ep->branch);
		for (i = ep->branch; i < PERIODIC_SIZE; i += ep->period) {
			struct ohs900h_ep	**prev = &ohs900->periodic[i];
			struct ohs900h_ep	*here = *prev;

			while (here && ep != here) {
				if (ep->period > here->period)
					break;
				prev = &here->next;
				here = *prev;
			}
			if (ep != here) {
				ep->next = here;
				*prev = ep;
			}
			ohs900->load[i] += ep->load;
		}
		ohs900->periodic_count++;
		hcd_to_bus(&ohs900->hcd)->bandwidth_allocated
				+= ep->load / ep->period;
		sofirq_on(ohs900);
	}

	/* in case of unlink-during-submit */
	spin_lock(&urb->lock);
	if (urb->status != -EINPROGRESS) {
		spin_unlock(&urb->lock);
		finish_request(ohs900, ep, req, NULL, 0);
		req = NULL;
		retval = 0;
		goto fail;
	}
	list_add_tail(&req->queue, &ep->queue);
	spin_unlock(&urb->lock);

	start_transfer(ohs900);
	ohs900_write(ohs900, OHS900_IRQ_ENABLE, ohs900->irq_enable);
fail:
	spin_unlock_irqrestore(&ohs900->lock, flags);
	if (retval)
		kfree(req);
	return retval;
}

static int ohs900h_urb_dequeue(struct usb_hcd *hcd, struct urb *urb)
{
	struct ohs900		*ohs900 = hcd_to_ohs900(hcd);
	struct usb_device	*udev = urb->dev;
	struct hcd_dev		*hdev = (struct hcd_dev *) udev->hcpriv;
	unsigned int		pipe = urb->pipe;
	int			is_out = !usb_pipein(pipe);
	unsigned long		flags;
	unsigned		i;
	struct ohs900h_ep	*ep;
	struct ohs900h_req	*req = urb->hcpriv;
	int			retval = 0;

	i = usb_pipeendpoint(pipe) << 1;
	if (i && is_out)
		i |= 1;

	spin_lock_irqsave(&ohs900->lock, flags);
	ep = hdev->ep[i];
	if (ep) {
		/* finish right away if this urb can't be active ...
		 * note that some drivers wrongly expect delays
		 */
		if (ep->queue.next != &req->queue) {
			/* not front of queue?  never active */

		/* for active transfers, we expect an IRQ */
		} else if (ohs900->active_a == ep) {
			if (time_before_eq(ohs900->jiffies_a, jiffies)) {
				/* happens a lot with lowspeed?? */
				DBG("giveup on DONE_A: ctrl %02x sts %02x\n",
					ohs900_read(ohs900,OHS900_HOST_TX_CTLREG),
					ohs900_read(ohs900,OHS900_HRXSTATREG));
				ohs900_write(ohs900, OHS900_HOST_TX_CTLREG,0);
				ohs900->active_a = NULL;
			} else
				req = NULL;

		} else {
			/* front of queue for inactive endpoint */
		}

		if (req)
			finish_request(ohs900, ep, req, NULL, 0);
		else
			VDBG("dequeue, urb %p active %s; wait4irq\n", urb,
				(ohs900->active_a == ep) ? "A" : "B");
	} else
		retval = -EINVAL;
	spin_unlock_irqrestore(&ohs900->lock, flags);
	return retval;
}

static void
ohs900h_endpoint_disable(struct usb_hcd *hcd, struct hcd_dev *hdev, int epnum)
{
	struct ohs900		*ohs900 = hcd_to_ohs900(hcd);
	struct ohs900h_ep	*ep;
	unsigned long		flags;
	int			i;

	i = (epnum & 0xf) << 1;
	if (epnum && !(epnum & USB_DIR_IN))
		i |= 1;

	spin_lock_irqsave(&ohs900->lock, flags);
	ep = hdev->ep[i];
	hdev->ep[i] = NULL;
	spin_unlock_irqrestore(&ohs900->lock, flags);

	if (ep) {
		/* assume we'd just wait for the irq */
		if (!list_empty(&ep->queue))
			msleep(3);
		if (!list_empty(&ep->queue))
			WARN("ep %p not empty?\n", ep);

		usb_put_dev(ep->udev);
		kfree(ep);
	}
	return;
}

static int
ohs900h_get_frame(struct usb_hcd *hcd)
{
	struct ohs900 *ohs900 = hcd_to_ohs900(hcd);

	/* wrong except while periodic transfers are scheduled;
	 * never matches the on-the-wire frame;
	 * subject to overruns.
	 */
	return ohs900->frame;
}


/*-------------------------------------------------------------------------*/

/* the virtual root hub timer IRQ checks for hub status */
static int
ohs900h_hub_status_data(struct usb_hcd *hcd, char *buf)
{
	struct ohs900 *ohs900 = hcd_to_ohs900(hcd);
#ifdef	QUIRK3
	unsigned long flags;

	/* non-SMP HACK: use root hub timer as i/o watchdog
	 * this seems essential when SOF IRQs aren't in use...
	 */
	local_irq_save(flags);
	if (!timer_pending(&ohs900->timer)) {
		if (ohs900h_irq(~0, ohs900, NULL) != IRQ_NONE)
			ohs900->stat_lost++;
	}
	local_irq_restore(flags);
#endif

	if (!(ohs900->port1 & (0xffff << 16)))
		return 0;

	/* tell khubd port 1 changed */
	*buf = (1 << 1);
	return 1;
}

static void
ohs900h_hub_descriptor (
	struct ohs900			*ohs900,
	struct usb_hub_descriptor	*desc
) {
	u16		temp = 0;

	desc->bDescriptorType = 0x29;
	desc->bHubContrCurrent = 0;

	desc->bNbrPorts = 1;
	desc->bDescLength = 9;

	/* per-port power switching (gang of one!), or none */
	desc->bPwrOn2PwrGood = 0;
	if (ohs900->board && ohs900->board->port_power) {
		desc->bPwrOn2PwrGood = ohs900->board->potpg;
		if (!desc->bPwrOn2PwrGood)
			desc->bPwrOn2PwrGood = 10;
		temp = 0x0001;
	} else
		temp = 0x0002;

	/* no overcurrent errors detection/handling */
	temp |= 0x0010;

	desc->wHubCharacteristics = (__force __u16)cpu_to_le16(temp);

	/* two bitmaps:  ports removable, and legacy PortPwrCtrlMask */
	desc->bitmap[0] = 1 << 1;
	desc->bitmap[1] = ~0;
}

static void
ohs900h_timer(unsigned long _ohs900)
{
	struct ohs900 	*ohs900 = (void *) _ohs900;
	unsigned long	flags;
	u8		irqstat;
	u8		signaling = ohs900->ctrl1 & OHS900_TXLCTL_MASK_LINE_CTRL_BITS;
	const u32	mask = (1 << USB_PORT_FEAT_CONNECTION)
				| (1 << USB_PORT_FEAT_ENABLE)
				| (1 << USB_PORT_FEAT_LOWSPEED);
	u8		sofEnReg = 0;

	spin_lock_irqsave(&ohs900->lock, flags);

	/* stop special signaling */
	ohs900->ctrl1 &= ~OHS900_TXLCTL_MASK_FORCE;
	ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);
	udelay(3);

	irqstat = ohs900_read(ohs900, OHS900_IRQ_STATUS);

	switch (signaling) {
	case OHS900_TXLCTL_MASK_SE0:
		DBG("end reset\n");
		ohs900->port1 = (1 << USB_PORT_FEAT_C_RESET)
				| (1 << USB_PORT_FEAT_POWER);
		ohs900->ctrl1 = 0;
		/* don't wrongly ack RD */
		if (irqstat & OHS900_INTMASK_INSRMV)
			irqstat &= ~OHS900_INTMASK_RESUME_DET;
		break;
	case OHS900_TXLCTL_MASK_FS_K:
		DBG("end resume\n");
		ohs900->port1 &= ~(1 << USB_PORT_FEAT_SUSPEND);
		break;
	default:
		DBG("odd timer signaling: %02x\n", signaling);
		break;
	}
	ohs900_write(ohs900, OHS900_IRQ_STATUS, irqstat);

	//if (irqstat & OHS900_INTMASK_RESUME_DET) {
	if (ohs900_read(ohs900, OHS900_RXCONNSTATEREG) == OHS900_DISCONNECT_STATE) {
		/* usbcore nukes all pending transactions on disconnect */
		if (ohs900->port1 & (1 << USB_PORT_FEAT_CONNECTION))
			ohs900->port1 |= (1 << USB_PORT_FEAT_C_CONNECTION)
					| (1 << USB_PORT_FEAT_C_ENABLE);
		ohs900->port1 &= ~mask;
		ohs900->irq_enable = OHS900_INTMASK_INSRMV;
	} else {
		ohs900->port1 |= mask;
		if (ohs900_read(ohs900, OHS900_RXCONNSTATEREG) & OHS900_FS_CONN_STATE)
			ohs900->port1 &= ~(1 << USB_PORT_FEAT_LOWSPEED);
		ohs900->irq_enable = OHS900_INTMASK_INSRMV | OHS900_INTMASK_RESUME_DET;
	}

	if (ohs900->port1 & (1 << USB_PORT_FEAT_CONNECTION)) {

		ohs900->irq_enable |= OHS900_INTMASK_TRANS_DONE;
		if (ohs900->port1 & (1 << USB_PORT_FEAT_LOWSPEED)) {
			ohs900->ctrl1 &= ~OHS900_TXLCTL_MASK_FS_POL;
			ohs900->ctrl1 &= ~OHS900_TXLCTL_MASK_FS_RATE;
		}
		else {
			ohs900->ctrl1 |= OHS900_TXLCTL_MASK_FS_POL;
			ohs900->ctrl1 |= OHS900_TXLCTL_MASK_FS_RATE;
		}

		/* start SOFs flowing, kickstarting with A registers */
		sofEnReg = OHS900_MASK_SOF_ENA;		

		/* Set default device address */
		ohs900_write(ohs900, OHS900_TXADDRREG, 0); 

		/* khubd provides debounce delay */
	} else {
		ohs900->ctrl1 = 0;
	}
	ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);
	ohs900_write(ohs900, OHS900_SOFENREG, sofEnReg);

	/* reenable irqs */
	ohs900_write(ohs900, OHS900_IRQ_ENABLE, ohs900->irq_enable);
	spin_unlock_irqrestore(&ohs900->lock, flags);
}

static int
ohs900h_hub_control(
	struct usb_hcd	*hcd,
	u16		typeReq,
	u16		wValue,
	u16		wIndex,
	char		*buf,
	u16		wLength
) {
	struct ohs900	*ohs900 = hcd_to_ohs900(hcd);
	int		retval = 0;
	unsigned long	flags;

	spin_lock_irqsave(&ohs900->lock, flags);

	switch (typeReq) {
	case ClearHubFeature:
	case SetHubFeature:
		switch (wValue) {
		case C_HUB_OVER_CURRENT:
		case C_HUB_LOCAL_POWER:
			break;
		default:
			goto error;
		}
		break;
	case ClearPortFeature:
		if (wIndex != 1 || wLength != 0)
			goto error;

		switch (wValue) {
		case USB_PORT_FEAT_ENABLE:
			ohs900->port1 &= (1 << USB_PORT_FEAT_POWER);
			ohs900->ctrl1 = 0;
			ohs900_write(ohs900, OHS900_SOFENREG, 0);
			ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);
			ohs900->irq_enable = OHS900_INTMASK_INSRMV;
			ohs900_write(ohs900, OHS900_IRQ_ENABLE,
						ohs900->irq_enable);
			break;
		case USB_PORT_FEAT_SUSPEND:
			if (!(ohs900->port1 & (1 << USB_PORT_FEAT_SUSPEND)))
				break;

			/* 20 msec of resume/K signaling, other irqs blocked */
			DBG("start resume...\n");
			ohs900->irq_enable = 0;
			ohs900_write(ohs900, OHS900_IRQ_ENABLE,
						ohs900->irq_enable);
			ohs900->ctrl1 |= OHS900_TXLCTL_MASK_FS_K;
			ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);

			mod_timer(&ohs900->timer, jiffies
					+ msecs_to_jiffies(20));
			break;
		case USB_PORT_FEAT_POWER:
			port_power(ohs900, 0);
			break;
		case USB_PORT_FEAT_C_ENABLE:
		case USB_PORT_FEAT_C_SUSPEND:
		case USB_PORT_FEAT_C_CONNECTION:
		case USB_PORT_FEAT_C_OVER_CURRENT:
		case USB_PORT_FEAT_C_RESET:
			break;
		default:
			goto error;
		}
		ohs900->port1 &= ~(1 << wValue);
		break;
	case GetHubDescriptor:
		ohs900h_hub_descriptor(ohs900, (struct usb_hub_descriptor *) buf);
		break;
	case GetHubStatus:
		*(__le32 *) buf = cpu_to_le32(0);
		break;
	case GetPortStatus:
		if (wIndex != 1)
			goto error;
		*(__le32 *) buf = cpu_to_le32(ohs900->port1);

#ifndef	VERBOSE
	if (*(u16*)(buf+2))	/* only if wPortChange is interesting */
#endif
		DBG("GetPortStatus %08x\n", ohs900->port1);
		break;
	case SetPortFeature:
		if (wIndex != 1 || wLength != 0)
			goto error;
		switch (wValue) {
		case USB_PORT_FEAT_SUSPEND:
			if (ohs900->port1 & (1 << USB_PORT_FEAT_RESET))
				goto error;
			if (!(ohs900->port1 & (1 << USB_PORT_FEAT_ENABLE)))
				goto error;

			DBG("suspend...\n");
			ohs900_write(ohs900, OHS900_SOFENREG, 0);
			break;
		case USB_PORT_FEAT_POWER:
			port_power(ohs900, 1);
			break;
		case USB_PORT_FEAT_RESET:
			if (ohs900->port1 & (1 << USB_PORT_FEAT_SUSPEND))
				goto error;
			if (!(ohs900->port1 & (1 << USB_PORT_FEAT_POWER)))
				break;

			/* 50 msec of reset/SE0 signaling, irqs blocked */
			ohs900->irq_enable = 0;
			ohs900_write(ohs900, OHS900_IRQ_ENABLE,
						ohs900->irq_enable);
			ohs900_write(ohs900, OHS900_SOFENREG, 0);
			ohs900->ctrl1 = OHS900_TXLCTL_MASK_SE0;
			ohs900_write(ohs900, OHS900_TXLINECTLREG, ohs900->ctrl1);
			ohs900->port1 |= (1 << USB_PORT_FEAT_RESET);
			mod_timer(&ohs900->timer, jiffies
					+ msecs_to_jiffies(50));
			break;
		default:
			goto error;
		}
		ohs900->port1 |= 1 << wValue;
		break;

	default:
error:
		/* "protocol stall" on error */
		retval = -EPIPE;
	}

	spin_unlock_irqrestore(&ohs900->lock, flags);
	return retval;
}

#ifdef	CONFIG_PM

static int
ohs900h_hub_suspend(struct usb_hcd *hcd)
{
	// SOFs off
	DBG("%s\n", __FUNCTION__);
	return 0;
}

static int
ohs900h_hub_resume(struct usb_hcd *hcd)
{
	// SOFs on
	DBG("%s\n", __FUNCTION__);
	return 0;
}

#else

#define	ohs900h_hub_suspend	NULL
#define	ohs900h_hub_resume	NULL

#endif


/*-------------------------------------------------------------------------*/

#ifdef STUB_DEBUG_FILE

static inline void create_debug_file(struct ohs900 *ohs900) { }
static inline void remove_debug_file(struct ohs900 *ohs900) { }

#else

#include <linux/proc_fs.h>
#include <linux/seq_file.h>

static void dump_irq(struct seq_file *s, char *label, u8 mask)
{
	seq_printf(s, "%s %02x%s%s%s%s\n", label, mask,
		(mask & OHS900_INTMASK_TRANS_DONE) ? " done" : "",
		(mask & OHS900_INTMASK_SOFINTR) ? " sof" : "",
		(mask & OHS900_INTMASK_INSRMV) ? " ins/rmv" : "",
		(mask & OHS900_INTMASK_RESUME_DET) ? " rd" : "");
}

static int proc_ohs900h_show(struct seq_file *s, void *unused)
{
	struct ohs900		*ohs900 = s->private;
	struct ohs900h_ep	*ep;
	unsigned		i;
	u8	t;
	
	seq_printf(s, "%s\n%s version %s\nportstatus[1] = %08x\n",
		ohs900->hcd.product_desc,
		hcd_name, DRIVER_VERSION,
		ohs900->port1);

	seq_printf(s, "insert/remove: %ld\n", ohs900->stat_insrmv);
	seq_printf(s, "current session:  done_a %ld done_b %ld "
			"wake %ld sof %ld overrun %ld lost %ld\n\n",
		ohs900->stat_a, ohs900->stat_b,
		ohs900->stat_wake, ohs900->stat_sof,
		ohs900->stat_overrun, ohs900->stat_lost);

	spin_lock_irq(&ohs900->lock);

	t = ohs900_read(ohs900, OHS900_TXLINECTLREG);


	seq_printf(s, "ctrl1 %02x%s%s%s%s\n", t,
		(ohs900_read(ohs900, OHS900_SOFENREG)) ? " sofgen" : "",
		({char *s; switch (t & OHS900_TXLCTL_MASK_LINE_CTRL_BITS) {
		case OHS900_TXLCTL_MASK_NORMAL: s = ""; break;
		case OHS900_TXLCTL_MASK_SE0: s = " se0/reset"; break;
		case OHS900_TXLCTL_MASK_FS_K: s = " FS k/resume"; break;
		case OHS900_TXLCTL_MASK_FS_J: s = " FS J/resume"; break;
		default: s = " not valid ?"; break;
		}; s; }),
		(t & OHS900_TXLCTL_MASK_FS_POL) ? " fs pol" : " ls pol ",
		(t & OHS900_TXLCTL_MASK_FS_RATE) ? " fs rate" : " ls rate ");

	dump_irq(s, "irq_enable",
			ohs900_read(ohs900, OHS900_IRQ_ENABLE));
	dump_irq(s, "irq_status",
			ohs900_read(ohs900, OHS900_IRQ_STATUS));
	seq_printf(s, "frame clocks remaining:  %d\n",
			ohs900_read(ohs900, OHS900_SOFTMRREG) << 6);


	
	seq_printf(s, "A: qh%p ctl %02x sts %02x\n", ohs900->active_a,
		ohs900_read(ohs900, OHS900_HOST_TX_CTLREG),
		ohs900_read(ohs900, OHS900_HRXSTATREG));
	seq_printf(s, "\n");
	list_for_each_entry (ep, &ohs900->async, schedule) {
		struct ohs900h_req	*req;

		seq_printf(s, "%s%sqh%p, ep%d%s, maxpacket %d"
					" nak %d err %d\n",
			(ep == ohs900->active_a) ? "(A) " : "",
			(ep == ohs900->active_b) ? "(B) " : "",
			ep, ep->epnum,
			({ char *s; switch (ep->nextpid) {
			case USB_PID_IN: s = "in"; break;
			case USB_PID_OUT: s = "out"; break;
			case USB_PID_SETUP: s = "setup"; break;
			case USB_PID_ACK: s = "status"; break;
			default: s = "?"; break;
			}; s;}),
			ep->maxpacket,
			ep->nak_count, ep->error_count);
		list_for_each_entry (req, &ep->queue, queue) {
			seq_printf(s, "  urb%p, %d/%d\n", req->urb,
				req->urb->actual_length,
				req->urb->transfer_buffer_length);
		}
	}
	if (!list_empty(&ohs900->async))
		seq_printf(s, "\n");

	seq_printf(s, "periodic size= %d\n", PERIODIC_SIZE);

	for (i = 0; i < PERIODIC_SIZE; i++) {
		ep = ohs900->periodic[i];
		if (!ep)
			continue;
		seq_printf(s, "%2d [%3d]:\n", i, ohs900->load[i]);

		/* DUMB: prints shared entries multiple times */
		do {
			seq_printf(s,
				"   %s%sqh%d/%p (%sdev%d ep%d%s max %d) "
					"err %d\n",
				(ep == ohs900->active_a) ? "(A) " : "",
				(ep == ohs900->active_b) ? "(B) " : "",
				ep->period, ep,
				(ep->udev->speed == USB_SPEED_FULL)
					? "" : "ls ",
				ep->udev->devnum, ep->epnum,
				(ep->epnum == 0) ? ""
					: ((ep->nextpid == USB_PID_IN)
						? "in"
						: "out"),
				ep->maxpacket, ep->error_count);
			ep = ep->next;
		} while (ep);
	}

	spin_unlock_irq(&ohs900->lock);
	seq_printf(s, "\n");

	return 0;
}

static int proc_ohs900h_open(struct inode *inode, struct file *file)
{
	return single_open(file, proc_ohs900h_show, PDE(inode)->data);
}

static struct file_operations proc_ops = {
	.open		= proc_ohs900h_open,
	.read		= seq_read,
	.llseek		= seq_lseek,
	.release	= single_release,
};

/* expect just one ohs900 per system */
static const char proc_filename[] = "driver/ohs900";

static void create_debug_file(struct ohs900 *ohs900)
{
	struct proc_dir_entry *pde;

	pde = create_proc_entry(proc_filename, 0, NULL);
	if (pde == NULL)
		return;

	pde->proc_fops = &proc_ops;
	pde->data = ohs900;
	ohs900->pde = pde;
}

static void remove_debug_file(struct ohs900 *ohs900)
{
	if (ohs900->pde)
		remove_proc_entry(proc_filename, NULL);
}

#endif

/*-------------------------------------------------------------------------*/

static void
ohs900h_stop(struct usb_hcd *hcd)
{
	struct ohs900	*ohs900 = hcd_to_ohs900(hcd);
	unsigned long	flags;

	del_timer_sync(&ohs900->hcd.rh_timer);

	spin_lock_irqsave(&ohs900->lock, flags);
	port_power(ohs900, 0);
	spin_unlock_irqrestore(&ohs900->lock, flags);
}

static int
ohs900h_start(struct usb_hcd *hcd)
{
	struct ohs900		*ohs900 = hcd_to_ohs900(hcd);
	struct usb_device	*udev;

	/* chip has been reset, VBUS power is off */

	udev = usb_alloc_dev(NULL, &ohs900->hcd.self, 0);
	if (!udev)
		return -ENOMEM;

	udev->speed = USB_SPEED_FULL;
	hcd->state = USB_STATE_RUNNING;

	if (ohs900->board)
		ohs900->hcd.can_wakeup = ohs900->board->can_wakeup;

	if (hcd_register_root(udev, &ohs900->hcd) != 0) {
		usb_put_dev(udev);
		ohs900h_stop(hcd);
		return -ENODEV;
	}

	if (ohs900->board && ohs900->board->power)
		hub_set_power_budget(udev, ohs900->board->power * 2);

	return 0;
}

/*-------------------------------------------------------------------------*/

static struct hc_driver ohs900h_hc_driver = {
	.description =		hcd_name,

	/*
	 * generic hardware linkage
	 */
	.flags =		HCD_USB11,

	/*
	 * managing i/o requests and associated device resources
	 */
	.urb_enqueue =		ohs900h_urb_enqueue,
	.urb_dequeue =		ohs900h_urb_dequeue,
	.endpoint_disable =	ohs900h_endpoint_disable,

	/*
	 * periodic schedule support
	 */
	.get_frame_number =	ohs900h_get_frame,

	/*
	 * root hub support
	 */
	.hub_status_data =	ohs900h_hub_status_data,
	.hub_control =		ohs900h_hub_control,
	.hub_suspend =		ohs900h_hub_suspend,
	.hub_resume =		ohs900h_hub_resume,
};

/*-------------------------------------------------------------------------*/
#define resource_len(r) (((r)->end - (r)->start) + 1)

static int __init_or_module
ohs900h_remove(struct device *dev)
{
	struct ohs900		*ohs900 = dev_get_drvdata(dev);
	struct platform_device	*pdev;
	struct resource		*res;

	pdev = container_of(dev, struct platform_device, dev);

	if (HCD_IS_RUNNING(ohs900->hcd.state))
		ohs900->hcd.state = USB_STATE_QUIESCING;

	usb_disconnect(&ohs900->hcd.self.root_hub);
	remove_debug_file(ohs900);
	ohs900h_stop(&ohs900->hcd);

	if (!list_empty(&ohs900->hcd.self.bus_list))
		usb_deregister_bus(&ohs900->hcd.self);

	if (ohs900->hcd.irq >= 0)
		free_irq(ohs900->hcd.irq, ohs900);


	if (ohs900->addr_reg) 
		iounmap(ohs900->addr_reg);
	res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	release_mem_region(res->start, resource_len(res));

	kfree(ohs900);
	return 0;
}


static int __init
ohs900h_probe(struct device *dev)
{
	struct ohs900		*ohs900;
	struct platform_device	*pdev;
	struct resource		*addr;
	int			irq;
	int			status;
	u8			tmp;
	unsigned long		flags;

	/* basic sanity checks first.  board-specific init logic should
	 * have initialized these three resources and probably board
	 * specific platform_data.  we don't probe for IRQs, and do only
	 * minimal sanity checking.
	 */


	//---------------------------------- FIXME Resource allocation is not working
	INFO("driver %s, starting ohs900h_probe\n", hcd_name);
	pdev = container_of(dev, struct platform_device, dev);
	if (pdev->num_resources < 3)
		return -ENODEV;

	addr = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	irq = platform_get_irq(pdev, 0); // FIXME should this be (pdev, 1) ?
	if (!addr || irq < 0)
		return -ENODEV;
	//---------------------------------- 

	/* refuse to confuse usbcore */
	if (dev->dma_mask) {
		DBG("no we won't dma\n");
		return -EINVAL;
	}

	//---------------------------------- FIXME Resource allocation is not working
	INFO("driver %s, requesting mem region\n", hcd_name);
	if (!request_mem_region(addr->start, resource_len(addr), hcd_name))
		return -EBUSY;
	//---------------------------------- 

	/* allocate and initialize hcd */
	INFO("driver %s, allocating memory\n", hcd_name);
	ohs900 = kcalloc(1, sizeof *ohs900, GFP_KERNEL);
	if (!ohs900)
		return 0;
	dev_set_drvdata(dev, ohs900);

	INFO("driver %s, usb_bus_init\n", hcd_name);
	usb_bus_init(&ohs900->hcd.self);
	INFO("driver %s, returned from usb_bus_init\n", hcd_name);
	ohs900->hcd.self.controller = dev;
	ohs900->hcd.self.bus_name = dev->bus_id;
	ohs900->hcd.self.op = &usb_hcd_operations;
	ohs900->hcd.self.hcpriv = ohs900;

	// NOTE: 2.6.11 starts to change the hcd glue layer some more,
	// eventually letting us eliminate struct ohs900h_req and a
	// lot of the boilerplate code here 

	INFO("driver %s, INIT_LIST_HEAD\n", hcd_name);
	INIT_LIST_HEAD(&ohs900->hcd.dev_list);
	ohs900->hcd.self.release = &usb_hcd_release;

	ohs900->hcd.description = ohs900h_hc_driver.description;
	INFO("driver %s, init_timer\n", hcd_name);
	init_timer(&ohs900->hcd.rh_timer);
	ohs900->hcd.driver = &ohs900h_hc_driver;
	ohs900->hcd.irq = -1;
	ohs900->hcd.state = USB_STATE_HALT;

	INFO("driver %s, spin_lock_init\n", hcd_name);
	spin_lock_init(&ohs900->lock);
	INIT_LIST_HEAD(&ohs900->async);
	ohs900->board = dev->platform_data;
	init_timer(&ohs900->timer);
	ohs900->timer.function = ohs900h_timer;
	ohs900->timer.data = (unsigned long) ohs900;

	INFO("driver %s, ioremap addr->start = 0x%lx, resource_len(addr) = 0x%lx\n",
		       	hcd_name, addr->start, resource_len(addr));
	INFO("driver %s, ioremap\n", hcd_name);
	
	ohs900->addr_reg = ioremap(addr->start, resource_len(addr)); 
	if (ohs900->addr_reg == NULL) {
		status = -ENOMEM;
		goto fail;
	}

	spin_lock_irqsave(&ohs900->lock, flags);
	INFO("driver %s, port_power\n", hcd_name);
	port_power(ohs900, 0);
	INFO("driver %s, returned from port_power\n", hcd_name);
	spin_unlock_irqrestore(&ohs900->lock, flags);
	INFO("driver %s, returned from spin_unlock_irqrestore\n", hcd_name);
	msleep(200);

	INFO("driver %s, getting hw version\n", hcd_name);
	tmp = ohs900_read(ohs900, OHS900_HWREVREG);
	switch (tmp) {
	case 0x7:
		ohs900->hcd.product_desc = "OHS900 v0.7";
		break;
	case 0x8:
		ohs900->hcd.product_desc = "OHS900 v0.8";
		break;
	case 0x10:
		ohs900->hcd.product_desc = "OHS900 v1.0";
		break;
	case 0x11:
		ohs900->hcd.product_desc = "OHS900 v1.1";
		break;
	default:
		/* reject other chip revisions */
		DBG("chiprev %02x\n", tmp);
		status = -ENXIO;
		goto fail;
	}
	INFO("driver %s, hw version = %d\n", hcd_name, tmp);


#ifdef	CONFIG_ARM
	set_irq_type(irq, IRQT_RISING);
#endif
	status = request_irq(irq, ohs900h_irq, SA_INTERRUPT, hcd_name, ohs900);
	if (status < 0)
		goto fail;
	ohs900->hcd.irq = irq;

	INFO("%s, irq %d\n", ohs900->hcd.product_desc, irq);

	status = usb_register_bus(&ohs900->hcd.self);
	if (status < 0)
		goto fail;
	status = ohs900h_start(&ohs900->hcd);
	if (status == 0) {
		create_debug_file(ohs900);
		return 0;
	}
fail:
	ohs900h_remove(dev);
	DBG("init error, %d\n", status);
	return status;
}


#ifdef	CONFIG_PM

/* for this device there's no useful distinction between the controller
 * and its root hub, except that the root hub only gets direct PM calls 
 * when CONFIG_USB_SUSPEND is enabled.
 */

static int
ohs900h_suspend(struct device *dev, u32 state, u32 phase)
{
	struct ohs900	*ohs900 = dev_get_drvdata(dev);
	int		retval = 0;

	if (phase != SUSPEND_POWER_DOWN)
		return retval;

	if (state <= PM_SUSPEND_MEM)
		retval = ohs900h_hub_suspend(&ohs900->hcd);
	else
		port_power(ohs900, 0);
	if (retval == 0)
		dev->power.power_state = state;
	return retval;
}

static int
ohs900h_resume(struct device *dev, u32 phase)
{
	struct ohs900	*ohs900 = dev_get_drvdata(dev);

	if (phase != RESUME_POWER_ON)
		return 0;

	/* with no "check to see if VBUS is still powered" board hook,
	 * let's assume it'd only be powered to enable remote wakeup.
	 */
	if (dev->power.power_state > PM_SUSPEND_MEM
			|| !ohs900->hcd.can_wakeup) {
		ohs900->port1 = 0;
		port_power(ohs900, 1);
		return 0;
	}

	dev->power.power_state = PM_SUSPEND_ON;
	return ohs900h_hub_resume(&ohs900->hcd);
}

#else

#define	ohs900h_suspend	NULL
#define	ohs900h_resume	NULL

#endif


static struct device_driver ohs900h_driver = {
	.name =		(char *) hcd_name,
	.bus =		&platform_bus_type,

	.probe =	ohs900h_probe,
	.remove =	ohs900h_remove,

	.suspend =	ohs900h_suspend,
	.resume =	ohs900h_resume,
};

//---------------------------------- FIXME Resource allocation is not working
static struct resource ohs900_resources[] = { 
 [0] = {
   .start          = 0x80900c00,
   .end            = (0x80900c00 + OHS900_IO_EXTENT - 1),
   .flags          = IORESOURCE_MEM,
 },
 [1] = {
   .start          = 0x80900e00,
   .end            = (0x80900e00 + 4 - 1),
   .flags          = IORESOURCE_MEM,
 },
 [2] = {
   .start          = 11,
   .end            = 11,
   .flags          = IORESOURCE_IRQ,
 },
};
//---------------------------------- 



static void sm3k_port_power(struct device *dev, int is_on) {
	INFO("driver %s, inside stubbed sm3k_port_power\n", hcd_name);
 // see linux/usb_ohs900.h
}
static void sm3k_hc_reset(struct device *dev) {
 // see linux/usb_ohs900.h
	struct ohs900	*ohs900 = dev_get_drvdata(dev);

	INFO("Resetting core\n");
	ohs900_write(ohs900, OHS900_HOSTSLAVECTLREG, OHS900_HSCTLREG_RESET_CORE);
}
struct ohs900_platform_data sm3k_ohs900 = {
 .potpg = 10,
 .power = 250,
 .port_power = sm3k_port_power,
 .reset = sm3k_hc_reset,
};
static struct platform_device ohs900_device = {
 .name           = "ohs900-hcd",
 .id             = -1,
 .dev = {
   .platform_data = &sm3k_ohs900,
 },
 .num_resources  = ARRAY_SIZE(ohs900_resources),
 .resource       = ohs900_resources,
};


/*-------------------------------------------------------------------------*/
 
static int __init ohs900h_init(void) 
{
	if (usb_disabled())
		return -ENODEV;
	
	platform_device_register(&ohs900_device); 
	
	INFO("driver %s, %s\n", hcd_name, DRIVER_VERSION);
	return driver_register(&ohs900h_driver);
}
module_init(ohs900h_init);

static void __exit ohs900h_cleanup(void) 
{	
	driver_unregister(&ohs900h_driver);
}
module_exit(ohs900h_cleanup);
