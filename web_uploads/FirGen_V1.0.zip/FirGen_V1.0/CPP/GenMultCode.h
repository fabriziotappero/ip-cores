#ifndef GenMultCode_H
#define GenMultCode_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;

#include "GenMultScript.h"
#include "GenMathVHDL.h"
#include "GenVHDL.h"
#include "MathVHDL_var.h"
#include "VHDL_var.h"
#include "GenMultScript.h"
#include "GenOptimizeVHDL.h"

class GenMultCode {
 protected:
  GenMathVHDL*             m_code;
  vector<MathVHDL_var*>    mult_out_vector;
  //vector<coreGen_element_s*> codeScript;

  void GenIOPort(int inDataWidth);
  MathVHDL_var* GenCommon(int inDataWidth);
  vector<MathVHDL_var*> SortVarScript(vector<MathVHDL_var*> scriptIn);

  MathExpresionVHDL* GenSingle_pMult(vector<mult_s> script,MathVHDL_var* DIn,vector<MathVHDL_var*> TermList);
  vector<MathVHDL_var*> Gen_pMult(vector<vector<mult_s> > script, MathVHDL_var* DIn, vector<MathVHDL_var*> TermList);
  
  vector<MathVHDL_var*> Gen_FinalStage(vector<MathVHDL_var*> pMult);

 public:
  GenMultCode(vector<vector<mult_s> > term,vector<vector<mult_s> > script,int inDataWidth,string fname,vector<int> mult_array);
  void GenMultCode_construct(vector<vector<mult_s> > term,vector<vector<mult_s> > script,int inDataWidth,string fname,vector<int> mult_array);
  ~GenMultCode();
  vector<MathVHDL_var*> GetOutVector();

  string GetComponent();
  string GetPortMapCon(string ImplementName,string ClkName, MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut);

};

#endif
