#ifndef GEN_MATH_VHDL_H
#define GEN_MATH_VHDL_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>
#include <sstream>

#include "GenVHDL.h"
#include "MathVHDL_var.h"
#include "VHDL_var.h"
#include "MathExpresionVHDL.h"

using namespace std;

class GenMathVHDL : public GenVHDL {
 protected :
   vector<MathVHDL_var*> m_varList;
   int tempCount;

   int GetNextTemp();
   int GetCurTemp();
   string GetNextTempName();

 public :
   GenMathVHDL(string fname);
   //~GenMathVHDL();

   MathVHDL_var* AddVariable(string nameIn, int type, int from, int to,
                    int mathVarType,int shift,int sign,int termNum,
		            int pipeStage,string str_label,void* attach);

   MathVHDL_var* AddVariable(MathVHDL_var* varIn,int pipeStage);
   MathVHDL_var* GetVariable(string name);
   MathVHDL_var* GetVariable(string baseName,int pipeStage);
   vector<MathVHDL_var*> GetVarList();
   void SetVarList(vector<MathVHDL_var*> var);
   //////////////////////////////////////////////////////////

   MathVHDL_var* Gen_FinalOut(MathVHDL_var* varIn,string outName,int termNumIn,int mult_num,int inDataWidth);
   MathVHDL_var* Script2MathVar(mult_s s,MathVHDL_var* DIn,vector<MathVHDL_var*> TermList);
   
   //MathVHDL_var* FindVar(string name);
   vector<MathVHDL_var*> ResampleArray(vector<MathVHDL_var*> varIn);
   vector<string> VHDL_GenVar(vector<MathVHDL_var*> varList);
   vector<MathVHDL_var*> CopyToNewArray(vector<MathVHDL_var*> varIn,string newName,int pipeStage);
   
   string codeGen_ExtendBitSize(string varName,int addBits);
   string codeGen_VarDownto(string varName,int downto);
   string codeGen_VarUp(string varName,int upTo);
   string codeGen_A_pm_B(MathVHDL_var* a,MathVHDL_var* b,MathVHDL_var* dest,int sign);
   string codeGen_finalizeTerm(MathVHDL_var* a,MathVHDL_var* dest);

   coreGen_element_s* Gen_A_op_B_VHDL(int cmd,MathVHDL_var* a,MathVHDL_var* b,MathVHDL_var* DestIn);
   coreGen_element_s* Gen_Lim_VHDL(MathVHDL_var* var,int NewBitSize);
   coreGen_element_s* Gen_ZERO_Output();   
};
#endif
