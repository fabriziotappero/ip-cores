#include "FirGenCode.h"

int FirGenCode::calcNumOfBits(int numIn) {
	int bitCount;
	
	bitCount = 0;
	while(numIn!=0) {
		numIn = numIn >> 1;
		bitCount++;
	}
	return(bitCount);
}

FirGenCode::FirGenCode(string fname,int inDataWidth,vector<int> multVector) {
   vector<MathVHDL_var*> OutVector;
   vector<MathVHDL_var*> MultVector;
   MathVHDL_var* tempVar;
   MathVHDL_var* DInVar;
   string str;
   int i,size;
   coreGen_element_s* code;
   coreGen_element_s* codeLim;
   int CoefSum;
   //string codeStr;
   
   MathVHDL_var* a;
   MathVHDL_var* b;
   MathVHDL_var* dest;
   
   int totalNumOfBits;
   	
   mCode = new GenMathVHDL(fname); // Create New VHDL File
   mCode->AddVHDLCode    ("------------------------------------------------");
   mCode->AddCodeComments("FIR Filter Generator (V1.0)");
   mCode->AddVHDLCode("");
  
   // Create Input port
   DInVar = new MathVHDL_var("DataIn",VHDL_var_std_logic_vector,inDataWidth-1,0,MatVHDL_var_DIN,0,1,0,1,"",NULL);
   mCode->AddPort("CLK",VHDL_var_std_logic,1,0,0,NULL);
   mCode->AddPort("DataIn",VHDL_var_std_logic_vector,1,inDataWidth-1,0,NULL);
  
   // Create multiplication array 
   mMultGen = new MultGen(fname+"_mult",inDataWidth,multVector);
   OutVector = mMultGen->GetOutVector();
   
   /////////////////////////////////////////
   // Add component
   str = mMultGen->GetComponent();
   str = "  ------------------------------------------------\r\n" + str + "\r\n";
   mCode->AddComponent(str);
   
   /////////////////////////////////////////
   // Impleminatation
   // create variables
   for (i=0;i<OutVector.size();i++) {
   	   tempVar = OutVector[i];
   	   tempVar = mCode->AddVariable(tempVar,0);  
   }

   mCode->AddVHDLCode("------------------------------------------------");
   str = mMultGen->GetPortMapCon("M_MULT","CLK",DInVar,OutVector);
   mCode->AddVHDLCode(str);
   mCode->AddVHDLCode("------------------------------------------------");
   
   ////////////////////////////////////
   // Generate FIR 
  
   cout << "Generate FIR ----------------------------\r\n";
   
   size = OutVector.size();
   
/*   // Generate First ADDER
   if (size>=2) {
      a = MultVector[size-1];
      b = MultVector[size-2];
      
      code = mCode->Gen_A_op_B_VHDL(CMD_A_pm_B,a,b,NULL);
      mCode->AddVHDLCodeClk(code->code);
   }*/
   
   CoefSum = 0;
   
   if (size>0) {
   	  do {
         a = OutVector[size-1];

         code = mCode->Gen_A_op_B_VHDL(CMD_EQUAL,a,NULL,NULL);
         
         // Calculate output bit width
         CoefSum += abs(multVector[size-1]);
         totalNumOfBits = calcNumOfBits(CoefSum) + inDataWidth + 1;
         cout << "CoefSum_#_:"<<CoefSum<< " TotalNumOfBits:" << totalNumOfBits << "\r\n";
         codeLim = mCode->Gen_Lim_VHDL(code->dest,totalNumOfBits);
         
         size--;
   	  } while((size>0)&&(multVector[size]==0));
      /////////////////////////////////////////////// 
      //codeStr = code->code;
      //codeStr += codeLim->code;
      mCode->AddVHDLCode(code->code);
      //codeLim = code;
      mCode->AddVHDLCodeClk(codeLim->code);
   }

   if (size>0) {
      for (i=size-1;i>=0;i--) {
          a = OutVector[i];
          b = codeLim->dest;
      
          if (multVector[i]==0) {
             code = mCode->Gen_A_op_B_VHDL(CMD_EQUAL,b,NULL,NULL);
          } else {
             code = mCode->Gen_A_op_B_VHDL(CMD_A_pm_B,a,b,NULL);
          }
 
          // Calculate output bit width
          CoefSum += abs(multVector[i]);
          totalNumOfBits = calcNumOfBits(CoefSum) + inDataWidth + 1;
          cout << "CoefSum_@_:"<<CoefSum<< " TotalNumOfBits:" << totalNumOfBits << "\r\n";
          codeLim = mCode->Gen_Lim_VHDL(code->dest,totalNumOfBits);

          //codeStr = code->code;
          //codeStr += codeLim->code;
          //mCode->AddVHDLCodeClk(codeStr);
          mCode->AddVHDLCode(code->code);
          mCode->AddVHDLCodeClk(codeLim->code);
      }
   }
 
   ////////////////////////////////////////////////////
   // Generate Data Out
   str = "DOut <= " + codeLim->dest->GetVarName() + ";";
   mCode->AddVHDLCode(str);
   mCode->AddPort("DOut",VHDL_var_std_logic_vector,0,codeLim->dest->GetRangeFrom(),codeLim->dest->GetRangeTo(),NULL);

}

FirGenCode::~FirGenCode() {
   delete mMultGen;
   delete mCode;
}

