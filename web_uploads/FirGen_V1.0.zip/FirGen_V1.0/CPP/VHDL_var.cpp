//////////////////////////////////////////////////////////////////
// Basic VHDL Variable Container
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
//
#include "VHDL_var.h"

VHDL_var::VHDL_var(string name,int type,int range_from=0,int range_to=0,int port_In_nOut=(-1),string str_label=NULL,void* attach=NULL) { // constructor 
  this->name = name; 
  this->type = type;
  this->range_from = range_from;
  this->range_to   = range_to;
  this->port_In_nOut = port_In_nOut;
  this->attach = attach;
  this->var_ver = STD_VHDL_VAR_VER;
}

VHDL_var::VHDL_var(VHDL_var* cloneIn) {
  this->name         = cloneIn->GetVarName(); 
  this->type         = cloneIn->GetVarType();
  this->range_from   = cloneIn->GetRangeFrom();
  this->range_to     = cloneIn->GetRangeTo();
  this->port_In_nOut = cloneIn->GetPortType();
  this->attach       = cloneIn->GetAttachment();
  //this->var_ver      = cloneIn->GetVHDL_VarVer();  
  this->var_ver     = STD_VHDL_VAR_VER;
}

VHDL_var::VHDL_var(VHDL_var* cloneIn,int pipeDelay) {
  int i;

  this->name         = cloneIn->GetVarName(); 
  for (i=0;i<pipeDelay;i++) {
    this->name+="_d";
  }
  this->type         = cloneIn->GetVarType();
  this->range_from   = cloneIn->GetRangeFrom();
  this->range_to     = cloneIn->GetRangeTo();
  this->port_In_nOut = cloneIn->GetPortType();
  this->attach       = cloneIn->GetAttachment();
  //this->var_ver      = cloneIn->GetVHDL_VarVer();  
  this->var_ver     = STD_VHDL_VAR_VER;
  this->str_label   = str_label;
}

VHDL_var::~VHDL_var() {
}

string VHDL_var::GetVarName() {
  return(name);
}
int    VHDL_var::GetVarType() {   // return variable type
  return(type);
}
string VHDL_var::GetVarTypeStr() {   // return variable type as string 
  char myChar[200];
  switch(type) {
    case VHDL_var_integer :        
      return("Integer");
    case VHDL_var_std_logic : 
      return("Std_logic");
    case VHDL_var_std_logic_vector :
      if (range_from >= range_to)
         sprintf(myChar,"Std_logic_vector(%d downto %d)",range_from,range_to);
      else
         sprintf(myChar,"Std_logic_vector(%d upto %d)",range_from,range_to);
      return(myChar);
    default : return("");
  }
  return("");
}

int    VHDL_var::GetRangeFrom() {
  return(range_from);
}

int    VHDL_var::GetRangeTo() {
  return(range_to);
}
int    VHDL_var::GetPortType() {
  return(port_In_nOut);
}
string VHDL_var::GetPortTypeStr() {
  if (port_In_nOut==1) return("In");
  if (port_In_nOut==0) return("Out");
  return("");
}

void* VHDL_var::GetAttachment() {
  return(attach);
}

int VHDL_var::GetVHDL_VarVer() {
  return(var_ver);
}

void VHDL_var::SetVarRange(int from,int to) {
  this->range_from = from;
  this->range_to   = to;
}

int VHDL_var::GetVarBitSize() {
  if (range_from>=range_to) 
    return(range_from - range_to   + 1);
  else 
    return(range_to   - range_from + 1);
}

string VHDL_var::GetLabel() {
	return(str_label);
}

void VHDL_var::SetLabel(string str) {
	str_label = str;
}
