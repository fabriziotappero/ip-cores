#ifndef GEN_OPTIMIZATION_VHDL_H
#define GEN_OPTIMIZATION_VHDL_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;

#include "MathExpresionVHDL.h"
#include "MathVHDL_var.h"
#include "VHDL_var.h"
#include "GenMathVHDL.h"

struct XYPtr{
	int x;
	int y;
};

class GenOptimizeVHDL {

  protected:
	GenMathVHDL* mGenMath;

    vector<MathVHDL_var*> mVarList;   // Variable List
    vector<MathExpresionVHDL*> mCode; // Code

    coreGen_element_s GetElement(XYPtr ptr);
    coreGen_element_s GetElement(int MultiplyFunction, int SubExpression);
    vector<XYPtr> FindMathExpression(int cmd,MathVHDL_var* a,MathVHDL_var* b);


    void ReplaceVar(MathVHDL_var* PrevVar,MathVHDL_var* NewVar);
    vector<MathExpresionVHDL*> ReGen(vector<MathExpresionVHDL*> CodeIn);
    
    void DeliteExpression(XYPtr exPtr);
    void ChangeExpression(XYPtr exPtr,MathExpresionVHDL ex);
    coreGen_element_s* FindDuplicatedExpression(void);
    void OptimizeCommonExpression(void);
    
  public:
    GenOptimizeVHDL(GenMathVHDL* GenMath_in,vector<MathExpresionVHDL*> CodeIn,vector<MathVHDL_var*> varList);
    vector<MathExpresionVHDL*> GetNewCode();
    vector<MathVHDL_var*> GetNewVarList();
};

#endif
