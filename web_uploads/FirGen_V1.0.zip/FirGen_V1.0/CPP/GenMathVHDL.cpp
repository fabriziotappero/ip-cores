//////////////////////////////////////////////////////////////////
// Automatic Multiplier Generator Tool                      
// This module generates VHDL code for mathematical expressions
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
//
#include "GenMathVHDL.h"
#include <math.h>

GenMathVHDL::GenMathVHDL(string fname) : GenVHDL(fname) {
  tempCount = 0;
}

///////////////////////////////////////////
//           ADD Variable                //
///////////////////////////////////////////
MathVHDL_var* GenMathVHDL::AddVariable(string nameIn, int type, int from=0, int to=0,
			      int mathVarType=0,int shift=0,int sign=0,int termNum=0,
                  int pipeStage=0,string str_label="",void* attach=NULL) {
  MathVHDL_var* var;
  int i;
  string name;

  name = nameIn;

  for (i=0;i<pipeStage;i++) name+= "_d";

  var = new MathVHDL_var(name,type,from,to,mathVarType,shift,sign,termNum,(-1),str_label,attach);
  m_varList.push_back(var);
  AddBaseVariable(var);
  return(var);
}

MathVHDL_var* GenMathVHDL::AddVariable(MathVHDL_var* varIn,int pipeStage=0) {
  string name;
  int i;
  MathVHDL_var* var;

  name = varIn->GetVarName();

  for (i=0;i<pipeStage;i++) name+= "_d";

  var = new MathVHDL_var(name,varIn->GetVarType(),varIn->GetRangeFrom(),varIn->GetRangeTo(),
			 varIn->GetMathVarType(),varIn->GetShift(),varIn->GetSign(),var->GetTermNum(),
             varIn->GetPortType(),varIn->GetLabel(),varIn->GetAttachment());

  m_varList.push_back(var);
  AddBaseVariable(var);
  return(var);
}

//////////////////////////////////////////////////////////
//                  Get Variable                        //
//               from variables list                    //
//////////////////////////////////////////////////////////
MathVHDL_var* GenMathVHDL::GetVariable(string name) {
  int i;
  MathVHDL_var* var;
  
  var = NULL;

  for (i=0;i<m_varList.size();i++) {
    if (name.compare(m_varList[i]->GetVarName()) == 0) { // scan variables
      var = m_varList[i];
    }
    // if (name.compare(m_ioList[i]->GetVarName()) == 0) {  // scan IO ports
    //     var = m_ioList[i];
    // }
  }
  return(var);
}

MathVHDL_var* GenMathVHDL::GetVariable(string baseName,int pipeStage) {
  for (int i=0;i<pipeStage;i++) baseName+="_d";
  return(GetVariable(baseName));
}

vector<MathVHDL_var*> GenMathVHDL::GetVarList() {
	return(m_varList);
}

void GenMathVHDL::SetVarList(vector<MathVHDL_var*> var) {
	m_varList = var;
}

int GenMathVHDL::GetNextTemp() {
  tempCount++;
  return(tempCount-1);
}
int GenMathVHDL::GetCurTemp() {
  return(tempCount);
}

string GenMathVHDL::GetNextTempName() {
  int num;
  char myChar[200];

  num = GetNextTemp();
  sprintf(myChar,"Temp%d",num);

  return(myChar);
}

///////////////////////////////////////////////////////////////////////////////////////
//  Generate Mathematics Variable From Multipliers Script                            //
///////////////////////////////////////////////////////////////////////////////////////
MathVHDL_var* GenMathVHDL::Script2MathVar(mult_s s,MathVHDL_var* DIn,vector<MathVHDL_var*> TermList) {
  MathVHDL_var* var;
  int sign;
  int shift;
  string name;
  char myChar[200];
  int termNum;
  int type;
  int i;
  
  shift = s.shift;
  termNum = s.termNum;
  type = 0;

  switch(s.type) {
    case TERMT_PP :
    case TERMT_PM :
      var = new MathVHDL_var(TermList[termNum]);
      break;
 
    case TERMT_MM :
    case TERMT_MP :
      var = new MathVHDL_var(TermList[termNum]);
      var->MultMinus1();
      break;
 
    case SIG_P    :
      var = new MathVHDL_var(DIn);
      break;
 
    case SIG_M    :
      var = new MathVHDL_var(DIn);
      var->MultMinus1();
      break;

    default :
      cout << "\r\nError at : GenMathVHDL::Script2MathVar\r\n";
      var = NULL; // Generate System Error
      break;
  }
 
  // update Shift
  // Shift = (Original Variable Shift) + (Script Shift)
  shift += var->GetShift();
  var->SetShift(shift);
  
  //printf("Script2MathVar Sign=%d Sign=%d\r\n",var->GetSign(),sign);
  //cout << "Script2MathVar Label" << var->GetLabel() << "\r\n";
  return(var);
}


// /////////////////////////////////////////////////////////
// // Find variable by Name
// MathVHDL_var* GenMathVHDL::FindVar(string name) {
//   MathVHDL_var* var;
//
//   var = NULL;
//   for (int i=0;i<m_varList.size();i++) {
//     if (!(name.compare(m_varList[i]->GetVarName()))) {
//       var = m_varList[i];
//     }
//   }
//   return(var);
// }

////////////////////////////////////////////////////////////////////////////////////////////////
string GenMathVHDL::codeGen_ExtendBitSize(string varName,int addBits) {
    int i;
    ostringstream str_s;

    str_s.clear();
    //cout << "AddBits:" << addBits << "\r\n";
	for (i=0;i<addBits;i++) {
	   str_s << varName << "(" << varName << "'high) & ";
	}
	return(str_s.str());
}

string GenMathVHDL::codeGen_VarDownto(string varName,int downto) {
    ostringstream str_s;
	str_s << varName << "(" << varName << "'high downto " << downto << ")";
	return(str_s.str());
}

string GenMathVHDL::codeGen_VarUp(string varName,int upTo) {
    ostringstream str_s;
	str_s << varName << "(" << upTo << " downto 0)";
	return(str_s.str());
}

// Generate A +/- B VHDL code
string GenMathVHDL::codeGen_A_pm_B(MathVHDL_var* a,MathVHDL_var* b,MathVHDL_var* dest,int sign) {
    ostringstream str_s;
    int i;
    
	string aName,bName,destName;
	int aShift,bShift,destShift;
	int aSize,bSize,destSize;
	int aTotalSize,bTotalSize,destTotalSize;
	int aExtand,bExtand;
	int delta,mDelta;
	string sign_str;
    
    aName      = a->GetVarName();
    aShift     = a->GetShift();
    aSize      = a->GetVarBitSize();
    aTotalSize = aSize + aShift;
	    
    bName      = b->GetVarName();
    bShift     = b->GetShift();
    bSize      = b->GetVarBitSize();	    
    bTotalSize = bSize + bShift;

    destName      = dest->GetVarName();
    destShift     = dest->GetShift();
    destSize      = dest->GetVarBitSize();
    destTotalSize = destSize + destShift;

    aExtand = destTotalSize - aTotalSize; // calculate extansion from left
    bExtand = destTotalSize - bTotalSize;

    delta   = aShift-bShift;
    mDelta  = bShift-aShift;

    //cout << destName << " TotalSize=" << destTotalSize << " A_Extand:" << aExtand << " B_Extand:" << bExtand << " Delta:" << delta <<"\r\n";
    
    if (delta<0) delta=0;    // don't use delta if bShift>aShift
    
    // decrement common delta
    //aExtand -= delta;
    //bExtand -= delta;
    
    // xbit + xbits = xbits + 1
    //aExtand++;
    //bExtand++;

    if (sign>0) {
       cout << "GenMathVHDL::codeGen_A_pm_B + \r\n";
    	// + operation
       str_s << "  -- " << destName << " = " << aName << "<<" << aShift << '+' << bName << "<<" << bShift << "\r\n";
       str_s << "  " << destName << " <= (";
       str_s << "(" << codeGen_ExtendBitSize(aName,aExtand) << aName << ") + \r\n"; // a(a'high) & a
       str_s << "           ";
       str_s << "(" << codeGen_ExtendBitSize(bName,bExtand) << codeGen_VarDownto(bName,delta);
       if (mDelta>0) {
       	  str_s << " & \"";
       	  for (i=0;i<mDelta;i++) {
       	  	str_s << "0";
       	  }
       	  str_s << "\"";
       }
       str_s << ")";
       if (delta>0) str_s << " & " << codeGen_VarUp(bName,delta-1);
       str_s << ");\r\n";
       str_s << "\r\n";
      
    } else {
       cout << "GenMathVHDL::codeGen_A_pm_B - \r\n";
       str_s << "  -- " << destName << " = " << aName << "<<" << aShift << '-' << bName << "<<" << bShift << "\r\n";
       str_s << "  " << destName << " <= (";
       str_s << "(" << codeGen_ExtendBitSize(aName,aExtand) << aName;
       if (delta>0) {
       	  str_s << " & \"";
       	  for (i=0;i<delta;i++) {
       	  	str_s << "0";
       	  }
       	  str_s << "\"";
       }
       str_s << ") - \r\n"; // a(a'high) & a
       str_s << "           ";
       str_s << "(" << codeGen_ExtendBitSize(bName,bExtand) << bName;
       if (mDelta>0) {
       	  str_s << " & \"";
       	  for (i=0;i<mDelta;i++) {
       	  	str_s << "0";
       	  }
       	  str_s << "\"";
       }
       str_s << ")";
       str_s << ");\r\n";
       str_s << "\r\n";
    }
    
    //cout << str_s.str();
    return(str_s.str()); 
}

string GenMathVHDL::codeGen_finalizeTerm(MathVHDL_var* a,MathVHDL_var* dest) {
    int i;
    string varName;
    ostringstream str_s;

    
    varName = dest->GetVarName();
    varName = codeGen_ExtendBitSize(varName,dest->GetShift()-a->GetShift()) + varName;
    if (a->GetShift()>0) {
      varName += " & """;
      for (i=0;i<a->GetShift();i++) {
      	varName += "0";
      }
      varName += """";
    }
    varName += ";";
 
    if (a->GetSign()>0) {
       str_s << "-- Finalize: " << dest->GetVarName() << " = " << a->GetVarName() << "<<" << a->GetShift() << "\r\n";	
       str_s << dest->GetVarName() << " <= " << varName;
    } else {
       str_s << "-- Finalize: " << dest->GetVarName() << " = (-1) * " << a->GetVarName() << "<<" << a->GetShift() << "\r\n";	
       //str_s << dest->GetVarName() << " <= ";
       str_s << dest->GetVarName() << " <= (not(" << varName << ")+1);" ;
    }
    return(str_s.str());
}

coreGen_element_s* GenMathVHDL::Gen_ZERO_Output() {
   int destType;
   string destName;
   int termNum;
   MathVHDL_var* destVar;	
   coreGen_element_s *ret;
	
   destType = MatVHDL_var_TERM;
   destName = GetNextTempName();
   termNum  = GetCurTemp();
       
   destVar = new MathVHDL_var(destName,VHDL_var_std_logic_vector,0,0,
                    destType,0,1,termNum,
                    0,"",NULL);

   m_varList.push_back(destVar);
   AddBaseVariable(destVar);

   ret = new coreGen_element_s;
   
   ret->a = destVar; 
   ret->b = destVar; 
   ret->dest = destVar;

   ret->code = destVar->GetVarName() + " <= \"0\"; ";
   ret->cmd = CMD_ZERO;

   return(ret);
}

coreGen_element_s* GenMathVHDL::Gen_Lim_VHDL(MathVHDL_var* var,int NewBitSize) {
	MathVHDL_var* destVar;
	coreGen_element_s *ret;
    ostringstream str_s;

    int termNum;
    int destType;
    string destName;
    string code;

	//zzz
	

    destType = MatVHDL_var_TERM;
    destName = GetNextTempName();
    termNum  = GetCurTemp();
    
    if (var->GetVarBitSize()<NewBitSize) {
        NewBitSize = var->GetVarBitSize();
    }
        
    destVar = new MathVHDL_var(destName,VHDL_var_std_logic_vector,NewBitSize-1,0,
                          destType,var->GetShift(),var->GetSign(),termNum,
                          0,var->GetLabel(),var->GetAttachment());

    m_varList.push_back(destVar);
    AddBaseVariable(destVar);

    str_s.clear();
    str_s << "  " << destVar->GetVarName() << " <= " << var->GetVarName() << "(" << NewBitSize-1 << " downto 0); -- LIM \r\n";
    code = str_s.str();// + "--- test --- \r\n";

	ret = new coreGen_element_s;
	ret->a = NULL;
	ret->b = NULL;
	ret->dest = destVar;
	ret->cmd = CMD_LIM;
	ret->code = code;

    return(ret);
}

coreGen_element_s* GenMathVHDL::Gen_A_op_B_VHDL(int cmd,MathVHDL_var* aIn,MathVHDL_var* bIn=NULL,MathVHDL_var* DestIn=NULL) {
	string code;
	MathVHDL_var* destVar;
	MathVHDL_var* tempVar;
	coreGen_element_s *ret;
	
	int aBitSize,bBitSize;
	string aName,bName;
	int aShift,bShift;
	int aSize,bSize;
	int aTotalSize,bTotalSize;
	int aSign,bSign;
	int destTotalSize,destShift,destSize,destSign;

    int termNum;
    int destType;
    string destName;
    
    int    tempInt;
    string tempStr;

	MathVHDL_var* a;
	MathVHDL_var* b;
	
    int sign;

	ret = new coreGen_element_s;
	
	ret->cmd = cmd;
	ret->a   = aIn;
	ret->b   = bIn;
	
	// Get Variables parameters
	aName  = aIn->GetVarName();
	aSize  = aIn->GetVarBitSize();
    aShift = aIn->GetShift();
    aSign  = aIn->GetSign();

    // Set default values for B=NULL
    if (bIn!=NULL) {
	   bName  = bIn->GetVarName();
	   bSize  = bIn->GetVarBitSize();
       bShift = bIn->GetShift();
       bSign  = bIn->GetSign();
    } else {
       bName  = "";
       bSize  = 0;
       bShift = 0;
       bSign  = 1;
    }

    // Calculate Total Size (VarSize+Shift)    
    aTotalSize = aSize + aShift;
    bTotalSize = bSize + bShift;
    
    // Chose Destination Total Size
    if (aTotalSize>bTotalSize) {
    	destTotalSize = aTotalSize + 1;
    } else {
    	destTotalSize = bTotalSize + 1;
    }
    
    // Chouse destination Shift
    if (aShift < bShift) {
       destShift = aShift;
    } else {
       destShift = bShift;
    }
    
    ///////////////////////////////////////
    if (cmd==CMD_A_pm_B) {

        cout << "@@##@@##@@ CMD_A_pm_B  ##@@##@@##@@##\r\n";
    	
        /////////////////////////////////////////////////
        // Create Variable
        destSize = destTotalSize - destShift;
        
        
        /*
        switch(a->GetMathVarType()) {
      	   case MatVHDL_var_DIN  : 
      	        destType = MatVHDL_var_TEMP;
      	        break;
       	   case MatVHDL_var_TERM : 
       	   case MatVHDL_var_TEMP :
       	   default :
       	        destType = MatVHDL_var_TERM;
        }
        */
        
        if (DestIn!=NULL) {
           destVar = DestIn;
        } else {
           destType = MatVHDL_var_TERM;
           destName = GetNextTempName();
           termNum  = GetCurTemp();
        
           destVar = new MathVHDL_var(destName,VHDL_var_std_logic_vector,destSize-1,0,
                                      destType,destShift,1,termNum,
                                       0,aIn->GetLabel(),aIn->GetAttachment());
        }

        
    	/////////////////////////////////////////////////
        // Generate +/- Command
        // -A-B = -(A+B);
        // -A+B = B-A;
    	if ((aIn->GetSign()>0) && (bIn->GetSign()>0)) {
    	   cmd = CMD_pA_pB;
    	   //cout << "CMD_pA_pB\r\n";
    	} 
    	if ((aIn->GetSign()<0) && (bIn->GetSign()<0)) {
    	   cmd = CMD_pA_pB;
    	   destVar->MultMinus1();
    	   //cout << "CMD_mA_mB ---------------------- \r\n";
    	}
    	if ((aIn->GetSign()>0) && (bIn->GetSign()<0)) {
    	   cmd = CMD_pA_mB;
    	   //cout << "CMD_pA_mB\r\n";
    	}
    	if ((aIn->GetSign()<0) && (bIn->GetSign()>0)) {
    	   cmd = CMD_pA_mB;
    	   destVar->MultMinus1();
    	   //cout << "CMD_pA_mB\r\n";
    	}
        
    	////////////////////////////////////////////////
    	// Execute Code
        
        // Sort A <-> B
        if (aTotalSize > bTotalSize) {
           a = new MathVHDL_var(aIn);
           b = new MathVHDL_var(bIn);
        } else {
           // a+b = b+a	
           a = new MathVHDL_var(bIn);
           b = new MathVHDL_var(aIn);
           // a-b = (-1)*(b-a)
           if (cmd == CMD_pA_mB) destVar->MultMinus1(); 
        }
        
       /* 
        // Extract parameters
	    aName  = a->GetVarName();
        aShift = a->GetShift();
	    aSize  = a->GetVarBitSize();
        aTotalSize = aSize + aShift;
	    
	    bName  = b->GetVarName();
        bShift = b->GetShift();
	    bSize  = b->GetVarBitSize();	    
        bTotalSize = bSize + bShift;*/
        
        code = "";

        if ( (cmd == CMD_pA_mB) &&
             ( (a->GetVarName()) == (b->GetVarName()) ) &&
             ( (a->GetShift()-1) == (b->GetShift())   ) ) {

           cout << "CMD_pA_mB\r\n";
           
           if (DestIn==NULL) {
              destVar->SetVarRange(a->GetRangeFrom(),a->GetRangeTo()); // update variable range (decrement)
              m_varList.push_back(destVar);
              AddBaseVariable(destVar);
           }
          
           code = destVar->GetVarName()+" <= "+a->GetVarName()+";\r\n";
           cout << "Shift distance=1 :" << code;
           cout << "DestVarBitSize:" << destVar->GetVarBitSize() << "\r\n";
           
        } else {
           //tempVar = AddVariable(destVar,0);
           if (DestIn==NULL) {
               m_varList.push_back(destVar);
               AddBaseVariable(destVar);
           }
        	
           //destVar = AddVariable(destVar,0);

           if (cmd == CMD_pA_pB) {
              //cout << "CMD_pA_pB\r\n";
           	  code = codeGen_A_pm_B(a,b,destVar,1);
           	  //cout << code;
           } else {
              //cout << "CMD_pA_mB\r\n";
           	  code = codeGen_A_pm_B(a,b,destVar,(-1));
           	  //cout << code;
           }
         /*
           if (a->GetSign()>0) cout << "a+ ";
                          else cout << "a- ";

           if (b->GetSign()>0) cout << "b+ ";
                          else cout << "b- ";
                          
           if (destVar->GetSign()>0) cout << "dest+ ";
                                else cout << "dest- ";
                          
           */               
        }
        
    }
    if (cmd==CMD_GEN_OUT) {

        cout << "@@##@@##@@ CMD_GEN_OUT  ##@@##@@##@@##\r\n";

        /////////////////////////////////////////////////
        // Create Variable
        destSize = aTotalSize;            // Set Output Size to maximum
        if (aIn->GetSign()<0) destSize++; // increment to avoid overlap
        
        termNum  = GetCurTemp();
        destType = MatVHDL_var_TEMP;
        destName = GetNextTempName();

        destVar = AddVariable(destName,VHDL_var_std_logic_vector,destSize-1,0,
                              destType,destShift,1,termNum,
                              0,aIn->GetLabel());
                              
        code = codeGen_finalizeTerm(aIn,destVar);                      
    }
    if (cmd==CMD_EQUAL) {

        cout << "@@##@@##@@ CMD_EQUAL  ##@@##@@##@@##\r\n";

    	destVar = DestIn;
    	if (destVar==NULL) {
    		destSize = aSize;//aTotalSize - aShift;
            termNum  = GetCurTemp();
            destType = MatVHDL_var_TEMP;
            destName = GetNextTempName();
            destShift = aShift;
            destSign  = aSign;

            destVar = AddVariable(destName,VHDL_var_std_logic_vector,destSize-1,0,
                                  destType,destShift,destSign,termNum,
                                  0,aIn->GetLabel());
    	}
    	code = destVar->GetVarName() + " <= " + aIn->GetVarName() + ";";
    }
    if (cmd==CMD_BLANK) {

        cout << "@@##@@##@@ CMD_BLANK  ##@@##@@##@@##\r\n";
        
    	code = "-- Optimized:";
    	if (DestIn!=NULL) code+=DestIn->GetVarName();
    	destVar = DestIn;
    }

    if (destVar->GetSign()>0) code = code + "-- Sign + \r\n";
    if (destVar->GetSign()<0) code = code + "-- Sign - \r\n";

    ret->dest = destVar;
    ret->code = code;
    
    return(ret);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                   Finilize Output                                              //
// this function get the finnal result and executes final sign conversion and Shift operations    //
////////////////////////////////////////////////////////////////////////////////////////////////////
MathVHDL_var* GenMathVHDL::Gen_FinalOut(MathVHDL_var* varIn,string outName="",int termNumIn = (-1),int mult_num=1,int inDataWidth=1) {

  MathVHDL_var* destVar;
  string code;
  char myChar[200],ch;
  int i;

  int termNum;
  int destType;
  string destName;
  int destBitSize;
  
  int CoefBitSize,TotalBitSize;
  int temp;
  int shift;
  int UpLimit;
  
  ostringstream str_s;
  
  
  ch = '"';
  code.clear();  
  destBitSize = varIn->GetVarBitSize();
  shift = varIn->GetShift();
  destBitSize += shift;

  // Calculate target bit size
  temp = mult_num;
  CoefBitSize = 0;  
  while (temp!=0) {
  	temp = temp/2;
  	CoefBitSize++;
  }
  
  cout << "Multiplier:" << mult_num << " CoefBitSize:" << CoefBitSize << "\r\n";
  TotalBitSize = CoefBitSize + inDataWidth + 1;
  
  if (destBitSize<TotalBitSize) TotalBitSize = destBitSize; // in case of 0,1 or special
  

  //////////////////////////////////
  // SHIFT
  UpLimit = TotalBitSize - shift;

  str_s.clear();
  str_s << "(" << varIn->GetVarName() + "(" << (UpLimit-1) << " downto 0)";
  if (shift>0) {
    str_s << " & \"";
    code += ch;
    for (i=0;i<shift;i++) {
      str_s << "0";
    }
    str_s << "\"";
  }
  str_s << ")";
  code = str_s.str();

  ////////////////////////////////
  // Negate
  if ((varIn->GetSign())<0) {
    printf("negative\r\n");
    code = "( (not("+code+")) + 1)";
    //destBitSize++;
  }

  ///////////////////////////////
  // Generate Variable Name
  if (!outName.compare("")) {
    termNum  = GetCurTemp();
    destType = MatVHDL_var_TEMP;
    destName = GetNextTempName();
  } else {
    destType = MatVHDL_var_TERM;
    termNum  = termNumIn;
    //sprintf(myChar,"%s%d",outName.c_str(),termNum);
    //destName = myChar;
    destName = outName;
  }

  destVar = new MathVHDL_var(destName,destType,TotalBitSize-1,0,
			     varIn->GetMathVarType(),0,1,termNum,
			     varIn->GetPortType(),varIn->GetLabel(),varIn->GetAttachment());
  
  destVar = AddVariable(destVar,0);

  code = destName + " <= " + code + ";";

  if ((varIn->GetSign())>0) {
    sprintf(myChar,"Gen_pA_mB : %s = %s<<%d",destName.c_str(),(varIn->GetVarName()).c_str(),varIn->GetShift());
  } else {
    sprintf(myChar,"Gen_pA_mB : %s = -%s<<%d",destName.c_str(),(varIn->GetVarName()).c_str(),varIn->GetShift());
  }

  AddCodeComments(myChar);
  AddVHDLCode(code);

  return(destVar);
}

///////////////////////////////////////////////////////////////////////////////////
//                               Resample Array                                  //
///////////////////////////////////////////////////////////////////////////////////
vector<MathVHDL_var*> GenMathVHDL::ResampleArray(vector<MathVHDL_var*> varIn) {
  vector<string> code;
  vector<MathVHDL_var*> varOut;
  MathVHDL_var* tempVar;
  int i;
  char myChar[200];

  code.clear();
  varOut.clear();
  for (i=0;i<varIn.size();i++) {
    tempVar = new MathVHDL_var(varIn[i],1);
    tempVar = AddVariable(tempVar,0);
    varOut.push_back(tempVar);
    sprintf(myChar,"%s <= %s;",(varOut[i]->GetVarName()).c_str(),(varIn[i]->GetVarName()).c_str() );
    code.push_back(myChar);
  }

  AddVHDLCodeClk(code);
  return(varOut);
}

/////////////////////////////////////////////////////////////////
//                     Copy to new Array                       //
/////////////////////////////////////////////////////////////////
// this function creates new array by specidied name           //
// and copies existing array to new one                        //
// return new array                                            //
/////////////////////////////////////////////////////////////////
vector<MathVHDL_var*> GenMathVHDL::CopyToNewArray(vector<MathVHDL_var*> varIn,string newName,int pipeStage=0) {
  vector<string> code;
  vector<MathVHDL_var*> varOut;
  MathVHDL_var* tempVar;
  int i,j;
  char myChar[200];
  string varName;

  code.clear();
  varOut.clear();
  for (i=0;i<varIn.size();i++) {
    
    sprintf(myChar,"%s%d",newName.c_str(),i); 
    varName = myChar;

    for (j=0;j<pipeStage;j++) varName += "_d";
    
    tempVar = new MathVHDL_var(varName,varIn[i]->GetVarType(),varIn[i]->GetRangeFrom(),varIn[i]->GetRangeTo(),
			       varIn[i]->GetMathVarType(),varIn[i]->GetShift(),varIn[i]->GetSign(),varIn[i]->GetTermNum(),
			       varIn[i]->GetPortType(),varIn[i]->GetLabel(),varIn[i]->GetAttachment());
 
    tempVar = AddVariable(tempVar,0);
    varOut.push_back(tempVar);
    sprintf(myChar,"%s <= %s;",(varOut[i]->GetVarName()).c_str(),(varIn[i]->GetVarName()).c_str() );
    code.push_back(myChar);
  }

  AddVHDLCode(code);
  return(varOut);
}

/////////////////////////////////////////////////////////////////
//                  Generate Variable List                     //
/////////////////////////////////////////////////////////////////
vector<string> GenMathVHDL::VHDL_GenVar(vector<MathVHDL_var*> varList) {
  vector<string> str;
  string s;
  int i;

  str.clear();
  printf("GenMathVar varSize=%d\r\n",varList.size());

  for (i=0;i<varList.size();i++) {
    //printf(".");
    s =  "  Signal ";
    s += varList[i]->GetVarName();
    s += " : ";
    s += varList[i]->GetVarTypeStr();
    s += ";";
    str.push_back(s);
  }
 
  return(str);
}

/*GenMathVHDL::~GenMathVHDL() {
  vector<string> str;

  str = VHDL_GenVar(m_varList);
  AddVHDLCode(str);
  }*/
  