#include "VarContainer.h"

//////////////////////////////////////////////////////////////////////////////////////
// Constructor
// Get 
//   1) Array of Variables assotiated with term
//   2) DIn Variable assotiated with Din
VarContainer::VarContainer(vector<MathVHDL_var*> termArray, MathVHDL_var* Din) {
	mTermArray = termArray;
	mDin = Din;
}

///////////////////////////////////////////////////////////////////////////////////////
// Get Term by number
MathVHDL_var* VarContainer::GetTerm(int num) {
	return(mTermArray[num]);
}

MathVHDL_var* VarContainer::GetDin() {
	return(mDin);
}

MathVHDL_var* VarContainer::GetByType(int Type,int TermNum) {
  switch(Type) {	
	case TERMT_PP :
    case TERMT_MM :
    case TERMT_PM :
    case TERMT_MP : return(GetTerm(TermNum));
    				break;
    case SIG_P    :
    case SIG_M    : return(GetDin());
                    break;
    default       : return(NULL);
                    break;
  }
}

