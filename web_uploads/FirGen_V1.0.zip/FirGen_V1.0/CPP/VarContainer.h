#ifndef VarContainer_H
#define VarContainer_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;

#include "GenMultScript.h"
#include "GenMathVHDL.h"
#include "GenVHDL.h"
#include "MathVHDL_var.h"
#include "VHDL_var.h"


class VarContainer {
 public:	
   VarContainer(vector<MathVHDL_var*> termArray, MathVHDL_var* Din);
   MathVHDL_var* GetTerm(int num);
   MathVHDL_var* GetDin();
   MathVHDL_var* GetByType(int Type,int TermNum);
   
 protected:
   vector<MathVHDL_var*> mTermArray;
   MathVHDL_var* mDin;
};

#endif
