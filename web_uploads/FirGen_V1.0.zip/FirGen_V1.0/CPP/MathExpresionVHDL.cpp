///////////////////////////////////////////////////////////////////////////
// Mathematic Expression Container                                       //
// This class contains expression for single mathematic operation        //
// use:                                                                  //
//     GetCode function to get VHDL code                                 //
//     GetDest fucntion to get destination variable                      //
//     (note: destination variable is the last entry destination ptr)    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
// Writer : Boris Kipnis
// Last Update : 9/6/2005
//

#include "MathExpresionVHDL.h"

// Constructor
MathExpresionVHDL::MathExpresionVHDL() {
  ar.clear();
}

MathExpresionVHDL::~MathExpresionVHDL() {
  ar.clear();
}

void MathExpresionVHDL::Add(coreGen_element_s ex) {
  ar.push_back(ex);
}

void MathExpresionVHDL::Add(vector<coreGen_element_s> ex) {
	int i;
	
	for (i=0;i<ex.size();i++) {
		Add(ex[i]);
	}
}


void MathExpresionVHDL::Add(MathExpresionVHDL ex) {
	vector<coreGen_element_s> ex_v;
	
	ex_v = ex.GetArray();
	Add(ex_v);
}

string MathExpresionVHDL::GetCode() {
  int i;
  string code;
  
  code = "";
  for (i=0;i<ar.size();i++) {
  	code = code + ar[i].code;
  }
  return(code);
}

coreGen_element_s MathExpresionVHDL::GetElement(int num) {
  return(ar[num]);
}

int MathExpresionVHDL::GetSize() {
  return(ar.size());
}

// Return Destination
// (Last variable expression is destination)
// t1 = a+b; t2=c+d; t3=t1+t2
MathVHDL_var* MathExpresionVHDL::GetDest() {
  return((GetElement(GetSize()-1)).dest);
}

vector<coreGen_element_s> MathExpresionVHDL::GetArray() {
  return(ar);
}


