#ifndef GenMultScript_H
#define GenMultScript_H


#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>


using namespace std;

/////////////////////////////////
// Structures and Defenitions  //
/////////////////////////////////

// defenitions
#define DIST_PP_MM  0
#define DIST_PM_MP  1

// 2 integer structure a,b
struct inta_intb_s {
  int a;
  int b;
};

// X,Y position structure
struct pos_s {
  int x;
  int y;
};

// Maximum value structure MaxValue,(X,Y)position
struct max_s {
  pos_s pos;
  int max;
};


#define TERMT_PP 0
#define TERMT_MM 1
#define TERMT_PM 2
#define TERMT_MP 3
#define SIG_P    4
#define SIG_M    5
#define TEMP_P   6
#define TEMP_M   7
#define PMULT_P  8
#define PMULT_M  9
#define ZERO    10
//#define REF_P   10
//#define REF_N   11
//#define ZERO    12

struct mult_s {
  int type;
  int shift;
  int termNum;
};
class GenMultScript {
 private:
  void printArray(vector<int> ar);
  void printDualArray(vector<inta_intb_s> ar);
  void printPosArray(vector<pos_s> ar);
  string int2binStr(int num, const int size);
  vector<int> int23x(int num,int size);
  int convert_3x_2int(vector<int> num);
  int calcSingleDistance(vector<int> ar3x,int dist,int type);
  vector<int> calcDistance(vector<int> ar3x,int type);
  vector<inta_intb_s> calcDistance(vector<int> ar3x);
  vector<vector<inta_intb_s> > calcDistanceArray(vector<vector<int> > ar3x);
  vector<int> deleteDistanceSingle(vector<int> ar_i,int dist,int type);
  vector<vector<int> > deleteDistance(vector<vector<int> > ar_i,int dist,int type);
  vector<inta_intb_s> calcGlobalDistance(vector<vector<inta_intb_s> > l_dist);
  max_s findMax(vector<inta_intb_s> ar);
  vector<pos_s> getCommonTerms(vector<vector<int> > ar3x);
  vector<vector<int> > getOthers(vector<vector<int> > ar3x,vector<pos_s> Term);
  vector<mult_s> lookForTerms(vector<int> ar3x,int dist,int type);
  vector<mult_s> singleMultScript(vector<int>ar3x, vector<pos_s> termArray);
  vector<vector<mult_s> > MultScript(vector<vector<int> > ar3x, vector<pos_s> termArray);
  int SingleTerm2Num(pos_s t);
  vector<int> Term2Num(vector<pos_s> t);
  int SingleMultScript2Num(vector<mult_s> script,vector <pos_s> termArray);
  vector<int> MultScript2Num(vector<vector<mult_s> > script,vector <pos_s> termArray);
  vector<vector<mult_s> > Term2Script(vector<pos_s> term);

  vector<vector<mult_s> > m_script;
  vector<vector<mult_s> > m_term;

 public:
  GenMultScript(vector<int> ar);
  vector<vector<mult_s> > GetTerm();
  vector<vector<mult_s> > GetScript();

};
void printMultScript(vector<mult_s> ar);

#endif
