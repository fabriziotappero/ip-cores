///////////////////////////////////////////////////////////////////////
//                     Generate VHDL Source Code                     //
///////////////////////////////////////////////////////////////////////
// This Module Generates VHDL Syntax                                 //
// and VHDL Source code from abstract input code                     //
///////////////////////////////////////////////////////////////////////
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
//
#include "GenVHDL.h"
#include <sys/time.h>

///////////////////////////////////////////////////////////////////////
//                    Generate VHDL HEADER                           //
///////////////////////////////////////////////////////////////////////
vector<string> GenVHDL::VHDL_GenHeader(vector<string> commentsIn) {
  vector<string> str,comments;
  char MyTimeStr[200];

  time_t tt;
  struct tm ut;  
  tt = time(NULL);
  localtime_r(&tt, &ut);
  sprintf(MyTimeStr,"-- Date %d/%d/%d\r\n-- Time %d:%d:%d",
          ut.tm_mday,(ut.tm_mon+1),(1900+ut.tm_year),ut.tm_hour,ut.tm_min,ut.tm_sec);


  str.clear();
  str.push_back("--------------------------------------------------");
  str.push_back("-- Atomatic VHDL Code Generator (v1.0)          --");
  str.push_back("--                                              --");
  str.push_back("-- Writed By: Boris Kipnis                      --");
  str.push_back("--------------------------------------------------");
  str.push_back("-- File Name : "+m_fname+".vhd");
  str.push_back("--------------------------------------------------");
  str.push_back("-- Created at: ");
  str.push_back(MyTimeStr);
  str.push_back("--------------------------------------------------");
  str.push_back("-- Comments:");
  str.push_back("--");
  comments = AddStr2Vector("-- ",commentsIn);
  str      = AddStrVector2Vector(str,comments);
  str.push_back("");
  str.push_back("LIBRARY IEEE;");
  str.push_back("USE IEEE.STD_LOGIC_1164.ALL;");
  str.push_back("USE IEEE.STD_LOGIC_ARITH.ALL;");
  str.push_back("USE IEEE.STD_LOGIC_UNSIGNED.ALL;");
  str.push_back("");

  return(str);
}


////////////////////////////////////////////////////////////////
//                  Generate Ports                            //
////////////////////////////////////////////////////////////////
vector<string>  GenVHDL::VHDL_GenPort(vector<VHDL_var*> ioList) {
  int i;
  vector<string> str;
  string s;
  VHDL_var* port;
 
  str.clear();
 
  str.push_back("port(");
  
  for (i=0; i<ioList.size(); i++) {

    port = ioList[i];
    s = "  ";
    s += port->GetVarName();
    s += " : ";
    s += port->GetPortTypeStr();
    s += " ";
    s += port->GetVarTypeStr();
    if (i<(ioList.size()-1)) s += ";";

    str.push_back(s);
  }

  str.push_back(");");
  return(str);
}

/////////////////////////////////////////////////////////////////
// Generate Complite Entity (Entity Name,ports,end entity)     //
/////////////////////////////////////////////////////////////////
vector<string>  GenVHDL::VHDL_GenEntty(vector<VHDL_var*> ioList) {
  vector<string> str;

  str.clear();

  str.push_back("entity "+m_fname+" is");
  str = AddStrVector2Vector(str,VHDL_GenPort(ioList));
  str.push_back("end "+m_fname+";");
  str.push_back("");
 
  return(str);
}

/////////////////////////////////////////////////////////////////
//                  Generate Variable List                     //
/////////////////////////////////////////////////////////////////
vector<string>  GenVHDL::VHDL_GenVar(vector<VHDL_var*> varList) {
  vector<string> str;
  string s;
  int i;

  str.clear();
  printf("GenVar varSize=%d\r\n",varList.size());

  for (i=0;i<varList.size();i++) {
    //printf(".");
    s =  "  Signal ";
    s += varList[i]->GetVarName();
    s += " : ";
    s += varList[i]->GetVarTypeStr();
    s += ";";
    str.push_back(s);
  }
 
  return(str);
}

/////////////////////////////////////////////////////////////////
//                   Generate Architecture                     //
/////////////////////////////////////////////////////////////////
vector<string>  GenVHDL::VHDL_GenArchitecture(vector<VHDL_var*> varList) {
  vector<string> str;

  str.clear();
  str.push_back("architecture Behavioral of " + m_fname + " is");
  str = AddStrVector2Vector(str,VHDL_GenVar(varList));
  str.push_back("");

  return(str);
}

/////////////////////////////////////////////////////////////////
//                     Generate VHDL Body                      //
/////////////////////////////////////////////////////////////////
vector<string>  GenVHDL::VHDL_GenBody(vector<string> userCode) {
  vector<string> str;
  int i;

  str.clear();
  str.push_back("begin");
  for (i=0;i<userCode.size();i++) {
    str.push_back("  "+userCode[i]);
  }
  str.push_back("end Behavioral;");

  return(str);
}
////////////////////////////////////////////////////////////////
// Generate VHDL Code
vector<string> GenVHDL::VHDL_Gen(vector<string> comments, vector<VHDL_var*> ioList,
                                 vector<VHDL_var*> varList,vector<string> userCode) {
  vector<string> code;
  int i;

  code.clear();
  code = AddStrVector2Vector(code, VHDL_GenHeader(comments));
  code = AddStrVector2Vector(code, VHDL_GenEntty(ioList));
  code = AddStrVector2Vector(code, VHDL_GenArchitecture(varList));
  code = AddStrVector2Vector(code, m_components);
  code = AddStrVector2Vector(code, VHDL_GenBody(userCode));

  return(code);
}

///////////////////////////////////////////
//            Constructor                //
///////////////////////////////////////////
GenVHDL::GenVHDL(string fname) {
  m_varList.clear();
  m_ioList.clear();
  m_code.clear();
  m_comments.clear();
  m_components.clear();
  m_fname = fname;
}

///////////////////////////////////////////
//            Destructor                 //
///////////////////////////////////////////
GenVHDL::~GenVHDL() {
  vector<string> code;
  FILE * fout;
  int i;
  string fileName;

  fileName = m_fname + ".vhd";
  code = VHDL_Gen(m_comments,m_ioList,m_varList,m_code);
  fout = fopen(fileName.c_str(),"wt");
  for (i=0;i<code.size();i++) {
    fprintf(fout,"%s\r\n",code[i].c_str());
  }
  fclose(fout);
  m_varList.clear();
  m_code.clear();
}

///////////////////////////////////////////
//           ADD Variable                //
///////////////////////////////////////////
VHDL_var* GenVHDL::AddVariable(string nameIn, int type, int from=0, int to=0,int pipeStage=0,string str_label="",void* attach=NULL) {
  VHDL_var* var;
  int i;
  string name;

  name = nameIn;

  for (i=0;i<pipeStage;i++) name+= "_d";

  var = new VHDL_var(name,type,from,to,(-1),str_label,attach);
  m_varList.push_back(var);

  return(var);
}

VHDL_var* GenVHDL::AddVariable(VHDL_var* varIn,int pipeStage=0) {
  string name;
  int i;
  VHDL_var* var;

  name = varIn->GetVarName();

  for (i=0;i<pipeStage;i++) name+= "_d";

  var = new VHDL_var(name,varIn->GetVarType(),varIn->GetRangeFrom(),varIn->GetRangeTo(),
                     varIn->GetPortType(),varIn->GetLabel(),varIn->GetAttachment());

  m_varList.push_back(var);

  return(var);
}

VHDL_var* GenVHDL::AddBaseVariable(VHDL_var* var) {
  return(AddVariable(var,0));
}


//////////////////////////////////////////////////////////
//                  Get Variable                        //
//               from variables list                    //
//////////////////////////////////////////////////////////
VHDL_var* GenVHDL::GetVariable(string name) {
  int i;
  VHDL_var* var;
  
  var = NULL;

  for (i=0;i<m_varList.size();i++) {
    if (name.compare(m_varList[i]->GetVarName()) == 0) { // scan variables
      var = m_varList[i];
    }
    if (name.compare(m_ioList[i]->GetVarName()) == 0) {  // scan IO ports
      var = m_ioList[i];
    }
  }
  return(var);
}

VHDL_var* GenVHDL::GetVariable(string baseName,int pipeStage) {
  int i;
  string name;

  name = baseName;
  for (i=0;i<pipeStage;i++) name+="_d";

  return(GetVariable(name));
}

///////////////////////////////////////////
//           ADD I/O Port                //
///////////////////////////////////////////
VHDL_var* GenVHDL::AddPort(string name, int type, int In_nOut, int from=NULL, int to=NULL,void* attach=NULL) {
  VHDL_var* var;

  var = new VHDL_var(name,type,from,to,In_nOut,"",attach);

  m_ioList.push_back(var);
  return(var);
}

///////////////////////////////////////////
//         ADD Comments                  //
///////////////////////////////////////////
void GenVHDL::AddComments(string str) {
  m_comments.push_back(str);
}

void GenVHDL::AddComments(vector<string> str) {
  m_comments = AddStrVector2Vector(m_comments,str);
}

void GenVHDL::AddCodeComments(string str) {
 AddVHDLCode("-- "+str);
}

void GenVHDL::AddCodeComments(vector<string> strIn) {
  vector<string> strOut;
  strOut.clear();
  strOut = AddStr2Vector("-- ",strIn);
  AddVHDLCode(strOut);
}

/////////////////////////////////////////////////
// add Code Tititle
// -----------
// -- Title --
// -----------
void GenVHDL::AddCodeTitle(string strIn) {
 string str;
 int borderSize = 80;
 int complementSize;
 int i;
 
 complementSize = (borderSize - strIn.size() - 4)/2;

 str = "";
 for (i=0;i<borderSize;i++) str += "-";
 AddVHDLCode(str);

 str = "--";
 for (i=0;i<complementSize;i++) str+=" ";
 str += strIn;
 while (str.size()<(borderSize-2)) str+=" ";
 str += "--";
 AddVHDLCode(str);

 str = "";
 for (i=0;i<borderSize;i++) str += "-";
 AddVHDLCode(str);
}


///////////////////////////////////////////
//          ADD VHDL Code Line           //
///////////////////////////////////////////
void GenVHDL::AddVHDLCode(string code) {
  m_code.push_back(code); 
}

void GenVHDL::AddVHDLCode(vector<string> code) {
  m_code = AddStrVector2Vector(m_code,code);
}

void GenVHDL::AddVHDLCodeClk(string code) {
  AddVHDLCode("process (Clk) begin");
  AddVHDLCode("  if (Clk'event and Clk='1') then");
  AddVHDLCode("    "+code);
  AddVHDLCode("  end if;");
  AddVHDLCode("end process;");
}

void GenVHDL::AddVHDLCodeClk(vector<string> code) {
  AddVHDLCode("process (Clk) begin");
  AddVHDLCode("  if (Clk'event and Clk='1') then");
  AddVHDLCode(AddStr2Vector("    ",code));
  AddVHDLCode("  end if;");
  AddVHDLCode("end process;");
}

///////////////////////////////////////////////////////////////////////////////////
//                    Others internal service functions                          //
///////////////////////////////////////////////////////////////////////////////////
vector<string> GenVHDL::AddStrVector2Vector(vector<string> a,vector<string> b) {
  vector<string> str;
  int i;

  str = a;
  for (i=0;i<b.size();i++) {
    str.push_back(b[i]);
  }
  return(str);
}

vector<string> GenVHDL::AddStr2Vector(string a,vector<string> b) {
  vector<string> str;
  int i;

  str.clear();
  for (i=0;i<b.size();i++) {
    str.push_back(a + b[i]);
  }
  return(str);
}

///////////////////////////////////////////////////////////////////////////////////
//                   Export Component from IO ports                              //
///////////////////////////////////////////////////////////////////////////////////
vector<string> GenVHDL::GetComponent() {
  vector<string> code,portCode;

  code.clear();
  code.push_back("component "+m_fname+" is");
  portCode = VHDL_GenPort(m_ioList);
  code = AddStrVector2Vector(code,portCode);
  code.push_back("end component;");
  return(code);
}

///////////////////////////////////////////////////////////////////////////////////
//                   Import Component                                            //
///////////////////////////////////////////////////////////////////////////////////
void GenVHDL::AddComponent(string str) {
	m_components.push_back(str);
}


///////////////////////////////////////////////////////////////////////////////////
//                               Resample Array                                  //
///////////////////////////////////////////////////////////////////////////////////
vector<VHDL_var*> GenVHDL::ResampleArray(vector<VHDL_var*> varIn) {
  vector<string> code;
  vector<VHDL_var*> varOut;
  VHDL_var* tempVar;
  int i;
  char myChar[200];

  code.clear();
  varOut.clear();
  for (i=0;i<varIn.size();i++) {
    tempVar = new VHDL_var(varIn[i],1);
    AddVariable(tempVar,0);
    varOut.push_back(tempVar);
    sprintf(myChar,"%s <= %s;",(varIn[i]->GetVarName()).c_str(),(varOut[i]->GetVarName()).c_str() );
  }

  AddVHDLCodeClk(code);
  return(varOut);
}

string GenVHDL::GetFileName() {
  return(m_fname);
}
