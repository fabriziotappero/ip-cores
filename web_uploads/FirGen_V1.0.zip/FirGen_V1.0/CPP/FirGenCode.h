#ifndef FIR_GRN_CODE_H
#define FIR_GRN_CODE_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>
#include <sstream>

#include "GenMathVHDL.h"
#include "MultGen.h"

class FirGenCode {
   protected:	
      GenMathVHDL* mCode;
      MultGen* mMultGen;
   public:	
      int calcNumOfBits(int numIn);
      FirGenCode(string fname,int inDataWidth,vector<int> multVector); // Constructor
      ~FirGenCode(); // destructor
};
#endif

