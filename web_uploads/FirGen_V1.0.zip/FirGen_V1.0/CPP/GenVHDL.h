////////////////////////////////////////////////////
//        Generate VHDL Source Code               //
//        H file                                  //
////////////////////////////////////////////////////
#ifndef GenVHDL_H
#define GenVHDL_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

#include "VHDL_var.h"

using namespace std;

class GenVHDL {

 protected:
  vector<VHDL_var*> m_varList;
  vector<string>    m_varListStr;
  vector<VHDL_var*> m_ioList;
  vector<string> m_code;
  vector<string> m_comments;
  vector<string> m_components;
  string m_fname;

  vector<string> VHDL_GenHeader(vector<string> comments);
  vector<string> VHDL_GenPort(vector<VHDL_var*> ioList);
  vector<string> VHDL_GenEntty(vector<VHDL_var*> ioList);
  vector<string> VHDL_GenVar(vector<VHDL_var*> varList);
  vector<string> VHDL_GenArchitecture(vector<VHDL_var*> varList);
  vector<string> VHDL_GenBody(vector<string> userCode);
  vector<string> VHDL_Gen(vector<string> comments,vector<VHDL_var*> ioList,
                          vector<VHDL_var*> varList,vector<string> userCode);
  vector<string> AddStrVector2Vector(vector<string> a,vector<string> b);
  vector<string> AddStr2Vector(string a,vector<string> b);

 public:
  GenVHDL(string fname);
  ~GenVHDL();
  VHDL_var* AddVariable(string nameIn, int type, int from, int to,int pipeStage,string str_label,void* attach);
  VHDL_var* AddVariable(VHDL_var* var,int pipeStage);
  VHDL_var* AddBaseVariable(VHDL_var* var);
  VHDL_var* GetVariable(string name);
  VHDL_var* GetVariable(string baseName,int pipeStage);
  VHDL_var* AddPort(string name, int type, int In_nOut, int from, int to,void* attach);
  void AddComments(string str);
  void AddComments(vector<string> str);
  void AddVHDLCode(string code);
  void AddVHDLCode(vector<string> code);
  void AddVHDLCodeClk(string code);
  void AddVHDLCodeClk(vector<string> code);
  void AddCodeComments(string str);
  void AddCodeComments(vector<string> strIn);
  void AddCodeTitle(string strIn);
  vector<string> GetComponent();
  void AddComponent(string str);
  vector<VHDL_var*> ResampleArray(vector<VHDL_var*> varIn);
  string GetFileName();
  
};

#endif
