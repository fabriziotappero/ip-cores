###################################################
# 
#   BlazeCluster  opb.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   OPB bus object
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package OPB;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};

    bless($self, $class);

    $self->{device_addr_start} = 0x40000000;
    $self->{device_addr_current} = 0x40000000;

    $self->{extsdram_addr_start} = 0x30000000;
#    $self->{extsdram} = 0;

    return $self;
}

sub get_instance() {
    my $self = shift;

    return $self->{instance};

}

sub get_device_address_start() {
    my $self = shift;

    return $self->{device_addr_start};

}

sub get_device_address() {
    my $self = shift;
    my $size = shift;
    my $addr = $self->{device_addr_current};

    if (defined($size)) {
    	$self->{device_addr_current} += $size;
    	}
    return $addr;

}

sub opb_get_extsdram_address() {
    my $self = shift;

    return $self->{extsdram_addr_start};

}

sub generate() {
    my $self = shift;
    my $system = shift;
    *MHS = shift;
    *MSS = shift;

	my $opb_instance = $self->get_instance();


    print MHS "BEGIN opb_v20\n";
    print MHS " PARAMETER INSTANCE = $opb_instance\n";
    print MHS " PARAMETER HW_VER = 1.10.c\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT OPB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = opbarb\n";
    print MSS " PARAMETER DRIVER_VER = 1.02.a\n";
    print MSS " PARAMETER HW_INSTANCE = $opb_instance\n";
    print MSS "END\n\n";

}

1;
