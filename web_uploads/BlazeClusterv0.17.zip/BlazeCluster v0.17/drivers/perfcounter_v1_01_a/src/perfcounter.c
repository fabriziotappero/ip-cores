/****************************************************
* 
*   BlazeCluster  perfcounter.c  $version
*   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
*
*   Generate multiprocessor architecture on FPGA
* 
*   Performance counter library
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*   You can also get a copy of the license through the web at
*   <http://www.gnu.org/licenses/gpl.html>
*
****************************************************/

#ifndef _PERFCOUNTER_C
#define _PERfCOUNTER_C

#include "perfcounter.h"

/* static int fsl_perfcounter; */

#define FSL_PERFCOUNTER_SLOT_ID 0

int perfcounter_init(int fsl) {

/*	fsl_perfcounter=fsl; */
	return 0;

}

void reset_and_stop_counter() {

	write_into_fsl(0x00000040, FSL_PERFCOUNTER_SLOT_ID);
	return;

}

void reset_and_start_counter() {

	write_into_fsl(0x000000c0, FSL_PERFCOUNTER_SLOT_ID);
	return;
	
}

void start_counter() {

	write_into_fsl(0x00000080, FSL_PERFCOUNTER_SLOT_ID);
	return;


}

void stop_counter() {

	write_into_fsl(0x00000000, FSL_PERFCOUNTER_SLOT_ID);
}

unsigned int read_counter() {
	unsigned cnt;

	read_from_fsl(cnt, FSL_PERFCOUNTER_SLOT_ID);
	read_from_fsl(cnt, FSL_PERFCOUNTER_SLOT_ID);

	return cnt;
}

#endif

