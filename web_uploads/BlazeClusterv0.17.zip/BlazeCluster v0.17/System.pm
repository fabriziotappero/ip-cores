###################################################
# 
#   BlazeCluster  system.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   FPGA chip and board object. 
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package System;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};
    my @copydev;

    bless($self, $class);

    $self->{slicecnt} = 0;
    $self->{bramcnt} = 0;
    $self->{mulcnt} = 0;

    $self->{slice_on_device} = 13696;
    $self->{bram_on_device} = 136;
    $self->{mul_on_device} = 136;

    $self->{lcopydev} = \@copydev;
	
    return $self;
}

sub area_estimate {
	my $self = shift;
	my $comp = shift;
	my $slice = shift;
	my $ff = shift;
	my $lut = shift;
	my $bram = shift;
	my $mul = shift;

	$self->{slicecnt} += $slice;
	$self->{bramcnt} += $bram;
	$self->{mulcnt} += $mul;

	return $comp;	

}

sub get_opb {
	my $self = shift;

	if (defined($self->{opb})) {
		return $self->{opb};
	}

	my $opb = OPB->new(
		instance => "opb_".$self->{instance},
		);
		
	$self->{opb} = $opb;
	return $self->{opb};
	
}

sub get_dcr {
	my $self = shift;

	if (defined($self->{dcr})) {
		return $self->{dcr};
	}

	my $dcr = DCR->new(
		instance => "dcr_".$self->{instance},
		);
		
	$self->{dcr} = $dcr;
	return $self->{dcr};
	
}

sub set_external_uart {
	my $self = shift;
	my $instance = shift;

# only one external UART allowed	
	if (defined($self->{extuart})) {
		die "competition of external UART between $self->{extuart} and $instance. one UART one system";
		}

	$self->{extuart} = $instance;
	return $instance;

}

sub set_external_cf_card {
	my $self = shift;
	my $instance = shift;

# only one external UART allowed	
	if (defined($self->{extcfcard})) {
		die "competition of external CF-CARD between $self->{extcfcard} and $instance. one CF CARD one system";
		}

	$self->{extcfcard} = $instance;
	return $instance;

}

sub set_external_vga_controller {
	my $self = shift;
	my $instance = shift;

# only one external UART allowed	
	if (defined($self->{ext_vga_controller})) {
		die "competition of external VGA between $self->{ext_vga_controller} and $instance. one VGA one system";
		}

	$self->{ext_vga_controller} = $instance;
	return $instance;

}

sub set_external_sdram {
	my $self = shift;
	my $instance = shift;

# only one external SDRAM allowed	
	if (defined($self->{ext_sdram})) {
		die "competition of external SDRAM between $self->{ext_sdram}->{instance} and $instance->{instance}. one VGA one system";
		}

	$self->{ext_sdram} = $instance;
	return $instance;

}

sub copydevice {
	my $self = shift;
	my $device = shift;
	my $devlist = "@{$self->{lcopydev}}";
	my $target = $self->{target};

 # print "$device --  $devlist\n";	

#  check if it's already copied first

	if (!($devlist =~ $device)) {
		push (@{$self->{lcopydev}}, $device);
		system("cp -r pcores/$device $target/pcores/$device\n");
	       system("cp -r drivers/$device $target/drivers/$device\n");
        }

}

# different parameters

sub prepare {
	my $self = shift;
	my $system = shift;
	*LOG = shift;

	my $target = $self->{target};
	
	system("rm -rf $target\n");
	system("mkdir $target\n");
	system("cp $target.js $target\n");
	system("mkdir $target/data\n");
	if (-e "source") {
		system("cp -r source $target/source\n");
	} else {
		system("mkdir $target/source\n");
	}
	system("mkdir $target/pcores\n");
	system("mkdir $target/drivers\n");

	system("mkdir $target/etc\n");
	system("cp etc/download.cmd $target/etc/download.cmd");

}

# different parameters

sub generate_xmp {
	my $self = shift;
	my $system = shift;
	*XMP = shift;
	*LOG = shift;
	
	print XMP "# #######################################################################\n";
	print XMP "#  Created by BlazeCluster v0.11 for Xilinx EDK 7.1\n";
	print XMP "#  Target Board: Xilinx XUP Virtex-II Pro Development System Rev C\n";
	print XMP "#  Family: virtex 2p\n";
	print XMP "#  Device: xc2vp30\n";
	print XMP "#  Package: ff896\n";
	print XMP "#  Speed Grade: -7\n";
	print XMP "#  Processor: PPC405 x 2\n";
	print XMP "#  Bus clock frequency: 100Mhz\n";
	if (defined($self->{ext_sdram})) {	
		printf XMP "#  Total on-board SDRAM: 0x%x bytes\n", $self->{ext_sdram}->{size};
		}
	if (defined($self->{ext_vga_controller})) {
		print XMP "#  On-board VGA controller\n";
	}
	print XMP "#  Documents: http://www.opencores.org/projects.cgi/web/mpdma/overview\n";
	print XMP "# #######################################################################\n\n";
	
	print XMP "XmpVersion: 7.1\n";
	print XMP "IntStyle: default\n";
	print XMP "MHS File: system.mhs\n";
	print XMP "MSS File: system.mss\n";
	print XMP "NPL File: projnav/system.ise\n";
	print XMP "Architecture: virtex2p\n";
	print XMP "Device: xc2vp30\n";
	print XMP "Package: ff896\n";
	print XMP "SpeedGrade: -7\n";
	print XMP "UseProjNav: 0\n";
	print XMP "AddToNPL: 0\n";
	print XMP "PNImportBitFile: projnav/system.bit\n"; 
	print XMP "PNImportBmmFile: implementation/system_bd.bmm\n"; 
	print XMP "UserCmd1: \n";
	print XMP "UserCmd1Type: 0\n";
	print XMP "UserCmd2:\n";
	print XMP "UserCmd2Type: 0\n";
	print XMP "SynProj: xst\n";
	print XMP "ReloadPbde: 0\n";
	print XMP "MainMhsEditor: 0\n";
	print XMP "InsertNoPads: 0\n";
	print XMP "HdlLang: VHDL\n";
	print XMP "Simulator: mti\n";
	print XMP "SimModel: BEHAVIORAL\n";
	print XMP "SimXLib:\n"; 
	print XMP "SimEdkLib:\n"; 
	print XMP "MixLangSim: 1\n";
	print XMP "UcfFile: data/system.ucf\n";

	foreach my $proc (@{$self->{lproc}}) {
		print XMP "Processor: $proc->{instance}\n";
		print XMP "BootLoop: 0\n";
		print XMP "XmdStub: 0\n";
	}


	print LOG "- XMP file generated\n";

}

sub generate_header {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;
	*LOG = shift;

	print MHS "# #######################################################################\n";
	print MHS "#  Created by BlazeCluster v0.11 for Xilinx EDK 7.1\n";
	print MHS "#  Target Board: Xilinx XUP Virtex-II Pro Development System Rev C\n";
	print MHS "#  Family: virtex 2p\n";
	print MHS "#  Device: xc2vp30\n";
	print MHS "#  Package: ff896\n";
	print MHS "#  Speed Grade: -7\n";
	print MHS "#  Processor: PPC405 x 2\n";
	print MHS "#  Bus clock frequency: 100Mhz\n";
	if (defined($self->{ext_sdram})) {	
		printf MHS "#  Total on-board SDRAM: 0x%x bytes\n", $self->{ext_sdram}->{size};
		}
	if (defined($self->{ext_vga_controller})) {
		print MHS "#  On-board VGA controller\n";
	}
	print MHS "#  Documents: http://www.opencores.org/projects.cgi/web/mpdma/overview\n";
	print MHS "# #######################################################################\n\n";

	print MHS " PARAMETER VERSION = 2.1.0\n\n";

	print MSS "# #######################################################################\n";
	print MSS "#  Created by BlazeCluster v0.11 for Xilinx EDK 7.1\n";
	print MSS "#  Target Board: Xilinx XUP Virtex-II Pro Development System Rev C\n";
	print MSS "#  Family: virtex 2p\n";
	print MSS "#  Device: xc2vp30\n";
	print MSS "#  Package: ff896\n";
	print MSS "#  Speed Grade: -7\n";
	print MSS "#  Processor: PPC405 x 2\n";
	print MSS "#  Bus clock frequency: 100Mhz\n";
	if (defined($self->{ext_sdram})) {	
		printf MSS "#  Total on-board SDRAM: 0x%x bytes\n", $self->{ext_sdram}->{size};
		}
	if (defined($self->{ext_vga_controller})) {
		print MSS "#  On-board VGA controller\n";
	}
	print MSS "#  Documents: http://www.opencores.org/projects.cgi/web/mpdma/overview\n";
	print MSS "# #######################################################################\n\n";

	print MSS " PARAMETER VERSION = 2.2.0\n\n";

	print UCF "# #######################################################################\n";
	print UCF "#  Created by BlazeCluster v0.11 for Xilinx EDK 7.1\n";
	print UCF "#  Target Board: Xilinx XUP Virtex-II Pro Development System Rev C\n";
	print UCF "#  Family: virtex 2p\n";
	print UCF "#  Device: xc2vp30\n";
	print UCF "#  Package: ff896\n";
	print UCF "#  Speed Grade: -7\n";
	print UCF "#  Processor: PPC405 x 2\n";
	print UCF "#  Bus clock frequency: 100Mhz\n";
	if (defined($self->{ext_sdram})) {	
		printf UCF "#  Total on-board SDRAM: 0x%x bytes\n", $self->{ext_sdram}->{size};
		}
	if (defined($self->{ext_vga_controller})) {
		print UCF "#  On-board VGA controller\n";
	}
	print UCF "#  Documents: http://www.opencores.org/projects.cgi/web/mpdma/overview\n";
	print UCF "# #######################################################################\n\n";

	print LOG "----------------------------------------------------------------\n- Log Start\n";
	print LOG "- Board: Xilinx XUP Virtex-II Pro Development System Rev C\n";
	print LOG "- Device: xc2vp30\n";
	

}

sub generate_external_port_and_ucf {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;

	my $pin = $self->{instance}."_pin";

    if (defined($self->{extuart})) {
    
        print MHS " PORT ${pin}_uart0_rx_pin = ${pin}_uart0_rx, DIR = INPUT\n";
        print MHS " PORT ${pin}_uart0_tx_pin = ${pin}_uart0_tx, DIR = OUTPUT\n";

    }

    if (defined($self->{extcfcard})) {
    
        print MHS " PORT ${pin}_cf_card_CLK_pin = ${pin}_cf_card_CLK, DIR = INPUT\n";
        print MHS " PORT ${pin}_cf_card_MPA_pin = ${pin}_cf_card_MPA, VEC = [6:0], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_cf_card_MPD_pin = ${pin}_cf_card_MPD, VEC = [15:0], DIR = INOUT\n";
        print MHS " PORT ${pin}_cf_card_CEN_pin = ${pin}_cf_card_CEN, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_cf_card_OEN_pin = ${pin}_cf_card_OEN, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_cf_card_WEN_pin = ${pin}_cf_card_WEN, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_cf_card_MPIRQ_pin = ${pin}_cf_card_MPIRQ, DIR = INPUT\n";

    }

    if (defined($self->{ext_sdram})) {
    
        print MHS " PORT ${pin}_DDR_Clk_pin = ${pin}_DDR_Clk, VEC = [0:2], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_Clkn_pin = ${pin}_DDR_Clkn, VEC = [0:2], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_Addr_pin = ${pin}_DDR_Addr, VEC = [0:12], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_BankAddr_pin = ${pin}_DDR_BankAddr, VEC = [0:1], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_CASn_pin = ${pin}_DDR_CASn, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_RASn_pin = ${pin}_DDR_RASn, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_WEn_pin = ${pin}_DDR_WEn, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_DM_pin = ${pin}_DDR_DM, VEC = [0:7], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_DQS_pin = ${pin}_DDR_DQS, VEC = [0:7], DIR = INOUT\n";
        print MHS " PORT ${pin}_DDR_DQ_pin = ${pin}_DDR_DQ, VEC = [0:63], DIR = INOUT\n";
        print MHS " PORT ${pin}_DDR_CKE_pin = ${pin}_DDR_CKE, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_DDR_CSn_pin = ${pin}_DDR_CSn, DIR = OUTPUT\n";
        
        print MHS " PORT ${pin}_DDR_CLK_FB_pin = ddr_feedback_s, DIR = INPUT\n";
        print MHS " PORT ${pin}_DDR_CLK_FB_OUT_pin = ddr_clk_feedback_out_s, DIR = OUTPUT\n";

    }

    if (defined($self->{ext_vga_controller})) {
    
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_CLK_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_CLK, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK, DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_B, VEC = [5:0], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_G, VEC = [5:0], DIR = OUTPUT\n";
        print MHS " PORT ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin = ${pin}_VGA_FrameBuffer_TFT_LCD_R, VEC = [5:0], DIR = OUTPUT\n";

	}
   
    
    print MHS " PORT sys_clk_pin = dcm_clk_s, DIR = INPUT, SIGIS = DCMCLK\n";
    print MHS " PORT sys_rst_pin = sys_rst_s, DIR = INPUT\n";
    
    print MHS "\n";

    print UCF "Net sys_clk_pin LOC=AJ15;\n";
    print UCF "Net sys_clk_pin IOSTANDARD = LVCMOS25;\n";
    print UCF "Net sys_rst_pin LOC=AH5;\n";
    print UCF "Net sys_rst_pin IOSTANDARD = LVTTL;\n";
    print UCF "## System level constraints\n";
    print UCF "Net sys_clk_pin TNM_NET = sys_clk_pin;\n";
    print UCF "TIMESPEC TS_sys_clk_pin = PERIOD sys_clk_pin 10000 ps;\n";
    print UCF "Net sys_rst_pin TIG;\n";
    print UCF "\n";
    
    print UCF "## FPGA pin constraints\n";
    
    if (defined($self->{extuart})) {
    
        print UCF "Net ${pin}_uart0_rx_pin LOC=AJ8;\n";
        print UCF "Net ${pin}_uart0_rx_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_uart0_tx_pin LOC=AE7;\n";
        print UCF "Net ${pin}_uart0_tx_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_uart0_tx_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_uart0_tx_pin DRIVE = 12;\n";

    }
    
    if (defined($self->{extcfcard})) {
    
        print UCF "Net ${pin}_cf_card_CLK_pin LOC=AH15;\n";
        print UCF "Net ${pin}_cf_card_CLK_pin PERIOD = 30000 ps;\n";
        print UCF "Net ${pin}_cf_card_CLK_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<0> LOC=AF21;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<0> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<0> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<0> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<1> LOC=AG21;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<1> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<1> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<1> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<2> LOC=AC19;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<2> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<2> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<2> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<3> LOC=AD19;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<3> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<3> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<3> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<4> LOC=AE22;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<4> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<4> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<4> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<5> LOC=AE21;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<5> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<5> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<5> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<6> LOC=AH22;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<6> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<6> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPA_pin<6> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<0> LOC=AE15;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<0> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<0> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<0> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<1> LOC=AD15;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<1> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<1> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<1> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<2> LOC=AG14;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<2> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<2> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<2> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<3> LOC=AF14;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<3> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<3> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<3> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<4> LOC=AE14;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<4> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<4> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<4> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<5> LOC=AD14;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<5> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<5> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<5> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<6> LOC=AC15;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<6> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<6> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<6> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<7> LOC=AB15;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<7> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<7> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<7> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<8> LOC=AJ9;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<8> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<8> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<8> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<9> LOC=AH9;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<9> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<9> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<9> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<10> LOC=AE10;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<10> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<10> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<10> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<11> LOC=AE9;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<11> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<11> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<11> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<12> LOC=AD12;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<12> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<12> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<12> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<13> LOC=AC12;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<13> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<13> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<13> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<14> LOC=AG10;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<14> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<14> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<14> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<15> LOC=AF10;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<15> IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<15> SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_MPD_pin<15> DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_CEN_pin LOC=AB16;\n";
        print UCF "Net ${pin}_cf_card_CEN_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_CEN_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_CEN_pin DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_OEN_pin LOC=AD17;\n";
        print UCF "Net ${pin}_cf_card_OEN_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_OEN_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_OEN_pin DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_WEN_pin LOC=AC16;\n";
        print UCF "Net ${pin}_cf_card_WEN_pin IOSTANDARD = LVCMOS25;\n";
        print UCF "Net ${pin}_cf_card_WEN_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_cf_card_WEN_pin DRIVE = 8;\n";
        print UCF "Net ${pin}_cf_card_MPIRQ_pin LOC=AD16;\n";
        print UCF "Net ${pin}_cf_card_MPIRQ_pin IOSTANDARD = LVCMOS25;\n";

    }
    
    if (defined($self->{ext_sdram})) {
    
        print UCF "Net ${pin}_DDR_Addr_pin<12> LOC=M25;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<12> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<11> LOC=N25;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<11> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<10> LOC=L26;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<10> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<9> LOC=M29;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<9> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<8> LOC=K30;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<8> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<7> LOC=G25;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<7> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<6> LOC=G26;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<6> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<5> LOC=D26;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<5> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<4> LOC=J24;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<4> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<3> LOC=K24;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<3> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<2> LOC=F28;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<1> LOC=F30;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<0> LOC=M24;\n";
        print UCF "Net ${pin}_DDR_Addr_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_BankAddr_pin<1> LOC=M26;\n";
        print UCF "Net ${pin}_DDR_BankAddr_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_BankAddr_pin<0> LOC=K26;\n";
        print UCF "Net ${pin}_DDR_BankAddr_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_CASn_pin LOC=L27;\n";
        print UCF "Net ${pin}_DDR_CASn_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_CKE_pin LOC=R26;\n";
        print UCF "Net ${pin}_DDR_CKE_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_CSn_pin LOC=R24;\n";
        print UCF "Net ${pin}_DDR_CSn_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_RASn_pin LOC=N29;\n";
        print UCF "Net ${pin}_DDR_RASn_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_WEn_pin LOC=N26;\n";
        print UCF "Net ${pin}_DDR_WEn_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<7> LOC=U26;\n";
        print UCF "Net ${pin}_DDR_DM_pin<7> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<6> LOC=V29;\n";
        print UCF "Net ${pin}_DDR_DM_pin<6> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<5> LOC=W29;\n";
        print UCF "Net ${pin}_DDR_DM_pin<5> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<4> LOC=T22;\n";
        print UCF "Net ${pin}_DDR_DM_pin<4> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<3> LOC=W28;\n";
        print UCF "Net ${pin}_DDR_DM_pin<3> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<2> LOC=W27;\n";
        print UCF "Net ${pin}_DDR_DM_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<1> LOC=W26;\n";
        print UCF "Net ${pin}_DDR_DM_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DM_pin<0> LOC=W25;\n";
        print UCF "Net ${pin}_DDR_DM_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<7> LOC=E30;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<7> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<6> LOC=J29;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<6> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<5> LOC=M30;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<5> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<4> LOC=P29;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<4> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<3> LOC=V23;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<3> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<2> LOC=AA25;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<1> LOC=AC25;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<0> LOC=AH26;\n";
        print UCF "Net ${pin}_DDR_DQS_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<63> LOC=C27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<63> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<62> LOC=D28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<62> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<61> LOC=D29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<61> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<60> LOC=D30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<60> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<59> LOC=H25;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<59> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<58> LOC=H26;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<58> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<57> LOC=E27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<57> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<56> LOC=E28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<56> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<55> LOC=J26;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<55> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<54> LOC=G27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<54> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<53> LOC=G28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<53> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<52> LOC=G30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<52> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<51> LOC=L23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<51> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<50> LOC=L24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<50> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<49> LOC=H27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<49> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<48> LOC=H28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<48> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<47> LOC=J27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<47> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<46> LOC=J28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<46> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<45> LOC=K29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<45> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<44> LOC=L29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<44> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<43> LOC=N23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<43> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<42> LOC=N24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<42> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<41> LOC=K27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<41> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<40> LOC=K28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<40> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<39> LOC=R22;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<39> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<38> LOC=M27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<38> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<37> LOC=M28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<37> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<36> LOC=P30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<36> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<35> LOC=P23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<35> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<34> LOC=P24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<34> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<33> LOC=N27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<33> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<32> LOC=N28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<32> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<31> LOC=V27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<31> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<30> LOC=Y30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<30> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<29> LOC=U24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<29> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<28> LOC=U23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<28> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<27> LOC=V26;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<27> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<26> LOC=V25;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<26> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<25> LOC=Y29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<25> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<24> LOC=AA29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<24> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<23> LOC=Y26;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<23> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<22> LOC=AA28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<22> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<21> LOC=AA27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<21> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<20> LOC=W24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<20> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<19> LOC=W23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<19> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<18> LOC=AB28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<18> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<17> LOC=AB27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<17> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<16> LOC=AC29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<16> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<15> LOC=AB25;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<15> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<14> LOC=AE29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<14> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<13> LOC=AA24;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<13> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<12> LOC=AA23;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<12> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<11> LOC=AD28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<11> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<10> LOC=AD27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<10> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<9> LOC=AF30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<9> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<8> LOC=AF29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<8> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<7> LOC=AF25;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<7> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<6> LOC=AG30;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<6> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<5> LOC=AG29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<5> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<4> LOC=AD26;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<4> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<3> LOC=AD25;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<3> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<2> LOC=AG28;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<1> LOC=AH27;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<0> LOC=AH29;\n";
        print UCF "Net ${pin}_DDR_DQ_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<2> LOC=AC27;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<1> LOC=AD29;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<0> LOC=AB23;\n";
        print UCF "Net ${pin}_DDR_Clk_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<2> LOC=AC28;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<2> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<1> LOC=AD30;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<1> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<0> LOC=AB24;\n";
        print UCF "Net ${pin}_DDR_Clkn_pin<0> IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_CLK_FB_pin LOC=C16;\n";
        print UCF "Net ${pin}_DDR_CLK_FB_pin IOSTANDARD = SSTL2_II;\n";
        print UCF "Net ${pin}_DDR_CLK_FB_OUT_pin LOC=G23;\n";
        print UCF "Net ${pin}_DDR_CLK_FB_OUT_pin IOSTANDARD = SSTL2_II;\n";

    }

    if (defined($self->{ext_vga_controller})) {

        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_CLK_pin LOC=H12;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_CLK_pin IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_CLK_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_CLK_pin DRIVE = 12;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC_pin LOC=B8;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC_pin IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC_pin DRIVE = 12;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC_pin LOC=D11;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC_pin IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC_pin DRIVE = 12;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<0> LOC=H15;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<0> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<0> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<0> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<1> LOC=J15;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<1> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<1> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<1> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<2> LOC=C13;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<2> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<2> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<2> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<3> LOC=D13;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<3> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<3> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<3> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<4> LOC=D14;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<4> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<4> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<4> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<5> LOC=E14;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<5> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<5> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_B_pin<5> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<0> LOC=D10;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<0> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<0> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<0> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<1> LOC=D8;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<1> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<1> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<1> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<2> LOC=C8;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<2> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<2> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<2> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<3> LOC=H11;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<3> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<3> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<3> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<4> LOC=G11;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<4> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<4> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<4> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<5> LOC=E11;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<5> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<5> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_G_pin<5> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<0> LOC=G9;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<0> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<0> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<0> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<1> LOC=F9;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<1> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<1> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<1> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<2> LOC=F10;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<2> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<2> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<2> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<3> LOC=D7;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<3> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<3> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<3> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<4> LOC=C7;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<4> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<4> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<4> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<5> LOC=H10;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<5> IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<5> SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_R_pin<5> DRIVE = 6;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK_pin LOC=A8;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK_pin IOSTANDARD = LVTTL;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK_pin SLEW = SLOW;\n";
        print UCF "Net ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK_pin DRIVE = 6;\n";
	}    

}

sub generate {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;
	*LOG = shift;

	if (defined($self->{opb})) {

	    print MHS "BEGIN opb_v20\n";
	    print MHS " PARAMETER INSTANCE = opb_$self->{instance}\n";
	    print MHS " PARAMETER HW_VER = 1.10.c\n";
	    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
	    print MHS " PORT SYS_Rst = sys_rst_s\n";
	    print MHS " PORT OPB_Clk = sys_clk_s\n";
	    print MHS "END\n\n";

	    print MSS "BEGIN DRIVER\n";
	    print MSS " PARAMETER DRIVER_NAME = opbarb\n";
	    print MSS " PARAMETER DRIVER_VER = 1.02.a\n";
	    print MSS " PARAMETER HW_INSTANCE = opb_$self->{instance}\n";
	    print MSS "END\n\n";
	    }

	if (defined($self->{dcr})) {

	    print MHS "BEGIN opb2dcr_bridge\n";
	    print MHS " PARAMETER INSTANCE = opb2dcr_bridge_$self->{instance}\n";
	    print MHS " PARAMETER HW_VER = 1.00.a\n";
	    print MHS " PARAMETER C_BASEADDR = 0xD0000000\n";
	    print MHS " PARAMETER C_HIGHADDR = 0xD00003FF\n";
	    print MHS " BUS_INTERFACE SOPB = opb_$self->{instance}\n";
	    print MHS " BUS_INTERFACE MDCR = dcr_$self->{instance}\n";
	    print MHS "END\n\n";

		print MSS "BEGIN DRIVER\n";    
		print MSS " PARAMETER DRIVER_NAME = generic\n";    
		print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
		print MSS " PARAMETER HW_INSTANCE = opb2dcr_bridge_$self->{instance}\n";    
		print MSS "END\n\n";
		
	    print MHS "BEGIN dcr_v29\n";
	    print MHS " PARAMETER INSTANCE = dcr_$self->{instance}\n";
	    print MHS " PARAMETER HW_VER = 1.00.a\n";
	    print MHS " PARAMETER C_DCR_NUM_SLAVES = 1\n";
	    print MHS "END\n\n";
	    }
	
	
    print MHS "BEGIN dcm_module\n";
    print MHS " PARAMETER INSTANCE = dcm_0\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_CLK0_BUF = TRUE\n";
    print MHS " PARAMETER C_CLK90_BUF = TRUE\n";
    print MHS " PARAMETER C_CLK180_BUF = TRUE\n";
    print MHS " PARAMETER C_CLK270_BUF = TRUE\n";
    print MHS " PARAMETER C_CLKIN_PERIOD = 10.000000\n";
    print MHS " PARAMETER C_CLK_FEEDBACK = 1X\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 1\n";
    print MHS " PORT CLKIN = dcm_clk_s\n";
    print MHS " PORT CLK0 = sys_clk_s\n";
    print MHS " PORT CLK90 = clk_90_s\n";
    print MHS " PORT CLK180 = sys_clk_n_s\n";
    print MHS " PORT CLK270 = clk_90_n_s\n";
    print MHS " PORT CLKFB = sys_clk_s\n";
    print MHS " PORT RST = net_gnd\n";
    print MHS " PORT LOCKED = dcm_0_lock\n";
    print MHS "END\n\n";

    print MHS "BEGIN dcm_module\n";
    print MHS " PARAMETER INSTANCE = dcm_1\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_CLK0_BUF = TRUE\n";
    print MHS " PARAMETER C_CLK90_BUF = TRUE\n";
    print MHS " PARAMETER C_CLK270_BUF = TRUE\n";
    print MHS " PARAMETER C_CLKIN_PERIOD = 10.000000\n";
    print MHS " PARAMETER C_CLK_FEEDBACK = 1X\n";
    print MHS " PARAMETER C_PHASE_SHIFT = 60\n";
    print MHS " PARAMETER C_CLKOUT_PHASE_SHIFT = FIXED\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT CLKIN = ddr_feedback_s\n";
    print MHS " PORT CLK0 = dcm_1_FB\n";
    print MHS " PORT CLK90 = ddr_clk_90_s\n";
    print MHS " PORT CLK270 = ddr_clk_90_n_s\n";
    print MHS " PORT CLKFB = dcm_1_FB\n";
    print MHS " PORT RST = dcm_0_lock\n";
    print MHS " PORT LOCKED = dcm_1_lock\n";
    print MHS "END\n\n";


    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = generic\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = dcm_0\n";
    print MSS "END\n\n";

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = generic\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = dcm_1\n";
    print MSS "END\n\n";

    print LOG "- Device utilization estimation\n";
    print LOG "-  Slice  $self->{slicecnt}\tout of $self->{slice_on_device}\n";
    print LOG "-  BRAM   $self->{bramcnt}\tout of $self->{bram_on_device}\n";
    print LOG "-  MUL    $self->{mulcnt}\tout of $self->{mul_on_device}\n";
    print LOG"- Note LUT packing is not evaluated so slice number can be 10%-25% larger\n";
}


1;
