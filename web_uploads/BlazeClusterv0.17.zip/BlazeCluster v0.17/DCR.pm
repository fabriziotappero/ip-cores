###################################################
# 
#   BlazeCluster  dcr.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   DCR bus object
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package DCR;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};

    bless($self, $class);

#    $self->{device_addr_start} = 0x40000000;
#    $self->{device_addr_current} = 0x40000000;

    return $self;
}

sub get_instance() {
    my $self = shift;

    return $self->{instance};

}

sub generate() {
    my $self = shift;
    my $system = shift;
    *MHS = shift;
    *MSS = shift;

	my $opb_instance = $self->get_instance();

}

1;
