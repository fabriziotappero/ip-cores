#!/usr/bin/perl

###################################################
# 
#   BlazeCluster  jena.pl  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   This is the main file. Make sure Perl is installed. It can generate
#   MHS, MSS and UCF files.
#   Usage: jena.pl system.js  
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

use strict;
use warnings;

use OPB;
use DCR;
use Swproj;
use System;
use PowerPC;
use Microblaze;
use Dpram;

my @ldpram;
my @lshared;
my @lproc;
my @lswproj;


	my $system = System->new(
		instance => "mp",
		target => "system",
		lproc => \@lproc,
		ldpram => \@ldpram,
		lshared => \@lshared,
		lswproj => \@lswproj,
		);
	


	open LOG, ">>jena.log" or die "can't open $!";

	my $js = shift;
	if (!defined($js)) {
		$js = "system.js";
		}
	open JS, $js or die "can't open $!";
	my @target_list = split /\./, $js;
	$system->{target} = $target_list[0];

	while (<JS>) {
	    chop;

	    next unless (/,/);
	    next if  (/^\s*\#/);
	    
	    my @comp = split /,/, $_;
	    my $typestr = $comp[1];
	    
	    if ($typestr =~ "(sw-project|sw-proj)") {
		 my $swproj = Swproj->new();

	        $swproj->read($system, @comp);
	    	 push(@lswproj, $swproj);
	    } elsif ($typestr =~ "microblaze") {
	    	my $microblaze = Microblaze->new();

	    	$microblaze->read($system, @comp);
	    	push(@lproc, $microblaze);
	    }

	    elsif (($typestr =~ "powerpc") || ($typestr =~ "ppc")) {
	    	my $ppc = PowerPC->new();

	    	$ppc->read($system, @comp);
	    	push(@lproc, $ppc);
	    }

	    elsif ($typestr =~ "dpram") {
	       my $dpram = Dpram->new();

	       $dpram->read($system, @comp);
	       push(@ldpram, $dpram);
	    }

	}

	$system->prepare($system, *LOG);
	my $target = $system->{target};

	open XMP, ">$target/system.xmp" or die "can't open $!";
	open MHS, ">$target/system.mhs" or die "can't open $!";
	open MSS, ">$target/system.mss" or die "can't open $!";
	open UCF, ">$target/data/system.ucf" or die "can't open $!";

	$system->generate_header($system, *MHS, *MSS, *UCF, *LOG);
	$system->generate_xmp($system, *XMP, *LOG);
	$system->generate_external_port_and_ucf($system, *MHS, *MSS, *UCF);	
	
	foreach my $proc (@lproc) {
		$proc->generate($system, *MHS, *MSS, *UCF);
	}

	foreach my $dp (@ldpram) {
	    $dp->generate($system, *MHS, *MSS, *UCF);
	}

        foreach my $swproj (@lswproj) {
   		$swproj->generate($system, *XMP, *LOG);
        }

	$system->generate($system, *MHS, *MSS, *UCF, *LOG);	

	    foreach my $proc (@lproc) {
#        print "processor $proc->{instance}:  ";
		 for (keys %{$proc}) {
#	     print ("$_ -> $proc->{$_}  ");
		 }
#	 print "\n";
	    }

	    foreach my $dp (@ldpram) {
#        print "dpram $dp->{instance}:  ";
		 for (keys %{$dp}) {
#	     print ("$_ -> $dp->{$_}  ");
		 }
#	 print "\n";
	    }

	close JS;
	close XMP;
	close MHS;
	close MSS;
	close UCF;
	close LOG;


