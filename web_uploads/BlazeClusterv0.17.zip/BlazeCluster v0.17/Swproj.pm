###################################################
# 
#   BlazeCluster  swproj.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   software project object
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package Swproj;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};

    bless($self, $class);

    $self->{com} = "swproj";
    return $self;
}

sub read() {
	my $self = shift;
	my $system = shift;
	my $instance = shift;

	$self->{instance} = $instance;

	    foreach (@_) {

	        if (/(sw-project|sw-proj)\s+on\s+(.*)/) {
	        	my @proclist = split /\s+/, $2;

	        	$self->{lproclist} = \@proclist;
#	        	print "---> @proclist\n";
	        	
	        } elsif (/source\s+(.*)/) {
	        	my @srclist = split /\s+/, $1;

	        	$self->{lsrclist} = \@srclist;
#	        	print "src ---> @srclist\n";
			
	        } elsif (/(c-flags|c-flag)\s+(.*)/) {
	        	my @cflaglist = split /\s+/, $2;

	        	$self->{cflaglist} = \@cflaglist;
#	        	print "cflag ---> @cflaglist\n";
			
	        } elsif (/linkscript\s+(\S+)/) {
	        	my $linkscript = $1;

		       $self->{linkscript} = $linkscript;
#	        	print "linkscript ---> $linkscript\n";
	        }
	        	       
	    }

    return $self;

}

sub generate() {
	my $self = shift;
	my $system = shift;
	*XMP = shift;
	*LOG = shift;

	my $instance = $self->{instance};

	if (!defined($self->{lproclist})) {
		die "no processor defined for $instance\n";
	}

	if (!defined($self->{lsrclist})) {
		die "no source file defined for $instance\n";
	}

	my $procid=0;
	
	foreach my $proc (@{$self->{lproclist}}) {
		print XMP "SwProj: ${instance}_${proc}\n";
		print XMP "Processor: $proc\n";
		print XMP "Executable: ${instance}_${proc}/executable.elf\n";
		foreach my $src (@{$self->{lsrclist}}) {
			print XMP "Source: source\\$src\n";
		}
		print XMP "DefaultInit: EXECUTABLE\n";
		print XMP "InitBram: 1\n";
		print XMP "Active: 1\n";
		print XMP "CompilerOptLevel: 2\n";
		print XMP "GlobPtrOpt: 0\n";
		print XMP "DebugSym: 0\n";
		print XMP "AsmOpt: \n";
		print XMP "LinkOpt: \n";
		print XMP "ProgStart:\n";
		print XMP "StackSize: \n";
		print XMP "HeapSize: \n";
		if (defined($self->{linkscript})) {
			print XMP "LinkerScript: source\\$self->{linkscript}\n";
		} else {
			print XMP "LinkerScript:\n";
		}

		printf XMP "ProgCCFlags: -DPROC_$proc -DPROJ_${instance} -DPROCID=%d -DNUM_PROC_IN_GROUP=%d", $procid++, $#{$self->{lproclist}}+1;
		if (defined($self->{cflaglist})) {
			printf XMP " @{$self->{cflaglist}}";
		} 
		print XMP "\n";
	}
    
}


1;


