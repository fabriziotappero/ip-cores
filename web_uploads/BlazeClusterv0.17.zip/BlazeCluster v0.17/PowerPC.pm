###################################################
# 
#   BlazeCluster  powerpc.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   PowerPC processor object and peripherals
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package PowerPC;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};

    bless($self, $class);

    $self->{com} = "powerpc";
    return $self;
}

sub get_com {
	my $self = shift;

	return $self->{com};
	
}

sub get_instance {
	my $self = shift;

	return $self->{instance};

}

sub read {
	my $self = shift;
	my $system = shift;
	my $instance = shift;
	my @ldrivers;

	$self->{instance} = $instance;
	$self->{drivers} = \@ldrivers;

 	foreach (@_) {

		if (/jtag/) {
	    		$self->{jtag} = 1;
		}
	
		elsif (/(\d+)(k|m)\s+on(-*)chip\s+(ram|mem)/) {
	    		my $onchip_mem_size = eval($1);
	    		
	    		if ($2 eq 'k') { $onchip_mem_size *= 1024; }
	    		elsif ($2 eq 'm') { $onchip_mem_size *= 1024*1024; }
	    		else {
				die "unknown memory size $2";
	    		}
	    		$self->{onchip_mem_size} = $onchip_mem_size;
	    
		    if (/address\s*(\S+)/) {
		        $self->{onchip_mem_addr} = eval($1);
		    } else {
	               $self->{onchip_mem_addr} = 0xffffffff - $self->{onchip_mem_size} + 1;
		    }
		} 

		elsif (/opb-uartlite/) {
			my $opb = $system->get_opb();
			if (!defined($self->{plb2opb})) {
				$self->{plb2opb} = $instance;
			}

		    my $opb_uartlite = {
		       device => "opb-uartlite",
			instance => "opb_uartlite_$instance",
	              interrupt => 0,
	              addr => 0,
	 	       addrfix => 0,
	              size => 0x10000,
			baudrate => 9600,
			bits => 8,
			stop => 1,
			parity => 0,
		    };

		    if (/address\s*(\S+)/) {
		        $opb_uartlite->{addr} = eval($1);
	               $opb_uartlite->{addrfix} = 1;
		    } 	  else {
	               $opb_uartlite->{addr} = $opb->get_device_address($opb_uartlite->{size});
	               $opb_uartlite->{addrfix} = 0;
		    }

		    if (/baudrate\s*(\d+)/) {
	               $opb_uartlite->{baudrate} = eval($1);
		    }

	           if (/stdio/) {
	               $self->{stdio} = $opb_uartlite->{instance};
	           }
	           
		    push (@ldrivers, $opb_uartlite);
		    $system->set_external_uart($instance);
		}

		elsif (/opb-cf-card/) {
			my $opb = $system->get_opb();
			if (!defined($self->{plb2opb})) {
				$self->{plb2opb} = $instance;
			}
			
		    my $opb_cf_card = {
		        device => "opb-cf-card",
		        instance => "opb_cf_card_$instance",
		        interrupt => 0,
		        addr => 0,
	   	        addrfix => 0,
		        size => 0x10000,
		        write => 0,
		    };

		    if (/address\s*(\S+)/) {
		        $opb_cf_card->{addr} = eval($1);
	               $opb_cf_card->{addrfix} = 1;
		    } 	  else {
	               $opb_cf_card->{addr} = $opb->get_device_address($opb_cf_card->{size});
	               $opb_cf_card->{addrfix} = 0;
		    }
		    
		    if (/readwrite|rw/) {
			 $opb_cf_card->{write} = 1;
		    }
		    push (@ldrivers, $opb_cf_card);
		    $system->set_external_cf_card($instance);
		}

		elsif (/plb-dcr-vga-controller|plb-dcr-vgacontroller/) {
			my $dcr = $system->get_dcr();
			if (!defined($self->{opb2dcr})) {
				$self->{opb2dcr} = $instance;
			}

			my $plb_dcr_vga_controller = {
				device => "plb_dcr_vga_controller",
				instance => "plb_dcr_vga_controller_$instance",
				plb => "plb_$instance",
				dcr => $dcr->get_instance(),
			};
		    push (@ldrivers, $plb_dcr_vga_controller);
		    $system->set_external_vga_controller($instance);
			
		}   # plb-dcr-vga-controller

		elsif (/(\d+)(k|m)\s+on.board\s+plb-ddr/) {
			my $plb_ddr = {
				device => "on-board-ddr-sdram",
				instance => "on_board_ddr_sdram_$instance",
				owner => $instance,
				plb => "plb_$instance",
				addr => 0,
				size => 0
			};

	    		my $size = eval($1);
				
	    		if ($2 eq 'k') { $size *= 1024; }
	    		elsif ($2 eq 'm') { $size *= 1024*1024; }
	    		else {
				die "unknown memory size $2";
	    		}
	    		$plb_ddr->{size} = $size;

	    		if ($size != 256*1024*1024) {   # hack. should fix after I have other memory module to test
				die "only 256mb external memory is supported in this version";
	    		}
	    
		    if (/address\s*(\S+)/) {
		        $plb_ddr->{addr} = eval($1);
		    } else {
	               $plb_ddr->{addr} = 0;
		    }
		    push (@ldrivers, $plb_ddr);
		    $system->set_external_sdram($plb_ddr);

#		    printf "external sdram addr=%x size=%x\n", $plb_ddr->{addr}, $plb_ddr->{size}

		}   # on board ddr sdram

    }

    return $self;

}

# ppc0, powerpc, 100mhz, 32k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, plb-dcr-vgacontroller

sub generate {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;

	my $instance = $self->{instance};

	print MHS "BEGIN ppc405\n";
	print MHS " PARAMETER INSTANCE = $instance\n";
	print MHS " PARAMETER HW_VER = 2.00.c\n";
	print MHS " BUS_INTERFACE JTAGPPC = jtagppc_$instance\n";
	print MHS " BUS_INTERFACE IPLB = plb_$instance\n";
	print MHS " BUS_INTERFACE DPLB = plb_$instance\n";
	if (defined($self->{dsocm})) {
		print MHS " BUS_INTERFACE DSOCM = dsocm_$instance\n";
		}
	print MHS " PORT PLBCLK = sys_clk_s\n";
	print MHS " PORT C405RSTCHIPRESETREQ = C405RSTCHIPRESETREQ\n";
	print MHS " PORT C405RSTCORERESETREQ = C405RSTCORERESETREQ\n";
	print MHS " PORT C405RSTSYSRESETREQ = C405RSTSYSRESETREQ\n";
	print MHS " PORT RSTC405RESETCHIP = RSTC405RESETCHIP\n";
	print MHS " PORT RSTC405RESETCORE = RSTC405RESETCORE\n";
	print MHS " PORT RSTC405RESETSYS = RSTC405RESETSYS\n";
	print MHS " PORT BRAMDSOCMCLK = sys_clk_s\n";
	print MHS " PORT CPMC405CLOCK = sys_clk_s\n";
	print MHS "END\n\n";
	    
 	print MSS "BEGIN OS\n";    
 	print MSS " PARAMETER OS_NAME = standalone\n";    
 	print MSS " PARAMETER OS_VER = 1.00.a\n";    
 	print MSS " PARAMETER PROC_INSTANCE = $instance\n";    
	if (defined($self->{stdio})) { 	
 		print MSS " PARAMETER STDIN = $self->{stdio}\n";    
 		print MSS " PARAMETER STDOUT = $self->{stdio}\n";    
 	}
 	print MSS "END\n\n";	

	print MSS "BEGIN PROCESSOR\n";    
	print MSS " PARAMETER DRIVER_NAME = cpu_ppc405\n";    
	print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
	print MSS " PARAMETER HW_INSTANCE = $instance\n";    
	print MSS " PARAMETER COMPILER = powerpc-eabi-gcc\n";    
	print MSS " PARAMETER ARCHIVER = powerpc-eabi-ar\n";    
	print MSS " PARAMETER CORE_CLOCK_FREQ_HZ = 100000000\n";    
	print MSS "END\n\n";    

# hack. dummy PowerPC should be inserted automatically

	print MHS "BEGIN ppc405\n";   
	print MHS " PARAMETER INSTANCE = ppc405_1\n";   
	print MHS " PARAMETER HW_VER = 2.00.c\n";   
	print MHS " BUS_INTERFACE JTAGPPC = jtagppc_ppc1\n";   
	print MHS "END\n\n";   
	
 	print MSS "BEGIN OS\n";    
 	print MSS " PARAMETER OS_NAME = standalone\n";    
 	print MSS " PARAMETER OS_VER = 1.00.a\n";    
 	print MSS " PARAMETER PROC_INSTANCE = ppc405_1\n";    
 	print MSS "END\n\n";	

	print MSS "BEGIN PROCESSOR\n";    
	print MSS " PARAMETER DRIVER_NAME = cpu_ppc405\n";    
	print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
	print MSS " PARAMETER HW_INSTANCE = ppc405_1\n";    
	print MSS " PARAMETER COMPILER = powerpc-eabi-gcc\n";    
	print MSS " PARAMETER ARCHIVER = powerpc-eabi-ar\n";    
	print MSS " PARAMETER CORE_CLOCK_FREQ_HZ = 100000000\n";    
	print MSS "END\n\n";    

	print MHS "BEGIN proc_sys_reset\n";
	print MHS " PARAMETER INSTANCE = reset_block\n";
	print MHS " PARAMETER HW_VER = 1.00.a\n";
	print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
	print MHS " PORT Ext_Reset_In = sys_rst_s\n";
	print MHS " PORT Slowest_sync_clk = sys_clk_s\n";
	print MHS " PORT Chip_Reset_Req = C405RSTCHIPRESETREQ\n";
	print MHS " PORT Core_Reset_Req = C405RSTCORERESETREQ\n";
	print MHS " PORT System_Reset_Req = C405RSTSYSRESETREQ\n";
	print MHS " PORT Rstc405resetchip = RSTC405RESETCHIP\n";
	print MHS " PORT Rstc405resetcore = RSTC405RESETCORE\n";
	print MHS " PORT Rstc405resetsys = RSTC405RESETSYS\n";
	print MHS " PORT Bus_Struct_Reset = sys_bus_reset\n";
	print MHS " PORT Dcm_locked = dcm_1_lock\n";
	print MHS "END\n\n";

 	if (defined($self->{jtag})) {

		print MHS "BEGIN jtagppc_cntlr\n";
		print MHS " PARAMETER INSTANCE = jtagppc_0\n";
		print MHS " PARAMETER HW_VER = 2.00.a\n";
		print MHS " BUS_INTERFACE JTAGPPC0 = jtagppc_$instance\n";
		print MHS " BUS_INTERFACE JTAGPPC1 = jtagppc_ppc1\n";
		print MHS "END\n\n";

	}

# create plb, ocm bus, on-chip  memory device

	if (defined($self->{dsocm})) {
		print MHS "BEGIN dsocm_v10\n";
		print MHS " PARAMETER INSTANCE = dsocm_$instance\n";
		print MHS " PARAMETER HW_VER = 2.00.a\n";
		print MHS " PARAMETER C_DSCNTLVALUE = 0x81\n";
		print MHS " PORT SYS_Rst = sys_bus_reset\n";
		print MHS " PORT DSOCM_Clk = sys_clk_s\n";
		print MHS "END\n\n";

		print MSS "BEGIN DRIVER\n";    
		print MSS " PARAMETER DRIVER_NAME = generic\n";    
		print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
		print MSS " PARAMETER HW_INSTANCE = dsocm_$instance\n";    
		print MSS "END\n";
	}

	print MHS "BEGIN plb_v34\n";
	print MHS " PARAMETER INSTANCE = plb_$instance\n";
	print MHS " PARAMETER HW_VER = 1.02.a\n";
	print MHS " PARAMETER C_EXT_RESET_HIGH = 1\n";
	print MHS " PARAMETER C_DCR_INTFCE = 0\n";
	print MHS " PORT SYS_Rst = sys_bus_reset\n";
	print MHS " PORT PLB_Clk = sys_clk_s\n";
	print MHS "END\n\n";


	$system->area_estimate("plb_$instance", 332, 0, 0, 0, 0);
	
	print MSS "BEGIN DRIVER\n";    
	print MSS " PARAMETER DRIVER_NAME = plbarb\n";    
	print MSS " PARAMETER DRIVER_VER = 1.01.a\n";    
	print MSS " PARAMETER HW_INSTANCE = plb_$instance\n";    
	print MSS "END\n";

	print MHS "BEGIN plb_bram_if_cntlr\n";
	print MHS " PARAMETER INSTANCE = plb_bram_if_cntlr_$instance\n";
	print MHS " PARAMETER HW_VER = 1.00.b\n";
	print MHS " PARAMETER c_plb_clk_period_ps = 10000\n";
	printf MHS " PARAMETER c_baseaddr = 0x%08x\n", $self->{onchip_mem_addr};
	printf MHS " PARAMETER c_highaddr = 0x%08x\n", $self->{onchip_mem_addr}+$self->{onchip_mem_size}-1;
	print MHS " BUS_INTERFACE SPLB = plb_$instance\n";
	print MHS " BUS_INTERFACE PORTA = plb_bram_port_$instance\n";
	print MHS " PORT PLB_Clk = sys_clk_s\n";
	print MHS "END\n\n";

	$system->area_estimate("plb_bram_if_cntlr_$instance", 185, 0, 0, 0, 0);
	
	print MSS "BEGIN DRIVER\n";    
	print MSS " PARAMETER DRIVER_NAME = bram\n";    
	print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
	print MSS " PARAMETER HW_INSTANCE = plb_bram_if_cntlr_$instance\n";    
	print MSS "END\n\n";
	
	print MHS "BEGIN bram_block\n";
	print MHS " PARAMETER INSTANCE = bram_$instance\n";
	print MHS " PARAMETER HW_VER = 1.00.a\n";
	print MHS " BUS_INTERFACE PORTA = plb_bram_port_$instance\n";
	print MHS "END\n\n";

	my $bram = $self->{onchip_mem_size}/2048;
	$system->area_estimate("bram_$instance", 0, 0, 0, $bram, 0);

	if (defined($self->{plb2opb})) {
		my $opb = $system->get_opb();
		my $opb_instance = $opb->get_instance();
		my $start = $opb->get_device_address_start();
		my $end = $opb->get_device_address()-1;

		print MHS "BEGIN plb2opb_bridge\n";
		print MHS " PARAMETER INSTANCE = plb2opb\n";
		print MHS " PARAMETER HW_VER = 1.01.a\n";
		print MHS " PARAMETER C_DCR_INTFCE = 0\n";
		print MHS " PARAMETER C_RNG0_BASEADDR = 0xD0000000\n";
		print MHS " PARAMETER C_RNG0_HIGHADDR = 0xD0000FFF\n";
		printf MHS " PARAMETER C_RNG1_BASEADDR = 0x%08x\n", $start;
		printf MHS " PARAMETER C_RNG1_HIGHADDR = 0x%08x\n", $end;
		print MHS " PARAMETER C_NUM_ADDR_RNG = 2\n";
		print MHS " BUS_INTERFACE SPLB = plb_$instance\n";
		print MHS " BUS_INTERFACE MOPB = $opb_instance\n";
		print MHS " PORT PLB_Clk = sys_clk_s\n";
		print MHS " PORT OPB_Clk = sys_clk_s\n";
		print MHS "END\n\n";

		$system->area_estimate("plb2opb", 656, 0, 0, 0, 0);

		print MSS "BEGIN DRIVER\n";    
		print MSS " PARAMETER DRIVER_NAME = plb2opb\n";    
		print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
		print MSS " PARAMETER HW_INSTANCE = plb2opb\n";    
		print MSS "END\n\n";		

	}

#    foreach my $driver (@{$self->{drivers}}) {
#        print ("--driver $driver->{instance}\n");
#    }

	my $pin = $system->{instance}."_pin";

    foreach my $driver (@{$self->{drivers}}) {
        if ($driver->{device} eq "opb-uartlite") {
            print MHS "BEGIN opb_uartlite\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            print MHS " PARAMETER C_BAUDRATE = $driver->{baudrate}\n";
            print MHS " PARAMETER C_DATA_BITS = 8\n";
            print MHS " PARAMETER C_ODD_PARITY = 0\n";
            print MHS " PARAMETER C_USE_PARITY = 0\n";
            print MHS " PARAMETER C_CLK_FREQ = 100000000\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = opb_$system->{instance}\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            print MHS " PORT RX = ${pin}_uart0_rx\n";
            print MHS " PORT TX = ${pin}_uart0_tx\n";
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = uartlite\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
            
        }

        if ($driver->{device} eq "opb-timer") {
            print MHS "BEGIN opb_timer\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = opb_$system->{instance}\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            if ($driver->{interrupt} > 0) {
                print MHS " PORT Interrupt = $driver->{instance}_interrupt\n";
            }
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = tmrctr\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
        }
        
        if ($driver->{device} eq "opb-cf-card") {
        	print MHS "BEGIN opb_sysace\n";
              print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
              print MHS " PARAMETER HW_VER = 1.00.c\n";
              print MHS " PARAMETER C_MEM_WIDTH = 16\n";
              printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
              printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
              print MHS " BUS_INTERFACE SOPB = opb_$system->{instance}\n";
              print MHS " PORT OPB_Clk = sys_clk_s\n";
              print MHS " PORT SysACE_CLK = ${pin}_cf_card_CLK\n";
              print MHS " PORT SysACE_MPA = ${pin}_cf_card_MPA\n";
              print MHS " PORT SysACE_MPD = ${pin}_cf_card_MPD\n";
              print MHS " PORT SysACE_CEN = ${pin}_cf_card_CEN\n";
              print MHS " PORT SysACE_OEN = ${pin}_cf_card_OEN\n";
              print MHS " PORT SysACE_WEN = ${pin}_cf_card_WEN\n";
              print MHS " PORT SysACE_MPIRQ = ${pin}_cf_card_MPIRQ\n";
              print MHS "END\n\n";

             print MSS "BEGIN DRIVER\n";
             print MSS " PARAMETER DRIVER_NAME = sysace\n";
             print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
             print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
             print MSS "END\n\n";
            
             print MSS "BEGIN LIBRARY\n";
             print MSS " PARAMETER LIBRARY_NAME = xilfatfs\n";
             print MSS " PARAMETER LIBRARY_VER = 1.00.a\n";
             print MSS " PARAMETER CONFIG_WRITE = true\n";
             print MSS " PARAMETER CONFIG_MAXFILES = 2\n";
             print MSS " PARAMETER CONFIG_BUFCACHE_SIZE = 1280\n";
             print MSS " PARAMETER PROC_INSTANCE = $instance\n";
             print MSS "END\n\n";
        }

        if ($driver->{device} eq "plb_dcr_vga_controller") {

             print MHS "BEGIN plb_tft_cntlr_ref\n";
             print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
             print MHS " PARAMETER HW_VER = 1.00.d\n";
             print MHS " PARAMETER C_DEFAULT_TFT_BASE_ADDR = 0b00000000000\n";
             print MHS " PARAMETER C_PIXCLK_IS_BUSCLK_DIVBY4 = 0b1\n";
             print MHS " PARAMETER C_ON_INIT = 0b0\n";
             print MHS " PARAMETER C_DCR_BASEADDR = 0b0000010000\n";
             print MHS " PARAMETER C_DCR_HIGHADDR = 0b0000010001\n";
             print MHS " BUS_INTERFACE MPLB = $driver->{plb}\n";
             print MHS " BUS_INTERFACE SDCR = $driver->{dcr}\n";
             print MHS " PORT SYS_dcrClk = sys_clk_s\n";
             print MHS " PORT TFT_LCD_CLK = ${pin}_VGA_FrameBuffer_TFT_LCD_CLK\n";
             print MHS " PORT TFT_LCD_HSYNC = ${pin}_VGA_FrameBuffer_TFT_LCD_HSYNC\n";
             print MHS " PORT TFT_LCD_VSYNC = ${pin}_VGA_FrameBuffer_TFT_LCD_VSYNC\n";
             print MHS " PORT TFT_LCD_B = ${pin}_VGA_FrameBuffer_TFT_LCD_B\n";
             print MHS " PORT TFT_LCD_G = ${pin}_VGA_FrameBuffer_TFT_LCD_G\n";
             print MHS " PORT TFT_LCD_R = ${pin}_VGA_FrameBuffer_TFT_LCD_R\n";
             print MHS " PORT TFT_LCD_BLNK = ${pin}_VGA_FrameBuffer_TFT_LCD_BLNK\n";
             print MHS "END\n\n";

		$system->area_estimate("$driver->{instance}", 151, 0, 0, 1, 0);
		
		print MSS "BEGIN DRIVER\n";    
		print MSS " PARAMETER DRIVER_NAME = tft_ref\n";    
		print MSS " PARAMETER DRIVER_VER = 1.00.a\n";    
		print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";    
		print MSS "END\n\n";             
		
        }  # plb_dcr_vga_controller

        if ($driver->{device} eq "on-board-ddr-sdram") {

             print MHS "# DDR_256MB_32MX64_rank1_row13_col10_cl2_5\n";
             
             print MHS "BEGIN plb_ddr\n";
             print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
             print MHS " PARAMETER HW_VER = 1.11.a\n";
             print MHS " PARAMETER C_PLB_CLK_PERIOD_PS = 10000\n";
             print MHS " PARAMETER C_NUM_BANKS_MEM = 1\n";
             print MHS " PARAMETER C_NUM_CLK_PAIRS = 4\n";
             print MHS " PARAMETER C_INCLUDE_BURST_CACHELN_SUPPORT = 1\n";
             print MHS " PARAMETER C_REG_DIMM = 0\n";
             print MHS " PARAMETER C_DDR_TMRD = 20000\n";
             print MHS " PARAMETER C_DDR_TWR = 20000\n";
             print MHS " PARAMETER C_DDR_TRAS = 60000\n";
             print MHS " PARAMETER C_DDR_TRC = 90000\n";
             print MHS " PARAMETER C_DDR_TRFC = 100000\n";
             print MHS " PARAMETER C_DDR_TRCD = 30000\n";
             print MHS " PARAMETER C_DDR_TRRD = 20000\n";
             print MHS " PARAMETER C_DDR_TRP = 30000\n";
             print MHS " PARAMETER C_DDR_TREFC = 70300000\n";
             print MHS " PARAMETER C_DDR_AWIDTH = 13\n";
             print MHS " PARAMETER C_DDR_COL_AWIDTH = 9\n";
             print MHS " PARAMETER C_DDR_BANK_AWIDTH = 2\n";
             print MHS " PARAMETER C_DDR_DWIDTH = 64\n";
             print MHS " PARAMETER C_MEM0_BASEADDR = 0x30000000\n";
             print MHS " PARAMETER C_MEM0_HIGHADDR = 0x37ffffff\n";
             print MHS " BUS_INTERFACE SPLB = $driver->{plb}\n";
             print MHS " PORT PLB_Clk = sys_clk_s\n";
             print MHS " PORT DDR_Addr = ${pin}_DDR_Addr\n";
             print MHS " PORT DDR_BankAddr = ${pin}_DDR_BankAddr\n";
             print MHS " PORT DDR_CASn = ${pin}_DDR_CASn\n";
             print MHS " PORT DDR_CKE = ${pin}_DDR_CKE\n";
             print MHS " PORT DDR_CSn = ${pin}_DDR_CSn\n";
             print MHS " PORT DDR_RASn = ${pin}_DDR_RASn\n";
             print MHS " PORT DDR_WEn = ${pin}_DDR_WEn\n";
             print MHS " PORT DDR_DM = ${pin}_DDR_DM\n";
             print MHS " PORT DDR_DQS = ${pin}_DDR_DQS\n";
             print MHS " PORT DDR_DQ = ${pin}_DDR_DQ\n";
             print MHS " PORT DDR_Clk = ${pin}_DDR_Clk & ddr_clk_feedback_out_s\n";
             print MHS " PORT DDR_Clkn = ${pin}_DDR_Clkn & 0b0\n";
             print MHS " PORT Clk90_in = clk_90_s\n";
             print MHS " PORT Clk90_in_n = clk_90_n_s\n";
             print MHS " PORT PLB_Clk_n = sys_clk_n_s\n";
             print MHS " PORT DDR_Clk90_in = ddr_clk_90_s\n";
             print MHS " PORT DDR_Clk90_in_n = ddr_clk_90_n_s\n";
             print MHS "END\n\n";

		$system->area_estimate($driver->{instance}, 1322, 0, 0, 0, 0);
		
		print MSS "BEGIN DRIVER\n";    
		print MSS " PARAMETER DRIVER_NAME = ddr\n";    
		print MSS " PARAMETER DRIVER_VER = 1.00.b\n";    
		print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";    
		print MSS "END\n\n";
		
        }  # on-board-ddr-sdram
        
    }

}


1;
