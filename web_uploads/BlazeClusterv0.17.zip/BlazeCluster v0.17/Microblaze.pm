###################################################
# 
#   BlazeCluster  microblaze.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   Microblaze processor object and peripherals
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package Microblaze;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};
    my @fsldev;

    bless($self, $class);

    $self->{com} = "microblaze";
    $self->{lfsldev} = \@fsldev;
    return $self;
}

sub get_com {
	my $self = shift;

	return $self->{com};
	
}

sub get_instance {
	my $self = shift;

	return $self->{instance};

}

# mb0, microblaze, 32k on-chip ram address 0, opb master, barrel-shifter, interrupt from timer0, uart driver baudrate 115200, cf-card driver readwrite

sub read {
	my $self = shift;
	my $system = shift;
	my $instance = shift;
	my @ldrivers;

	$self->{instance} = $instance;
	$self->{drivers} = \@ldrivers;

	foreach (@_) {

		if (/jtag/) {
		    $self->{jtag} = 1;
		}
		
		elsif (/barrel(-|\s*)shifter/) {
		    $self->{barrel} = 1;
		}

		elsif (/fpu/) {
			$self->{fpu} = 1;
		}

		elsif (/(perfcnt|perfcounter)/) {
			$self->{perfcnt} = 1;
			push (@{$self->{lfsldev}}, "perfcounter");
		}
		
		elsif (/(\d+)(k|m)\s*on(-*)chip\s*(ram|mem|memory)/) {
		    my $onchip_mem_size = eval($1);
		    if ($2 eq 'k') { $onchip_mem_size *= 1024; }
		    else { $onchip_mem_size *= 1024*1024; }
		    $self->{onchip_mem_size} = $onchip_mem_size;
		    
		    if (/address\s*(\S+)/) {
		        $self->{onchip_mem_addr} = eval($1);
		    } else {
	               $self->{onchip_mem_addr} = 0;
		    }
		} 

		elsif (/opb-timer/) {
			my $opb = $system->get_opb();
			
		    my $opb_timer = {
		        device => "opb-timer",
		        instance => "opb_timer_$instance", 
		        owner => $instance,
		        opb => $opb->get_instance(),
		        interrupt => 0,
		        addr => 0,
		        addrfix => 0,
		        size => 65536,
		    };

		    if (/interrupt/) {
	               $opb_timer->{interrupt} = 1;
		    }

		    if (/address\s*(\S+)/) {
		        $opb_timer->{addr} = eval($1);
	               $opb_timer->{addrfix} = 1;
		    } else {
	               $opb_timer->{addr} = $opb->get_device_address($opb_timer->{size});
	               $opb_timer->{addrfix} = 0;
		    }

		    push (@ldrivers, $opb_timer);
		    $self->{opb} = $opb;
		}

		elsif (/opb-uartlite/) {
			my $opb = $system->get_opb();
			
		    my $opb_uartlite = {
		       device => "opb-uartlite",
			instance => "opb_uartlite_$instance",
		        owner => $instance,
		        opb => $opb->get_instance(),
	              interrupt => 0,
	              addr => 0,
	 	       addrfix => 0,
	              size => 0x10000,
			baudrate => 9600,
			bits => 8,
			stop => 1,
			parity => 0,
		    };

		    if (/address\s*(\S+)/) {
		        $opb_uartlite->{addr} = eval($1);
	               $opb_uartlite->{addrfix} = 1;
		    } 	  else {
	               $opb_uartlite->{addr} = $opb->get_device_address($opb_uartlite->{size});
	               $opb_uartlite->{addrfix} = 0;
		    }

		    if (/baudrate\s*(\d+)/) {
	               $opb_uartlite->{baudrate} = eval($1);
		    }

	           if (/stdio/) {
	               $self->{stdio} = $opb_uartlite->{instance};
	           }
	           
		    push (@ldrivers, $opb_uartlite);
		    $self->{opb} = $opb;
		    $system->set_external_uart($instance);
		}

		elsif (/opb-cf-card/) {
			my $opb = $system->get_opb();
			
		    my $opb_cf_card = {
		        device => "opb-cf-card",
		        instance => "opb_cf_card_$instance",
		        owner => $instance,
		        opb => $opb->get_instance(),
		        interrupt => 0,
		        addr => 0,
	   	        addrfix => 0,
		        size => 65536,
		        write => 0,
		    };

		    if (/address\s*(\S+)/) {
		        $opb_cf_card->{addr} = eval($1);
	               $opb_cf_card->{addrfix} = 1;
		    } 	  else {
	               $opb_cf_card->{addr} = $opb->get_device_address($opb_cf_card->{size});
	               $opb_cf_card->{addrfix} = 0;
		    }
		    
		    if (/readwrite|rw/) {
			 $opb_cf_card->{write} = 1;
		    }
		    push (@ldrivers, $opb_cf_card);
		    $self->{opb} = $opb;
		    $system->set_external_cf_card($instance);
		}

		elsif (/(\d+)(k|m)\s+on.board\s+opb-ddr/) {
			my $opb = $system->get_opb();
			my $ddr = {
				device => "on-board-opb-ddr-sdram",
				instance => "on_board_opb_ddr_sdram_$instance",
				owner => $instance,
				opb => $opb->get_instance(),
				addr => 0,
				size => 0
			};

	    		my $size = eval($1);
				
	    		if ($2 eq 'k') { $size *= 1024; }
	    		elsif ($2 eq 'm') { $size *= 1024*1024; }
	    		else {
				die "unknown memory size $2";
	    		}
	    		$ddr->{size} = $size;

	    		if ($size != 256*1024*1024) {   # hack. should fix after I have other memory module to test
				die "only 256mb external memory is supported in this version";
	    		}
	    
		    if (/address\s*(\S+)/) {
		        $ddr->{addr} = eval($1);
		    } else {
	               $ddr->{addr} = 0;
		    }
		    push (@ldrivers, $ddr);
		    $self->{opb} = $opb;
		    $system->set_external_sdram($ddr);

#		    printf "external sdram addr=%x size=%x\n", $plb_ddr->{addr}, $plb_ddr->{size}

		}   # on board ddr sdram
		

	    }

	    return $self;

}


sub generate {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;

	my $fsl = 0;

	my ($slice, $bram, $mul);

	my $instance = $self->{instance};

	$slice = 897; 
	$bram = 0;
	$mul = 3; 
    
    print MHS "BEGIN microblaze\n";
    print MHS " PARAMETER INSTANCE = $instance\n";
    print MHS " PARAMETER HW_VER = 4.00.a\n";
    print MHS " PARAMETER C_DEBUG_ENABLED = 1\n";
    print MHS " PARAMETER C_NUMBER_OF_PC_BRK = 2\n";
    print MHS " PARAMETER C_NUMBER_OF_RD_ADDR_BRK = 1\n";
    print MHS " PARAMETER C_NUMBER_OF_WR_ADDR_BRK = 1\n";
    print MHS " PORT CLK = sys_clk_s\n";
    if ($#{$self->{lfsldev}}>-1) {
	printf MHS " PARAMETER C_FSL_LINKS = %d\n", $#{$self->{lfsldev}}+1;
    }
    foreach my $dev (@{$self->{lfsldev}}) {
    	print MHS " BUS_INTERFACE MFSL$fsl = ${instance}_to_$dev\n";
	print MHS " BUS_INTERFACE SFSL$fsl = ${dev}_to_$instance\n";
	$fsl++;
    }
    print MHS " BUS_INTERFACE DLMB = dlmb_$instance\n";
    print MHS " BUS_INTERFACE ILMB = ilmb_$instance\n";

    if (defined($self->{opb})) {
    		my $opb_instance = $self->{opb}->get_instance();
    		
	    print MHS " BUS_INTERFACE DOPB = $opb_instance\n";
	    print MHS " BUS_INTERFACE IOPB = $opb_instance\n";
    }
    
    if (defined($self->{barrel})) {
    	    print MHS " PARAMETER C_USE_BARREL = 1\n";
    }

    if (defined($self->{fpu})) {
    	    print MHS " PARAMETER C_USE_FPU = 1\n";
    	    $slice += 1637-897;
    	    $mul += 4;
    }

    if (defined($self->{jtag})) {
    	    print MHS " PORT DBG_CAPTURE = DBG_CAPTURE_s\n";
	    print MHS " PORT DBG_CLK = DBG_CLK_s\n";
	    print MHS " PORT DBG_REG_EN = DBG_REG_EN_s\n";
	    print MHS " PORT DBG_TDI = DBG_TDI_s\n";
	    print MHS " PORT DBG_TDO = DBG_TDO_s\n";
	    print MHS " PORT DBG_UPDATE = DBG_UPDATE_s\n";
    }

    if (defined($self->{interrupt})) {
	    print MHS " PORT INTERRUPT = $self->{interrupt}_interrupt\n";
    }

    print MHS "END\n\n";

    print MSS "BEGIN OS\n";
    print MSS " PARAMETER OS_NAME = standalone\n";
    print MSS " PARAMETER OS_VER = 1.00.a\n";
    print MSS " PARAMETER PROC_INSTANCE = $instance\n";
    if (defined($self->{stdio})) {
        print MSS " PARAMETER STDIN = $self->{stdio}\n";
        print MSS " PARAMETER STDOUT = $self->{stdio}\n";
    }
    print MSS "END\n\n";

    print MSS "BEGIN PROCESSOR\n";
    print MSS " PARAMETER DRIVER_NAME = cpu\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = $instance\n";
    print MSS " PARAMETER COMPILER = mb-gcc\n";
    print MSS " PARAMETER ARCHIVER = mb-ar\n";
    if (defined($self->{jtag})) { print MSS " PARAMETER XMDSTUB_PERIPHERAL = debug_module\n"; }
    print MSS "END\n\n";

# create mdm device and driver 

    if (defined($self->{jtag})) {
        print MHS "BEGIN opb_mdm\n";
        print MHS " PARAMETER INSTANCE = debug_module\n";
        print MHS " PARAMETER HW_VER = 2.00.a\n";
        print MHS " PARAMETER C_MB_DBG_PORTS = 1\n";
        print MHS " PARAMETER C_USE_UART = 1\n";
        print MHS " PARAMETER C_UART_WIDTH = 8\n";
        print MHS " PARAMETER C_BASEADDR = 0x41400000\n";
        print MHS " PARAMETER C_HIGHADDR = 0x4140ffff\n";
        print MHS " BUS_INTERFACE SOPB = opb_mp\n";
        print MHS " PORT OPB_Clk = sys_clk_s\n";
        print MHS " PORT DBG_CAPTURE_0 = DBG_CAPTURE_s\n";
        print MHS " PORT DBG_CLK_0 = DBG_CLK_s\n";
        print MHS " PORT DBG_REG_EN_0 = DBG_REG_EN_s\n";
        print MHS " PORT DBG_TDI_0 = DBG_TDI_s\n";
        print MHS " PORT DBG_TDO_0 = DBG_TDO_s\n";
        print MHS " PORT DBG_UPDATE_0 = DBG_UPDATE_s\n";
        print MHS "END\n\n";

        print MSS "BEGIN DRIVER\n";
        print MSS " PARAMETER DRIVER_NAME = uartlite\n";
        print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
        print MSS " PARAMETER HW_INSTANCE = debug_module\n";
        print MSS "END\n\n";
    }

	$system->area_estimate($instance, $slice, 0, 0, $bram, $mul);

# create perfcnt

    if (defined($self->{perfcnt})) {
    
        print MHS "BEGIN fsl_v20\n";
        print MHS " PARAMETER INSTANCE = ${instance}_to_perfcounter\n";
        print MHS " PARAMETER HW_VER = 2.00.a\n";
        print MHS " PARAMETER C_EXT_RESET_HIGH = 1\n";
        print MHS " PARAMETER C_FSL_DEPTH = 1\n";
        print MHS " PORT FSL_Clk = sys_clk_s\n";
        print MHS " PORT SYS_Rst = sys_bus_reset\n";
        print MHS "END\n\n";

        print MHS "BEGIN perfcounter\n";
        print MHS " PARAMETER INSTANCE = perfcounter_$instance\n";
        print MHS " PARAMETER HW_VER = 1.01.a\n";
        print MHS " BUS_INTERFACE SFSL = ${instance}_to_perfcounter\n";
        print MHS " BUS_INTERFACE MFSL = perfcounter_to_$instance\n";
        print MHS " PORT FSL_Clk = sys_clk_s\n";
        print MHS "END\n\n";

        print MHS "BEGIN fsl_v20\n";
        print MHS " PARAMETER INSTANCE = perfcounter_to_$instance\n";
        print MHS " PARAMETER HW_VER = 2.00.a\n";
        print MHS " PARAMETER C_EXT_RESET_HIGH = 1\n";
        print MHS " PARAMETER C_FSL_DEPTH = 1\n";
        print MHS " PORT FSL_Clk = sys_clk_s\n";
        print MHS " PORT SYS_Rst = sys_bus_reset\n";
        print MHS "END\n\n";

        print MSS "BEGIN DRIVER\n";
        print MSS " PARAMETER DRIVER_NAME = perfcounter\n";
        print MSS " PARAMETER DRIVER_VER = 1.01.a\n";
        print MSS " PARAMETER HW_INSTANCE = perfcounter_$instance\n";
        print MSS "END\n\n";

	 $system->copydevice("perfcounter_v1_01_a");

    }
	
# create lmb bus, on-chip  memory device

    print MHS "BEGIN lmb_v10\n";
    print MHS " PARAMETER INSTANCE = dlmb_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT LMB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MHS "BEGIN lmb_v10\n";
    print MHS " PARAMETER INSTANCE = ilmb_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT LMB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = dlmb_cntlr_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{onchip_mem_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{onchip_mem_addr}+$self->{onchip_mem_size}-1;
    print MHS " BUS_INTERFACE SLMB = dlmb_$instance\n";
    print MHS " BUS_INTERFACE BRAM_PORT = dlmb_port_$instance\n";
    print MHS "END\n\n";
    
    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = ilmb_cntlr_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{onchip_mem_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{onchip_mem_addr}+$self->{onchip_mem_size}-1;
    print MHS " BUS_INTERFACE SLMB = ilmb_$instance\n";
    print MHS " BUS_INTERFACE BRAM_PORT = ilmb_port_$instance\n";
    print MHS "END\n\n";

    print MHS "BEGIN bram_block\n";
    print MHS " PARAMETER INSTANCE = bram_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " BUS_INTERFACE PORTA = ilmb_port_$instance\n";
    print MHS " BUS_INTERFACE PORTB = dlmb_port_$instance\n";
    print MHS "END\n\n";

	$bram = $self->{onchip_mem_size}/2048;
	$system->area_estimate("bram_$instance", 0, 0, 0, $bram, 0);

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = bram\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = dlmb_cntlr_$instance\n";
    print MSS "END\n\n";

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = bram\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = ilmb_cntlr_$instance\n";
    print MSS "END\n\n";


#    foreach my $driver (@{$self->{drivers}}) {
#        print ("--driver $driver->{instance}\n");
#    }

# create pheripheral

	my $pin = $system->{instance}."_pin";

    foreach my $driver (@{$self->{drivers}}) {
        if ($driver->{device} eq "opb-uartlite") {
            print MHS "BEGIN opb_uartlite\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            print MHS " PARAMETER C_BAUDRATE = $driver->{baudrate}\n";
            print MHS " PARAMETER C_DATA_BITS = 8\n";
            print MHS " PARAMETER C_ODD_PARITY = 0\n";
            print MHS " PARAMETER C_USE_PARITY = 0\n";
            print MHS " PARAMETER C_CLK_FREQ = 100000000\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = $driver->{opb}\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            print MHS " PORT RX = ${pin}_uart0_rx\n";
            print MHS " PORT TX = ${pin}_uart0_tx\n";
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = uartlite\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
            
        }

        if ($driver->{device} eq "opb-timer") {
            print MHS "BEGIN opb_timer\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = $driver->{opb}\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            if ($driver->{interrupt} > 0) {
                print MHS " PORT Interrupt = $driver->{instance}_interrupt\n";
            }
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = tmrctr\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
        }
        
        if ($driver->{device} eq "opb-cf-card") {
        	print MHS "BEGIN opb_sysace\n";
              print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
              print MHS " PARAMETER HW_VER = 1.00.c\n";
              print MHS " PARAMETER C_MEM_WIDTH = 16\n";
              printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
              printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
              print MHS " BUS_INTERFACE SOPB = $driver->{opb}\n";
              print MHS " PORT OPB_Clk = sys_clk_s\n";
              print MHS " PORT SysACE_CLK = ${pin}_cf_card_CLK\n";
              print MHS " PORT SysACE_MPA = ${pin}_cf_card_MPA\n";
              print MHS " PORT SysACE_MPD = ${pin}_cf_card_MPD\n";
              print MHS " PORT SysACE_CEN = ${pin}_cf_card_CEN\n";
              print MHS " PORT SysACE_OEN = ${pin}_cf_card_OEN\n";
              print MHS " PORT SysACE_WEN = ${pin}_cf_card_WEN\n";
              print MHS " PORT SysACE_MPIRQ = ${pin}_cf_card_MPIRQ\n";
              print MHS "END\n\n";

             print MSS "BEGIN DRIVER\n";
             print MSS " PARAMETER DRIVER_NAME = sysace\n";
             print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
             print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
             print MSS "END\n\n";
            
             print MSS "BEGIN LIBRARY\n";
             print MSS " PARAMETER LIBRARY_NAME = xilfatfs\n";
             print MSS " PARAMETER LIBRARY_VER = 1.00.a\n";
             print MSS " PARAMETER CONFIG_WRITE = true\n";
             print MSS " PARAMETER CONFIG_MAXFILES = 2\n";
             print MSS " PARAMETER CONFIG_BUFCACHE_SIZE = 1280\n";
             print MSS " PARAMETER PROC_INSTANCE = $instance\n";
             print MSS "END\n\n";
        }  # opb-cf-card

        if ($driver->{device} eq "on-board-opb-ddr-sdram") {

             print MHS "# DDR_256MB_32MX64_rank1_row13_col10_cl2_5\n";
             
	        print MHS "BEGIN opb_ddr\n";
	        print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
	        print MHS " PARAMETER HW_VER = 2.00.b\n";
	        print MHS " PARAMETER C_OPB_CLK_PERIOD_PS = 10000\n";
	        print MHS " PARAMETER C_NUM_BANKS_MEM = 1\n";
	        print MHS " PARAMETER C_NUM_CLK_PAIRS = 4\n";
	        print MHS " PARAMETER C_REG_DIMM = 0\n";
	        print MHS " PARAMETER C_DDR_TMRD = 20000\n";
	        print MHS " PARAMETER C_DDR_TWR = 20000\n";
	        print MHS " PARAMETER C_DDR_TRAS = 60000\n";
	        print MHS " PARAMETER C_DDR_TRC = 90000\n";
	        print MHS " PARAMETER C_DDR_TRFC = 100000\n";
	        print MHS " PARAMETER C_DDR_TRCD = 30000\n";
	        print MHS " PARAMETER C_DDR_TRRD = 20000\n";
	        print MHS " PARAMETER C_DDR_TRP = 30000\n";
	        print MHS " PARAMETER C_DDR_TREFC = 70300000\n";
	        print MHS " PARAMETER C_DDR_AWIDTH = 13\n";
	        print MHS " PARAMETER C_DDR_COL_AWIDTH = 10\n";
	        print MHS " PARAMETER C_DDR_BANK_AWIDTH = 2\n";
	        print MHS " PARAMETER C_DDR_DWIDTH = 64\n";
	        printf MHS " PARAMETER C_MEM0_BASEADDR = 0x%08x\n", $driver->{addr};
	        printf MHS " PARAMETER C_MEM0_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
	        print MHS " BUS_INTERFACE SOPB = $driver->{opb}\n";
	        print MHS " PORT OPB_Clk = sys_clk_s\n";
	        print MHS " PORT DDR_Addr = ${pin}_DDR_Addr\n";
	        print MHS " PORT DDR_BankAddr = ${pin}_DDR_BankAddr\n";
	        print MHS " PORT DDR_CASn = ${pin}_DDR_CASn\n";
	        print MHS " PORT DDR_CKE = ${pin}_DDR_CKE\n";
	        print MHS " PORT DDR_CSn = ${pin}_DDR_CSn\n";
	        print MHS " PORT DDR_RASn = ${pin}_DDR_RASn\n";
	        print MHS " PORT DDR_WEn = ${pin}_DDR_WEn\n";
	        print MHS " PORT DDR_DM = ${pin}_DDR_DM\n";
	        print MHS " PORT DDR_DQS = ${pin}_DDR_DQS\n";
	        print MHS " PORT DDR_DQ = ${pin}_DDR_DQ\n";
	        print MHS " PORT DDR_Clk = ${pin}_DDR_Clk & ddr_clk_feedback_out_s\n";
	        print MHS " PORT DDR_Clkn = ${pin}_DDR_Clkn & 0b0\n";
	        print MHS " PORT Device_Clk90_in = clk_90_s\n";
	        print MHS " PORT Device_Clk90_in_n = clk_90_n_s\n";
	        print MHS " PORT Device_Clk = sys_clk_s\n";
	        print MHS " PORT Device_Clk_n = sys_clk_n_s\n";
	        print MHS " PORT DDR_Clk90_in = ddr_clk_90_s\n";
	        print MHS " PORT DDR_Clk90_in_n = ddr_clk_90_n_s\n";
	        print MHS "END\n\n";

	        $system->area_estimate($driver->{instance}, 1322, 0, 0, 0, 0); 

	        print MSS "BEGIN DRIVER\n";
	        print MSS " PARAMETER DRIVER_NAME = ddr\n";
	        print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
	        print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
	        print MSS "END\n\n";
		
        }  # on-board-ddr-sdram

        
    }

}

1;

