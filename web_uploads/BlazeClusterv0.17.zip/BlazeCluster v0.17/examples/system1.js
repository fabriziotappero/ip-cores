microblaze_0, microblaze, opb-master, 64k on-chip ram, 256m on-board opb-ddr sdram address 0x30000000, jtag, barrel-shifter, opb-uartlite baudrate 9600 stdio, opb-cf-card readwrite

