ppc0, powerpc, 32k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, plb-dcr-vga-controller, 256m on-board plb-ddr sdram address 0x30000000
mb0, microblaze, 8k on-chip ram, barrel-shifter, fpu
mb1, microblaze, 8k on-chip ram, barrel-shifter, fpu
mb2, microblaze, 8k on-chip ram, barrel-shifter, fpu
mb3, microblaze, 8k on-chip ram, barrel-shifter, fpu
dp_ppc0_mb0, dpram, 8k, left ppc0 address 0x20000000, right mb0
dp_ppc0_mb1, dpram, 8k, left ppc0 address 0x20100000, right mb1
dp_ppc0_mb2, dpram, 8k, left ppc0 address 0x20200000, right mb2
dp_ppc0_mb3, dpram, 8k, left ppc0 address 0x20300000, right mb3
