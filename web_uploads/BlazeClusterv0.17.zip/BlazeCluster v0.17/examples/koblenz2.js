ppc0, powerpc, 32k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, plb-dcr-vga-controller, 256m on-board plb-ddr sdram address 0x30000000
mb0, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb1, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
dp_ppc0_mb0, dpram, 8k, left ppc0 address 0x20000000, right mb0
dp_ppc0_mb1, dpram, 8k, left ppc0 address 0x20100000, right mb1
mbman, sw-project on mb0 mb1, source mb-man.c, c-flags -DMBMAN
mandelbrot, sw-project on ppc0, source mandel.c xupv2p.c, c-flags -D__SHOWPROGRESS -DNUM_COPROC=2, linkscript mandelbrot_linker_script
