###################################################
# 
#   BlazeCluster  dpram.pm  $version
#   <www.opencores.org/projects.cgi/web/mpdma> by SunWei
#
#   Generate multiprocessor architecture on FPGA
# 
#   Dual port memory object
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#   You can also get a copy of the license through the web at
#   <http://www.gnu.org/licenses/gpl.html>
#
###################################################

package Dpram;

use strict;
use warnings;
use Carp;

sub new {
    my $class = shift;
    my $self = {@_};

    bless($self, $class);

    $self->{com} = "dpram";
    return $self;
}

sub findprocessor {
	my $self = shift;
	my $system = shift;
	my $proc_instance = shift;

	foreach my $proc (@{$system->{lproc}}) {
		if ($proc_instance eq $proc->get_instance()) {
			return $proc;
		}
	}

	die "can't find processor $proc_instance for $self->{instance}";
	
}

sub read() {
	my $self = shift;
	my $system = shift;
	my $instance = shift;

	$self->{instance} = $instance;

	    foreach (@_) {

	        if (/(\d+)(k|m)/) {
	            my $size = eval($1);
		    if ($2 eq 'k') { $size *= 1024; }
		    else { $size *= 1024*1024; }
		    $self->{size} = $size;
	        }

	        if (/left\s*(\S*)/) {
	            $self->{left} = $1;
	            my $proc = $self->findprocessor($system, $self->{left});
	            if ($proc->get_com() eq "powerpc") {
				$proc->{dsocm} = 1;
	            }
	            $self->{left_proc} = $proc;
	            
	            if (/address\s*(\S+)/) {
	                $self->{left_addr} = eval($1);
	            } else {
	                $self->{left_addr} = 0;
	            }
	        }

	         if (/right\s*(\S*)/) {
	            $self->{right} = $1;
	            my $proc = $self->findprocessor($system, $self->{right});
	            if ($proc->get_com() eq "powerpc") {
				$proc->{dsocm} = 1;
	            }
	            $self->{right_proc} = $proc;
	            
	            if (/address\s*(\S+)/) {
	                $self->{right_addr} = eval($1);
	            } else {
	                $self->{right_addr} = $self->{left_addr};
	            }
	        }
	       
	    }

    return $self;

}

sub generate() {
	my $self = shift;
	my $system = shift;
	*MHS = shift;
	*MSS = shift;
	*UCF = shift;

	my $instance = $self->{instance};

	my $left = $self->{left};
	my $right = $self->{right};

	my $proc = $self->{left_proc};
	if ($proc->get_com() eq "powerpc") {
	    print MHS "BEGIN dsbram_if_cntlr\n";
	    print MHS " PARAMETER INSTANCE = dsbram_cntlr_${instance}_left\n";
	    print MHS " PARAMETER HW_VER = 3.00.a\n";
	    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{left_addr};
	    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{left_addr}+$self->{size}-1;
	    print MHS " PARAMETER C_RANGECHECK = 1\n";
	    print MHS " BUS_INTERFACE DSOCM = dsocm_$left\n";
	    print MHS " BUS_INTERFACE PORTA = dpram_${instance}_left_port\n";
	    print MHS "END\n\n";
	} else {
	    print MHS "BEGIN lmb_bram_if_cntlr\n";
	    print MHS " PARAMETER INSTANCE = ilmb_cntlr_${instance}_left\n";
	    print MHS " PARAMETER HW_VER = 1.00.b\n";
	    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{left_addr};
	    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{left_addr}+$self->{size}-1;
	    print MHS " BUS_INTERFACE SLMB = dlmb_$left\n";
	    print MHS " BUS_INTERFACE BRAM_PORT = dpram_${instance}_left_port\n";
	    print MHS "END\n\n";
    	}

	$proc = $self->{right_proc};
	if ($proc->get_com() eq "powerpc") {
	    print MHS "BEGIN dsbram_if_cntlr\n";
	    print MHS " PARAMETER INSTANCE = dsbram_cntlr_${instance}_right\n";
	    print MHS " PARAMETER HW_VER = 3.00.a\n";
	    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{right_addr};
	    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{right_addr}+$self->{size}-1;
	    print MHS " PARAMETER C_RANGECHECK = 1\n";
	    print MHS " BUS_INTERFACE DSOCM = dsocm_$right\n";
	    print MHS " BUS_INTERFACE PORTA = dpram_${instance}_right_port\n";
	    print MHS "END\n\n";
	} else {
	    print MHS "BEGIN lmb_bram_if_cntlr\n";
	    print MHS " PARAMETER INSTANCE = ilmb_cntlr_${instance}_right\n";
	    print MHS " PARAMETER HW_VER = 1.00.b\n";
	    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $self->{right_addr};
	    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $self->{right_addr}+$self->{size}-1;
	    print MHS " BUS_INTERFACE SLMB = dlmb_$right\n";
	    print MHS " BUS_INTERFACE BRAM_PORT = dpram_${instance}_right_port\n";
	    print MHS "END\n\n";
	    }

    print MHS "BEGIN bram_block\n";
    print MHS " PARAMETER INSTANCE = bram_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " BUS_INTERFACE PORTA = dpram_${instance}_left_port\n";
    print MHS " BUS_INTERFACE PORTB = dpram_${instance}_right_port\n";
    print MHS "END\n\n";

    my $bram = $self->{size}/2048;
    $system->area_estimate("bram_$instance", 0, 0, 0, $bram, 0);
    
}

# dp-m-vlc, dpram, 8k, left mb-m address 0x20000000, right mb-vlc address 0x20000000

1;


