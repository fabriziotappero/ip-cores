Project: pipelined AVR (pAVR) controller
Author:  Doru Cuturela, doruu@yahoo.com
Date:    2002 August
License: GNU General Public License



For details about this project please check the compiled documentation in
   either /doc/chm or /doc/html folders. In /doc/chm is placed a compressed HTML
   format documentation, while /doc/html holds the HTML version of the same
   documentation.
