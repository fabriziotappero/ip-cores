===============================================================================
 vga80x40 - A monochrome text-mode video display adapter for vga monitors
 
 Project web page is at http://javiervalcarce.es
 MIT License
===============================================================================



2008-09-20

Alessandro was kind enough to send me a patch to fix a little misalignment in 
the first screen's column. To apply the fix (I have no tested it) replace the
original vga80x40.vhd file by vga80x40_col1fixed.vhd

Thank you Alessandro!

