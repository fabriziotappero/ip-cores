#ifndef __JOBS_H
#define __JOBS_H

portBASE_TYPE xJob(pdTASK_CODE funcPtr, void *arg0, void *arg1, void *arg2);

#endif
