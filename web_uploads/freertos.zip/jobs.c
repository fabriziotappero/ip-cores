#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#define MAX_JOBS	100

/***************** Jobs *******************/
typedef void (*JobFunc_t)();

static xQueueHandle jobQueue;
static xTaskHandle  jobThread;

static void xJobThread(void *pvParameters)
{
   unsigned int message[4];
   JobFunc_t funcPtr;
   for(;;)
   {
      xQueueReceive(jobQueue, (void *)message, portMAX_DELAY);
      funcPtr = (JobFunc_t)message[0];
      funcPtr(message[1], message[2], message[3]);
   }
}

/******************************************/
portBASE_TYPE xJob(pdTASK_CODE funcPtr, void *arg0, void *arg1, void *arg2)
{
   unsigned int message[4];
   portBASE_TYPE rc;

   if(jobThread == 0)		// new thread and queue for batch processing
   {
      jobQueue = xQueueCreate(MAX_JOBS, 16);
      rc = xTaskCreate(xJobThread, "JOBQ", 3000, 0, tskIDLE_PRIORITY, &jobThread);
      if(rc != pdPASS) { /* error creating thread */ }
   }
   message[0] = (unsigned int)funcPtr;
   message[1] = (unsigned int)arg0;
   message[2] = (unsigned int)arg1;
   message[3] = (unsigned int)arg2;
   
   rc = xQueueSend(jobQueue, (void *) message, portMAX_DELAY);
   return rc;
}
