
#ifndef __STL_MBSTATE_H__
#define __STL_MBSTATE_H__

struct mbstate_t
{
   int __fill[6];
};

#endif



