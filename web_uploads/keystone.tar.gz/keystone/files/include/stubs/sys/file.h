
#ifndef _SYS_FILE_H_
#define _SYS_FILE_H_

/*
 * GCC 3.3
 */

int flock (int fd, int operation);

#endif
