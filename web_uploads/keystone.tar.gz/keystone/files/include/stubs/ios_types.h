
#ifndef __STD_IOS_TYPES
#define __STD_IOS_TYPES

namespace std
{
   typedef unsigned int streamoff;
   typedef unsigned int streamsize;
}   

#endif
