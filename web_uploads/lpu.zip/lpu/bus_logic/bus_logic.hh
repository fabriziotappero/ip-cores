/***** Open Source Hardware *****/
/*

filename bus_logic.hh

description: header file for bus_logic.cc

Credits 
Brian Korsedal - Author of first draft

*/

public class bus_logic {
  /* data is passed in address_data_pair format where bits
  [63:61] = East/West bits (two bits)
  [60:58] = North/South bits (three bits)
  [57:32] = operation code
  [31:0]  = data
  */
private:
  address_data_pair  north_buffer[16];
  char north_write;
  char north_read;
  address_data_pair  east_buffer[16];
  char east_write;
  char east_read;
  address_data_pair  south_buffer;[16] 
  char south_write;
  char south_read;
  address_data_pair  west_buffer[16];
  char west_write;
  char west_read;
  address_data_pair  i_op_buffer[16];
  char i_op_write;
  char i_op_read;

  address_data_pair  o_op_buffer[16];
  char o_op_write;
  char o_op_read;


public:
  
  bus_logic(address A);
  ~bus_logic();
  address  a; 
  
int process_input(address i_a, char *read, char *write, address_data_pair *start)
int write_to_buffer(char *read, char *write, address_data_pair *start, address_data_pair i_data)
int get_buffer(char buffer, char *read, char *write, address_data_pair *start)
int check_for_read(char *read, char *write, address_data_pair *start, address_data_pair *o_data)

};



