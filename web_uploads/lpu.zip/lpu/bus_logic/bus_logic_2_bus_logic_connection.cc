/***** Open Source Hardware *****/
/*

filename bus_logic_2_bus_logic_connection.cc

description: a bus logic unit is described in the hardware spec.  This is a C++
implimentation that should mimic it the connection between two bus logic units.  Every time
step is called, it should pass data on this connection between the two bus logic units.  If a buffer is full on the recieve side, it 
should not pass data on that side of the connection.  If a buffer is empty on the transmit side, it should not pass data on that side
of the connection.

Credits 
Brian Korsedal - Author of first draft

*/

#include "bus_logic_2_bus_logic_connection.hh"

bus_logic_2_bus_logic_connection::bus_logic_2_bus_logic_connection(bus_logic *U1, bus_logic *U2)
{
  
  if(U1.a.ewb==U2.a.ewb){
    //if it's a North/South connection
    if(U1.a.nsb==U2.a.nsb){
      printf("illogical conneciton\n");
    }else{ direction_of_connection = 1;
    if(U1.a.nsb>U2.a.nsb){
      nwunit=U1;
      seunit =U2;
    }else{
      nwunit=U2;
      seunit = U1;
    }
    }
  }else{
    //if it's an East/West connection
    direction_of_connection = 0;
    if(U1.a.ewb>U2.a.ewb){
      nwunit=U1;
      seunit=U2;
    }else{
      nwunit=U2;
      seunit=U1;
    }
    traffic_meter = 0;
  }
}

bus_logic_2_bus_logic_connection::~bus_logic_2_bus_logic_connection(){}

/* functions for bus_logic:
  int process_input(address i_a, char *read, char *write, address_data_pair *start)
  int write_to_buffer(char *read, char *write, address_data_pair *start, address_data_pair i_data)
  int get_buffer(char buffer, char *read, char *write, address_data_pair *start)
  int check_for_read(char read, char write, address_data_pair *start, address_data_pair *o_data)
*/
int bus_logic_2_bus_logic_connection:: step(){
  char *read;
  char *hold_onto_read;
  char *write;
  address_data_pair *start;
  address_data_pair ad;  
  int error = 1;
  if(direction_of_connection==0){
    //transmit from West unit to East unit
    if(nwunit.get_buffer(EAST,hold_onto_read,write,start)==0){
      if(*hold_onto_read!=*write){
        ad=*(start+*hold_onto_read);
	if(seunit.process_input(ad.a,read,write,start)==0){
	  if(seunit.write_to_buffer(read,write,start,ad)==0){
	    hold_onto_read++;
	    traffic_meter++;
	    error=0;
	  }
	}
      }
    }
    //transmit from East to West unit
    if(seunit.get_buffer(WEST,hold_onto_read,write,start)==0){
      if(*hold_onto_read!=*write){
        ad=*(start+*hold_onto_read);
	if(nwunit.process_input(ad.a,read,write,start)==0){
	  if(nwunit.write_to_buffer(read,write,start,ad)==0){
	    hold_onto_read++;
	    traffic_meter++;
	    error=0;
	  }
	}
      }
    }  
    //handle traffic meter
    traffic_meter*=TRAFFIC_COEF;
    error=0;
  }else  if(direction_of_connection==1){
    //transmit from North unit to South unit
    if(nwunit.get_buffer(SOUTH,hold_onto_read,write,start)==0){
      if(*hold_onto_read!=*write){
        ad=*(start+*hold_onto_read);
	if(seunit.process_input(ad.a,read,write,start)==0){
	  if(seunit.write_to_buffer(read,write,start,ad)==0){
	    hold_onto_read++;
	    traffic_meter++;
	    error=0;
	  }
	}
      }
    }
    //transmit from South unit to North unit
    if(seunit.get_buffer(NORTH,hold_onto_read,write,start)==0){
      if(*hold_onto_read!=*write){
        ad=*(start+*hold_onto_read);
	if(nwunit.process_input(ad.a,read,write,start)==0){
	  if(nwunit.write_to_buffer(read,write,start,ad)==0){
	    hold_onto_read++;
	    traffic_meter++;
	    error=0;
	  }
	}
      }
    }      
    //handle traffic meter
    traffic_meter*=TRAFFIC_COEF;
    error=0;
  }else{
    printf("connection not properly initialized (use constructor first)");
  }
  return error; 
}











