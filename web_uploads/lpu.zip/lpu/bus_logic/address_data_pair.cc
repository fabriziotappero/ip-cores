/***** Open Source Hardware *****/
/*


Credits 
Brian Korsedal - Author of first draft

*/
#ifndef GLOBAL_INCLUDES      
#include "global_defines.cc"
#define GLOBAL_INCLUDES 1
#endif

#include "address_data_pair.hh"

address_data_pair::address_data_pair(address A, int D){
  a = A;
  d = D;
}
  





