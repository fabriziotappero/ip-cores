/***** Open Source Hardware *****/
/*

filename bus_logic.cc

description: a bus logic unit is described in the hardware spec.  This is a C++
implimentation that should mimic it.  It should handle all of the functions internal to the bus logic.
The connection between bus logic units will be handled by another class called bus_logic_connection.
This class with be a loop that simulates a connection between bus logic units.  It will pass one pair of values
(two 64-bit values passed between bus logic units) and then sleep until called again. 
Values should travel East/West first and then North/South to their destination.  Each bus logic unit will have an 
 address which will be used to figure out which way to send data.  Each output port is has a 16 value buffer.

Credits 
Brian Korsedal - Author of first draft

*/

#ifndef GLOBAL_INCLUDES      
#include "global_defines.cc"
#define GLOBAL_INCLUDES 1
#endif

#include "bus_logic.hh"

int bus_logic::process_input(address i_a, char *read, char *write, address_data_pair *start){
    int error = 1;
    if(i_a.ewb==ewb)
      {
	if(i_a.nsb==nsb){
	  read = &op_read;
	  write=&op_write;
	  start=&op_buffer;
	  error=0;
	}
	else if(i_a.nsb>nsb){
	  read = &north_read;
	  write=&north_write;
	  start=&north_buffer;
	  error=0;
	}
	else if(i_a.nsb<nsb){
	  read = &south_read;
	  write=&south_write;
	  start=&south_buffer;
	  error=0;
	}
      }
    else if(i_a.ewb>ewb){
      read = &west_read;
      write=&west_write;
      start=&west_buffer;
      error=0;
    }
    else if(i_a.web<ewb){
      read=&east_read;
      write=&east_write;
      start=&east_start;
      error=0;
    }
    return error;
}

int bus_logic::write_to_buffer(char *read, char *write, address_data_pair *start, address_data_pair i_data){
  int error = 1;
  //perform action with error checking and looping of write address
  if(!(*this_write == (this_read-1))&!((*this_write==15)&(this_read==0))){
    error=0;
    if(*this_write==15){
      *this_write=0;//loop write address to zero for this buffer
      *this_start=i_data;//put data in this_start's position in the array
    }else{
      *this_write++;//incriment write address on this buffer
      this_start+=*this_write;//incriment this_start to point to the desired location in array
      *this_start=i_data;//put data in this_start's position in the array
    }
  }
  return error;
}

int bus_logic::get_buffer(char buffer, char *read, char *write, address_data_pair *start){
  error = 1;
  switch(buffer){
  case I_OP:
    read =&i_op_read;
    write=&i_op_write;
    start=&i_op_buffer;
    error=0;
    break;
  case O_OP:
    read =&o_op_read;
    write=&o_op_write;
    start=&o_op_buffer;
    error=0;
    break;
  case NORTH:
    read = &north_read;
    write=&north_write;
    start=&north_buffer;
    error=0;
    break;
  case SOUTH:
    read = &south_read;
    write=&south_write;
    start=&south_buffer;
    error=0;
    break;  
  case WEST:
    read = &west_read;
    write=&west_write;
    start=&west_buffer;
    error=0;
    break;
  case EAST:
    read=&east_read;
    write=&east_write;
    start=&east_start;
    error=0;
    break;
  }
  return error;
}

int bus_logic::check_for_read(char *read, char *write, address_data_pair *start, address_data_pair *o_data){
    int error = 1;
    // pick proper buffer
    //perform action with error checking and looping of write address
    if((read == write){//buffer not empty
      this_start+=*this_read;
      o_data=this_start;//put this_start's address on the output (pass by reference pointer)
      error = 0;
    }
      return error;
}


  
      
      





