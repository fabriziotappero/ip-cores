/***** Open Source Hardware *****/
/*

filename bus_logic.cc

description: a bus logic unit is described in the hardware spec.  This is a C++
implimentation that should mimic it.  It should handle all of the functions internal to the bus logic.
The connection between bus logic units will be handled by another class called bus_logic_connection.
This class with be a loop that simulates a connection between bus logic units.  It will pass one pair of values
(two 64-bit values passed between bus logic units) and then sleep until called again. 
Values should travel East/West first and then North/South to their destination.  Each bus logic unit will have an 
 address which will be used to figure out which way to send data.  Each output port is has a 16 value buffer.

Credits 
Brian Korsedal - Author of first draft

*/

#include "bus_logic.hh"

int bus_logic::process_input(long long i_direction, char *buffer){
    int error = 0;
    char i_e_w_bits = (char)(i_direction>>61);
    char i_n_s_bits = (char)((i_direction<<3)>>61);
    if(i_e_w_bits==e_w_bits){
      if(i_n_s_bits==n_s_bits){buffer=OP}
      else if(i_n_s_bits>n_s_bits){buffer=NORTH;}
      else if(i_n_s_bits<n_s_bits){buffer=SOUTH;}
      else {error = 1;}
    }else if(i_e_w_bits>e_w_bits){buffer=WEST;}
    else if(i_e_w_bits<e_w_bits){buffer=EAST;}
    else{error = 1;}
    return error;
}

int bus_logic::check_for_write(long long i_data,char buffer){
    int error = 0;
    char this_read;
    char this_write;
    // pick proper buffer
    switch(buffer){
      case NORTH : 
         this_read = north_read;
         this_write = north_write;
         break;
      case SOUTH : 
         this_read = south_read;
         this_write = south_write;
         break;
      case EAST : 
         this_read = east_read;
         this_write = east_write;
         break;
      case WEST : 
         this_read = west_read;
         this_write = west_write;
         break;
      case OP : 
         this_read = op_read;
         this_write = op_write;
         break;
    default : 
      error = 1;
      break;
    }
    //check to see if we can write
    if(this_write == (this_read-1)){error==1;/*buffer full*/}
    else if((this_write==15)&(this_read==0)){error==1;/*buffer full*/}
    return error;
}

int bus_logic::write_to_buffer(long long i_data,char buffer){
    int error = 0;
    char this_read;
    char *this_write;
    long long *this_start;
    // pick proper buffer
    switch(buffer){
      case NORTH : 
         this_read = north_read;
         this_write = &north_write;
         this_start = north_start;
         break;
      case SOUTH : 
         this_read = south_read;
         this_write = &south_write;
         this_start = south_start;
         break;
      case EAST : 
         this_read = east_read;
         this_write = &east_write;
         this_start = east_start;
         break;
      case WEST : 
         this_read = west_read;
         this_write = &west_write;
         this_start = west_start;
         break;
      case OP : 
         this_read = op_read;
         this_write = &op_write;
         this_start = op_start;
         break;
    default : 
      error = 1;
      break;
    }
    //perform action with error checking and looping of write address
    if(*this_write == (this_read-1)){error==1;/*buffer full*/}
    else if((*this_write==15)&(this_read==0)){error==1;/*buffer full*/}
    else if(*this_write==15){
      *this_write=0;//loop write address to zero for this buffer
      *this_start=i_data;//put data in this_start's position in the array
    }else{
      *this_write++;//incriment write address on this buffer
      this_start+=*this_write;//incriment this_start to point to the desired location in array
      *this_start=i_data;//put data in this_start's position in the array
    }
    return error;
}

int bus_logic::check_for_read(long long *o_data,char buffer){
    int error = 0;
    char this_read;
    char this_write;
    long long *this_start;
    // pick proper buffer
    switch(buffer){
      case NORTH : 
         this_read = north_read;
         this_write = north_write;
         this_start = north_start;
         break;
      case SOUTH : 
         this_read = south_read;
         this_write = south_write;
         this_start = south_start;
         break;
      case EAST : 
         this_read = east_read;
         this_write = east_write;
         this_start = east_start;
         break;
      case WEST : 
         this_read = west_read;
         this_write = west_write;
         this_start = west_start;
         break;
    default : 
      error = 1;
      break;
    }
    //perform action with error checking and looping of write address
    if(*this_read == this_write){error==1;/*buffer empty*/}
    else{
      this_start+=*this_read;
      o_data=this_start;//put this_start's address on the output (pass by reference pointer)
    }
      return error;
}

int bus_logic::read_from_buffer(long long *o_data,char buffer){
    int error = 0;
    char *this_read;
    char this_write;
    long long *this_start;
    // pick proper buffer
    switch(buffer){
      case NORTH : 
         this_read = &north_read;
         this_write = north_write;
         this_start = north_start;
         break;
      case SOUTH : 
         this_read = &south_read;
         this_write = south_write;
         this_start = south_start;
         break;
      case EAST : 
         this_read = &east_read;
         this_write = east_write;
         this_start = east_start;
         break;
      case WEST : 
         this_read = &west_read;
         this_write = west_write;
         this_start = west_start;
         break;
      case OP : 
         this_read = &op_read;
         this_write = op_write;
         this_start = op_start;
         break;
    default : 
      error = 1;
      break;
    }
    //perform action with error checking and looping of write address
    if(*this_read == this_write){error==1;/*buffer empty*/}
    else if(*this_read==15){
      o_data = this_start;//put this_start's address on the output (pass by reference pointer)
      *this_read=0;//loop read address to zero for this buffer
    }else{
      this_start+=*this_read;
      o_data=this_start;//put this_start's address on the output (pass by reference pointer)
      *this_read++;//incriment read address on this buffer
    }
      return error;
}

  





