/***** Open Source Hardware *****/
/*

filename bus_logic_2_bus_logic_connection.hh

header for bus_logic_2_bus_logic_connection.cc

Credits 
Brian Korsedal - Author of first draft

*/

public class bus_logic_2_bus_logic_connection {
  bus_logic *n_w_unit;
  bus_logic *s_e_unit;
  bool direction_of_connection; //0 = East/West connection, 1 = North/South connection
  float traffic_meter;

public:
  // constructors and destructors
  bus_logic_2_bus_logic_connection(bus_logic *U1, bus_logic *U2);
 ~bus_logic_2_bus_logic_connection();
  
  void step();
}


