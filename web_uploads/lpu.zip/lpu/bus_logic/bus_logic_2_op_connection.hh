/***** Open Source Hardware *****/
/*

filename bus_logic.hh

description: header file for bus_logic.cc

Credits 
Brian Korsedal - Author of first draft

*/

public class bus_logic {
  /* data is passed in long long format where bits
  [63:61] = East/West bits (two bits)
  [60:58] = North/South bits (three bits)
  [57:32] = operation code
  [31:0]  = data
  */
private:
  long long  north_buffer[16];
  long long  east_buffer[16];
  long long  south_buffer;[16] 
  long long  west_buffer[16];
  long long  op_buffer[16];
  long long *north_start;
  long long *east_start;
  long long *south_start;
  long long *west_start;
  long long *op_start;
  char north_write;
  char north_read;
  char east_write;
  char east_read;
  char south_write;
  char south_read;
  char west_write;
  char west_read;
  char op_write;
  char op_read;
  char n_s_bits;
  char e_w_bits;

public:
  
  bus_logic(char address_extention);
  ~bus_logic();
  char  address_extention; 
  /* address format is 6 bits 
     this gives us 32 ops, 16 locations inside TC and 16 external connections (these may change)
  [5:3] = East/West bits (three bits)
  [2:0] = North/South bits (three bits)
  */
  int process_input(long long i_direction, char *buffer);
  int check_for_write(long long i_data,char buffer);
  int write_to_buffer(long long i_data,char buffer);
  int check_for_read(long long *o_data,char buffer);
  int read_from_buffer(long long *o_data,char buffer);
};



