/***** Open Source Hardware *****/
/*

Credits 
Brian Korsedal - Author of first draft

*/

public class address_data_pair {
public:
  address_data_pair(address A, int D);
  ~address_data_pair();
  address a;
  int d;
}
