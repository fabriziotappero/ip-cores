/***** Open Source Hardware *****/
/*

Credits 
Brian Korsedal - Author of first draft

*/

public class address{
public:

  address(short value);
  ~address();
  char ewb;
  char nsb;
  char opc;
  char buf;
}
