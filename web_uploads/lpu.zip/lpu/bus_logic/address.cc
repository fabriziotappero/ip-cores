/***** Open Source Hardware *****/
/*

Credits 
Brian Korsedal - Author of first draft

*/

#ifndef GLOBAL_INCLUDES      
#include "global_defines.cc"
#define GLOBAL_INCLUDES 1
#endif

#include "address.hh"

address::address(short value){
  ewb = (char) value>>13;
  nsb = (char) (value<<3)>>13;
  opc = (char) (value<<6)>>14;
  buf = (char) (value<<8)>>8;
}

address::~address(){}
  





