/***** Open Source Hardware *****/
/*

filename op.cc

description: This is the code for an actual OP.  There will be many different ops.  They should
all be in here.

Credits 
Brian Korsedal - Author of first draft

*/

#include "op.hh"
op::op(char type_of_op){}
op::~op(){}

int op::perform_op(long a, long b, long *r){}



  





