/***** Open Source Hardware *****/
/*

filename bus_logic.hh

description: header file for op.cc

Credits 
Brian Korsedal - Author of first draft

*/

public class op_unit {

  /* inside the op, the incoming data is converted to two groups,
  integers for the data and address portions.

  [31:29] = East/West bits (three bits)
  [28:26] = North/South bits (three bits)
  [25:0] = operation code
  
  [31:0]  = data
  */
private:
  long mem_a[64];
  long long stat_a;

  long mem_b[64];
  long long stat_b;

  char counter_ab;

  long mem_r[64];
  long long stat_r;

  long mem_d[64];
  long long stat_d;

  char counter_rd;


public:
  
  op_unit();
  ~op_unit();

  long long reserved_locations;

  int process_input(long i_, char *buffer);
  int write_to_buffer(long i_data,char buffer,char addr);
  int read_from_buffer(long *o_data,char buffer,char addr);
  int find_next_pair(long long *stat1, long long *stat2, char *addr char *counter);

};



