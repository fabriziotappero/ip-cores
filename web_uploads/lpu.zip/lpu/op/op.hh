/***** Open Source Hardware *****/
/*

filename op.hh

description: header file for op.cc

Credits 
Brian Korsedal - Author of first draft

*/

public class op {

char op_type;

public:
  op(char type_of_op);
  ~op();

  int perform_op(long a, long b, long *r);

}
