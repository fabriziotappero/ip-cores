/***** Open Source Hardware *****/
/*
  
filename op_unit.cc

description: This is the code for an OP_unit and surrounding hardware.  It should contain everything inside an OP_unit function 
found in the spec.

Credits 
Brian Korsedal - Author of first draft

*/

#include "op_unit.hh"

op_unit::op_unit(bus_logic *BUS_LOGIC,op *OPERATION){
  operation=OPERATION;
  blu = *BUS_LOGIC;
}
op_unit::~op_unit();

int op_unit::step(){
  int error = 1;
  char temp_count;
  char *read;	
  char *write;
  address_data_pair *start;
  address_data_pair ad;
  //load input from bus logic	
  if(*blu.get_buffer(I_OP,read,write,start)==0){
    start+=read;//move pointer to the read position
    switch(*start.a.opc){
    case MEM_A:
      stat_a=stat_a|(1<<*start.a.buf);
      mem_a[*start.a.buf]=*start.d;
      error = error|0x02;
      break;
    case MEM_B:
      stat_b=stat_b|(1<<*start.a.buf);
      mem_b[*start.a.buf]=*start.d;
      error = error|0x02;
      break;
    case MEM_D:
      stat_d=stat_d|(1<<*start.a.buf);
      mem_d[*start.a.buf]=*start.d;
      error = error|0x02;
      break;
    }
    //look for ready ab pair
    if((stat_a&stat_b)!=0) { //pair found
      while(((stat_a&stat_b)&(1<<ab_counter))==0){
	if((ab_counter++)==63) ab_counter=0;//incriment counter and handle roll over conditions
      }
      stat_a=stat_a^(1<<ab_counter);
      stat_b=stat_b^(1<<ab_counter);//cleared a and b stat bits
      ab_counter++;//incriment counter so that we start next search at next entry	  
      if((operation(mem_a[*start.a.buf],mem_b[*start.a.buf],&mem_r[*start.a.buf]))==0){error=error|0x04;}
    }//end of found pair statement
    
    //look for ready rd pair (only clear d stat)
    if((stat_r&stat_d)!=0) { //pair found
      while(((stat_r&stat_d)&(1<<rd_counter))==0){
	if((rd_counter++)==63) rd_counter=0;
      }//set rd_counter to right location
      // handle bottom 16 of destination memory value
      if((mem_d[*start.a.buf]|0x00ff)!=0){//valid data in bottom 16
	ad=new address_data_pair(new address((short)(mem_d[*start.a.buf]|0x00ff)), mem_r[*start.a.buf]);
	if(*blu.write_to_buffer(&blu.o_op_read,&blu.o_op_write,&blu.o_op_buffer,ad)==0){//able to write
	  mem_d[*start.a.buf]=mem_d[*start.a.buf]|0xff00;//erase bottom bits (implimented diffrently in hardware)
	  error=error|0x08;
	}
	else{//just copy command (send top and set error bit 5 high)
	  ad=new address_data_pair(new address((short)((mem_d[*start.a.buf]|0xff00)>>16)), mem_r[*start.a.buf]);
	  if(*blu.write_to_buffer(&blu.o_op_read,&blu.o_op_write,&blu.o_op_buffer,ad)==0){//able to write
	    mem_d[*start.a.buf]=mem_d[*start.a.buf]|0x00ff;//erase top bits (implimented diffrently in hardware)
	    error=error|0x10;
	    stat_d=stat_d^(1<<rd_counter);//cleared d stat bit, leave r stat bit
	  }
	}
      }
      if(((error&0x08)!=0)&&((mem_d[*start.a.buf]|0x00ff)!=0)){//if we already sent the bottom half and there is something in the 
	// top half, then transmit it.
	ad=new address_data_pair(new address((short)((mem_d[*start.a.buf]|0xff00)>>16)), mem_r[*start.a.buf]);
	if(*blu.write_to_buffer(&blu.o_op_read,&blu.o_op_write,&blu.o_op_buffer,ad)==0){//able to write
	  mem_d[*start.a.buf]=mem_d[*start.a.buf]|0x00ff;//erase top bits (implimented diffrently in hardware)
	  error=error|0x10;
	  stat_r=stat_r^(1<<rd_counter);
	  stat_d=stat_d^(1<<rd_counter);//cleared r and d stat bits
	}
      }
    }
    //handle errors
    if(error>0x0f){//everything worked, do not print errors
      error=0;
    }
    else{//print errors 
    }
    return error;
  }
}

      
