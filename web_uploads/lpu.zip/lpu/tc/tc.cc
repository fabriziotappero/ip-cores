/***** Open Source Hardware *****/
/*

filename tc.cc

Credits 
Brian Korsedal - Author of first draft

*/

#include "bus_logic_2_bus_logic_connection.hh"






/* functions for bus_logic:
  int process_input(address i_a, char *read, char *write, address_data_pair *start)
  int write_to_buffer(char *read, char *write, address_data_pair *start, address_data_pair i_data)
  int get_buffer(char buffer, char *read, char *write, address_data_pair *start)
  int check_for_read(char read, char write, address_data_pair *start, address_data_pair *o_data)
*/
int bus_logic_2_bus_logic_connection:: step(){
  char *read;
  char *write;
  address_data_pair *start;
  address_data_pair ad;  
  int error = 1;

  //transmit from e1 buffer to blu_e1
  if(e1_write!=e1_read){//check for read conditions
    ad=e1[e1_read];
    if(blu_e1.process_input(ad.a,read,write,start)==0){
      if(blu_e1.write_to_buffer(read,write,start,ad)==0){
	e1_read++;
	error=0;
      }
    }
  } 
  //transmit from blu_e1 to e1 buffer
  if(blu_e1.get_buffer(EAST,read,write,start)==0){
    if(*read!=*write){
      ad=*(start+*read);
      process_input(ad);
    }
  }
  //transmit from e2 buffer to blu_e2
  if(e2_write!=e2_read){//check for read conditions
    ad=e2[e2_read];
    if(blu_e2.process_input(ad.a,read,write,start)==0){
      if(blu_e2.write_to_buffer(read,write,start,ad)==0){
	e2_read++;
	error=0;
      }
    }
  } 
  //transmit from blu_e2 to e2 buffer
  if(blu_e2.get_buffer(EAST,read,write,start)==0){
    if(*read!=*write){
      ad=*(start+*read);
      process_input(ad);
    }
  }  
  //transmit from e3 buffer to blu_e3
  if(e3_write!=e3_read){//check for read conditions
    ad=e3[e3_read];
    if(blu_e3.process_input(ad.a,read,write,start)==0){
      if(blu_e3.write_to_buffer(read,write,start,ad)==0){
	e3_read++;
	error=0;
      }
    }
  } 
  //transmit from blu_e3 to e3 buffer
  if(blu_e3.get_buffer(EAST,read,write,start)==0){
    if(*read!=*write){
      ad=*(start+*read);
      process_input(ad);
    }
  }  
  //transmit from e4 buffer to blu_e4
  if(e4_write!=e4_read){//check for read conditions
    ad=e4[e4_read];
    if(blu_e4.process_input(ad.a,read,write,start)==0){
      if(blu_e4.write_to_buffer(read,write,start,ad)==0){
	e4_read++;
	error=0;
      }
    }
  } 
  //transmit from blu_e4 to e4 buffer
  if(blu_e4.get_buffer(EAST,read,write,start)==0){
    if(*read!=*write){
      ad=*(start+*read);
      process_input(ad);
    }
  } 
  //done transmitting data to  and from buffers
  return error; 
}











