/***** Open Source Hardware *****/
/*

filename global_defines.cc

description: these are some global definitions that should be always used;

Credits 
Brian Korsedal - Author of first draft

*/


/************************Bus Logic Defines************************/

/* these define the directions used by the bus logic units */

#define NORTH  0x00;
#define EAST      0x01;
#define SOUTH   0x02;
#define WEST     0x03;
#define I_OP          0x04;
#define O_OP      0x05;

/************************OP Defines************************/

/* 
these define the numbers used for buffers inside the op unit
 */

#define MEM_A 0x00;
#define MEM_B 0x01;
#define MEM_R 0x02;
#define MEM_D 0x03;


/* this is a coefficent for the throughput meter.  Each op should have a throughput 
meter that will be used to optimize the device and to give us a visual representation
of how the device is working. */

#define THROUGHPUT_COEF 0.999;

/************************Connection Defines************************/

/* there is a traffic meter inside the bus_logic connections.  This coefficent varies 
how sensitive the traffic meters are.  Any number from less than one to greater than 
zero is O.K.  Lower numbers mean traffic values will be more jumpy, higher numbers 
will mean that traffic values will be more stable.  When measuring traffic, we should 
find the average traffic values for all traffic variables and then divide the current variable 
by the average to find the relative traffic.  The traffic_meter variable alone will not tell 
you much.  Relative values are better.  These should be computed every time step of 
the bus logic. */

#define TRAFFIC_COEF 0.999;

/************************TC Defines************************/





