#!/usr/bin/perl

use strict;
use warnings;

my $sysname;
my $pin;

my $sysinfo;

sub comm_init() {

	$sysname = shift;
	$pin = shift;

	$sysinfo = shift;

}

sub gen_dpram() {

    *MHS = shift;
    my $dpram = shift;

    my $instance = $dpram->{instance};
    my $left = $dpram->{left};
    my $right = $dpram->{right};

    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = ilmb_cntlr_${instance}_left\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $dpram->{left_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $dpram->{left_addr}+$dpram->{size}-1;
    print MHS " BUS_INTERFACE SLMB = dlmb_$left\n";
    print MHS " BUS_INTERFACE BRAM_PORT = dpram_${instance}_left_port\n";
    print MHS "END\n\n";

    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = ilmb_cntlr_${instance}_right\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $dpram->{right_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $dpram->{right_addr}+$dpram->{size}-1;
    print MHS " BUS_INTERFACE SLMB = dlmb_$right\n";
    print MHS " BUS_INTERFACE BRAM_PORT = dpram_${instance}_right_port\n";
    print MHS "END\n\n";

    print MHS "BEGIN bram_block\n";
    print MHS " PARAMETER INSTANCE = bram_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " BUS_INTERFACE PORTA = dpram_${instance}_left_port\n";
    print MHS " BUS_INTERFACE PORTB = dpram_${instance}_right_port\n";
    print MHS "END\n\n";
    
}

# dp-m-vlc, dpram, 8k, left mb-m address 0x20000000, right mb-vlc address 0x20000000

sub read_dpram() {
    
    my $instance = shift;

    my $dpram = {
    	type => "dpram",
    	instance => $instance,
    	size => 0,
    	left => 0,
    	leftp => 0,
    	left_addr => 0,
    	right => 0,
    	rightp => 0,
    	right_addr => 0
    	};

    foreach (@_) {

        if (/(\d+)(k|m)/) {
            my $size = eval($1);
	    if ($2 eq 'k') { $size *= 1024; }
	    else { $size *= 1024*1024; }
	    $dpram->{size} = $size;
        }

        if (/left\s*(\S*)/) {
            $dpram->{left} = $1;
            if (/address\s*(\S+)/) {
                $dpram->{left_addr} = eval($1);
            } else {
                $dpram->{left_addr} = 0;
            }
        }

         if (/right\s*(\S*)/) {
            $dpram->{right} = $1;
            if (/address\s*(\S+)/) {
                $dpram->{right_addr} = eval($1);
            } else {
                $dpram->{right_addr} = 0;
            }
        }
       
    }

    return $dpram;

}


