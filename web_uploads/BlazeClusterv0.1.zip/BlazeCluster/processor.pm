#!/usr/bin/perl

use strict;
use warnings;

my $sysname;
my $pin;
my $sysinfo;

sub processor_init() {

	$sysname = shift;
	$pin = shift;
	$sysinfo = shift;

}

# mb0, microblaze, 32k on-chip ram address 0, opb master, barrel-shifter, interrupt from timer0, uart driver baudrate 115200, cf-card driver readwrite

sub read_microblaze() {
    
    my $instance = shift;
    my @ldrivers;

    my $microblaze = {
    	processor => "microblaze",
    	instance => $instance,
    	jtag => 0,
    	barrel => 0,
    	opb => 0,
    	profile => 0,
    	interrupt => "",
    	onchip_mem_size => 0,
    	onchip_mem_addr => 0,

    	stdio => "",
    	drivers => \@ldrivers,
    	};

    foreach (@_) {

	if (/opb(-|\s*)master/) {
	    $microblaze->{opb} = 1;
	}
	
	elsif (/barrel(-|\s*)shifter/) {
	    $microblaze->{barrel} = 1;
	}
	
	elsif (/jtag/) {
	    $microblaze->{jtag} = 1;
	    $sysinfo->{extjtag} = 1;
	}
	
	elsif (/profile/) {                    
	    my $opb_timer = {
	        device => "opb-timer",
	        instance => "opb_timer_$instance", 
	        interrupt => 0,
	        addr => 0,
	        addrfix => 0,
	        size => 65536,
	    };

           if ($microblaze->{interrupt} eq "") { $microblaze->{interrupt} = "opb_timer_$instance"; }  #  interrupt can override profile but not verse vesa
           $microblaze->{profile} = 1;

           $opb_timer->{interrupt} = 1;
	    if (/address\s*(\S+)/) {
	        $opb_timer->{addr} = eval($1);
               $opb_timer->{addrfix} = 1;
	    } else {
               $opb_timer->{addr} = &opb_get_device_address($opb_timer->{size});
               $opb_timer->{addrfix} = 0;
	    }
	    push (@ldrivers, $opb_timer);
           
	}

	elsif (/interrupt\s+(from|to)\s+(\S*)/) {
	    $microblaze->{interrupt} = $2;
	}
	
	elsif (/(\d+)(k|m)\s*on(-*)chip\s*(ram|mem|memory)/) {
	    my $onchip_mem_size = eval($1);
	    if ($2 eq 'k') { $onchip_mem_size *= 1024; }
	    else { $onchip_mem_size *= 1024*1024; }
	    $microblaze->{onchip_mem_size} = $onchip_mem_size;
	    
	    if (/address\s*(\S+)/) {
	        $microblaze->{onchip_mem_addr} = eval($1);
	    } else {
               $microblaze->{onchip_mem_addr} = 0;
	    }
	} 

	elsif (/opb-timer/) {
	    my $opb_timer = {
	        device => "opb-timer",
	        instance => "opb_timer_$instance", 
	        interrupt => 0,
	        addr => 0,
	        addrfix => 0,
	        size => 65536,
	    };

	    if (/interrupt/) {
               $opb_timer->{interrupt} = 1;
	    }

	    if (/address\s*(\S+)/) {
	        $opb_timer->{addr} = eval($1);
               $opb_timer->{addrfix} = 1;
	    } else {
               $opb_timer->{addr} = &opb_get_device_address($opb_timer->{size});
               $opb_timer->{addrfix} = 0;
	    }

	    push (@ldrivers, $opb_timer);
	}

	elsif (/opb-uartlite/) {
	    my $opb_uartlite = {
	       device => "opb-uartlite",
		instance => "opb_uartlite_$instance",
              interrupt => 0,
              addr => 0,
 	       addrfix => 0,
              size => 65536,
		baudrate => 9600,
		bits => 8,
		stop => 1,
		parity => 0,
	    };

	    if (/address\s*(\S+)/) {
	        $opb_uartlite->{addr} = eval($1);
               $opb_uartlite->{addrfix} = 1;
	    } 	  else {
               $opb_uartlite->{addr} = &opb_get_device_address($opb_uartlite->{size});
               $opb_uartlite->{addrfix} = 0;
	    }

	    if (/baudrate\s*(\d+)/) {
               $opb_uartlite->{baudrate} = eval($1);
	    }

           if (/stdio/) {
               $microblaze->{stdio} = $opb_uartlite->{instance};
           }
           
	    push (@ldrivers, $opb_uartlite);
	    $sysinfo->{extuart} = 1;
	}

	elsif (/opb-cf-card/) {
	    my $opb_cf_card = {
	        device => "opb-cf-card",
	        instance => "opb_cf_card_$instance",
	        interrupt => 0,
	        addr => 0,
   	        addrfix => 0,
	        size => 65536,
	        write => 0,
	    };

	    if (/address\s*(\S+)/) {
	        $opb_cf_card->{addr} = eval($1);
               $opb_cf_card->{addrfix} = 1;
	    } 	  else {
               $opb_cf_card->{addr} = &opb_get_device_address($opb_cf_card->{size});
               $opb_cf_card->{addrfix} = 0;
	    }
	    
	    if (/readwrite|rw/) {
		 $opb_cf_card->{write} = 1;
	    }
	    push (@ldrivers, $opb_cf_card);
	    $sysinfo->{extcf_card} = 1;
	}

    }


    return $microblaze;

}


sub gen_powerpc() {

}

sub gen_microblaze() {

    *MHS = shift;
    *MSS = shift;
    my $proc = shift;

    my $instance = $proc->{instance};
    
    print MHS "BEGIN microblaze\n";
    print MHS " PARAMETER INSTANCE = $instance\n";
    print MHS " PARAMETER HW_VER = 4.00.a\n";
    print MHS " PARAMETER C_DEBUG_ENABLED = 1\n";
    print MHS " PARAMETER C_NUMBER_OF_PC_BRK = 2\n";
    print MHS " PARAMETER C_NUMBER_OF_RD_ADDR_BRK = 1\n";
    print MHS " PARAMETER C_NUMBER_OF_WR_ADDR_BRK = 1\n";
    print MHS " PORT CLK = sys_clk_s\n";
    print MHS " BUS_INTERFACE DLMB = dlmb_$instance\n";
    print MHS " BUS_INTERFACE ILMB = ilmb_$instance\n";

    if ($proc->{opb}>0) {
	    print MHS " BUS_INTERFACE DOPB = mp_opb\n";
	    print MHS " BUS_INTERFACE IOPB = mp_opb\n";
    }
    
    if ($proc->{barrel}>0) {
    	    print MHS " PARAMETER C_USE_BARREL = 1\n";
    }

    if ($proc->{jtag}>0) {
    	    print MHS " PORT DBG_CAPTURE = DBG_CAPTURE_s\n";
	    print MHS " PORT DBG_CLK = DBG_CLK_s\n";
	    print MHS " PORT DBG_REG_EN = DBG_REG_EN_s\n";
	    print MHS " PORT DBG_TDI = DBG_TDI_s\n";
	    print MHS " PORT DBG_TDO = DBG_TDO_s\n";
	    print MHS " PORT DBG_UPDATE = DBG_UPDATE_s\n";
    }

    if ($proc->{interrupt} ne "") {
	    print MHS " PORT INTERRUPT = $proc->{interrupt}_interrupt\n";
    }

    print MHS "END\n\n";

    print MSS "BEGIN OS\n";
    print MSS " PARAMETER OS_NAME = standalone\n";
    print MSS " PARAMETER OS_VER = 1.00.a\n";
    print MSS " PARAMETER PROC_INSTANCE = $instance\n";
    if ($proc->{stdio} ne "") {
        print MSS " PARAMETER STDIN = $proc->{stdio}\n";
        print MSS " PARAMETER STDOUT = $proc->{stdio}\n";
    }
    if ($proc->{profile}>0) {
        print MSS " PARAMETER profile_timer = opb_timer_$instance\n";
        print MSS " PARAMETER enable_sw_intrusive_profiling = true\n";
    }
    print MSS "END\n\n";

    print MSS "BEGIN PROCESSOR\n";
    print MSS " PARAMETER DRIVER_NAME = cpu\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = $instance\n";
    print MSS " PARAMETER COMPILER = mb-gcc\n";
    print MSS " PARAMETER ARCHIVER = mb-ar\n";
    if ($proc->{jtag}>0) { print MSS " PARAMETER XMDSTUB_PERIPHERAL = debug_module\n"; }
    print MSS "END\n\n";

# create mdm device and driver 

    if ($proc->{jtag}>0) {
        print MHS "BEGIN opb_mdm\n";
        print MHS " PARAMETER INSTANCE = debug_module\n";
        print MHS " PARAMETER HW_VER = 2.00.a\n";
        print MHS " PARAMETER C_MB_DBG_PORTS = 1\n";
        print MHS " PARAMETER C_USE_UART = 1\n";
        print MHS " PARAMETER C_UART_WIDTH = 8\n";
        print MHS " PARAMETER C_BASEADDR = 0x41400000\n";
        print MHS " PARAMETER C_HIGHADDR = 0x4140ffff\n";
        print MHS " BUS_INTERFACE SOPB = mp_opb\n";
        print MHS " PORT OPB_Clk = sys_clk_s\n";
        print MHS " PORT DBG_CAPTURE_0 = DBG_CAPTURE_s\n";
        print MHS " PORT DBG_CLK_0 = DBG_CLK_s\n";
        print MHS " PORT DBG_REG_EN_0 = DBG_REG_EN_s\n";
        print MHS " PORT DBG_TDI_0 = DBG_TDI_s\n";
        print MHS " PORT DBG_TDO_0 = DBG_TDO_s\n";
        print MHS " PORT DBG_UPDATE_0 = DBG_UPDATE_s\n";
        print MHS "END\n\n";

        print MSS "BEGIN DRIVER\n";
        print MSS " PARAMETER DRIVER_NAME = uartlite\n";
        print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
        print MSS " PARAMETER HW_INSTANCE = debug_module\n";
        print MSS "END\n\n";
    }

# create lmb bus, on-chip  memory device

    print MHS "BEGIN lmb_v10\n";
    print MHS " PARAMETER INSTANCE = dlmb_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT LMB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MHS "BEGIN lmb_v10\n";
    print MHS " PARAMETER INSTANCE = ilmb_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT LMB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = dlmb_cntlr_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $proc->{onchip_mem_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $proc->{onchip_mem_addr}+$proc->{onchip_mem_size}-1;
    print MHS " BUS_INTERFACE SLMB = dlmb_$instance\n";
    print MHS " BUS_INTERFACE BRAM_PORT = dlmb_port_$instance\n";
    print MHS "END\n\n";
    
    print MHS "BEGIN lmb_bram_if_cntlr\n";
    print MHS " PARAMETER INSTANCE = ilmb_cntlr_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.b\n";
    printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $proc->{onchip_mem_addr};
    printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $proc->{onchip_mem_addr}+$proc->{onchip_mem_size}-1;
    print MHS " BUS_INTERFACE SLMB = ilmb_$instance\n";
    print MHS " BUS_INTERFACE BRAM_PORT = ilmb_port_$instance\n";
    print MHS "END\n\n";

    print MHS "BEGIN bram_block\n";
    print MHS " PARAMETER INSTANCE = bram_$instance\n";
    print MHS " PARAMETER HW_VER = 1.00.a\n";
    print MHS " BUS_INTERFACE PORTA = ilmb_port_$instance\n";
    print MHS " BUS_INTERFACE PORTB = dlmb_port_$instance\n";
    print MHS "END\n\n";


    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = bram\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = dlmb_cntlr_$instance\n";
    print MSS "END\n\n";

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = bram\n";
    print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
    print MSS " PARAMETER HW_INSTANCE = ilmb_cntlr_$instance\n";
    print MSS "END\n\n";


#    foreach my $driver (@{$proc->{drivers}}) {
#        print ("--driver $driver->{instance}\n");
#    }

# create pheripheral

    foreach my $driver (@{$proc->{drivers}}) {
        if ($driver->{device} eq "opb-uartlite") {
            print MHS "BEGIN opb_uartlite\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            print MHS " PARAMETER C_BAUDRATE = $driver->{baudrate}\n";
            print MHS " PARAMETER C_DATA_BITS = 8\n";
            print MHS " PARAMETER C_ODD_PARITY = 0\n";
            print MHS " PARAMETER C_USE_PARITY = 0\n";
            print MHS " PARAMETER C_CLK_FREQ = 100000000\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = mp_opb\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            print MHS " PORT RX = ${pin}_uart0_rx\n";
            print MHS " PORT TX = ${pin}_uart0_tx\n";
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = uartlite\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
            
        }

        if ($driver->{device} eq "opb-timer") {
            print MHS "BEGIN opb_timer\n";
            print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
            print MHS " PARAMETER HW_VER = 1.00.b\n";
            printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
            printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
            print MHS " BUS_INTERFACE SOPB = mp_opb\n";
            print MHS " PORT OPB_Clk = sys_clk_s\n";
            if ($driver->{interrupt} > 0) {
                print MHS " PORT Interrupt = $driver->{instance}_interrupt\n";
            }
            print MHS "END\n\n";

            print MSS "BEGIN DRIVER\n";
            print MSS " PARAMETER DRIVER_NAME = tmrctr\n";
            print MSS " PARAMETER DRIVER_VER = 1.00.b\n";
            print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
            print MSS "END\n\n";
        }
        
        if ($driver->{device} eq "opb-cf-card") {
        	print MHS "BEGIN opb_sysace\n";
              print MHS " PARAMETER INSTANCE = $driver->{instance}\n";
              print MHS " PARAMETER HW_VER = 1.00.c\n";
              print MHS " PARAMETER C_MEM_WIDTH = 16\n";
              printf MHS " PARAMETER C_BASEADDR = 0x%08x\n", $driver->{addr};
              printf MHS " PARAMETER C_HIGHADDR = 0x%08x\n", $driver->{addr}+$driver->{size}-1;
              print MHS " BUS_INTERFACE SOPB = mp_opb\n";
              print MHS " PORT OPB_Clk = sys_clk_s\n";
              print MHS " PORT SysACE_CLK = ${pin}_cf_card_CLK\n";
              print MHS " PORT SysACE_MPA = ${pin}_cf_card_MPA\n";
              print MHS " PORT SysACE_MPD = ${pin}_cf_card_MPD\n";
              print MHS " PORT SysACE_CEN = ${pin}_cf_card_CEN\n";
              print MHS " PORT SysACE_OEN = ${pin}_cf_card_OEN\n";
              print MHS " PORT SysACE_WEN = ${pin}_cf_card_WEN\n";
              print MHS " PORT SysACE_MPIRQ = ${pin}_cf_card_MPIRQ\n";
              print MHS "END\n\n";

             print MSS "BEGIN DRIVER\n";
             print MSS " PARAMETER DRIVER_NAME = sysace\n";
             print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
             print MSS " PARAMETER HW_INSTANCE = $driver->{instance}\n";
             print MSS "END\n\n";
            
             print MSS "BEGIN LIBRARY\n";
             print MSS " PARAMETER LIBRARY_NAME = xilfatfs\n";
             print MSS " PARAMETER LIBRARY_VER = 1.00.a\n";
             print MSS " PARAMETER CONFIG_WRITE = true\n";
             print MSS " PARAMETER CONFIG_MAXFILES = 2\n";
             print MSS " PARAMETER CONFIG_BUFCACHE_SIZE = 1280\n";
             print MSS " PARAMETER PROC_INSTANCE = $instance\n";
             print MSS "END\n\n";
        }
        
    }

}



