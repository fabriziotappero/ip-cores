microblaze_0, microblaze, opb-master, 64k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, opb-cf-card readwrite
microblaze_1, microblaze, 8k on-chip ram
microblaze_2, microblaze, 8k on-chip ram
dp01, dpram, 8k, left microblaze_0 address 0x20000000, right microblaze_1 address 0x20000000
dp12, dpram, 8k, left microblaze_1 address 0x21000000, right microblaze_2 address 0x21000000
dp20, dpram, 8k, left microblaze_2 address 0x22000000, right microblaze_0 address 0x22000000
ddr, on-board ddr sdram, 256m address 0x30000000
