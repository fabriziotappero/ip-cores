microblaze_0, microblaze, opb-master, 64k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, opb-cf-card readwrite
ddr, on-board ddr sdram, 256m address 0x30000000
