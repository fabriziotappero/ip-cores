#!/usr/bin/perl

# BlazeGenerator v0.1 by Sunwei 2007/05
# Generate multiprocessor architecture on FPGA  
# www.opencores.org/projects.cgi/web/mpdma

use strict;
use warnings;

my $sysname = "mp";
my $pin = "mp";

my @lprocessor;
my @ldpram;
my @lshared;


my $sysinfo = {
    name => "mp",  # not activated yet
    pin => "mp",

    opb => 0,

    extjtag => 0,
    extsdram => 0,
    extsram => 0,
    extuart => 0,
    extcf_card => 0,
    };



do "processor.pm";
do "comm.pm";
do "shared.pm";
do "misc.pm";



&processor_init($sysname, $pin, $sysinfo);
&comm_init($sysname, $pin, $sysinfo);
&shared_init($sysname, $pin, $sysinfo);
&misc_init($sysname, $pin, $sysinfo);


open MHS, ">system.mhs" or die "can't open $!";

print MHS "###################################################\n";
print MHS "#   Created by BlazeCluster v0.1 for Xilinx EDK 7.1\n";
print MHS "###################################################\n\n\n";

print MHS " PARAMETER VERSION = 2.1.0\n\n";

open MSS, ">system.mss" or die "can't open $!";

print MSS "###################################################\n";
print MSS "#   Created by BlazeCluster v0.1 for Xilinx EDK 7.1\n";
print MSS "###################################################\n\n\n";

print MSS " PARAMETER VERSION = 2.2.0\n\n";

open UCF, ">system.ucf" or die "can't open $!";

open JS, "system.js" or die "can't open $!";

while (<JS>) {
    my $microblaze;
    my $sdram;
    my $dpram;

    chop;
    next unless (/,/);
    my @comp = split /,/, $_;
    my $typestr = $comp[1];
    
    if ($typestr =~ "microblaze") {
       if ($sysinfo->{opb} == 0) { &read_opb(); }
       
	$microblaze = &read_microblaze(@comp);
	push (@lprocessor, $microblaze);
    }

    if ($typestr =~ "dpram") {
       $dpram = &read_dpram(@comp);
       push (@ldpram, $dpram);
    }

    if ($typestr =~ "on.board ddr sdram") {
	$sdram = &read_onboard_sdram(@comp);
       push (@lshared, $sdram);
       $sysinfo->{extsdram} = 1;
    }

}


&gen_pins(*MHS, *MSS, *UCF);

foreach my $proc (@lprocessor) {
    if ($proc->{processor} eq "microblaze") {
        &gen_microblaze(*MHS, *MSS, $proc);
    } else {
        &gen_powerpc(*MHS, *MSS, $proc);
    }
}

foreach my $dp (@ldpram) {
    &gen_dpram(*MHS, $dp);
}

foreach my $shared (@lshared) {
    &gen_shared(*MHS, $shared);
}

&gen_opb(*MHS, *MSS);

&gen_clock(*MHS);

    foreach my $proc (@lprocessor) {
#        print "processor $proc->{instance}:  ";
	 for (keys %{$proc}) {
#	     print ("$_ -> $proc->{$_}  ");
	 }
#	 print "\n";
    }

    foreach my $dp (@ldpram) {
#        print "dpram $dp->{instance}:  ";
	 for (keys %{$dp}) {
#	     print ("$_ -> $dp->{$_}  ");
	 }
#	 print "\n";
    }

close JS;
close MHS;


