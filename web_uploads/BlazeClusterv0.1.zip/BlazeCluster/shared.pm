#!/usr/bin/perl

use strict;
use warnings;

my $sysname;
my $pin;

my $sysinfo;

sub shared_init() {

	$sysname = shift;
	$pin = shift;

	$sysinfo = shift;

}

sub read_opb() {
    my $opb = {
        instance => "$sysinfo->{name}-opb",
        device_addr_start => 0x40000000,
        device_addr_current => 0x40000000,

        extsdram_addr_start => 0x30000000,
        extsdram => 0,
        };

    $sysinfo->{opb} = $opb;

}

sub opb_get_device_address() {
    my $size = shift;
    my $addr = $sysinfo->{opb}->{device_addr_current};

    $sysinfo->{opb}->{device_addr_current} += $size;
    return $addr;

}

sub opb_get_extsdram_address() {

    return $sysinfo->{opb}->{extsdram_addr_start};

}


sub gen_opb() {

    *MHS = shift;
    *MSS = shift;

    print MHS "BEGIN opb_v20\n";
    print MHS " PARAMETER INSTANCE = ${sysname}_opb\n";
    print MHS " PARAMETER HW_VER = 1.10.c\n";
    print MHS " PARAMETER C_EXT_RESET_HIGH = 0\n";
    print MHS " PORT SYS_Rst = sys_rst_s\n";
    print MHS " PORT OPB_Clk = sys_clk_s\n";
    print MHS "END\n\n";

    print MSS "BEGIN DRIVER\n";
    print MSS " PARAMETER DRIVER_NAME = opbarb\n";
    print MSS " PARAMETER DRIVER_VER = 1.02.a\n";
    print MSS " PARAMETER HW_INSTANCE = ${sysname}_opb\n";
    print MSS "END\n\n";


}


sub gen_shared() {

    *MHS = shift;
    my $shared = shift;

    if ($shared->{type} eq "on-board sdram") {
    
        print MHS "BEGIN opb_ddr\n";
        print MHS " PARAMETER INSTANCE = $shared->{instance}\n";
        print MHS " PARAMETER HW_VER = 2.00.b\n";
        print MHS " PARAMETER C_OPB_CLK_PERIOD_PS = 10000\n";
        print MHS " PARAMETER C_NUM_BANKS_MEM = 1\n";
        print MHS " PARAMETER C_NUM_CLK_PAIRS = 4\n";
        print MHS " PARAMETER C_REG_DIMM = 0\n";
        print MHS " PARAMETER C_DDR_TMRD = 20000\n";
        print MHS " PARAMETER C_DDR_TWR = 20000\n";
        print MHS " PARAMETER C_DDR_TRAS = 60000\n";
        print MHS " PARAMETER C_DDR_TRC = 90000\n";
        print MHS " PARAMETER C_DDR_TRFC = 100000\n";
        print MHS " PARAMETER C_DDR_TRCD = 30000\n";
        print MHS " PARAMETER C_DDR_TRRD = 20000\n";
        print MHS " PARAMETER C_DDR_TRP = 30000\n";
        print MHS " PARAMETER C_DDR_TREFC = 70300000\n";
        print MHS " PARAMETER C_DDR_AWIDTH = 13\n";
        print MHS " PARAMETER C_DDR_COL_AWIDTH = 10\n";
        print MHS " PARAMETER C_DDR_BANK_AWIDTH = 2\n";
        print MHS " PARAMETER C_DDR_DWIDTH = 64\n";
        printf MHS " PARAMETER C_MEM0_BASEADDR = 0x%08x\n", $shared->{addr};
        printf MHS " PARAMETER C_MEM0_HIGHADDR = 0x%08x\n", $shared->{addr}+$shared->{size}-1;
        print MHS " BUS_INTERFACE SOPB = mp_opb\n";
        print MHS " PORT OPB_Clk = sys_clk_s\n";
        print MHS " PORT DDR_Addr = ${pin}_DDR_Addr\n";
        print MHS " PORT DDR_BankAddr = ${pin}_DDR_BankAddr\n";
        print MHS " PORT DDR_CASn = ${pin}_DDR_CASn\n";
        print MHS " PORT DDR_CKE = ${pin}_DDR_CKE\n";
        print MHS " PORT DDR_CSn = ${pin}_DDR_CSn\n";
        print MHS " PORT DDR_RASn = ${pin}_DDR_RASn\n";
        print MHS " PORT DDR_WEn = ${pin}_DDR_WEn\n";
        print MHS " PORT DDR_DM = ${pin}_DDR_DM\n";
        print MHS " PORT DDR_DQS = ${pin}_DDR_DQS\n";
        print MHS " PORT DDR_DQ = ${pin}_DDR_DQ\n";
        print MHS " PORT DDR_Clk = ${pin}_DDR_Clk & ddr_clk_feedback_out_s\n";
        print MHS " PORT DDR_Clkn = ${pin}_DDR_Clkn & 0b0\n";
        print MHS " PORT Device_Clk90_in = clk_90_s\n";
        print MHS " PORT Device_Clk90_in_n = clk_90_n_s\n";
        print MHS " PORT Device_Clk = sys_clk_s\n";
        print MHS " PORT Device_Clk_n = sys_clk_n_s\n";
        print MHS " PORT DDR_Clk90_in = ddr_clk_90_s\n";
        print MHS " PORT DDR_Clk90_in_n = ddr_clk_90_n_s\n";
        print MHS "END\n\n";

        print MSS "BEGIN DRIVER\n";
        print MSS " PARAMETER DRIVER_NAME = ddr\n";
        print MSS " PARAMETER DRIVER_VER = 1.00.a\n";
        print MSS " PARAMETER HW_INSTANCE = $shared->{instance}\n";
        print MSS "END\n\n";

    }


}

# ddr, on-board sdram, 256m address 0x30000000, ddr2, opb

sub read_onboard_sdram() {
    
    my $instance = shift;

    my $sdram = {
    	type => "on-board sdram",
    	instance => $instance,
    	size => 0,
    	addr => 0,
    	opb => 0,
    	ddr => 0,
    	ddr2 => 0,
    	};

    foreach (@_) {

        if (/(\d+)(k|m)/) {
            my $size = eval($1);
	    if ($2 eq 'k') { $size *= 1024; }
	    else { $size *= 1024*1024; }
	    $sdram->{size} = $size;

	    if (/address\s*(\S+)/) {
	        $sdram->{addr} = eval($1);
	    } else {
               $sdram->{addr} = 0;
	    }
        }

        if (/opb/) {
		$sdram->{opb} = 1;
        }

	if (/ddr/) {
		$sdram->{ddr} = 1;
	}
	
    }

   return $sdram;

}


