///////////////////////////////////////////////////////////////
// Automatic Multiplication Array Generator tool             //
// Used to generate optimized FIR Filters/Corelators         //
// using Nonrecursive Signed Common Subexpression Algorithm  //
///////////////////////////////////////////////////////////////
//
// Writer      : Boris Kipnis
// Last Update : 8/5/2005
//

#include "MultGen.h"

/////////////////////////////////////////////////////////////////////////////////////
// Generate Multiplication Array VHDL file
// fname       - Target VHDL File Name
// inDataWidth - Input Data Size (std_logic_vector x-1 downto 0)
// multVector  - Multiplication Coefitions Array
// pm_flag     - when true generates both positive and negative multiplications
//               Mult0 = Din * C0; nMult = Din * (-C0);
MultGen::MultGen(string fname,int inDataWidth,vector<int> multVector,int ClkEn,int Async,string comments) {
	MultGen_construct(fname,inDataWidth,multVector,ClkEn,Async,comments);
}
// Beacuse of GGC/GDB Bug there is problem to put Break Point on Constructor
void MultGen::MultGen_construct(string fname,int inDataWidth,vector<int> multVector,int ClkEn,int Async,string comments) {
  vector<vector<mult_s> > script; 
  vector<vector<mult_s> > term; 
  GenMultScript *multScriptC;
 
  //////////////////////////////////////////////////////////////////////
  // Generate multiplication script using optimization algorithm
  multScriptC = new GenMultScript(multVector);
  script =  multScriptC->GetScript();
  term   =  multScriptC->GetTerm();

  //////////////////////////////////////////////////////////////////////
  // Convert Multplier script to VHDL code
  m_genCode = new GenMultCode(term,script,inDataWidth,fname,multVector,ClkEn,Async,comments);
  mult_out_vector = m_genCode->GetOutVector();
}


MultGen::~MultGen() {
  cout << "\r\nDelite Object,save file\r\n";	
  delete  m_genCode;
}

vector<MathVHDL_var*> MultGen::GetOutVector() {
	return(mult_out_vector);
}

// Get Component Implementation Header
// Return string
string MultGen::GetComponent() {
    return(m_genCode->GetComponent());
}
	  
// Get connection to port map
// return string
string MultGen::GetPortMapCon(string ImplementName, string ClkName, MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut) {
	return(m_genCode->GetPortMapCon(ImplementName,ClkName,DIn,MultOut));
}

string MultGen::GetPortMapCon_ClkEn(string ImplementName,string ClkName,string ClkEnName,MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut) {
	return(m_genCode->GetPortMapCon_ClkEn(ImplementName,ClkName,ClkEnName,DIn,MultOut));
}

