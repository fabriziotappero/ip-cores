#ifndef MATH_EXPRESION_VHDL_H
#define MATH_EXPRESION_VHDL_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;

#include "MathVHDL_var.h"
#include "VHDL_var.h"

#define CMD_mA_mB   1
#define CMD_mA_pB   2
#define CMD_pA_mB   3
#define CMD_pA_pB   4
#define CMD_A_pm_B  5
#define CMD_GEN_OUT 6
#define CMD_EQUAL   7
#define CMD_BLANK   8
#define CMD_ZERO    9
#define CMD_LIM    10

//////////////////////////////////////////
// Single Arithmetic operation element  //
//////////////////////////////////////////
struct coreGen_element_s {
  int cmd;             // Command
  MathVHDL_var* a;     // a Variable
  MathVHDL_var* b;     // b Variable
  MathVHDL_var* dest;  // destination Variable
  string code;         // VHDL code that executes the following command
};

/////////////////////////////////////////////////////////////////////////////////
// Mathematics function container
// this class contains array of arethmetic expressions for single Math. function
class MathExpresionVHDL {
  public:
    MathExpresionVHDL();
    ~MathExpresionVHDL();
    void Add(coreGen_element_s ex);
    void Add(vector<coreGen_element_s> ex);
    void Add(MathExpresionVHDL ex);
    string GetCode();
    coreGen_element_s GetElement(int num);
    int GetSize();
    MathVHDL_var* GetDest();
    vector<coreGen_element_s> GetArray();
    
  protected:
    vector<coreGen_element_s> ar; // array of arithmetics operands
};

#endif
