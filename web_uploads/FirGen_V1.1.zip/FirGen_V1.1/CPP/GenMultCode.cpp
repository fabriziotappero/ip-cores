////////////////////////////////////////////
// Automatic Multiplier Generator Tool    //
// Generate Multipplyers Code (VHDL)      //
// from Script                            //
////////////////////////////////////////////
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
// Last Update : 9/6/2005
//
#include "GenMultCode.h"

////////////////////////////////////////////
// Create I/O Ports                       //
////////////////////////////////////////////
void GenMultCode::GenIOPort(int inDataWidth) {
  int i;
  string s;
  char myChar[200];

  if (!m_AsyncMult) m_code->AddPort("Clk",VHDL_var_std_logic,1,0,0,NULL);
  if ((!m_AsyncMult)&&(m_ClkEn)) m_code->AddPort("CLK_EN",VHDL_var_std_logic,1,0,0,NULL);
  m_code->AddPort("DIn",VHDL_var_std_logic_vector,1,inDataWidth-1,0,NULL);
}

////////////////////////////////////////////
// Generate VHDL common                   //
////////////////////////////////////////////
MathVHDL_var* GenMultCode::GenCommon(int inDataWidth) {
  MathVHDL_var* var;

  var = m_code->AddVariable("DInReg",VHDL_var_std_logic_vector,inDataWidth-1,0,0,0,1,0,0,"",NULL); // "DInReg" add variable

  m_code->AddCodeTitle("Common Code");

  if (m_AsyncMult) m_code->AddVHDLCode("DInReg <= DIn;");
              else m_code->AddVHDLCodeClk("DInReg <= DIn;",m_ClkEn);
  
 
  return(var);
}

////////////////////////////
// Sort script            //
////////////////////////////

vector<MathVHDL_var*> GenMultCode::SortVarScript(vector<MathVHDL_var*> scriptIn) {
  vector<MathVHDL_var*> script;
  int i,j;
  MathVHDL_var* tempMult;

  script = scriptIn;

  for (i=0;i<script.size();i++) {
    for (j=0;j<script.size()-1;j++) {
      if (script[j]->GetShift() < script[j+1]->GetShift()) {
        // XChange
	    tempMult    = script[j];
        script[j]   = script[j+1];
        script[j+1] = tempMult;
      }
    }
  }
  return(script);
}


////////////////////////////////////////////
// Generate Single Multiplier             //
////////////////////////////////////////////
MathExpresionVHDL* GenMultCode::GenSingle_pMult(vector<mult_s> script,MathVHDL_var* DIn,vector<MathVHDL_var*> TermList) {
  MathVHDL_var* var;

  vector<MathVHDL_var*> varScript;
  vector<MathVHDL_var*> newScript;
  coreGen_element_s* codeElement;
  MathExpresionVHDL* codeArray;
  int i;

  codeArray = new MathExpresionVHDL();
  
  ////////////////////////////
  // Convert Script 2 var
  for (i=0;i<script.size();i++) {
    var = m_code->Script2MathVar(script[i],DIn,TermList);
    varScript.push_back(var);
  }

  ////////////////////////////
  // Sort script
  varScript = SortVarScript(varScript);
  
  //printf("----------------\r\n");
  //printMultScript(script);

  //cout << "GenSingle_pMult varScript.size()=" << varScript.size() << "\r\n"; 
  // ZERO output
  if (varScript.size()==0) {
     codeElement = m_code->Gen_ZERO_Output();
     codeArray->Add(*codeElement);
     var = codeElement->dest;
  } else {

     ////////////////////////////////
     // Generate Herachical Multiplier
     while (varScript.size()>2) {
        varScript = SortVarScript(varScript);
        newScript.clear();
        //////////////////////////////////////
        // Scan by 2 step jumps
        for (i=0;i<varScript.size();i+=2) {
          if (i!=(varScript.size()-1) ) { // Regular scan (step=2)
             codeElement = m_code->Gen_A_op_B_VHDL(CMD_A_pm_B,varScript[i],varScript[i+1],NULL);
             codeArray->Add(*codeElement);
             var = codeElement->dest;
             newScript.push_back(var);
          } else {                        // Last Element
             newScript.push_back(varScript[i]);
          }
       }
       varScript = newScript;
     }

     var = NULL;
     if (varScript.size()==2) {
        codeElement = m_code->Gen_A_op_B_VHDL(CMD_A_pm_B,varScript[0],varScript[1],NULL);
        codeArray->Add(*codeElement);
        var = codeElement->dest;
     }
     if (varScript.size()==1) {
     	//cout << "varScript.size()==1\r\n";
        codeElement = m_code->Gen_A_op_B_VHDL(CMD_EQUAL,varScript[0],NULL,NULL);
        codeArray->Add(*codeElement);
        var = varScript[0];
     }
  }

  // cout << "varScript Label:" << var->GetLabel() <<"\r\n";

  if (var==NULL) {
    printf("Internal ERROR GenMultCode->GenSingle_pMult\r\n");
    printf("Return value = NULL\r\n");
  }
  //cout << "GenSingle_pMult Finish\r\n";
  return(codeArray);
}

////////////////////////////////////////////
// Generate Multipliers Array             //
///////////////////////////////////////////
vector<MathVHDL_var*> GenMultCode::Gen_pMult(vector<vector<mult_s> > script, MathVHDL_var* DIn, vector<MathVHDL_var*> TermList) {
  int i,j,ii,jj;
  vector<MathExpresionVHDL*> ComplexMultArray;
  MathExpresionVHDL* ComplexMult;
  vector<MathVHDL_var*> pMultArray;
  GenOptimizeVHDL *mOptimize;

  MathExpresionVHDL* ComplexMult_a;
  MathExpresionVHDL* ComplexMult_b;
  coreGen_element_s el_a,el_b;
  
  ComplexMultArray.clear();
  pMultArray.clear();
  
  cout << "Gen_pMult: ";
  cout << "Script.size()=" << script.size() << " ";
  cout << "\r\n";
  
  
  for (i=0;i<script.size();i++) {
  	cout << "@#";
    ComplexMult = GenSingle_pMult(script[i],DIn,TermList); // Execute Single Multiply function
    ComplexMultArray.push_back(ComplexMult);               // Save Complex Multiply to vector (Code+Var)
    pMultArray.push_back(ComplexMult->GetDest());
  }
  cout << "\r\n";

  //cout << "ComplexMultArray.size:" << ComplexMultArray.size() << "\r\n";

  //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  //@@ ADD OPTIMIZATION  HERE                       @@
  //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  cout << "################## Optimization ##################\r\n";
  mOptimize = new GenOptimizeVHDL(m_code,ComplexMultArray,m_code->GetVarList());
  ComplexMultArray = mOptimize->GetNewCode();
  //m_code->SetVarList(mOptimize->GetNewVarList());

  //////////////////////////////////////////////////////////
  // Save Code to VHDL
  for (i=0;i<ComplexMultArray.size();i++) {
    m_code->AddVHDLCode("-----------------------------------");
    m_code->AddVHDLCode((ComplexMultArray[i])->GetCode());
    m_code->AddVHDLCode("");
  }
  //////////////////////////////////////////////////////////
  // Extract multiplication array
  pMultArray.clear();
  for (i=0;i<ComplexMultArray.size();i++) {
    pMultArray.push_back(ComplexMultArray[i]->GetDest());
  }

  return(pMultArray);
}

///////////////////////////////////////////
// Final Stage Multipliers Resample      //
///////////////////////////////////////////
vector<MathVHDL_var*> GenMultCode::Gen_FinalStage(vector<MathVHDL_var*> pMult) {
  char myChar[200];
  int i,numOfMults;
  vector<string> code;
  string str,mult_name;
  vector<MathVHDL_var*> multOut;
  MathVHDL_var* mult;


  m_code->AddCodeTitle("Final Stage Multipliers Resample");
  code.clear();

  numOfMults = pMult.size(); 

  for (i=0;i<numOfMults;i++) {

    //cout << "GetLabel:" << ((pMult[i])->GetLabel()) << "\r\n";
    
    sprintf(myChar,"Mult%d",i);
    mult_name = myChar;
    // Create Output Port
    m_code->AddPort(myChar,VHDL_var_std_logic_vector,0,pMult[i]->GetRangeFrom(),pMult[i]->GetRangeTo(),NULL);
  
    str  = myChar;
    str += " <= ";
    str += pMult[i]->GetVarName();
    str += ";";

    code.push_back(str);
    
    mult = new MathVHDL_var(mult_name,VHDL_var_std_logic_vector,
               pMult[i]->GetRangeFrom(),pMult[i]->GetRangeTo(),
                MatVHDL_var_MULT,0,1,i,
                0,pMult[i]->GetLabel(),
                pMult[i]->GetAttachment());

    multOut.push_back(mult);                
  }
  //code.push_back("");

  if (m_AsyncMult) m_code->AddVHDLCode(code);
              else m_code->AddVHDLCodeClk(code,m_ClkEn);
  return(multOut);
}

////////////////////////////////////////////
// Constructor:                           //
////////////////////////////////////////////
GenMultCode::GenMultCode(vector<vector<mult_s> > term,vector<vector<mult_s> > script,int inDataWidth,string fname,vector<int> mult_array,int ClkEn,int Async,string comments) {
	GenMultCode_construct(term,script,inDataWidth,fname,mult_array,ClkEn,Async,comments);
}

void GenMultCode::GenMultCode_construct(vector<vector<mult_s> > term,vector<vector<mult_s> > script,int inDataWidth,string fname,vector<int> mult_array,int ClkEn,int Async,string comments) {
  int numOfMultipliers;
  vector<MathVHDL_var*> pTerm;
  vector<MathVHDL_var*> pMult;
  MathVHDL_var* pDIn;
  vector<MathVHDL_var*> Mult;
  
  int i;
  char str[80];
  vector<string> str_label;
//  VarContainer* mTerm;

//  codeScript.clear();
  
  m_ClkEn = ClkEn;
  m_AsyncMult = Async;
  
  m_code = new GenMathVHDL(fname); // create new VHDL file  

  m_code->AddComments("Multipliers Array Generator (v1.0)");
  m_code->AddComments("");
  
  for (i=0;i<mult_array.size();i++) {
  	//sprintf(str,"Mult%d=%d",i,mult_array[i]);
  	sprintf(str,"Mult%d=%d",i,mult_array[i]);
  	m_code->AddComments(str);
  	sprintf(str,"Mult_%d",mult_array[i]);
  	str_label.push_back(str);
  }
  m_code->AddComments(comments);

  numOfMultipliers = script.size();

  printf("GenIoPort\r\n");
  GenIOPort(inDataWidth);
  printf("GenCommon\r\n");
  GenCommon(inDataWidth);

  // Create Pointer to Din
  pDIn = new MathVHDL_var("DIn",VHDL_var_std_logic_vector,inDataWidth-1,0,MatVHDL_var_DIN,0,1,0,1,"",0);

  cout << "############### Generate Terms ###################\r\n";
  m_code->AddCodeTitle("Generate Terms");
  pTerm = Gen_pMult(term,pDIn,pTerm);
  
  cout << "############### Generate Code ####################\r\n";
  m_code->AddCodeTitle("Copy Terms Result from Temp to Term");
  cout << "Copy Terms\r\n";
  pTerm = m_code->CopyToNewArray(pTerm,"Term",0);
  m_code->AddCodeTitle("Sample Terms");
  cout << "Resample Terms\r\n";

  if (!m_AsyncMult) pTerm = m_code->ResampleArray(pTerm,m_ClkEn);


  m_code->AddCodeTitle("Generate Multipliers Array");
  //cout << "ScriptSize:" << script.size() << "\r\n";
  cout << "Run Gen_pMult\r\n";
  pMult = Gen_pMult(script,pDIn,pTerm);
  //cout << "pMult Final Size:" << pMult.size() << "\r\n";

  cout << "############### Final Stage ######################\r\n";
  m_code->AddCodeTitle("Final Stage Multipliers");
  for(i=0;i<pMult.size();i++) {
    Mult.push_back(m_code->Gen_FinalOut(pMult[i],"",0,mult_array[i],inDataWidth));
  }

//  for (i=0;i<str_label.size();i++) {
//  	cout << "GM label :" << Mult[i]->GetLabel() << "\r\n";
//  }

  mult_out_vector = Gen_FinalStage(Mult);

}

GenMultCode::~GenMultCode() {
  delete(m_code);              // Close File, generate code
}

vector<MathVHDL_var*> GenMultCode::GetOutVector() {
	return(mult_out_vector);
}

// This function generates component for implemintation
string GenMultCode::GetComponent() {
	vector<string> strV;
	string str;
	int i;

    strV = m_code->GetComponent();
    str = "";
    for (i=0;i<strV.size();i++)
        str += ("  "+strV[i]+"\r\n");
        
    return(str);    
}

string GenMultCode::GetPortMapCon(string ImplementName, string ClkName, MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut) {
	string str;
	vector<MathVHDL_var*> OutVector;
	int i;
	
	OutVector = GetOutVector(); 

    if (MultOut.size() != OutVector.size()) {
    	return("ERROR MultOut Size <> OutVector Size");
    }
	str =  (ImplementName + ":" + m_code->GetFileName() + " port map (\r\n");
	str += ("     CLK   => " + ClkName + ",\r\n");
	str += ("     DIn   => " + DIn->GetVarName() + ",\r\n");
	
	for (i=0;i<OutVector.size();i++) {
	     str += ("     " + (OutVector[i])->GetVarName() + " => " + (MultOut[i])->GetVarName());
	     if (i<OutVector.size()-1) str+=",";
	     str +=  + "\r\n";
	}
	str += "  );\r\n";
	return(str);
}

string GenMultCode::GetPortMapCon_ClkEn(string ImplementName, string ClkName, string ClkEnName, MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut) {
	string str;
	vector<MathVHDL_var*> OutVector;
	int i;
	
	OutVector = GetOutVector(); 

    if (MultOut.size() != OutVector.size()) {
    	return("ERROR MultOut Size <> OutVector Size");
    }
	str =  (ImplementName + ":" + m_code->GetFileName() + " port map (\r\n");
	str += ("     CLK   => " + ClkName + ",\r\n");
	str += ("     CLK_EN   => " + ClkEnName + ",\r\n");
	str += ("     DIn   => " + DIn->GetVarName() + ",\r\n");
	
	for (i=0;i<OutVector.size();i++) {
	     str += ("     " + (OutVector[i])->GetVarName() + " => " + (MultOut[i])->GetVarName());
	     if (i<OutVector.size()-1) str+=",";
	     str +=  + "\r\n";
	}
	str += "  );\r\n";
	return(str);
}


