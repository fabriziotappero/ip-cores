///////////////////////////////////////////////////////////////
// Automatic FIR Generator Tool                              //
// Used to generate optimized FIR Filters/Corelators         //
// using Nonrecursive Signed Common Subexpression Algorithm  //
///////////////////////////////////////////////////////////////
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
// Last Update : 8/5/2005 - parisng using popt
//

#include <vector>
#include <string>

#include <popt.h>
#include <stdio.h>

#include "MultGen.h"
#include "FirGenCode.h"

#include <sys/time.h>

///////////////////////////////////////////////////////////////
// Convert String Line [int,int,int] to Integer Vector Array
vector<int> StrLine2CoefArray(string strLineIn) {
	vector<int> ar;
	string str;
	char ch;
	int temp;
	
	str="";
	for (int i=0;i<strLineIn.size();i++) {
		ch=strLineIn[i];
		str += ch;
		if (ch==',') {
			sscanf(str.c_str(),"%d",&temp);
            ar.push_back(temp);
            str = "";
		}
	}
    
    // Scan Last Expression if exist
    if (str.size()>0) {
       sscanf(str.c_str(),"%d",&temp);
       ar.push_back(temp);
    }
	
	
	return(ar);
}
/*
int GenFir(string fname,int inDataWidth,vector<int> multVector) {
	
	int pm_flag;
	int i,j;
	vector<int> ar;
	int dublicateFlag = 0;
	
	// Find +/- coefitions
	for (i=0;i<multVector.size();i++) {
		dublicateFlag = 0;
		for (j=i+1;j<multVector.size();j++) {
			if (multVector[i]==(-1)*multVector[j]) {
				pm_flag = 1; // Set PM FLAG
				dublicateFlag = 1;
			} 
		}
		if (!dublicateFlag) {
			printf("%d,",multVector[i]);
		}
	}
}*/

///////////////////////////////////////////
//                MAIN                   //
///////////////////////////////////////////
int main(int argc,char *argv[]) {
 
  int temp;
  int i;
  int result;
  vector<int> ar;

  int inDataWidth = 0;
  char testStr[] = "10";


  char *fname;
  char* coef_str;
  char c;
  
  int gen_Fir_nMult = 1;
  int gen_AsyncMult = 0;
  int gen_ClkEn     = 0;
  
  MultGen* mMultGen;
  FirGenCode* mFirGen;
  
  string params_str;
   
  struct poptOption myOptions[] = {
  	{ "input_width", 'w', POPT_ARG_INT, &inDataWidth,1,
  		                                    "Input Data Width", "16"},
  	{ "multiply_only", 'm', 0, 0, 2,
  		                                    "Generate Only Multipliers Array","zzz"},
  	{ "async_mult", 'a', 0, 0, 3,
  		                                    "Generate Asynchronus Multipliers Array","zzz"},
  	{ "clk_en", 'e', 0, 0, 4,
  		                                    "Use CLK Enable Signal","zzz"},

  	{ "coef", 'c', POPT_ARG_STRING, &coef_str, 5,
  		                                    "filter coefitions", "1234,4535,5656,.."},
  	{ "out", 'o', POPT_ARG_STRING, &fname, 6,
  		                                    "Output File Name (.VHD Extension not needed)", "fir_test"},

    POPT_AUTOHELP
    POPT_TABLEEND
  };

  poptContext optCon;

  cout << "FIR Filter /Multiplication Array Optimization Programm  \r\n";
  cout << "VHDL File Generator\r\n";
  cout << "Writed by : Boris Kipnis\r\n";
  cout << "----------------------------\r\n";
  
  inDataWidth = -1;
  coef_str = NULL;
  fname = NULL;
  optCon = poptGetContext(NULL,argc,(const char**)argv,myOptions,0);

  gen_Fir_nMult = 1;
  gen_AsyncMult = 0;
  gen_ClkEn = 0;
  
  while ((c = poptGetNextOpt(optCon)) >= 0) {
  	if (c==2) gen_Fir_nMult = 0;
  	if (c==3) {
  	   gen_AsyncMult = 1;
  	   gen_Fir_nMult = 0;
  	   cout << "JOPA !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\r\n";
  	}
  	if (c==4) gen_ClkEn = 1;
  }
  
  if ((inDataWidth<=0)||(coef_str==NULL)||(fname==NULL)) {
  	printf("ERROR Invalid Input parameters\r\n");
  	printf("Run -? option for more information");
  	return(1);
  }

  time_t tt;
  struct tm ut;  
  tt = time(NULL);
  localtime_r(&tt, &ut);
  cout << "Date - " << ut.tm_mday << "/" << ut.tm_mon+1 << "/" << (1900+ut.tm_year) << "\r\n";
  cout << "Time - "<< ut.tm_hour << ":" << ut.tm_min << ":" << ut.tm_sec << "\r\n";

  printf("Data Width %d\r\n",inDataWidth);

  ar = StrLine2CoefArray(coef_str);

  // Print Arguments
  printf("Using following COEF:");
  for (i=0;i<ar.size();i++) {
    printf("%d,",ar[i]);
  }
  printf("\r\n");

  params_str = "arguments:";
  for (i=0;i<argc-1;i++) {
   	 params_str += " ";
   	 params_str += argv[i+1]; 
  }
  
  ////////////////////////////////////////////////////////////////////
  if (gen_Fir_nMult==0) {
  	 printf("Generate Multiplier Array");
     mMultGen = new MultGen(fname,inDataWidth,ar,gen_ClkEn,gen_AsyncMult,params_str);
     delete mMultGen; // erase the class and save VHDL file
  } else {
     printf("Generate FIR Filter");
     mFirGen = new FirGenCode(fname,inDataWidth,ar,gen_ClkEn,params_str);
     delete mFirGen;
  }
   
  ////////////////////////////////////////////////////////////////////
  // FREE Memory
  ar.clear(); // remove aray
  printf("The END\r\n");
  // 
  
  return(0);
}
