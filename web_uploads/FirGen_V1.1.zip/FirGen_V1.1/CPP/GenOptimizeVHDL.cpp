#include "GenOptimizeVHDL.h"

///////////////////////////////////////////////////////////////////////////////////////////////
// This Function Replace Variable (by name) and all their index values by new variable
// this done by 2 steps:
//   1) Find all instances of variable name and replace them
//   2) Regenerate VHDL Code
// note : this function replace only A/B variables
//        it don't tach destination variable
void GenOptimizeVHDL::ReplaceVar(MathVHDL_var* PrevVar,MathVHDL_var* NewVar_in) {
   int i,j;
   MathExpresionVHDL* ComplexMult;
   coreGen_element_s el;
   vector<MathExpresionVHDL*> newCode;
   MathExpresionVHDL* newMult;
   bool updateFlag;
   int sign,shift;
   MathVHDL_var* NewVar;
  
   newCode.clear();
 
   NewVar = new MathVHDL_var(NewVar_in); // Generate new instance for replaced variable
                                         // used to avoid existing variable overlaping with new sign and shift
 
   for (i=0;i<mCode.size();i++) {
   	 // Read Single Multiplier Expression
   	 ComplexMult = mCode[i];
   	 // create new Math Expression
     newMult = new MathExpresionVHDL();
  	 for (j=0;j<ComplexMult->GetSize();j++) {
 	   el = GetElement(i,j);
 	   updateFlag = false;
 	   if ((el.a!=NULL)&&(el.a->GetVarName() == PrevVar->GetVarName())) {
 	   	   sign = el.a->GetSign();
 	   	   shift = el.a->GetShift();
 	   	   el.a = NewVar;
 	   	   el.a->SetSign(sign);
 	   	   el.a->SetShift(shift);
 	   	   updateFlag = true;
 	   }
 	   if ((el.b!=NULL)&&(el.b->GetVarName() == PrevVar->GetVarName())) {
 	   	   sign = el.b->GetSign();
 	   	   shift = el.b->GetShift();
 	   	   el.b = NewVar;
 	   	   el.b->SetSign(sign);
 	   	   el.b->SetShift(shift);
 	   	   updateFlag = true;
 	   }
 	   // Regenerate code
 	   if (updateFlag==true) {
 	   	  //sign = el.dest->GetSign();
    	  //shift = el.dest->GetShift();
    	  el.dest->SetSign(1); // rest sign flag before operation
    	                       // sign flag reseted because *(-1) function is used inside of GEN A op B
          el = *mGenMath->Gen_A_op_B_VHDL(el.cmd,el.a,el.b,el.dest);
 	      //el.dest->SetSign(sign);
 	      //el.dest->SetShift(shift);
 	      //cout << "------------ Updated Line --------------\r\n";
 	      //cout << el.code;
 	   }
 	   newMult->Add(el);
	 }
 	 newCode.push_back(newMult);	 
  } 
  mCode = newCode; // Replace Code with new code 
  
}

/////////////////////////////////////////////////////////////////////////////////////////
// Get element at ptr position
coreGen_element_s GenOptimizeVHDL::GetElement(XYPtr ptr) {
	MathExpresionVHDL* ComplexMult;
	ComplexMult = mCode[ptr.x];
	return(ComplexMult->GetElement(ptr.y));
}

coreGen_element_s GenOptimizeVHDL::GetElement(int MultiplyFunction, int SubExpression) {
	XYPtr ptr;
	ptr.x = MultiplyFunction;
	ptr.y = SubExpression;
	return(GetElement(ptr));
}


//////////////////////////////////////////////////////////////////////////////////////////
// This function looks for a(cmd)b expression
// return pointer array (ComplexMult,Single Arithmetic)
vector<XYPtr> GenOptimizeVHDL::FindMathExpression(int cmd,MathVHDL_var* a,MathVHDL_var* b) {
  int i,j;
  coreGen_element_s el;
  vector<XYPtr> table;
  XYPtr ptr;

  table.clear();

  //cout << "Enter FindMathExpression\r\n";
	
  for (i=0;i<mCode.size();i++) {
 	 for (j=0;j<mCode[i]->GetSize();j++) {
 	 	//cout << "i=" << i << " j=" << j <<"\r\n";
 	 	ptr.x = i;
 	 	ptr.y = j;
 	    el = GetElement(ptr);
 	    //cout << "<";
 	    if ((el.cmd == CMD_EQUAL) ||
            (el.cmd == CMD_BLANK) ||
            (el.cmd == CMD_ZERO) ||
            (cmd == CMD_EQUAL) ||
            (cmd == CMD_BLANK) ||
            (cmd == CMD_ZERO) ||
            (a == NULL) || (b == NULL)
            ) {
            	//cout << "zzz\r\n";
            	// nothing to optimize
        } else {
 	       if ( (el.dest != NULL) &&
 	            (el.cmd == cmd)  &&         // Check command
 	            (el.a->EqualPM(*a)==true) &&  // Check A Variable Name
 	            (el.b->EqualPM(*b)==true) ) { // Check B Variable Name
 	            if ( (el.a->GetSign() * el.b->GetSign()) == (a->GetSign() * b->GetSign()) ) {
 	               table.push_back(ptr);	
 	          }
 	        }
        }
        //cout << ">\r\n";
 	 }
  }
  //cout << "Exit FindMathExpression\r\n";
  return(table);
}

///////////////////////////////////////////////////////////////////////
// Scan Code for dublicated expresions                               //
// First dublicated expression *Object (copy) returned               //
// NULL if none                                                      //
///////////////////////////////////////////////////////////////////////
coreGen_element_s* GenOptimizeVHDL::FindDuplicatedExpression(void) {
  vector<XYPtr> ExpAr;
  coreGen_element_s* el;
  int i,j;
	
  el = new coreGen_element_s;
  
  //cout << "Enter FindDuplicatedExpression\r\n";
  	
  for (i=0;i<mCode.size();i++) {
 	 for (j=0;j<mCode[i]->GetSize();j++) {
 	 	 *el = GetElement(i,j);
 	 	 //cout << "Inside Loop I:"<<i<<" J:" << j << "\r\n";
 	 	 ExpAr = FindMathExpression(el->cmd,el->a,el->b);
 	 	 //cout << "After FindMathExpression\r\n";
 	 	 if (ExpAr.size()>1) {
 	 	 	cout << "Dublicated ("<<i<<","<<j<<") ArraySize:" << ExpAr.size() << "\r\n";
 	 	 	//cout << el.code << "\r\n";
            //cout << "Return FindDuplicatedExpression\r\n";
 	 	 	return(el);
 	 	 }
 	 }
  }
  //cout << "Return NULL FindDuplicatedExpression\r\n";
  return(NULL);
}

//////////////////////////////////////////////////////////////////////////////
// Change Code Expression at current(x,y) location with new one             //
//////////////////////////////////////////////////////////////////////////////
void GenOptimizeVHDL::ChangeExpression(XYPtr exPtr,MathExpresionVHDL ex) {
   int i,j;
   MathExpresionVHDL* ComplexMult;
   coreGen_element_s el;
   vector<MathExpresionVHDL*> newCode;
   MathExpresionVHDL* newMult;
   bool updateFlag;
  
   newCode.clear();
  
   for (i=0;i<mCode.size();i++) {
   	 // create new Math Expression
     newMult = new MathExpresionVHDL();
  	 for (j=0;j<mCode[i]->GetSize();j++) {
 	   el = GetElement(i,j);
 	   if ((exPtr.x==i)&&(exPtr.y==j)) {
 	      newMult->Add(ex);
 	   } else {
 	      newMult->Add(el);
 	   }
	 }
 	 newCode.push_back(newMult);	 
  } 
  mCode = newCode; // Replace Code with new code 
}

/////////////////////////////////////////////////////////////////////////////
// Delite Expression at(X,Y)                                               //
/////////////////////////////////////////////////////////////////////////////
void GenOptimizeVHDL::DeliteExpression(XYPtr exPtr) {
   int i,j;
   MathExpresionVHDL* ComplexMult;
   coreGen_element_s el;
   vector<MathExpresionVHDL*> newCode;
   MathExpresionVHDL* newMult;
   bool updateFlag;
  
   newCode.clear();
  
   for (i=0;i<mCode.size();i++) {
   	 // create new Math Expression
     newMult = new MathExpresionVHDL();
  	 for (j=0;j<mCode[i]->GetSize();j++) {
 	   el = GetElement(i,j);
 	   if ((exPtr.x==i)&&(exPtr.y==j)) {
 	   } else {
 	      newMult->Add(el);
 	   }
	 }
 	 newCode.push_back(newMult);	 
  } 
  mCode = newCode; // Replace Code with new code 
}

////////////////////////////////////////////////////////////////////////////
// Optimization routine                                                   //
// This routine looks for common expressions and gather their functions   //
////////////////////////////////////////////////////////////////////////////
void GenOptimizeVHDL::OptimizeCommonExpression(void) {
  int i;
  coreGen_element_s* el;
  coreGen_element_s el_temp;
  vector<XYPtr> ExpAr;
  XYPtr tempXY;
  MathVHDL_var* a;
  MathVHDL_var* b;
  MathExpresionVHDL* ComplexMult;
  
  //cout << "func: OptimizeCommonExpression\r\n";
	
  do {
  	el = FindDuplicatedExpression(); // check for dublicated expressions
  	//cout << "After FindDuplicatedExpression()\r\n";
  	
  	if (el!=NULL) {
  		cout << "Found dublicated:\r\n"; 
 	    
 	 	ExpAr = FindMathExpression(el->cmd,el->a,el->b); // Extract dublicated expression positions
 	    
 	    //cout << "Dublicated Extracted\r\n";
 	    //tempXY = ExpAr[0];
 	 	//cout << "OptimizeCommonExpression x:" << tempXY.x << " y:" << tempXY.y << "\r\n";
 	 	a = GetElement(ExpAr[1]).dest;
 	 	b = GetElement(ExpAr[0]).dest;
 	 	
 	 	ComplexMult = mCode[ExpAr[1].x];
 	 	if (ComplexMult->GetSize()>1) {
 	 		
 	 	   //cout << "Replace\r\n";
 	 	   ReplaceVar(a,b); // Replace Destionation of common expression 	 	   
 	 	   //cout << "Delite\r\n";
 	   	   DeliteExpression(ExpAr[1]); // Delite Common expression
 	   	   
 	 	} else {
 	 	   ReplaceVar(a,b); // Replace Destionation of common expression
 	 	   ComplexMult = new MathExpresionVHDL();
 	 	   el = new coreGen_element_s;
 	 	   el->a    = GetElement(ExpAr[0]).dest;
 	 	   el->b    = el->a;
 	 	   el->dest = GetElement(ExpAr[1]).dest;
 	 	   el->cmd = CMD_EQUAL;
 	 	   el->code = (el->dest)->GetVarName() + " <= " + (el->a)->GetVarName() + "; -- Optimized\r\n";
 	 	   ComplexMult->Add(*el);
 	 	   ChangeExpression(ExpAr[1],*ComplexMult);
 	   	   //DeliteExpression(ExpAr[1]); // Delite Common expression
 	 	   cout << "Main PTR";
 	 	}
  	}
  } while (el!=NULL);
    
}

// Constructor
GenOptimizeVHDL::GenOptimizeVHDL(GenMathVHDL* GenMath_in,vector<MathExpresionVHDL*> CodeIn,vector<MathVHDL_var*> varList) {
	mGenMath = GenMath_in; // pointer to father class
	mCode = CodeIn;
	mVarList = varList;
	OptimizeCommonExpression();
}

//////////////////////////////////////////////////////////////////////////////////////////
// Re-Generate Code
// This fuction generates VHDL code using new mathematics expressions
vector<MathExpresionVHDL*> GenOptimizeVHDL::ReGen(vector<MathExpresionVHDL*> CodeIn) {
}

vector<MathExpresionVHDL*> GenOptimizeVHDL::GetNewCode() {
  return(mCode);
}

vector<MathVHDL_var*> GenOptimizeVHDL::GetNewVarList() {
  return(mVarList);
}
