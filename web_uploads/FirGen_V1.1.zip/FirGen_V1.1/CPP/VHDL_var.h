#ifndef VHDL_var_H
#define VHDL_var_H

#define VHDL_var_others           0
#define VHDL_var_integer          1
#define VHDL_var_std_logic        2
#define VHDL_var_std_logic_vector 3

#define STD_VHDL_VAR_VER  0x01

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

using namespace std;


class VHDL_var {
 protected :
   string name;
   int var_ver;
   int type;
   int range_from;
   int range_to;
   int port_In_nOut; // input/output for ports values
   string str_label;
   void* attach;     // Extra Information Attached to variable

 public :
   VHDL_var(string name,int type,int range_from,int range_to,int In_nOut,string str_label,void* attach); // constructor 
   VHDL_var(VHDL_var* cloneIn);
   VHDL_var(VHDL_var* cloneIn,int pipeDelay);

   ~VHDL_var();
   string GetVarName();
   int    GetVarType();      // return variable type
   string GetVarTypeStr();   // return variable type as string 
   int    GetRangeFrom(); 
   int    GetRangeTo();
   int    GetPortType();
   string GetPortTypeStr();
   void*  GetAttachment();
   int    GetVHDL_VarVer(); // Get VHDL_var creator info (Original var,Math, ets.)
   void   SetVarRange(int from,int to);
   int    GetVarBitSize();
   string GetLabel();
   void   SetLabel(string str);
};

#endif
