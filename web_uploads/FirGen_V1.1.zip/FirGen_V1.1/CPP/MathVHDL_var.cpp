//////////////////////////////////////////////////////////////////
// Mathematical Variable Container
//
// Writer      : Boris Kipnis
// Last Update : 5/5/2005
//
#include "MathVHDL_var.h"
#include "VHDL_var.h"

MathVHDL_var::MathVHDL_var(string name,int type,int range_from,int range_to,
			   int mathVarType,int shift,int sign,int termNum,
               int In_nOut=(-1),string str_label="",void* attach=NULL) : VHDL_var(name,type,range_from,range_to,In_nOut,str_label,attach) {
  
  var_ver |= MATH_VHDL_VAR_VER;

  this->mathVarType = mathVarType;
  this->shift       = shift;
  this->sign        = sign;
  this->termNum     = termNum;
  this->str_label   = str_label;
  this->attach      = attach;
  //printf("MathVHDL_var Sign=%d\r\n",sign);
}

MathVHDL_var::MathVHDL_var(MathVHDL_var* cloneIn) : VHDL_var(cloneIn) {
  this->var_ver     = cloneIn->GetVHDL_VarVer();  
  this->var_ver    |= MATH_VHDL_VAR_VER;

  this->name         = cloneIn->GetVarName(); 
  this->type         = cloneIn->GetVarType();
  this->range_from   = cloneIn->GetRangeFrom();
  this->range_to     = cloneIn->GetRangeTo();
  this->port_In_nOut = cloneIn->GetPortType();
  this->attach       = cloneIn->GetAttachment();

  this->mathVarType = cloneIn->GetMathVarType();
  this->shift       = cloneIn->GetShift();
  this->sign        = cloneIn->GetSign();
  this->termNum     = cloneIn->GetTermNum();

  this->str_label   = cloneIn->GetLabel();
}

MathVHDL_var::MathVHDL_var(MathVHDL_var* cloneIn,int pipeDelay) : VHDL_var(cloneIn) {
  int i;

  this->var_ver     = cloneIn->GetVHDL_VarVer();  
  this->var_ver    |= MATH_VHDL_VAR_VER;

  this->name         = cloneIn->GetVarName(); 
  for (i=0;i<pipeDelay;i++) {
    this->name+="_d";
  }
  this->type         = cloneIn->GetVarType();
  this->range_from   = cloneIn->GetRangeFrom();
  this->range_to     = cloneIn->GetRangeTo();
  this->port_In_nOut = cloneIn->GetPortType();
  this->attach       = cloneIn->GetAttachment();

  this->mathVarType = cloneIn->GetMathVarType();
  this->shift       = cloneIn->GetShift();
  this->sign        = cloneIn->GetSign();
  this->termNum     = cloneIn->GetTermNum();
  
  this->str_label   = cloneIn->GetLabel();
}

int MathVHDL_var::GetShift() {
  if (!(var_ver & MATH_VHDL_VAR_VER)) return(0);
  return(shift);
}
int MathVHDL_var::GetSign() {
  if (!(var_ver & MATH_VHDL_VAR_VER)) return(0);
  return(sign);
}
int MathVHDL_var::GetMathVarType() {
  if (!(var_ver & MATH_VHDL_VAR_VER)) return(0);
  return(mathVarType);
}

///////////////////////////////////////////////////////////////////////////////////////
//  Generate Mathematics Variable From Multipliers Script                            //
///////////////////////////////////////////////////////////////////////////////////////
MathVHDL_var* MathVHDL_var::Script2MathVHDL_var(mult_s s,string termStr,string dinStr,int dataSizeBits=0) {
  MathVHDL_var* var;
  int sign;
  int shift;
  string name;
  char myChar[200];
  int termNum;
  int type;
  
  shift = s.shift;
  termNum = s.termNum;
  type = 0;

  switch(s.type) {
    case TERMT_PP :
    case TERMT_PM :
      type = MatVHDL_var_TERM;
      sprintf(myChar,"%s%d",termStr.c_str(),s.termNum);
      name = myChar;
      sign = 1;
      break;
 
    case TERMT_MM :
    case TERMT_MP :
      type = MatVHDL_var_TERM;
      sprintf(myChar,"%s%d",termStr.c_str(),s.termNum);
      name = myChar;
      sign = (-1);
      break;
 
    case SIG_P    :
      type = MatVHDL_var_DIN;
      sprintf(myChar,"%s%d",dinStr.c_str(),s.termNum);
      name = myChar;
      sign = 1;
      break;
 
    case SIG_M    :
      type = MatVHDL_var_DIN;
      sprintf(myChar,"%s%d",dinStr.c_str(),s.termNum);
      name = myChar;
      sign = (-1);
      break;

    default :
      name = "";
      sign = 0;
      break;
  }
 
  var = new MathVHDL_var(name,VHDL_var_std_logic_vector,dataSizeBits-1,0,type,shift,sign,termNum,(-1),NULL);

  return(var);
}

int MathVHDL_var::GetTermNum() {
  return(termNum);
}

void MathVHDL_var::MultMinus1() {
  //printf("Mult-1\r\n");
  if (var_ver & MATH_VHDL_VAR_VER) {
    this->sign = this->sign * (-1);
  } else {
  	printf("ERROR Can not MultMinus1 non mathematics variable");
  }
}

void MathVHDL_var::SetShift(int newShift) {
  if (var_ver & MATH_VHDL_VAR_VER) {
    shift = newShift;
  }
}

void MathVHDL_var::SetSign(int newSign) {
  this->sign = newSign;
}

// Check for current variable = +/- Input Variable
bool MathVHDL_var::EqualPM(MathVHDL_var v) {
	if ( (GetVarName() == v.GetVarName()) &&
   	     (GetShift()   == v.GetShift()) ) return(true);
   	     
   	return(false);     
}
