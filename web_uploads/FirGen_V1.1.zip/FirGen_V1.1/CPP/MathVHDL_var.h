#ifndef MATH_VHDL_VAR_H
#define MATH_VHDL_VAR_H

#include "VHDL_var.h"
#include "GenMultScript.h"

#define MATH_VHDL_VAR_VER  0x02

#define MatVHDL_var_DIN  1
#define MatVHDL_var_TERM 2
#define MatVHDL_var_TEMP 3
#define MatVHDL_var_MULT 4

class MathVHDL_var : public VHDL_var {
 protected :
   int shift;
   int sign;
   int mathVarType;
   int termNum;

 public:
   MathVHDL_var(string name,int type,int range_from,int range_to,
                int mathVarType,int shift,int sign,int termNum,
                int In_nOut,string str_label,void* attach);
   MathVHDL_var(MathVHDL_var* cloneIn);
   MathVHDL_var(MathVHDL_var* cloneIn,int pipeDelay);

   int GetShift();
   int GetSign();
   int GetMathVarType();
   int GetTermNum();
   MathVHDL_var* Script2MathVHDL_var(mult_s s,string termStr,string dinStr,int dataSizeBits);
   void MultMinus1();
   void SetShift(int newShift);
   void SetSign(int newSign);
   bool EqualPM(MathVHDL_var v);  
};

#endif
