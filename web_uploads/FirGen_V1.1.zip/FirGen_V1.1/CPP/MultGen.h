#ifndef MultGen_H
#define MultGen_H

#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <stdlib.h>

#include "GenMultScript.h"
#include "GenMultCode.h"
#include "MathVHDL_var.h"

using namespace std;

class MultGen  {
	private :
      GenMultCode *m_genCode;
      vector<MathVHDL_var*> mult_out_vector;
	  
	public:
	  // Constructor (File Name, Input Data Width, Multiplication Vector)
	  MultGen(string fname,int inDataWidth,vector<int> multVector,int ClkEn,int Async,string comments); 
      void MultGen_construct(string fname,int inDataWidth,vector<int> multVector,int ClkEn,int Async,string comments);
	  
	  ~MultGen();
      vector<MathVHDL_var*> GetOutVector();
	  
	  //vector<int> GetOutBitsize(); // Multiply output bit size
	  //vector<string> GetComponent(); // Get Component Implementation Header
	  
	  // Get Component Implementation Header
	  // Return string
	  string GetComponent(); 
	  
	  // Get connection to port map
	  // return string
	  string GetPortMapCon(string ImplementName,string ClkName, MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut);
	  string GetPortMapCon_ClkEn(string ImplementName,string ClkName,string ClkEnName,MathVHDL_var* DIn, vector<MathVHDL_var*> MultOut);
};

#endif
