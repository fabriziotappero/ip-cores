//////////////////////////////////////////////////////////////////////////////
// Filename:          D:\mb-jpeg\drivers/fsl_dct_v1_00_a/src/fsl_dct.c
// Version:           1.00.a
// Description:       fsl_dct (FSL DCT accelerator) Driver Source File
// Date:              Fri Jul 21 08:31:12 2006 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////

#include "fsl_dct.h"
/*
* Write your driver implementation in this file.
*/

