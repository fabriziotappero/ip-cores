#ifndef _EJPGL_H
#define _EJPGL_H

#define MATRIX_SIZE 8
#define MACRO_BLOCK_SIZE 16

int idct8x8(int* fblock, char* sblock);

#endif

