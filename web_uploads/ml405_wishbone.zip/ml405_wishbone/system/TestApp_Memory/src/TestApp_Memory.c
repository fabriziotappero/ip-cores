/*
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A 
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR 
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION 
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE 
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO 
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO 
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE 
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 */

/*
 * Xilinx EDK 10.1.03 EDK_K_SP3.6
 *
 * This file is a sample test application
 *
 * This application is intended to test and/or illustrate some 
 * functionality of your system.  The contents of this file may
 * vary depending on the IP in your system and may use existing
 * IP driver functions.  These drivers will be generated in your
 * XPS project when you run the "Generate Libraries" menu item
 * in XPS.
 *
 * Your XPS project directory is at:
 *    C:\Temp\ml405_wishbone\system\
 */


// Located in: microblaze_0/include/xparameters.h
#include "xparameters.h"
#include "stdio.h"
#include "xutil.h"
#include "xio.h"
//====================================================

#define STDIN_BASEADDRESS   0x90000000
#define STDOUT_BASEADDRESS  0x90000000

#define REG_DATA 0x00
#define REG_STAT 0x04


void outbyte(char ch)
{
 
  while((XIo_In8(STDOUT_BASEADDRESS+REG_STAT) & 0x01) == 0);

  XIo_Out8(STDOUT_BASEADDRESS+REG_DATA,ch);
}

char inbyte(void)
{
  char ch;
  while((XIo_In8(STDOUT_BASEADDRESS+REG_STAT) & 0x2) == 0);
  
  ch = XIo_In8(STDOUT_BASEADDRESS+REG_DATA);
  
  return(ch);
}

int main (void) {

  int i;
  char ch;

   xil_printf("\n\n\rHello World\n\r");

   for (i = 0; i < 4; i++) {
   	xil_printf("Byte %d\n\r", i);
   }

   xil_printf("Press any key...");
 
   while (1) {
     xil_printf("%c", inbyte());
   }   
 
   return 0;
}

