typedef struct
{
	int dummy__;

} YYNODESTATE;
