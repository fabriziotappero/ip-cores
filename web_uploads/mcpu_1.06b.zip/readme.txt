archive content:

ASM/
	- example programs.
	- simulator.
	- include file for smal.
	- smal.exe - see license for smal !
VHDL/
	- VHDL source of CPU.
	- VHDL testbench.
	- Memory files.
	- The testbench requires a simple sram implementation.
          I used this one: http://tech-www.informatik.uni-hamburg.de/vhdl/models/sram-simple/sram64kx8.vhd
 	  From the Hamburg VHDL archive (http://tech-www.informatik.uni-hamburg.de/vhdl/)

SMAL-source/
	- SMAL sourcode.

SIM-source/
   - WIN32 Simulator sourcecode. Porting to other platforms
     should be easy.

SMAL license:

/* smal32.c   language: C
   copyright 1996 by Douglas W. Jones
                     University of Iowa
                     Iowa City, Iowa  52242
                     USA

   Permission is granted to make copies of this program for any purpose,
   provided that the above copyright notice is preserved in the copy, and
   provided that the copy is not made for direct commercial advantage.

   Note: This software was developed with no outside funding.  If you find
   it useful, and especially if you find it useful in a profit making
   environment, please consider making a contribution to the University
   of Iowa Department of Computer Science in care of:

                     The University of Iowa Foundation
                     Alumni Center
                     University of Iowa
                     Iowa City, Iowa  52242
                     USA
*/


The other sources in this package are free, but I am always interested
in possible uses and modifications to it. Let me know what you are doing
with it.

