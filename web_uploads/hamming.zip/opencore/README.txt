compiled with mingwin-g++

Alexandre