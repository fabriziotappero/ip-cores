ppc0, powerpc, 32k on-chip ram, jtag, opb-uartlite baudrate 9600 stdio, plb-dcr-vga-controller, 256m on-board plb-ddr sdram address 0x30000000
mb0, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb1, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb2, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb3, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb4, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb5, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb6, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
mb7, microblaze, 8k on-chip ram, barrel-shifter, fpu, perfcnt
dp_ppc0_mb0, dpram, 8k, left ppc0 address 0x20000000, right mb0
dp_ppc0_mb1, dpram, 8k, left ppc0 address 0x20100000, right mb1
dp_ppc0_mb2, dpram, 8k, left ppc0 address 0x20200000, right mb2
dp_ppc0_mb3, dpram, 8k, left ppc0 address 0x20300000, right mb3
dp_ppc0_mb4, dpram, 8k, left ppc0 address 0x20400000, right mb4
dp_ppc0_mb5, dpram, 8k, left ppc0 address 0x20500000, right mb5
dp_ppc0_mb6, dpram, 8k, left ppc0 address 0x20600000, right mb6
dp_ppc0_mb7, dpram, 8k, left ppc0 address 0x20700000, right mb7
mbman, sw-project on mb0 mb1 mb2 mb3 mb4 mb5 mb6 mb7, source mb-man.c, c-flags -DMBMAN
mandelbrot, sw-project on ppc0, source mandel.c xupv2p.c, c-flags -D__SHOWPROGRESS -DNUM_COPROC=8, linkscript mandelbrot_linker_script
