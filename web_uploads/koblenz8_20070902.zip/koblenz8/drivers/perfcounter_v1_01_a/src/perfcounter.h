//////////////////////////////////////////////////////////////////////////////
//
// ***************************************************************************
// **                                                                       **
// ** Copyright (c) 1995-2005 Xilinx, Inc.  All rights reserved.            **
// **                                                                       **
// ** You may copy and modify these files for your own internal use solely  **
// ** with Xilinx programmable logic devices and Xilinx EDK system or       **
// ** create IP modules solely for Xilinx programmable logic devices and    **
// ** Xilinx EDK system. No rights are granted to distribute any files      **
// ** unless they are distributed in Xilinx programmable logic devices.     **
// **                                                                       **
// ***************************************************************************

#ifndef PERFCOUNTER_H
#define PERFCOUNTER_H

#ifdef __MICROBLAZE__
	#include "mb_interface.h" 
	#define write_into_fsl(val, id)  microblaze_bwrite_datafsl(val, id)
	#define read_from_fsl(val, id)  microblaze_bread_datafsl(val, id)
#else
	#include "xpseudo_asm_gcc.h" 
	#define write_into_fsl(val, id)  putfsl(val, id)
	#define read_from_fsl(val, id)  getfsl(val, id)
#endif

int perfcounter_init(int fsl);
void reset_and_stop_counter();
void reset_and_start_counter();
void start_counter();
void stop_counter();
unsigned int read_counter();


#endif 
