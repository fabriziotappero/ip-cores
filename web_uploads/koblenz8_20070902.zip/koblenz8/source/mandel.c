/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator on FPGA             Copyright (C) 2007, Sun Wei  *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at quickwayne@gmail.com   *
 * <quickwayne.googlepages.com>                                          *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator !                   Copyright (C) 2002, AnTiKoNs *
 *----------------------/                                                *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at antikons@ifrance.com   *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _MANDEL_C
#define _MANDEL_C

#ifdef __XUPV2P
#include <xparameters.h>
#include "xio.h"
#endif 
 
#include "mandel.h"

/*
La procedure mandel en Maple:

> mandel := proc(x,y)
>   local z,i,C;
>   C := x+I*y;
>   z := C;
>   for i from 1 to 50 do
>     z := z^2 + C;
>     if abs(z)>2 then
>       break;
>     fi;
>   od;
>   if i = 50 then
>     i := 0;
>   fi;
>   i;
> end;
*/

// #define __PPC_DRAW

int mandel_comm(FLOAT rmin, FLOAT rmax, FLOAT j, int y);


void mandel_build(UINT xsize, UINT ysize,
                 FLOAT rmin, FLOAT rmax, FLOAT jmin, FLOAT jmax,
                 UINT *grid) {
  UINT x,y,dwell;
  FLOAT rinc, jinc, j, r, oldr, oldj, rsq, jsq, nr, nj;

#ifdef __SHOWPROGRESS
	int count = 0;
#endif
   
  memset(grid,0,sizeof(UINT)*xsize*ysize);
  
  
#if defined(__PPC_DRAW)
  
  rinc = (rmax-rmin)/xsize;
  jinc = (jmax-jmin)/ysize;
  
  for( y=0, j=jmin; y < ysize ; y++ , j += jinc ) {
    for( x=0 , r=rmin ; x < xsize ; x++ , r+=rinc) {


      oldr = r;
      oldj = j;
      rsq = oldr*oldr;
      jsq = oldj*oldj;
      for(dwell=0;dwell<51;dwell++) {
        nr = (rsq - jsq) + r;
        nj = (2*oldr*oldj) + j;
        rsq = nr*nr;
        jsq = nj*nj;
        if( (rsq+jsq) > 4.0 ) {
          grid[y*xsize+x] = dwell;
          break;
        }
        oldr = nr;
        oldj = nj;
      }
	if (dwell>=51) dwell=0;
	mandel_write_pixel(x, y, dwell);
	
    }

#ifdef __SHOWPROGRESS
	if ((count&0x00000007) == 0) xil_printf("C"); 
	count++;
#endif
  }

#else  
  
  jinc = (jmax-jmin)/ysize;

  for( y=0, j=jmin; y < ysize ; y++ , j += jinc ) {

	  mandel_comm(rmin, rmax, j, y);

#ifdef __SHOWPROGRESS
	if ((count&0x0000000F) == 0) xil_printf("C"); 
	count++;
#endif
  }

#endif  
  
}



#endif

