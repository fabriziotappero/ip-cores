/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator on FPGA             Copyright (C) 2007, Sun Wei  *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at quickwayne@gmail.com   *
 * <quickwayne.googlepages.com>                                          *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __XUPV2P_C
#define __XUPV2P_C

#include <xparameters.h>
#include "xio.h"

#include "mandel.h"

UINT* grid;

int width = WIDTH;
int height = HEIGHT;

#define IMAGE_BASEADDR  0x30000000

int mandel_init() {

	memset(IMAGE_BASEADDR, 0, 2*1024*1024);
	grid = (UINT*)(IMAGE_BASEADDR+1024*1024*4);
	return 0;

}

int mandel_write_pixel(int x, int y, int pixel) {
	int base;
	int r, g, b;
	int  temp, writeaddr;

	base = IMAGE_BASEADDR;
	
	if (pixel>255) pixel=255;
	r=pixel*13;
	r=(r>255)?255:r;
	g=pixel*9;
	g=(g>255)?255:g;
	b=pixel*7;
	b=(b>255)?255:b;
	temp = ((((b<< 8) | g) << 8) | r);
	writeaddr = base+(y*1024+x)*4;
	XIo_Out32(writeaddr, temp);
	return 0;


}

void mandel_build(UINT xsize, UINT ysize,
                 FLOAT rmin, FLOAT rmax, FLOAT jmin, FLOAT jmax,
                 UINT *grid);

int mandel_comm(FLOAT rmin, FLOAT rmax, FLOAT j, int y) {
	int x, xsize;

#if 0
	xsize = WIDTH;

	while (pml->flag==1);
	pml->r0 = rmin; pml->r1 = rmax;
	pml->j = j; pml->y = y;
	pml->line = (int*)COMM_LINE;
	pml->flag = 1;
	while (pml->flag == 1);

// xil_printf("%x %x %x %x\r\n", pml->line, y, pml->line[0], pml->line[1]);

	for (x=0; x<xsize; x++) mandel_write_pixel(x, y, pml->line[x]);
	
	return 0;
#endif

}


volatile struct man_line_link* pml_list[NUM_COPROC];
volatile struct man_line_link* pml;
int comm_line[NUM_COPROC];
volatile unsigned int* pcnt[NUM_COPROC];

FLOAT xmin, xmax, ymin, ymax;
int linecount[NUM_COPROC];

FLOAT jinc, curr_j;
int curr_y;

int mandel_prepare() {
	int i;

	for (i=0; i<NUM_COPROC; i++) linecount[i]=0;
	curr_y=0;
	jinc=(ymax-ymin)/HEIGHT;
	curr_j = ymin;
	return 0;

}

int mandel_checkev() {
	int x;
	int i;

	for (i=0; i<NUM_COPROC; i++) {
		pml = pml_list[i];
		
		if (pml->flag==0) {
	//		xil_printf("%x %x %x %x\r\n", pml, pml->y, pml->magic, pml->j);
		
			if (pml->magic == MAGIC) {
				for (x=0; x<WIDTH; x++) mandel_write_pixel(x, pml->y, pml->line[x]);
#ifdef __SHOWPROGRESS
				if ((linecount[i]&0x0000000F) == 0) xil_printf("%c", 'A'+i); 
#endif
				linecount[i]++;
				}

			pml->r0=xmin; pml->r1=xmax;
			pml->j=curr_j; pml->y=curr_y;
			pml->line = (int*)comm_line[i];
			curr_y++; curr_j += jinc;
			pml->magic = 0;
			pml->flag = 1;
			}
		}
	
	return 1;

}

int main()
{
	int i;
	int sum;

	for (i=0; i<NUM_COPROC; i++) {
		pml_list[i] = (volatile struct man_line_link*)(COMM_BASE+i*0x100000);
		comm_line[i] = COMM_BASE+COMM_LINE_OFFSET+i*0x100000;
		pcnt[i]=(volatile unsigned int*)(COMM_BASE+i*0x100000+0x1ffc);
			
		pml = pml_list[i];
		pml->flag = 0;
		pml->magic = 0;
		}

  	xil_printf("\r\nMandelbrot Set Compiled at %s %s\r\n", __DATE__, __TIME__);
  	xil_printf("Turning caches on\r\n");

	XCache_EnableDCache(0xF000000F); 
	XCache_EnableICache(0xF000000F);

	XIo_Out32(0xD0000040, IMAGE_BASEADDR);
	XIo_Out32(0xD0000044, 0x1);  // turn on display

	  xmin = -2.0;
	  xmax = 1.4;
	  ymin = -1.5;
	  ymax = 1.4; 

	mandel_init();
#if __PPC_DRAW	
	mandel_build(width, height, xmin, xmax, ymin, ymax, grid);
#else
	mandel_prepare();
	for (;;) {
		mandel_checkev();
		for (i=0, sum=0; i<NUM_COPROC; i++) sum+=linecount[i];
		if (sum >= HEIGHT) break;
		}
#endif
	
  	xil_printf("\r\nNow, Look at your Monitor\r\n");
	xil_printf("Line counter ");
	for (i=0; i<NUM_COPROC; i++) {
		xil_printf("mb%d %d ", i , linecount[i]);
		}
	xil_printf("\r\n");
	xil_printf("Clock counter ");
	for (i=0, sum=0; i<NUM_COPROC; i++) {
		xil_printf("mb%d %d ", i , *pcnt[i]);
		sum+=*pcnt[i];
		}
	xil_printf("in total %d\r\n", sum);
	
	return 0;
  
}


#endif

