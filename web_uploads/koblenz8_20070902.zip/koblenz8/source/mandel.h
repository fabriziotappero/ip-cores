/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator on FPGA             Copyright (C) 2007, Sun Wei  *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at quickwayne@gmail.com   *
 * <quickwayne.googlepages.com>                                          *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* mandel.h : genere une fractale de mandelbrot */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator !                   Copyright (C) 2002, AnTiKoNs *
 *----------------------/                                                *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at antikons@ifrance.com   *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _MANDEL_H
#define _MANDEL_H

#define WIDTH       640
#define HEIGHT      512

typedef unsigned char      BYTE;  
typedef unsigned long int  DWORD; 
typedef unsigned short int WORD; 
typedef unsigned int       UINT;

#define FLOAT  float

struct man_line_link {
	int flag;
	float r0;
	float r1;
	float j;
	
	int y;
	int pad;
	int magic;
	int* line;
};

#define COMM_BASE 0x20000000
#define COMM_LINE_OFFSET 0x100

#define MAGIC 0x23410c56

#if 0
#if defined(__MB_MAN0)
#define COMM_BASE 0x20000000
#endif

#if defined(__MB_MAN1)
#define COMM_BASE 0x20100000
#endif

#if defined(__MB_MAN2)
#define COMM_BASE 0x20200000
#endif

#if defined(__MB_MAN3)
#define COMM_BASE 0x20300000
#endif

#if defined(__MB_MAN4)
#define COMM_BASE 0x20400000
#endif

#if defined(__MB_MAN5)
#define COMM_BASE 0x20500000
#endif

#if defined(__MB_MAN6)
#define COMM_BASE 0x20600000
#endif

#if defined(__MB_MAN7)
#define COMM_BASE 0x20700000
#endif

#define COMM_LINE COMM_BASE+0x100

#define COMM_BASE0  0x20000000
#define COMM_LINE0 COMM_BASE0+0x100

#define COMM_BASE1  0x20100000
#define COMM_LINE1 COMM_BASE1+0x100

#define COMM_BASE2  0x20200000
#define COMM_LINE2 COMM_BASE2+0x100

#define COMM_BASE3  0x20300000
#define COMM_LINE3 COMM_BASE3+0x100

#define COMM_BASE4  0x20400000
#define COMM_LINE4 COMM_BASE4+0x100

#define COMM_BASE5  0x20500000
#define COMM_LINE5 COMM_BASE5+0x100

#define COMM_BASE6  0x20600000
#define COMM_LINE6 COMM_BASE6+0x100

#define COMM_BASE7  0x20700000
#define COMM_LINE7 COMM_BASE7+0x100

#endif

#endif  
