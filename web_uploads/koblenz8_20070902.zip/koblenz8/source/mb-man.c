/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Mandelbrot Generator on FPGA             Copyright (C) 2007, Sun Wei  *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * The author of this program may be contacted at quickwayne@gmail.com   *
 * <quickwayne.googlepages.com>                                          *
 *                                                                       *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef MB_MAN_C
#define MB_MAN_C

#include <xparameters.h>
#include "xio.h"

#include "mandel.h"
#include "perfcounter.h"

volatile struct man_line_link* pml;
int xsize = WIDTH;

int mandel_line(FLOAT rmin, FLOAT rmax, FLOAT j, int* line) {
  UINT x,dwell;
  FLOAT rinc, jinc, r, oldr, oldj, rsq, jsq, nr, nj;

	start_counter();

	rinc = (rmax-rmin)/xsize; 
	memset(line, 0, WIDTH*sizeof(int));
  
    for( x=0 , r=rmin ; x < xsize ; x++ , r+=rinc) {

      oldr = r;
      oldj = j;
      rsq = oldr*oldr;
      jsq = oldj*oldj;
      for(dwell=0;dwell<51;dwell++) {   
        nr = (rsq - jsq) + r;
        nj = (2*oldr*oldj) + j;
        rsq = nr*nr;
        jsq = nj*nj;
        if( (rsq+jsq) > 4.0 ) {
		line[x] = dwell;
          	break; 
        }
        oldr = nr;
        oldj = nj;
      }
    } 

	stop_counter();

}

volatile unsigned int* pcnt;

int main() {

       perfcounter_init(0);
	reset_and_stop_counter();
	   
	pml = (volatile struct man_line_link*)(COMM_BASE+0x100000*PROCID);
	pcnt = (volatile unsigned int*)(COMM_BASE+0x100000*PROCID+0x1ffc);

	for (;;) {
		while (pml->flag==0);
		mandel_line(pml->r0, pml->r1, pml->j, pml->line);	
		pml->magic = MAGIC;
		pml->flag = 0;
		*pcnt = read_counter();
		}
	
}

#endif

