
Run the following command to generate Verilog HDL codes in GUI:
	
	$> perl perl/morphsGUI.pl

You need the perltk lib to run the GUI version, or you can run the command version:
	
	$> perl perl/Oracle.pl

All Verilog HDL codes are put into "module" directory. An encoder written in C is generated under "c" directory for verification.

The file "source" in the "data" directory contains the binary vectors for test. In order to generate the encode data, you need to type this command:
	
	$> c/encode8 < data/source > data/code

Then the encode data is prepared for simulation. And you can verify these Verilog HDL codes with any favorite simulator.

Good Luck!