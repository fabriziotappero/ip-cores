################################################################################
# ################################################################################  
# #                                                                              #  
# # Viterbi HDL Code Generator                                                   #  
# # Copyright (C) 2004  Sheng Zhu                                                #  
# #                                                                              #  
# # This program is free software; you can redistribute it and/or                #  
# # modify it under the terms of the GNU General Public License                  #  
# # as published by the Free Software Foundation; either version 2               #  
# # of the License, or (at your option) any later version.                       #  
# #                                                                              #  
# # This program is distributed in the hope that it will be useful,              #  
# # but WITHOUT ANY WARRANTY; without even the implied warranty of               #  
# # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #  
# # GNU General Public License for more details.                                 #  
# #                                                                              #  
# # You should have received a copy of the GNU General Public License            #  
# # along with this program; if not, write to the Free Software                  #  
# # Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  #  
# #                                                                              #  
# # If you have any problem, please email to me: mike@opencores.org              #  
# #                                                                              #  
# ################################################################################
################################################################################

sub testbench0()
{
my ($i, $j);

$CODE_LEN=10071;
$CODE_FILE="data/code";
$CLK_TIME=1;

print "`include \"$module_dir/glb_def.v\"\n";

print "
`define DEC_NUM $NUM_DEC_TBU           // equal to 2^(w+v)
`define RAM_BYTE_WIDTH $RAM_BYTE_WIDTH    // DEC_WIDTH*DEC_NUM
`define RAM_ADR_WIDTH  $RAM_ADR_WIDTH  // the size of ram is 1024bits, letting it be pow of two makes address generation work well.
`define OUT_STAGE_RADIX  $OUT_STAGE_RADIX    // the number of stages of one traceback output. It should be pow of two. The stage is the stage of encode lattice of radix r.
`define OUT_NUM_RADIX  $OUT_NUM_RADIX // radix of output number of DECS of one traceback action. It is equal U+OUT_STAGE_RADIX
`define OUT_STAGE   $OUT_STAGE    // 2^OUT_STAGE_RADIX

`define SLICE_NUM  $MAX_SLICE    //2^u
`define CODE_LEN  $CODE_LEN    // the length of the code source.
`define CODE_FILE  $CODE_FILE  // the file name of code source.
`define CLK_TIME  $CLK_TIME  // the cycle time of clock mclk

module testbench0;
reg code[`CODE_LEN-1:0];
reg mclk;
reg rst;
reg valid_in;
reg[`Bit_Width-1:0] ", join(", ", @SYMBOLS), ";
reg[`SYMBOLS_NUM-1:0] pattern;
integer i, j;

initial \$readmemb(\"$CODE_FILE\", code);
initial 
begin
   	mclk=1;
   	rst=0;
   	pattern=`SYMBOLS_NUM'b", 1x$para_symbol_num,";
//  valid_in=0;
   	# 50 rst=0;
   	# 5000.5 rst=1;
end

initial forever # `CLK_TIME mclk=~mclk;

always @(posedge mclk or negedge rst)
begin
    if(!rst)
    begin
        i=0;
        j=0;
        valid_in<=0;",
	prefix("\n\t", @SYMBOLS, "<=0;"),"
        pattern<=`SYMBOLS_NUM'b",1x$para_symbol_num, ";
    end
    else
    begin
        valid_in<=1;";
        for($i=0;$i<$para_symbol_num;$i++){ print 
	"\n\tif(code[i+$i]==1'b1)
		",$SYMBOLS[$i],"<=`Bit_Width'b", 1x$Bit_Width,";
	else
		",$SYMBOLS[$i],"<=`Bit_Width'b", 0 x$Bit_Width,";
	";
	} print "
	j=j+1;
        if(j==`SLICE_NUM)
        begin
            i=i+`SYMBOLS_NUM;
            j=0;
        end
        if(i==95*4*`SYMBOLS_NUM)
            \$finish;
    end
end

wire filo_out, valid_out;
            
decoder0 decoder0_0(.mclk(mclk), .rst(rst), .valid_in(valid_in), .", join(", .", party(@SYMBOLS, @SYMBOLS)), ", .pattern(pattern), .filo_out(filo_out), .valid_out(valid_out));
////////////////////////////////// test module //////////////////////////////////////////////////////////

integer f_filo_out, line;
initial
begin
line=0; 
f_filo_out=\$fopen(\"data/f_filo_out\");
end
always @(posedge mclk or negedge rst)
begin
    if(rst)     // high level is reset
    begin
        if(valid_out)
        begin
            \$fwrite(f_filo_out,",'"%b"',", {filo_out});
            if(line%4==3)
            begin
                \$fwrite(f_filo_out,",'"\n"',");
            end
            if(line%16==15)
            begin
                \$fwrite(f_filo_out,",'"\n"',");
            end
            line=line+1;
        end
    end
end
endmodule
";
}
1

