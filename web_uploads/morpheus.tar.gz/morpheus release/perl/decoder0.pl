################################################################################
# ################################################################################  
# #                                                                              #  
# # Viterbi HDL Code Generator                                                   #  
# # Copyright (C) 2004  Sheng Zhu                                                #  
# #                                                                              #  
# # This program is free software; you can redistribute it and/or                #  
# # modify it under the terms of the GNU General Public License                  #  
# # as published by the Free Software Foundation; either version 2               #  
# # of the License, or (at your option) any later version.                       #  
# #                                                                              #  
# # This program is distributed in the hope that it will be useful,              #  
# # but WITHOUT ANY WARRANTY; without even the implied warranty of               #  
# # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #  
# # GNU General Public License for more details.                                 #  
# #                                                                              #  
# # You should have received a copy of the GNU General Public License            #  
# # along with this program; if not, write to the Free Software                  #  
# # Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  #  
# #                                                                              #  
# # If you have any problem, please email to me: mike@opencores.org              #  
# #                                                                              #  
# ################################################################################
################################################################################

sub decoder0()
{
my ($i,$j, $reg_valid_in, @reg_symbols, $reg_pattern); 

my @text=("

`include \"$module_dir/glb_def.v\"

`define RAM_BYTE_WIDTH $RAM_BYTE_WIDTH
`define RAM_ADR_WIDTH $RAM_ADR_WIDTH 

module decoder0(mclk, rst, valid_in, ", join(", ", @SYMBOLS), ", pattern, filo_out, valid_out);
input mclk, rst, valid_in;
input[`Bit_Width-1:0] ", join(", ", @SYMBOLS), ";
input[`SYMBOLS_NUM-1:0] pattern;           //////////////////////////////////////////////
output filo_out, valid_out;

wire valid_decs;
wire[`V-1:0] ", join(", ", @DECS_TBU), ";
wire wr_en, rd_en, en_filo_in;
wire[`V-1:0] filo_in;
wire[`RAM_BYTE_WIDTH - 1:0] wr_data, rd_data;
wire[`RAM_ADR_WIDTH - 1:0] wr_adr, rd_adr;



vit2 vit2_0(.mclk(mclk), .rst(rst), .valid(valid_in), .", join(", .", party(@SYMBOLS, @SYMBOLS)), ", .pattern(pattern), .", join(", .", party(@DECS_TBU, @DECS_TBU)), ", .valid_decs(valid_decs));
trabacknew2 traback0(.clk(mclk), .rst(rst), .valid_in(valid_decs), .", join(", .", party(@DECS_TBU, @DECS_TBU)), ", .wr_en(wr_en), .wr_data(wr_data), .wr_adr(wr_adr), .rd_en(rd_en), .rd_data(rd_data), .rd_adr(rd_adr), .en_filo_in(en_filo_in), .filo_in(filo_in));
virtual_mem #($RAM_BYTE_WIDTH,$RAM_ADR_WIDTH) virtual_mem0(.clk(mclk), .rst(rst), .wr_data(wr_data), .wr_adr(wr_adr), .wr_en(wr_en), .rd_adr(rd_adr), .rd_en(rd_en), .rd_data(rd_data));
filo filo0(.clk(mclk), .rst(rst), .en_filo_in(en_filo_in), .filo_in(filo_in), .en_filo_out(1'b1), .filo_out(filo_out), .valid_out(valid_out));
`ifdef DEBUG
////////////// for debug ////////////////////////////////////
integer f_debug, line;
initial
begin
line=0; 
f_debug=\$fopen(\"data/f_debug\");
end
always @(posedge mclk or negedge rst)
begin
    if(rst)     // high level is reset
    begin
        if(valid_decs)
        begin
            \$fwrite(f_debug,", '"%b\n",',"{", join(", ", @DECS_TBU),"});
             line=line+1;
	     if(line%$MAX_SLICE\==0)
             begin
                 \$fwrite(f_debug,\"\\n\");
             end
//             if(line%16==15)
//             begin
//                 \$fwrite(f_debug,\"\\n\");
//             end
        end
    end
end
`endif
endmodule
");
print @text;
}
1
