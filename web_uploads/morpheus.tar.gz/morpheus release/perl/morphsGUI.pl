################################################################################
# ################################################################################  
# #                                                                              #  
# # Viterbi HDL Code Generator                                                   #  
# # Copyright (C) 2004  Sheng Zhu                                                #  
# #                                                                              #  
# # This program is free software; you can redistribute it and/or                #  
# # modify it under the terms of the GNU General Public License                  #  
# # as published by the Free Software Foundation; either version 2               #  
# # of the License, or (at your option) any later version.                       #  
# #                                                                              #  
# # This program is distributed in the hope that it will be useful,              #  
# # but WITHOUT ANY WARRANTY; without even the implied warranty of               #  
# # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #  
# # GNU General Public License for more details.                                 #  
# #                                                                              #  
# # You should have received a copy of the GNU General Public License            #  
# # along with this program; if not, write to the Free Software                  #  
# # Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  #  
# #                                                                              #  
# # If you have any problem, please email to me: mike@opencores.org              #  
# #                                                                              #  
# ################################################################################
################################################################################

#/usr/bin/perl -w
use 5.005; 
use Tk 8.0; 
use Tk::widgets qw/Dialog/; 
use strict;
use subs qw/init/;
use vars qw/$MW $VERSION/;

$MW = MainWindow->new;
init();
MainLoop();

sub creOpt {
	my ($frame, $label, $value)=@_;
	my ($Opt, $box, $text);
	$box = $frame->Frame->pack;
	$text = $box->Label(-text=>$label, -height=>1, -width=>10)->pack(-side=>'left');
	$Opt = $box->Entry(-textvariable=>$value)->pack(-after=>$text, -side=>'right');
	return $Opt;
}

sub init {
	my ($optFrame, $boxFrame);
	my ($opt_POLYS, $opt_V, $opt_B, $opt_OSR, $opt_TBL, $opt_RAW);
	my ($btn_OK, $btn_CLOSE);
	
	my $infoLabel = $MW->Label(-text=>"Viterbi decoder HDL codes generator: base on S.A.R.B(Same Address Write Back), PE(Process Element), TB(Trace Back).\n",-fg=>"blue")->pack;
	
	$optFrame = $MW->Frame->pack;
	$boxFrame = $MW->Frame->pack;
	my $licenseLabel = $MW->Label(-text=>"
All Right Reserved
	")->pack;
	my $def_opt_POLYS='91 121 101 91';
	my $def_opt_V = 1;
	my $def_opt_B = 3;
	my $def_opt_OSR = 4;
	my $def_opt_TBL = 32;
	my $def_opt_RAW = 10;
	 
	$opt_POLYS = creOpt($optFrame, "polys", \$def_opt_POLYS);
	$opt_V = creOpt($optFrame, "V", \$def_opt_V);
	$opt_B = creOpt($optFrame, "B", \$def_opt_B);
	$opt_OSR = creOpt($optFrame, "OSR", \$def_opt_OSR);
	$opt_TBL = creOpt($optFrame, "TBL", \$def_opt_TBL);
	$opt_RAW = creOpt($optFrame, "RAW", \$def_opt_RAW);
	
	my $text = $optFrame->Label(-text=>"
	POLYS is the generation words of convolution code.		
	V means using radix-2^V buttfly, only support V=1 now.		
	B means that we need 2^(B*V) cycles for decoder decoding one symbol.		
	OSR means that we send out 2^OSR*V symbols once trace back.		
	TBL means that the depth of trace back is TBL*V, TBL must be the multiple of 2^OSR.		
	RAW is the width of address of survivor path memory.		
	")->pack;
	
	$btn_OK = $boxFrame->Button(-text=>'~Ok', -height=>1, -width=>4, -command=>\&getOpt)->pack(-side=>"left");
	
	$btn_CLOSE = $boxFrame->Button(-text=>'~Close', -height=>1, -width=>4, -command=>sub{exit;})->pack(-side=>"right");
	
	sub getOpt {
		my ($POLYS, $V, $B, $OSR, $TBL, $RAW);
		
		$POLYS = $opt_POLYS->get;
		$V = $opt_V->get;
		$B = $opt_B->get;
		$OSR = $opt_OSR->get;
		$TBL = $opt_TBL->get;
		$RAW = $opt_RAW->get;
		
		my $dialog = $MW->Dialog(-title   => 'These parameters are as the following', 
                                -text    => "polys = '$POLYS'\nv = '$V'\nb = '$B'\nosr = '$OSR'\ntbl = '$TBL'\nraw = '$RAW'\nIs it all right?", 
                                -buttons => ['Yes, generate it!', 'No, wait next time'],
				-default_button => 'Generate it!', 
                                -bitmap  => 'question'); 
		my $answer = $dialog->Show(-global);
		my $result;
		print $answer;
		if($answer eq 'Yes, generate it!'){
			
			open RESULT, "perl perl/Oracle.pl -POLYS \"$POLYS\" -V $V -B $B -OSR $OSR -TBL $TBL -RAW $RAW |" or die;
			while (<RESULT>){
				$result = $_;
			}
			if($result==1){
				my $congDialog = $MW->Dialog(-title   => 'Congratulation!', 
					-text    => " The mission is complited, please see these files in module directory", 
					-buttons => ['Thanks'],
					-default_button => ['Thanks'], 
					-bitmap  => 'info'); 
				$congDialog->Show;
				return 0;
			}
			else {
				my $congDialog = $MW->Dialog(-title   => 'Mission failed!', 
					-text    => " Game Over\nplease check the error output", 
					-buttons => ['Thanks'],
					-default_button => ['Thanks'], 
					-bitmap  => 'info'); 
				$congDialog->Show;
				return 1;
			}
		}
		else {
			print "eeerroorr";
			return 1;
		}
	}
	1
}

