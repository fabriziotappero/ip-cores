#include <genlib.h>

main()

{
	DEF_LOFIG("cl");
	LOCON("cs", IN, "cs");
	LOCON("I[0:3]", IN, "I[0:3]");
	LOCON("ck", IN, "ck");
	LOCON("vdd", IN, "vdd");
	LOCON("vss", IN, "vss");
	LOCON("io", OUT, "io");
	LOCON("rw", OUT, "rw");
	LOCON("ag", OUT, "ag");
	LOCON("de", OUT, "de");
	LOCON("A[0:3]", OUT, "A[0:3]");

LOINS("n1_y", "inv1", "ck", "o_inv1", "vdd", "vss", 0);
LOINS("n1_y", "inv2", "cs", "o_inv2", "vdd", "vss", 0);

LOINS("p1_y", "buf0", "I[0]", "A[0]", "vdd", "vss", 0);
LOINS("p1_y", "buf1", "I[1]", "A[1]", "vdd", "vss", 0);
LOINS("p1_y", "buf2", "I[2]", "A[2]", "vdd", "vss", 0);
LOINS("p1_y", "buf3", "I[3]", "A[3]", "vdd", "vss", 0);

LOINS("a2_y", "and1", "o_inv1", "cs", "o_and1", "vdd", "vss",0);
LOINS("a2_y", "and2", "o_inv2", "ck", "o_and2", "vdd", "vss",0);
LOINS("a2_y", "and3", "ck", "cs", "o_and3", "vdd", "vss",0);

LOINS("o2_y", "or1", "o_and1", "o_and3", "io", "vdd", "vss", 0);
LOINS("o2_y", "or2", "o_and1", "o_and3", "rw", "vdd", "vss", 0);
LOINS("o2_y", "or3", "o_and2", "o_and3", "ag", "vdd", "vss", 0);
LOINS("o2_y", "or4", "o_and2", "o_and3", "de", "vdd", "vss", 0);

SAVE_LOFIG();
   exit(0); 
}
	 
