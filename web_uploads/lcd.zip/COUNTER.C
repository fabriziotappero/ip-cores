
#include <genlib.h>

main()
{
   DEF_LOFIG("counter");
   
   LOCON("E",                   IN, "E");
   LOCON("ck",                  IN, "ck");
   LOCON("res",                 IN, "res");
   LOCON("vdd",                 IN, "vdd"); 
   LOCON("vss",                 IN, "vss"); 
   LOCON("A[0:3]",             INOUT, "A[0:3]");
   LOCON("q_c",                 OUT, "q_c");

LOINS("a2_y","an00", "E","A[0]", "c_1", "vdd" ,"vss",0);
LOINS("a2_y","an01", "c_1","A[1]", "c_2", "vdd" ,"vss",0);
LOINS("a2_y","an02", "c_2","A[2]", "c_3", "vdd" ,"vss",0);
LOINS("a2_y","an03", "c_3","A[3]", "q_c", "vdd" ,"vss",0);

LOINS("xr2_y","xr00", "E","A[0]", "d_1", "vdd" ,"vss",0);
LOINS("xr2_y","xr01", "c_1","A[1]", "d_2", "vdd" ,"vss",0);
LOINS("xr2_y","xr02", "c_2","A[2]", "d_3", "vdd" ,"vss",0);
LOINS("xr2_y","xr03", "c_3","A[3]", "d_4", "vdd" ,"vss",0);


LOINS("dffres", "dff0", "d_1", "ck","res","A[0]","vdd","vss",0);
LOINS("dffres", "dff1", "d_2", "ck","res","A[1]","vdd","vss",0);
LOINS("dffres", "dff2", "d_3", "ck","res","A[2]","vdd","vss",0);
LOINS("dffres", "dff3", "d_4", "ck","res","A[3]","vdd","vss",0);


   SAVE_LOFIG();
   exit(0); 
}
