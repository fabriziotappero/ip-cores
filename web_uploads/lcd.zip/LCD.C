#include <genlib.h>

main()

{
	DEF_LOFIG("lcd");
	LOCON("E", IN, "E");
	LOCON("I[0:3]", IN, "I[0:3]");
	LOCON("cs", IN, "cs");
        LOCON("ck", IN, "ck");
	LOCON("vdd", IN, "vdd");
	LOCON("vss", IN, "vss");
	LOCON("res", IN, "res");
	LOCON("O[0:3]", OUT , "O[0:3]");
        LOCON("S[0:7]", OUT , "S[0:7]");
	LOCON("q_c",   OUT, "q_c");
        

LOINS("counter","coba","E","ck","res","A[0]","A[1]","A[2]","A[3]","q_c","vdd","vss",0); 
LOINS("decoder","dec","A[0]","A[1]","A[2]","A[3]","de","ck","res","C[0]","C[1]","C[2]","C[3]", "C[4]","C[5]","C[6]", "C[7]", "C[8]","C[9]", "C[10]","C[11]","C[12]","C[13]","C[14]", "C[15]","vdd","vss",0);  
LOINS("ram","mem","io","rw","C[0]","C[1]","C[2]","C[3]","C[4]","C[5]","C[6]","C[7]","C[8]","C[9]","C[10]","C[11]","C[12]","C[13]","C[14]","C[15]","res","S[0]","S[1]","S[2]","S[3]","S[4]","S[5]","S[6]","S[7]","vdd","vss",0);   
LOINS("decoder", "address","I[0]","I[1]","I[2]","I[3]","ag","ck","res","C[0]","C[1]","C[2]","C[3]","C[4]","C[5]","C[6]","C[7]","C[8]","C[9]","C[10]","C[11]","C[12]","C[13]","C[14]","C[15]","vdd","vss", 0);   LOINS("cl","colo","I[0]","I[1]","I[2]","I[3]","ck","cs","io","rw","ag","de","O[0]","O[1]","O[2]","O[3]","vdd","vss",0);

SAVE_LOFIG();
    exit(0);
}
