#include <genlib.h>

main()
{
	DEF_LOFIG("decoder");
	LOCON("A[0:3]", IN,	"A[0:3]");
	LOCON("en",	IN,	"en");
	LOCON("ck",	IN,	"ck");
   	LOCON("res",	IN, 	"res");
   	LOCON("vdd",	IN,	"vdd"); 
   	LOCON("vss",	IN, 	"vss"); 
	LOCON("C[0:15]",OUT,	"C[0:15]");

    
LOINS("n1_y", "inv0", "A[0]", "o_inv0", "vdd", "vss",0);
LOINS("n1_y", "inv1", "A[1]", "o_inv1", "vdd", "vss",0);
LOINS("n1_y", "inv2", "A[2]", "o_inv2", "vdd", "vss",0);
LOINS("n1_y", "inv3", "A[3]", "o_inv3", "vdd", "vss",0);

LOINS("a4_y", "0an0", "o_inv3", "o_inv2", "o_inv1","o_inv0","o_0an0","vdd","vss", 0); 
LOINS("a2_y", "0an1", "en", "o_0an0","C[0]", "vdd", "vss", 0);

LOINS("a4_y", "1an0", "o_inv3", "o_inv2", "o_inv1","A[0]","o_1an0","vdd","vss", 0); 
LOINS("a2_y", "1an1", "en", "o_1an0","C[1]", "vdd", "vss", 0);

LOINS("a4_y", "2an0", "o_inv3", "o_inv2", "A[1]","o_inv0","o_2an0","vdd","vss", 0);  
LOINS("a2_y", "2an1", "en","o_2an0","C[2]", "vdd", "vss", 0);

LOINS("a4_y", "3an0", "o_inv3", "o_inv2","A[1]","A[0]","O_3an0","vdd","vss",0); 
LOINS("a2_y", "3an1", "en","o_3an0","C[3]", "vdd", "vss", 0);

LOINS("a4_y", "4an0", "o_inv3","A[2]","o_inv1","o_inv0","o_4an0","vdd","vss",0);  
LOINS("a2_y", "4an1", "en","o_4an0","C[4]", "vdd", "vss", 0);

LOINS("a4_y", "5an0", "o_inv3", "A[2]","o_inv1","A[0]","o_5an0","vdd","vss",0);   
LOINS("a2_y", "5an1", "en","o_5an0","C[5]", "vdd", "vss", 0);

LOINS("a4_y", "6an0", "o_inv3", "A[2]","A[1]","o_inv0","o_6an0","vdd","vss",0);  
LOINS("a2_y", "6an1", "en","o_6an0","C[6]", "vdd", "vss", 0);

LOINS("a4_y", "7an0", "o_inv3", "A[2]","A[1]","A[0]","o_7an0","vdd","vss", 0);
LOINS("a2_y", "7an1", "en","o_7an0","C[7]", "vdd", "vss", 0);

LOINS("a4_y", "8an0", "A[3]","o_inv2","o_inv1","o_inv0","o_8an0","vdd","vss", 0); 
LOINS("a2_y", "8an1","en","o_8an0","C[8]", "vdd", "vss", 0);

LOINS("a4_y", "9an0", "A[3]", "o_inv2","o_inv1","A[0]","o_9an0","vdd","vss",0);  
LOINS("a2_y", "9an1", "en","o_9an0","C[9]", "vdd", "vss", 0);

LOINS("a4_y", "10an0", "A[3]","o_inv2","A[1]","o_inv0","o_10an0","vdd","vss", 0);  
LOINS("a2_y", "10an1","en", "o_10an0","C[10]", "vdd", "vss", 0);

LOINS("a4_y", "11an0", "A[3]", "o_inv2","A[1]","A[0]","o_11an0","vdd","vss",0); 
LOINS("a2_y", "11an1", "en","o_11an0","C[11]", "vdd", "vss", 0);

LOINS("a4_y", "12an0", "A[3]", "A[2]","o_inv1","o_inv0","o_12an0","vdd","vss",0);  
LOINS("a2_y", "12an1", "en","o_12an0","C[12]", "vdd", "vss", 0);

LOINS("a4_y", "13an0", "A[3]", "A[2]","o_inv1","A[0]","o_13an0","vdd","vss",0);
LOINS("a2_y", "13an1", "en","o_13an0","C[13]", "vdd", "vss", 0);

LOINS("a4_y", "14an0", "A[3]", "A[2]","A[1]","o_inv0","o_14an0","vdd","vss",0);
LOINS("a2_y", "14an1", "en","o_14an0","C[14]", "vdd", "vss", 0);

LOINS("a4_y", "15an0", "A[3]", "A[2]","A[1]","A[0]","o_15an0","vdd","vss",0);
LOINS("a2_y", "15an1", "en","o_15an0","C[15]", "vdd", "vss", 0);

SAVE_LOFIG();
   exit(0); 
}

