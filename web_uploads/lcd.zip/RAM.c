    
#include <genlib.h>

main()
{
   DEF_LOFIG("RAM");
   LOCON("RWS",     IN,  "RWS"    );  
   LOCON("CS",     IN,  "CS"    ); 
   LOCON("res",   IN,  "res"   );  
   LOCON("C[0:15]", IN,  "C[0:15]"   ); 
   LOCON("IO0", INOUT, "IO0"); 
   LOCON("IO1", INOUT, "IO1"); 
   LOCON("IO2", INOUT, "IO2"); 
   LOCON("IO3", INOUT, "IO3"); 
   LOCON("IO4", INOUT, "IO4"); 
   LOCON("IO5", INOUT, "IO5"); 
   LOCON("IO6", INOUT, "IO6"); 
   LOCON("IO7", INOUT, "IO7"); 
   LOCON("vdd",      IN,  "vdd"   );  
   LOCON("vss",      IN,  "vss"   );  

LOINS("a2_y", "and1", "RWS", "CS", "wren", "vdd", "vss",0);      

/*buffer 7-0 input (write) */
LOINS("p1_y","bufi7","IO7","in7","vdd","vss", 0);
LOINS("p1_y","bufi6","IO6","in6","vdd","vss", 0);
LOINS("p1_y","bufi5","IO5","in5","vdd","vss", 0);
LOINS("p1_y","bufi4","IO4","in4","vdd","vss", 0);
LOINS("p1_y","bufi3","IO3","in3","vdd","vss", 0);
LOINS("p1_y","bufi2","IO2","in2","vdd","vss", 0);
LOINS("p1_y","bufi1","IO1","in1","vdd","vss", 0);
LOINS("p1_y","bufi0","IO0","in0","vdd","vss", 0);

LOINS("mc", "mc07", "C[0]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc06", "C[0]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc05", "C[0]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc04", "C[0]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc03", "C[0]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc02", "C[0]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc01", "C[0]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc00", "C[0]", "wren", "in0","res", "q0", "vdd", "vss",0);   
          
LOINS("mc", "mc17", "C[1]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc16", "C[1]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc15", "C[1]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc14", "C[1]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc13", "C[1]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc12", "C[1]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc11", "C[1]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc10", "C[1]", "wren", "in0","res", "q0", "vdd", "vss",0);   

LOINS("mc", "mc27", "C[2]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc26", "C[2]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc25", "C[2]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc24", "C[2]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc23", "C[2]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc22", "C[2]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc21", "C[2]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc20", "C[2]", "wren", "in0","res", "q0", "vdd", "vss",0);

LOINS("mc", "mc37", "C[3]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc36", "C[3]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc35", "C[3]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc34", "C[3]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc33", "C[3]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc32", "C[3]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc31", "C[3]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc30", "C[3]", "wren", "in0","res", "q0", "vdd", "vss",0);

LOINS("mc", "mc47", "C[4]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc46", "C[4]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc45", "C[4]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc44", "C[4]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc43", "C[4]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc42", "C[4]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc41", "C[4]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc40", "C[4]", "wren", "in0","res", "q0", "vdd", "vss",0);

LOINS("mc", "mc57", "C[5]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc56", "C[5]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc55", "C[5]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc54", "C[5]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc53", "C[5]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc52", "C[5]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc51", "C[5]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc50", "C[5]", "wren", "in0","res", "q0", "vdd", "vss",0);   

LOINS("mc", "mc67", "C[6]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc66", "C[6]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc65", "C[6]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc64", "C[6]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc63", "C[6]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc62", "C[6]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc61", "C[6]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc60", "C[6]", "wren", "in0","res", "q0", "vdd", "vss",0);      
     
LOINS("mc", "mc77", "C[7]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc76", "C[7]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc75", "C[7]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc74", "C[7]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc73", "C[7]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc72", "C[7]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc71", "C[7]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc70", "C[7]", "wren", "in0","res", "q0", "vdd", "vss",0);      

LOINS("mc", "mc87", "C[8]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc86", "C[8]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc85", "C[8]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc84", "C[8]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc83", "C[8]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc82", "C[8]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc81", "C[8]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc80", "C[8]", "wren", "in0","res", "q0", "vdd", "vss",0);      

LOINS("mc", "mc97", "C[9]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc96", "C[9]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc95", "C[9]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc94", "C[9]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc93", "C[9]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc92", "C[9]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc91", "C[9]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc90", "C[9]", "wren", "in0","res", "q0", "vdd", "vss",0);      
                      
LOINS("mc", "mc107", "C[10]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc106", "C[10]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc105", "C[10]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc104", "C[10]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc103", "C[10]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc102", "C[10]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc101", "C[10]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc100", "C[10]", "wren", "in0","res", "q0", "vdd", "vss",0);   
      
LOINS("mc", "mc117", "C[11]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc116", "C[11]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc115", "C[11]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc114", "C[11]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc113", "C[11]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc112", "C[11]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc111", "C[11]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc110", "C[11]", "wren", "in0","res", "q0", "vdd", "vss",0);   
          
LOINS("mc", "mc127", "C[12]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc126", "C[12]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc125", "C[12]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc124", "C[12]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc123", "C[12]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc122", "C[12]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc121", "C[12]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc120", "C[12]", "wren", "in0","res", "q0", "vdd", "vss",0);   
          
LOINS("mc", "mc137", "C[13]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc136", "C[13]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc135", "C[13]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc134", "C[13]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc133", "C[13]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc132", "C[13]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc131", "C[13]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc130", "C[13]", "wren", "in0","res", "q0", "vdd", "vss",0);   
          
LOINS("mc", "mc147", "C[14]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc146", "C[14]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc145", "C[14]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc144", "C[14]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc143", "C[14]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc142", "C[14]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc141", "C[14]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc140", "C[14]", "wren", "in0","res", "q0", "vdd", "vss",0);   
          
LOINS("mc", "mc157", "C[15]", "wren", "in7","res", "q7", "vdd", "vss",0);   
LOINS("mc", "mc156", "C[15]", "wren", "in6","res", "q6", "vdd", "vss",0);   
LOINS("mc", "mc155", "C[15]", "wren", "in5","res", "q5", "vdd", "vss",0);   
LOINS("mc", "mc154", "C[15]", "wren", "in4","res", "q4", "vdd", "vss",0);   
LOINS("mc", "mc153", "C[15]", "wren", "in3","res", "q3", "vdd", "vss",0);   
LOINS("mc", "mc152", "C[15]", "wren", "in2","res", "q2", "vdd", "vss",0);   
LOINS("mc", "mc151", "C[15]", "wren", "in1","res", "q1", "vdd", "vss",0);   
LOINS("mc", "mc150", "C[15]", "wren", "in0","res", "q0", "vdd", "vss",0);   
     
/*buffer 7 - 0 untuk out (read) */
LOINS("p1_y","bufo7","q7","IO7","vdd","vss", 0);
LOINS("p1_y","bufo6","q6","IO6","vdd","vss", 0);
LOINS("p1_y","bufo5","q5","IO5","vdd","vss", 0);
LOINS("p1_y","bufo4","q4","IO4","vdd","vss", 0);
LOINS("p1_y","bufo3","q3","IO3","vdd","vss", 0);
LOINS("p1_y","bufo2","q2","IO2","vdd","vss", 0);
LOINS("p1_y","bufo1","q1","IO1","vdd","vss", 0);
LOINS("p1_y","bufo0","q0","IO0","vdd","vss", 0);


   SAVE_LOFIG();
   exit(0); 
}       
  
   
