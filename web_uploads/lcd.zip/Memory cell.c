#include <genlib.h>

main()
{
   DEF_LOFIG("mc");
   LOCON("x",     IN,  "x"    );  
   LOCON("res",   IN,  "res"   );  
   LOCON("rowsel", IN,  "rowsel"   ); 
   LOCON("wren", IN,  "wren"   ); 
   LOCON("y", OUT, "y"); 
   LOCON("vdd",      IN,  "vdd"   );  
   LOCON("vss",      IN,  "vss"   );  

LOINS("a2_y", "and1", "rowsel", "wren", "c", "vdd", "vss",0);            
LOINS("dffres", "dff", "x", "c", "res", "q", "vdd", "vss",0);   
LOINS("p1_y", "buf", "q",  "y", "vdd", "vss", 0);           

   SAVE_LOFIG();
   exit(0); 
}  
   
   
